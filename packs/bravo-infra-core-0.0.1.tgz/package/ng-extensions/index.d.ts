import { BrSafeAny, DataTypeEnum } from '@bravo-infra/core/definition';
import * as _angular_core from '@angular/core';
import { EffectCleanupRegisterFn, CreateEffectOptions, EffectRef, Injector, ProviderToken, DestroyRef, Type, InjectionToken, Optional, Self, SkipSelf, Host, Provider, EnvironmentProviders, InjectOptions, Signal, WritableSignal } from '@angular/core';
import * as rxjs from 'rxjs';
import { Observable, ReplaySubject, Subject, ObservableInput, OperatorFunction, Subscribable } from 'rxjs';
import { NavigationExtras, Params } from '@angular/router';
import { ToSignalOptions, ToObservableOptions } from '@angular/core/rxjs-interop';
import { ValidatorFn } from '@angular/forms';

/**
 * Options for the InputSetter decorator.
 */
interface IInputTransformOptions {
    /**
     * A transform function that will be executed every time the property is set.
     *
     * @param {BrSafeAny} value - The value being assigned to the property.
     * @param {BrSafeAny} [enumType] - Optional enum type or additional data to help with transformation.
     * @returns {BrSafeAny} - The transformed value that will actually be stored.
     *
     * @example
     * // Example: Convert string input to number
     * const options = {
     *   transform: (value) => Number(value)
     * };
     */
    transform: (value: BrSafeAny, enumType?: BrSafeAny) => BrSafeAny;
    /**
     * Optional enum type or reference object that can be passed into the transform function.
     */
    enumType?: BrSafeAny;
}
/**
 * A property decorator factory that intercepts property assignments
 * and applies a transformation function before setting the value.
 *
 * This is useful for:
 * - Enum parsing
 * - Input sanitization
 * - Type conversion (e.g. string → number)
 * - Applying normalization logic whenever a property is updated
 *
 * @param {IInputTransformOptions} pOptions - The configuration options containing the transformation logic.
 * @returns {PropertyDecorator} - A decorator that transforms property assignments.
 *
 * @example
 * import { InputSetter } from './InputSetter';
 * import { BravoEnumExtensions } from './BravoEnumExtensions';
 *
 * enum Permission { Read = 1, Write = 2, Execute = 4 }
 *
 * class UserPermissions {
 *   private _permissions: number = 0;
    @InputSetter({ transform: enumAttribute, enumType: Permission })
 *   set permissions(value: number) {
 *     this._permissions = value;
 *   }
 *   get permissions(): number {
 *     return this._permissions;
 *   }
 * }
 *
 * const user = new UserPermissions();
 * user.permissions = 'Read | Write';
 * console.log(user.permissions); // 3
 */
declare function InputSetter(pOptions: IInputTransformOptions): (pTarget: Object, pPropertyKey: string | symbol, pDescriptor: TypedPropertyDescriptor<BrSafeAny>) => TypedPropertyDescriptor<any>;

/**
 * A property decorator that intercepts the setter and automatically normalizes
 * the incoming format string based on the given format type.
 *
 * This avoids manually calling ensureFormat() inside every setter.
 *
 * @param {DataTypeEnum} pType - The format type to apply normalization for.
 * @returns {MethodDecorator} - A decorator that transforms the value before it reaches the setter.
 *
 * @example
 * readonly #format = signal(BravoAppSettings.settings.dateFormat);
 *
 * @Input()
 * @InputEnsureFormat(BravoFormatType.Date)
 * public get format() {
 *     return this.#format();
 * }
 * public set format(pValue: string) {
 *     this.#format.set(pValue); // pValue is already normalized
 * }
 */
declare function EnsureFormat(pType: DataTypeEnum): (pTarget: Object, pPropertyKey: string | symbol, pDescriptor: TypedPropertyDescriptor<BrSafeAny>) => TypedPropertyDescriptor<any>;

declare function effectOnceIf<T = unknown>(pConditionCallback: () => T, pExecutionCallback: (valueFromCondition: NonNullable<T>, onCleanup: EffectCleanupRegisterFn) => void, pOptions?: Omit<CreateEffectOptions, 'allowSignalWrites' | 'manualCleanup'>): EffectRef;
type EffectOnceIfConditionFn<T> = Parameters<typeof effectOnceIf<T>>[0];
type EffectOnceIfExecutionFn<T> = Parameters<typeof effectOnceIf<T>>[1];
type EffectOnceIfOptions<T> = Parameters<typeof effectOnceIf<T>>[2];

/**
 * We want to have the Tuple in order to use the types in the function signature
 */
type ExplicitEffectValues<T> = {
    [K in keyof T]: () => T[K];
};
/**
 * Extend the regular set of effect options
 */
declare interface ICreateExplicitEffectOptions extends CreateEffectOptions {
    /**
     * Option that allows the computation not to execute immediately, but only run on first change.
     */
    defer?: boolean;
}
/**
 * This explicit effect function will take the dependencies and the function to run when the dependencies change.
 * const count = signal(0);
 * const state = signal('idle');
 *
 * explicitEffect([count, state], ([count, state], cleanup) => {
 *   console.log('count updated', count, state);
 *
 *   cleanup(() => {
 *     console.log('cleanup');
 *   });
 * });
 * ```
 *
 * @param pDeps - The dependencies that the effect will run on
 * @param pCallback - The function to run when the dependencies change
 * @param pOptions - The options for the effect with the addition of defer (it allows the computation to run on first change, not immediately)
 */
declare function explicitEffect<Input extends readonly unknown[], Params = Input>(pDeps: readonly [...ExplicitEffectValues<Input>], pCallback: (deps: Params, onCleanup: EffectCleanupRegisterFn) => void, pOptions?: ICreateExplicitEffectOptions | undefined): EffectRef;

/**
 * Creates an auto-wired `Effect` using the current injection context.
 *
 * Useful when working in places without an implicit injection context
 * (e.g. `ngOnInit`, `afterNextRender`).
 *
 * @returns A function that registers an Angular `effect`.
 *
 * @example
 * ```ts
 * @Component()
 * export class MyComponent {
 *   @Input({ required: true }) data!: Signal<Data>;
 *
 *   private autoEffect = injectAutoEffect();
 *
 *   constructor() {
 *     // Not safe: input not initialized yet
 *     effect(() => {
 *       console.log(this.data());
 *     });
 *   }
 *
 *   ngOnInit() {
 *     //Safe: input is available
 *     this.autoEffect(() => {
 *       console.log(this.data());
 *     });
 *   }
 * }
 * ```
 */
declare function injectAutoEffect(pInjector?: Injector): (pAutoEffectCallback: (autoEffectInjector: Injector) => void | (() => void), pOptions?: Omit<CreateEffectOptions, "injector">) => _angular_core.EffectRef;

/**
 * Lazy import type that includes default and normal imports
 */
type LazyImportLoaderFn<T> = () => Promise<ProviderToken<T>> | Promise<{
    default: ProviderToken<T>;
}>;

type DefaultValueOptions<DefaultValueT> = {
    /**
     * The default value to use
     */
    defaultValue?: DefaultValueT;
};

/**
 * The optional "custom" Injector. If this is not provided, will be retrieved from the current injection context
 */

type InjectorOptions = {
    injector?: Injector;
};

type ParseOptions<ReadT, WriteT> = {
    /**
     * A function to convert the written value to the expected read value.
     *
     * @param v - The value to parse.
     * @returns The parsed value.
     */
    parse?: (v: WriteT) => ReadT;
};

/**
 * Loads a service lazily. The service is loaded when the observable is subscribed to.
 *
 * @param pLoaderCallback A function that returns a promise of the service to load.
 * @param pInjector The injector to use to load the service. If not provided, the current injector is used.
 * @returns An observable of the service.
 *
 * @example
 * ```ts
 * const dataService$ = injectLazy(() => import('./data-service').then((m) => m.MyService));
 * or
 * const dataService$ = injectLazy(() => import('./data-service'));
 * ```
 */
declare function injectLazy<T>(pLoaderCallback: LazyImportLoaderFn<T>, pInjector?: Injector): Observable<T>;

declare function injectActiveElement(pInjector?: Injector): rxjs.Observable<Element | null>;

/**
 * `assertInjector` extends `assertInInjectionContext` with an optional `Injector`
 * After assertion, `assertInjector` runs the `runner` function with the guaranteed `Injector`
 * whether it is the default `Injector` within the current **Injection Context**
 * or the custom `Injector` that was passed in.
 *
 * @template {() => any} Runner - Runner is a function that can return anything
 * @param {Function} pFn - the Function to pass in `assertInInjectionContext`
 * @param {Injector | undefined | null} pInjector - the optional "custom" Injector
 * @param {Runner} pRunner - the runner fn
 * @returns {ReturnType<Runner>} result - returns the result of the Runner
 *
 * @example
 * ```ts
 * function injectValue(injector?: Injector) {
 *  return assertInjector(injectValue, injector, () => 'value');
 * }
 *
 * injectValue(); // string
 * ```
 */
declare function assertInjector<Runner extends () => BrSafeAny>(pFn: Function, pInjector: Injector | undefined | null, pRunner: Runner): ReturnType<Runner>;
/**
 * `assertInjector` extends `assertInInjectionContext` with an optional `Injector`
 * After assertion, `assertInjector` returns a guaranteed `Injector` whether it is the default `Injector`
 * within the current **Injection Context** or the custom `Injector` that was passed in.
 *
 * @param {Function} pCallback - the Function to pass in `assertInInjectionContext`
 * @param {Injector | undefined | null} pInjector - the optional "custom" Injector
 * @returns Injector
 *
 * @example
 * ```ts
 * function injectDestroy(injector?: Injector) {
 *  injector = assertInjector(injectDestroy, injector);
 *
 *  return runInInjectionContext(injector, () => {
 *    // code
 *  })
 * }
 * ```
 */
declare function assertInjector(pCallback: Function, pInjector: Injector | undefined | null): Injector;

/**
 * Injects the `DestroyRef` service and returns a `ReplaySubject` that emits
 * when the component is destroyed.
 *
 * @throws {Error} If no `DestroyRef` is found.
 * @returns {ReplaySubject<void>} A `ReplaySubject` that emits when the component is destroyed.
 *
 * @example
 * // In your component:
 * export class MyComponent {
 *   #destroy$ = injectDestroy();
 *
 *   getData() {
 *     return this.service.getData()
 *       .pipe(takeUntil(this.#destroy$))
 *       .subscribe(data => { ... });
 *   }
 * }
 */
declare const injectDestroy: (pInjector?: Injector) => ReplaySubject<void> & {
    onDestroy: DestroyRef["onDestroy"];
};

interface IInjectIsIntersectingOptions {
    injector?: Injector;
    element?: Element;
}
/**
 * Injects an observable that emits whenever the element is intersecting the viewport.
 * The observable will complete when the element is destroyed.
 * @param options
 *
 * @example
 * export class MyComponent {
 *   private destroyRef = inject(DestroyRef);
 *
 *   isIntersecting$ = injectIsIntersecting();
 *   isInViewport$ = this.isIntersecting$.pipe(
 *     filter(x => x.intersectionRatio > 0),
 *     take(1),
 *   );
 *
 *   ngOnInit() {
 *     this.getData().subscribe();
 *   }
 *
 *   getData() {
 *     // Only fetch data when the element is in the viewport
 *     return this.isInViewport$.pipe(
 *       switchMap(() => this.service.getData()),
 *       takeUntil(this.destroy$)
 *     );
 *   }
 * }
 */
declare const injectIsIntersecting: ({ injector, element }?: IInjectIsIntersectingOptions) => Subject<IntersectionObserverEntry>;
declare class IsInViewportService implements IIsInViewportServiceInterface {
    observerListeners: Map<Element, Subject<IntersectionObserverEntry>>;
    observer?: IntersectionObserver;
    createObserver(): void;
    observe(pElement: Element): Subject<IntersectionObserverEntry>;
    unobserve(pElement: Element): void;
    intersect(pElement: Element, pEntry: IntersectionObserverEntry): void;
    disconnect(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<IsInViewportService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<IsInViewportService>;
}
interface IIsInViewportServiceInterface {
    observe(element: Element): Subject<IntersectionObserverEntry>;
    unobserve(element: Element): void;
    intersect(element: Element, entry: IntersectionObserverEntry): void;
}

type CreateInjectionTokenDep<TTokenType> = Type<TTokenType> | (abstract new (...args: BrSafeAny[]) => TTokenType) | InjectionToken<TTokenType>;
type CreateInjectionTokenDeps<TFactory extends (...args: BrSafeAny[]) => BrSafeAny, TFactoryDeps extends Parameters<TFactory> = Parameters<TFactory>> = {
    [Index in keyof TFactoryDeps]: CreateInjectionTokenDep<TFactoryDeps[Index]> | [...modifiers: Array<Optional | Self | SkipSelf | Host>, token: CreateInjectionTokenDep<TFactoryDeps[Index]>];
} & {
    length: TFactoryDeps['length'];
};
type CreateInjectionTokenOptions<TFactory extends (...args: BrSafeAny[]) => BrSafeAny, TFactoryDeps extends Parameters<TFactory> = Parameters<TFactory>> = (TFactoryDeps[0] extends undefined ? {
    deps?: never;
} : {
    deps: CreateInjectionTokenDeps<TFactory, TFactoryDeps>;
}) & {
    isRoot?: boolean;
    isFunctionValue?: boolean;
    multi?: boolean;
    token?: InjectionToken<ReturnType<TFactory>>;
    extraProviders?: Provider | EnvironmentProviders;
};
type InjectFn<TFactoryReturn> = {
    (): TFactoryReturn;
    (injectOptions: InjectOptions & {
        optional?: false;
    } & {
        injector?: Injector;
    }): TFactoryReturn;
    (injectOptions: InjectOptions & {
        injector?: Injector;
    }): TFactoryReturn | null;
};
type ProvideFn<TNoop extends boolean, TFactoryReturn, TReturn = TFactoryReturn extends Array<infer Item> ? Item : TFactoryReturn> = (TNoop extends true ? (value: TReturn | (() => TReturn)) => Provider : () => Provider) & (TReturn extends Function ? (value: TReturn | (() => TReturn), isFunctionValue: boolean) => Provider : (value: TReturn | (() => TReturn)) => Provider);
type CreateInjectionTokenReturn<TFactoryReturn, TNoop extends boolean = false> = [
    InjectFn<TFactoryReturn>,
    ProvideFn<TNoop, TFactoryReturn>,
    InjectionToken<TFactoryReturn>,
    () => Provider
];
/**
 * `createInjectionToken` accepts a factory function and returns a tuple of `injectFn`, `provideFn`, and the `InjectionToken`
 * that the factory function is for.
 *
 * @param {Function} pFactoryCallback - Factory Function that returns the value for the `InjectionToken`
 * @param {CreateInjectionTokenOptions} pOptions - object to control how the `InjectionToken` behaves
 * @returns {CreateInjectionTokenReturn}
 *
 * @example
 * ```ts
 * const [injectCounter, provideCounter, COUNTER] = createInjectionToken(() => signal(0));
 *
 * export class Counter {
 *  counter = injectCounter(); // WritableSignal<number>
 * }
 * ```
 */
declare function createInjectionToken<TFactory extends (...args: BrSafeAny[]) => BrSafeAny, TFactoryDeps extends Parameters<TFactory> = Parameters<TFactory>, TOptions extends CreateInjectionTokenOptions<TFactory, TFactoryDeps> = CreateInjectionTokenOptions<TFactory, TFactoryDeps>, TFactoryReturn = TOptions['multi'] extends true ? Array<ReturnType<TFactory>> : ReturnType<TFactory>>(pFactoryCallback: TFactory, pOptions?: TOptions): CreateInjectionTokenReturn<TFactoryReturn>;
declare function createNoopInjectionToken<TValue, TMulti extends boolean = false, TOptions = Pick<CreateInjectionTokenOptions<() => void, []>, 'extraProviders'> & (TValue extends (...args: BrSafeAny[]) => BrSafeAny ? {
    isFunctionValue: true;
} : {
    isFunctionValue?: never;
}) & (TMulti extends true ? {
    multi: true;
} : {
    multi?: never;
})>(pDescription: string, pOptions?: TOptions): CreateInjectionTokenReturn<TMulti extends true ? TValue[] : TValue, true>;

/**
 * Returns a signal that emits the previous value of the given signal.
 * The first time the signal is emitted, the previous value will be the same as the current value.
 *
 * @example
 * ```ts
 * const value = signal(0);
 * const previous = computedPrevious(value);
 *
 * effect(() => {
 *  console.log('Current value:', value());
 *  console.log('Previous value:', previous());
 * });
 *
 * Logs:
 * // Current value: 0
 * // Previous value: 0
 *
 * value.set(1);
 *
 * Logs:
 * // Current value: 1
 * // Previous value: 0
 *
 * value.set(2);
 *
 * Logs:
 * // Current value: 2
 * // Previous value: 1
 *```
 *
 * @param pSource Signal to compute previous value for
 * @returns Signal that emits previous value of `s`
 */
declare function computedPrevious<T>(pSource: Signal<T>): Signal<T>;

/**
 * Creates a signal notifier that can be used to notify effects or other consumers.
 *
 * @returns A notifier object.
 */
declare function createNotifier(): {
    notify: () => void;
    listen: _angular_core.Signal<number>;
};

type ObservableSignalInput$1<T> = ObservableInput<T> | Signal<T>;
type DerivedFromOptions<T> = {
    readonly injector?: Injector;
    readonly initialValue?: T | null;
};
type InferObservableSignalOutput<I> = {
    [K in keyof I]: I[K] extends Signal<infer S> ? S : I[K] extends ObservableInput<infer O> ? O : never;
};
/**
 * So that we can have `fn([Observable<A>, Signal<B>]): Observable<[A, B]>`
 */
type ObservableSignalInputTuple$1<T> = {
    [K in keyof T]: ObservableSignalInput$1<T[K]> | (() => T[K]);
};
declare function derivedFrom<Input extends readonly unknown[], Output = Input>(pSources: readonly [...ObservableSignalInputTuple$1<Input>], pOperator?: OperatorFunction<Input, Output>, pOptions?: DerivedFromOptions<Output>): Signal<Output>;
declare function derivedFrom<Input extends readonly unknown[], Output = Input>(pSources: readonly [...ObservableSignalInputTuple$1<Input>], pOptions?: DerivedFromOptions<Input>): Signal<Output>;
declare function derivedFrom<Input extends object, Output = Input>(pSources: ObservableSignalInputTuple$1<Input>, pOperatorCallback?: OperatorFunction<Input, Output>, pOptions?: DerivedFromOptions<Output>): Signal<Output>;
declare function derivedFrom<Input extends object, Output = Input>(pSources: ObservableSignalInputTuple$1<Input>, pOptions?: DerivedFromOptions<Input>): Signal<Output>;

declare function lazyInject<T extends object>(pToken: ProviderToken<T>): T;

type ObservableSignalInput<T> = ObservableInput<T> | Signal<T>;
/**
 * So that we can have `fn([Observable<A>, Signal<B>]): Observable<[A, B]>`
 */
type ObservableSignalInputTuple<T> = {
    [K in keyof T]: ObservableSignalInput<T[K]>;
};
type MergeFromOptions<T> = {
    readonly injector?: Injector;
    readonly initialValue?: T | null;
};
declare function mergeFrom<Inputs extends readonly unknown[], Output = Inputs[number]>(pInputs: readonly [...ObservableSignalInputTuple<Inputs>], pOperator?: OperatorFunction<Inputs[number], Output>, pOptions?: MergeFromOptions<Output>): Signal<Output>;
declare function mergeFrom<Inputs extends readonly unknown[], Output = Inputs[number]>(pInputs: readonly [...ObservableSignalInputTuple<Inputs>], pOptions?: MergeFromOptions<Output>): Signal<Output>;

type ResizeOptions = {
    box: ResizeObserverBoxOptions;
    debounce: number | {
        scroll: number;
        resize: number;
    };
    scroll: boolean;
    offsetSize: boolean;
    emitInitialResult: boolean;
};
declare const defaultResizeOptions: ResizeOptions;
declare const injectResizeOptions: {
    (): ResizeOptions;
    (injectOptions: _angular_core.InjectOptions & {
        optional?: false;
    } & {
        injector?: _angular_core.Injector;
    }): ResizeOptions;
    (injectOptions: _angular_core.InjectOptions & {
        injector?: _angular_core.Injector;
    }): ResizeOptions | null;
};
declare const provideResizeOptions: (() => _angular_core.Provider) & ((value: ResizeOptions | (() => ResizeOptions)) => _angular_core.Provider);
declare const RESIZE_OPTIONS: _angular_core.InjectionToken<ResizeOptions>;
type ResizeResult = {
    readonly entries: ReadonlyArray<ResizeObserverEntry>;
    readonly x: number;
    readonly y: number;
    readonly width: number;
    readonly height: number;
    readonly top: number;
    readonly right: number;
    readonly bottom: number;
    readonly left: number;
    readonly dpr: number;
};
declare function createResizeStream({ debounce, scroll, offsetSize, box, emitInitialResult }: ResizeOptions, pNativeElement: HTMLElement, pDocument: Document): Observable<ResizeResult>;
declare function calculateResult(pNativeElement: HTMLElement, pWindow: Window, pOffsetSize: boolean, pEntries: ResizeObserverEntry[]): [ResizeResult, Omit<DOMRect, 'toJSON'>];
declare function findScrollContainers(pElement: HTMLOrSVGElement | null, pWindow: Window | null, pDocumentBody: HTMLElement): HTMLOrSVGElement[];

interface ISignalHistoryRecord<T> {
    value: T;
    timestamp: number;
}
/**
 * Enhances a writable signal with undo/redo history functionality.
 *
 * @param pSource The writable signal to track.
 * @param pOptions Configuration options for the history.
 * @returns An object with `history`, `undo`, `redo`, `canUndo`, and `canRedo` properties.
 */
declare function signalHistory<T>(pSource: WritableSignal<T>, pOptions?: {
    /**
     * The maximum number of history records to store.
     * @default 100
     */
    capacity?: number;
    /**
     * A function that determines whether a value should be recorded in the history.
     * By default, all values are recorded.
     */
    shouldRecord?: (value: T, oldValue: T) => boolean;
    /**
     * The injector to use for the effect.
     * @default undefined
     */
    injector?: Injector;
}): {
    /**
     * The history of changes to the source signal.
     */
    history: Signal<ISignalHistoryRecord<T>[]>;
    /**
     * Undo the last change to the source signal.
     */
    undo: () => void;
    /**
     * Redo the last undone change to the source signal.
     */
    redo: () => void;
    /**
     * Reset the history to the current state.
     */
    reset: () => void;
    /**
     * Clear the history. This will remove all history records.
     */
    clear: () => void;
    /**
     * A signal indicating if undo is possible.
     */
    canUndo: Signal<boolean>;
    /**
     * A signal indicating if redo is possible.
     */
    canRedo: Signal<boolean>;
    currentValue: Signal<T>;
    previousValue: Signal<T | undefined>;
};

/**
 * Creates a lazy singleton proxy for any object.
 *
 * The underlying instance is NOT created immediately.
 * It will only be created on the first property access (get/set).
 *
 * This is especially useful for:
 * - Lazy initialization (avoid heavy setup until needed)
 * - Angular dependency injection (via `inject`)
 * - Deferring object creation until runtime conditions are met
 *
 * @template T - The type of the singleton instance
 * @param pCreateInstance - A factory function that returns a new instance of T
 *
 * @returns An object containing:
 * - `proxy`: A proxy that behaves like the real instance (with full IntelliSense)
 * - `reset`: A function to clear the current instance so it will be recreated on next access
 *
 * @example
 * // Basic usage
 * class ApiService {
 *   getData() {
 *     return 'data';
 *   }
 * }
 *
 * const { proxy: api } = createSingletonProxy(() => new ApiService());
 *
 * // Instance is created here (lazy)
 * api.getData();
 *
 * @example
 * // Lazy initialization (instance is NOT created until used)
 * const { proxy: service } = createSingletonProxy(() => {
 *   console.log('Created!');
 *   return new ApiService();
 * });
 *
 * // Nothing logged yet
 *
 * service.getData(); // 👉 logs "Created!"
 *
 * @example
 * // With reset (force recreate instance)
 * const singleton = createSingletonProxy(() => new ApiService());
 *
 * singleton.proxy.getData();
 *
 * singleton.reset(); // clear instance
 *
 * singleton.proxy.getData(); // 👉 new instance created again
 * @remarks
 * - The proxy fully preserves the type of T (IntelliSense works as expected).
 * - The instance is shared (singleton) until `reset()` is called.
 */
declare function createSingletonProxy<T extends object>(pCreateInstance: () => T, pInjector?: Injector): {
    proxy: T;
    reset: () => void;
};
/**
 * Lazy singleton proxy (NULLABLE version)
 * - Preserve null semantics
 * - Safe access (không crash khi null)
 */
declare function createSingletonProxyNullable<T extends object>(pFactory: () => T | null): {
    proxy: T | null;
    reset: () => void;
};

declare function toLazySignal<T>(pSource: Observable<T> | Subscribable<T>): Signal<T | undefined>;
declare function toLazySignal<T>(pSource: Observable<T> | Subscribable<T>, pOptions: ToSignalOptions<T> & {
    initialValue?: undefined;
    requireSync?: false;
}): Signal<T | undefined>;
declare function toLazySignal<T>(pSource: Observable<T> | Subscribable<T>, pOptions: ToSignalOptions<T> & {
    initialValue?: null;
    requireSync?: false;
}): Signal<T | null>;
declare function toLazySignal<T>(pSource: Observable<T> | Subscribable<T>, pOptions: ToSignalOptions<T> & {
    initialValue?: undefined;
    requireSync: true;
}): Signal<T>;
declare function toLazySignal<T, const U extends T>(pSource: Observable<T> | Subscribable<T>, pOptions: ToSignalOptions<T> & {
    initialValue: U;
    requireSync?: false;
}): Signal<T | U>;

declare function toObservableDefer<T>(pSource: Signal<T>, pOptions?: ToObservableOptions): Observable<T>;

/**
 * 📌 `debug<T>` - Logs detailed information about RxJS Observables with intuitive icons.
 *
 * 🛠️ **Usage:**
 * - Insert `debug(tag, options?)` into an `Observable` pipeline to track events.
 * - Supports logging for events: `next` (new value), `error` (error occurred), `complete` (completed),
 *   `subscribe` (subscription started), `unsubscribe` (subscription canceled), and `finalize` (finalization).
 * - Allows customization of `subscribe`, `unsubscribe`, and `finalize` logs via `ExtraNotifications`.
 *
 * 🔹 **Parameters:**
 * @param {string} tag - A name or description to identify the `Observable`.
 * @param {ExtraNotifications} [extraNotifications] - Optional logging configuration.
 *        - `subscribe`: Logs when the `Observable` is subscribed to.
 *        - `unsubscribe`: Logs when the `Observable` is unsubscribed.
 *        - `finalize`: Logs when the `Observable` finalizes.
 *
 * 📌 **Example Usage:**
 * ```typescript
 * import { of } from 'rxjs';
 * import { delay } from 'rxjs/operators';
 *
 * of('Hello World')
 *   .pipe(
 *     debug('Test Observable', { finalize: true }),
 *     delay(1000)
 *   )
 *   .subscribe();
 * ```
 *
 * 📝 **Console Output (Assuming after 1 second):**
 * ```
 * 2025-03-26T12:00:00.123Z [Test Observable: 🟠 Next] Hello World
 * 2025-03-26T12:00:01.125Z [Test Observable: ✅ Completed]
 * 2025-03-26T12:00:01.126Z [Test Observable: 🔚 Finalized]
 * ```
 */
type ExtraNotifications = {
    subscribe?: boolean;
    unsubscribe?: boolean;
    finalize?: boolean;
};
declare function debug<T>(pTag: string, pExtraNotifications?: ExtraNotifications): rxjs.MonoTypeOperatorFunction<T>;

/**
 * `injectResize` returns an `Observable<ResizeResult>` that observes the `resize` event on the Host element
 * of the component. `options` passed in is merged with default options
 *
 * @see {@link defaultResizeOptions}
 *
 * @param {Partial<ResizeOptions>} [pOptions={}]
 * @see {@link ResizeOptions}
 *
 * @returns {Observable<ResizeResult>}
 * @see {@link ResizeResult}
 */
declare function injectResize(pOptions?: Partial<ResizeOptions>): Observable<ResizeResult>;

/**
 * @desc Provides dependency injection for localStorage and sessionStorage in Angular.
 *       Allows components and services to interact with browser storage using WritableSignal.
 *       Supports automatic synchronization, custom serialization, and Angular's DI system.
 */

/**
 * @desc Injection token for localStorage.
 */
declare const LOCAL_STORAGE: InjectionToken<Storage>;
/**
 * @desc Provides a custom implementation for localStorage.
 */
declare function provideLocalStorageImpl(pImpl: typeof globalThis.localStorage): {
    provide: InjectionToken<Storage>;
    useValue: Storage;
};
/**
 * @desc Injection token for sessionStorage.
 */
declare const SESSION_STORAGE: InjectionToken<Storage>;
/**
 * @desc Provides a custom implementation for sessionStorage.
 */
declare function provideSessionStorageImpl(pImpl: typeof globalThis.sessionStorage): {
    provide: InjectionToken<Storage>;
    useValue: Storage;
};
type StorageType = 'local' | 'session';
type StorageOptionsNoDefault = {
    storageSync?: boolean;
    stringify?: (value: unknown) => string;
    parse?: (value: string) => unknown;
    injector?: Injector;
};
type StorageOptionsWithDefaultValue<T> = StorageOptionsNoDefault & {
    defaultValue: T | (() => T);
};
/**
 * @desc Injects a storage mechanism (localStorage or sessionStorage) into a WritableSignal.
 */
declare const injectStorage: {
    <T>(pKey: string, pStorageType: StorageType, pOptions: StorageOptionsWithDefaultValue<T>): WritableSignal<T>;
    <T>(pKey: string, pStorageType: StorageType, pOptions?: StorageOptionsNoDefault): WritableSignal<T | undefined>;
};

type StateOptions<ReadT, WriteT> = {
    parse?: (v: WriteT) => ReadT;
    defaultValue?: ReadT;
    injector?: Injector;
};
type StateTransformFn<T> = (state: NavigationExtras['state']) => T;
/**
 * Custom hook to inject navigation state in Angular applications using Signals.
 *
 * @param {string | StateTransformFn<T>} [keyOrTransform] - The key to extract state or a transformation function to apply to the entire state.
 * @param {StateOptions<T, string>} [options] - Optional configuration to customize state parsing and default values.
 * @returns {Signal<T | Record<string, BrSafeAny> | null>} - A Signal representing the state or transformed state.
 *
 * @template T - The type of the transformed state.
 *
 * @example
 * // Basic usage with state extraction
 * const state = injectNavigationState();
 *
 * // Usage with key and default value
 * const userId = injectNavigationState('userId', { defaultValue: 'guest' });
 *
 * // Usage with transformation function
 * const parsedState = injectNavigationState((state) => state?.user, {
 *   parse: (value) => value?.toLowerCase(),
 * });
 *
 * @typedef {Object} StateOptions
 * @property {(v: WriteT) => ReadT} [parse] - Function to parse the value before using it.
 * @property {ReadT} [defaultValue] - Default value if state or key is not found.
 * @property {Injector} [injector] - Optional custom injector to resolve dependencies.
 *
 * @typedef {Function} StateTransformFn
 * @param {NavigationExtras['state']} state - The current navigation state.
 * @returns {T} - The transformed state.
 */
declare function injectNavigationState(): Signal<Record<string, BrSafeAny> | null>;
declare function injectNavigationState<T>(pKeyOrTransform?: string | StateTransformFn<T>, pOptions?: StateOptions<T, string>): Signal<T | Record<string, BrSafeAny> | null>;

type ParamsTransformFn<ReadT> = (params: Params) => ReadT;
/**
 * The `ParamsOptions` type defines options for configuring the behavior of the `injectParams` function.
 *
 * @template ReadT - The expected type of the read value.
 * @template WriteT - The type of the value to be written.
 * @template DefaultValueT - The type of the default value.
 */
type ParamsOptions<ReadT, WriteT, DefaultValueT> = ParseOptions<ReadT, WriteT> & DefaultValueOptions<DefaultValueT> & InjectorOptions;
/**
 * The `injectParams` function allows you to access and manipulate parameters from the current route.
 *
 * @returns A `Signal` that emits the entire parameters object.
 */
declare function injectParams(): Signal<Params>;
/**
 * The `injectParams` function allows you to access and manipulate parameters from the current route.
 *
 * @param {string} pKey - The name of the parameter to retrieve.
 * @returns {Signal} A `Signal` that emits the value of the specified parameter, or `null` if it's not present.
 */
declare function injectParams(pKey: string): Signal<string | null>;
/**
 * The `injectParams` function allows you to access and manipulate parameters from the current route.
 *
 * @param {string} pKey - The name of the parameter to retrieve.
 * @param {ParamsOptions} pOptions - Optional configuration options for the parameter.
 * @returns {Signal} A `Signal` that emits the transformed value of the specified parameter, or `null` if it's not present.
 */
declare function injectParams<ReadT>(pKey?: string, pOptions?: ParamsOptions<ReadT, string, ReadT>): Signal<ReadT | null>;
/**
 * The `injectParams` function allows you to access and manipulate parameters from the current route.
 * It retrieves the value of a parameter based on a custom transform function applied to the parameters object.
 *
 * @template ReadT - The expected type of the read value.
 * @param {ParamsTransformFn<ReadT>} pCallback - A transform function that takes the parameters object (`params: Params`) and returns the desired value.
 * @returns {Signal} A `Signal` that emits the transformed value based on the provided custom transform function.
 *
 * @example
 * const searchValue = injectParams((params) => params['search'] as string);
 */
declare function injectParams<ReadT>(pCallback: ParamsTransformFn<ReadT>): Signal<ReadT>;

interface IDBConfig {
    dbName: string;
    storeName: string;
    keyPath: string;
    version?: number;
}
/**
 * Initializes and manages a table (object store) in IndexedDB.
 * The data is wrapped in a WritableSignal for reactive usage in Angular.
 * Automatically synchronizes data across multiple browser tabs using BroadcastChannel.
 *
 * @template T The type of records stored in the object store.
 *
 * @param {Object} pConfig Configuration for IndexedDB connection.
 * @param {string} pConfig.dbName The database name.
 * @param {string} pConfig.storeName The name of the object store (table).
 * @param {string} pConfig.keyPath The key path used as the primary key in the object store.
 * @param {number} [pConfig.version=1] The database version.
 *
 * @returns {Object} An object containing methods to interact with the store and the reactive signal:
 * @returns {WritableSignal<T[]>} return.items A signal containing all records in the store.
 * @returns {() => Promise<void>} return.refresh Reloads all data from IndexedDB into the signal.
 * @returns {(item: T) => Promise<void>} return.add Adds a new record; throws if key already exists.
 * @returns {(item: T) => Promise<void>} return.set Adds or updates a record (put).
 * @returns {(id: IDBValidKey, updateFn: (item: T) => T) => Promise<void>} return.update Updates a record by id.
 * @returns {(id: IDBValidKey) => Promise<void>} return.delete Deletes a record by id.
 * @returns {(id: IDBValidKey) => Promise<T | undefined>} return.get Retrieves a record by id.
 *
 * @example
 * ```ts
 * const { items, add, set, update, delete: deleteItem, get } = injectIndexedDBTable<User>({
 *   dbName: 'appDB',
 *   storeName: 'users',
 *   keyPath: 'userId',
 * });
 *
 * // Get current list
 * console.log(items());
 *
 * // Add a new record
 * await add({ userId: 1, name: 'Alice' });
 *
 * // Update a record
 * await update(1, user => ({ ...user, name: 'Bob' }));
 *
 * // Delete a record
 * await deleteItem(1);
 *
 * // Get a record by id
 * const user = await get(1);
 * ```
 *
 * @note
 * - Data is automatically synchronized between browser tabs using BroadcastChannel.
 * - BroadcastChannel will be automatically closed when the component or service is destroyed via DestroyRef.
 * - Only works in browser environments where window is available.
 */
declare function injectIndexedDBTable<T>(pConfig: IDBConfig): {
    items: _angular_core.WritableSignal<T[]>;
    refresh: () => Promise<void>;
    add: (pItem: T) => Promise<void>;
    set: (pItem: T) => Promise<void>;
    update: (pId: IDBValidKey, pUpdateCallback: (item: T) => T) => Promise<void>;
    delete: (pId: IDBValidKey) => Promise<void>;
    get: (pId: IDBValidKey) => Promise<T | undefined>;
    deleteAll: () => Promise<void>;
};

declare function validateEmail(): ValidatorFn;

declare function validatePhone(): ValidatorFn;

export { EnsureFormat, InputSetter, IsInViewportService, LOCAL_STORAGE, RESIZE_OPTIONS, SESSION_STORAGE, assertInjector, calculateResult, computedPrevious, createInjectionToken, createNoopInjectionToken, createNotifier, createResizeStream, createSingletonProxy, createSingletonProxyNullable, debug, defaultResizeOptions, derivedFrom, effectOnceIf, explicitEffect, findScrollContainers, injectActiveElement, injectAutoEffect, injectDestroy, injectIndexedDBTable, injectIsIntersecting, injectLazy, injectNavigationState, injectParams, injectResize, injectResizeOptions, injectStorage, lazyInject, mergeFrom, provideLocalStorageImpl, provideResizeOptions, provideSessionStorageImpl, signalHistory, toLazySignal, toObservableDefer, validateEmail, validatePhone };
export type { CreateInjectionTokenOptions, CreateInjectionTokenReturn, DerivedFromOptions, EffectOnceIfConditionFn, EffectOnceIfExecutionFn, EffectOnceIfOptions, ExtraNotifications, IInjectIsIntersectingOptions, IInputTransformOptions, IIsInViewportServiceInterface, ISignalHistoryRecord, InferObservableSignalOutput, MergeFromOptions, ParamsOptions, ResizeOptions, ResizeResult, StateOptions };
