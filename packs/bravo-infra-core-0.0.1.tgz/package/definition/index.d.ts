interface ITryCastPattern {
    implementsInterface(pImplementInterface: string): boolean;
}

interface IBravoExpressionBase {
    isTrue(pzExpression: string, pDataItem?: unknown): boolean;
    evaluateText(pzText: string, pDataItem?: unknown, pCulture?: unknown): string;
}

type BrSafeAny = any;

/**
 * @description
 * The function which is used by `KeyCompareMap` to determine if changes are distinct or not.
 * Should return true if values are equal.
 *
 * @param {T} oldVal
 * @param {T} newVal
 *
 * @return boolean
 *
 * @docsPage interfaces
 * @docsCategory operators
 */
type CompareFn<T> = (oldVal: T, newVal: T) => boolean;
type ComparableData<T> = CompareFn<T> | keyof T | (keyof T)[];

declare enum DataTypeEnum {
    /** Object (anything). */
    Object = 0,
    /** String. */
    String = 1,
    /** Number. */
    Number = 2,
    /** Boolean. */
    Boolean = 3,
    /** Date (date and time). */
    Date = 4,
    /** Array. */
    Array = 5
}

export { DataTypeEnum };
export type { BrSafeAny, ComparableData, CompareFn, IBravoExpressionBase, ITryCastPattern };
