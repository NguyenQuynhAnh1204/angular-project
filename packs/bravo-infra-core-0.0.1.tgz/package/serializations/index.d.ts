import { TypeCodeEnum, IBravoDataRow, SerializeOptionEnum, DataViewRowStateEnum, BravoDataTable, BravoDataSet, IBravoDataSet, BravoXmlStringTypeEnum, DataRowStateEnum, XmlWriteModeEnum, XmlReadModeEnum } from '@bravo-infra/core/data';
import { BrSafeAny } from '@bravo-infra/core/definition';
import { ObservableArray, BravoComparableMap, JsonSerializer, BravoStringBuilder } from '@bravo-infra/core/utils/data-extensions';
import { BravoLangEnum, BravoLangType } from '@bravo-infra/core/utils/global-settings';
import { BravoExpressionEvaluator, OperatorEnum, BravoExpression } from '@bravo-infra/core/expression';
import { Type } from '@angular/core';

declare enum AttributeNameEnum {
    LayoutName = 0,
    Expression = 1,
    Expr = 2,
    Condition = 3,
    Resource = 4,
    Encrypt = 5,
    Template = 6,
    Merge = 7
}

declare enum MergeActionEnum {
    Default = 0,
    Override = 1,
    Union = 2
}

declare const LAYOUT_K = "?o!O:q\u0011?";
declare class BravoLayoutItem {
    static readonly LayoutNameAttribute = "LayoutName";
    name: string;
    value: unknown;
    description?: string;
    attributes: BrSafeAny;
    type?: string;
    parent?: BravoLayoutItem;
    set parentItem(pVal: BravoLayoutItem | undefined);
    get parentItem(): BravoLayoutItem | undefined;
    get bHasAttributes(): boolean;
    constructor(pName?: string, pValue?: unknown, pDescription?: string, pAttributes?: BrSafeAny);
    get isData(): boolean;
    isEncrypt(): any;
    isExpression(): any;
    data(): BravoLayoutData;
    bool(): boolean;
    number(): number;
    str(pLangKey?: BravoLangEnum | BravoLangType): string;
    valueAs<T>(pLanguage?: BravoLangEnum, pType?: TypeCodeEnum): unknown;
    getAttributeValue(pAttribute: AttributeNameEnum): any;
    getMergeAction(): MergeActionEnum;
    getHierarchy(pOutArgs?: {
        pLayoutNameAttribute: string | null;
    }, pExcludeRoot?: boolean, pIgnoreCurrentLocation?: boolean): ObservableArray<any>;
}

declare const RootName = "root";
declare const BravoLayoutDataInterfaceName = "IBravoLayoutData";
declare class BravoLayoutData extends BravoComparableMap<string, BravoLayoutItem> {
    get count(): number;
    get isEmpty(): boolean;
    get(pKey: string): BravoLayoutItem | undefined;
    getKeys(): string[];
    getValues(): BravoLayoutItem[];
    static createNew(pXml: string | Uint8Array, pUserOptions?: unknown): unknown;
    static createNewString(pXml: string, pOptions?: BrSafeAny): unknown;
    static getItemValue<T>(pKey: string, pLayoutData: BravoLayoutData, pTemplateLayoutData?: BravoLayoutData, pOption?: {
        pDefaultValue?: BrSafeAny;
        pbIgnoreUnion?: boolean;
        pzUnionSeperator?: string;
        pLang?: BravoLangEnum;
        pDefaultLayoutData?: BravoLayoutData | null;
        pType?: TypeCodeEnum;
    }): T;
    static isValidKeyName(pzKeyName: string): boolean;
    constructor();
    contains(...pKeys: string[]): boolean;
    containsValue(pItem: BravoLayoutItem): boolean;
    containsChildLayoutData(...pKeys: string[]): boolean;
    getChildLayoutData(...pKeys: string[]): BravoLayoutData | undefined;
    getChildLayoutItem(...pKeys: string[]): BravoLayoutItem | undefined;
    add(pItem: BravoLayoutItem): void;
    addLayoutItem(pKey: string, pValue: BrSafeAny, pDescription?: string): void;
    openChildLayoutData(...pKeys: string[]): BravoLayoutData;
    serialize(pType?: 'base64' | 'uint8array'): string | Uint8Array<ArrayBufferLike>;
    remove(...pKeys: string[]): void;
    clone(pIncludeHierarchy?: boolean, pParentItem?: BravoLayoutItem): BravoLayoutData;
    toString(pRootName?: string): string;
    private _addChildNode;
    implementsInterface(pInterfaceName: string): boolean;
}

declare class BravoLayoutItemUtil {
    static evalText(pLayoutItem: BravoLayoutItem | undefined, pExpressionEval: BravoExpressionEvaluator, pLangKey?: BravoLangType | null, pDataItem?: IBravoDataRow | Record<string, unknown>): string;
}

declare class BravoResponseData<T> {
    returnValue?: T;
    outputValue?: unknown[];
    constructor(pArgs: {
        returnValue?: T;
        outputValue?: unknown[];
    });
}

declare class BravoJsonSerializer extends JsonSerializer {
    #private;
    serialize(pValue: object | object[], pOptions?: SerializeOptionEnum, pExpr?: BravoExpressionEvaluator, pRowState?: DataViewRowStateEnum): (null | undefined) | {};
    deserialize<T extends object>(pValue: string | object | object[], pType: T | Type<T> | BravoDataTable | BravoDataSet | BravoResponseData<T>, pOptions?: SerializeOptionEnum): T | T[];
    deserializeObject<T extends object>(pObject: string | object, pType: T | Type<T> | BravoDataTable | BravoDataSet | BravoResponseData<T>, pOptions?: SerializeOptionEnum): T | null;
}
declare function containsPropertyValue(pObject: Record<BrSafeAny, BrSafeAny>, propertyName: string): boolean;
declare function getPropertyValue(pObject: Record<BrSafeAny, BrSafeAny>, pPropertyName: string, pDefaultValue?: BrSafeAny): any;

declare class ExpressionParam {
    operator: OperatorEnum;
    value: BrSafeAny;
    expressions?: Array<ExpressionParam>;
    clauses?: Array<ExpressionParam>;
    clauseToken?: number;
    attributes?: Array<ExpressionParam>;
}

declare class ExpressionSerializer {
    static fromExpression(pzException: string): ExpressionParam[] | undefined;
    static fromExpression(pExprs: BravoExpression[]): ExpressionParam[] | undefined;
    private static _fromExpression;
}

declare class BravoXmlHelper {
    static convertToXmlString(pDataSet: IBravoDataSet, pTables?: Array<string> | null, pColumns?: Array<string> | null, pbUseTableAlias?: boolean, pType?: BravoXmlStringTypeEnum): string;
    static serializeDataSet(pDataSet: IBravoDataSet, pTables?: string[] | null, pColumns?: string[] | null, pRowFilter?: string | null, pRowState?: number, pbUseTableAlias?: boolean, pType?: BravoXmlStringTypeEnum, pFormat?: BrSafeAny): string;
    static serializeDataTable(pTable: BravoDataTable, pColumns: string[], pRowFilter: string | null | undefined, pRowState: DataRowStateEnum | undefined, pbUseTableAlias: boolean | undefined, pType: BravoXmlStringTypeEnum): string;
    static writeDataSet(pDataSet: IBravoDataSet, pTables?: string[] | null, pColumns?: string[] | null, pbUseTableAlias?: boolean, pType?: BravoXmlStringTypeEnum, pFormat?: BrSafeAny): string;
    static writeDataTable(pTable: BravoDataTable, pColumns: string[], pbUseTableAlias: boolean, pType: BravoXmlStringTypeEnum): string;
    static writeXmlSchema(pData: BrSafeAny, pStringWriter: StringWriter): void;
    static writeXmlDataSet(pDataSet: IBravoDataSet, pMode: XmlWriteModeEnum): string;
    private static _writeXmlDiffGram;
    private static _writeXmlDiffGramFragment;
    static readXmlDataSet(pDataSet: BravoDataSet, pXml: string, pMode: XmlReadModeEnum): void;
    private static _readXmlAuto;
    private static _readXmlDiffGram;
}
declare class StringWriter {
    private _encoded;
    get encoded(): any;
    set encoded(pValue: any);
    private _stringBuilder;
    get stringBuilder(): BravoStringBuilder | null;
    set stringBuilder(pValue: BravoStringBuilder | null);
    private _format;
    get format(): any;
    set format(pValue: any);
    constructor(pStringBuilder?: BravoStringBuilder, pFormat?: BrSafeAny);
    close(): void;
}
declare function convertStringToType(pzType: string): TypeCodeEnum.Boolean | TypeCodeEnum.Byte | TypeCodeEnum.Int32 | TypeCodeEnum.Double | TypeCodeEnum.Decimal | TypeCodeEnum.DateTime | TypeCodeEnum.String | TypeCodeEnum.ByteArray;
declare function escapeXml(pText: string | null | undefined): string;

export { AttributeNameEnum, BravoJsonSerializer, BravoLayoutData, BravoLayoutDataInterfaceName, BravoLayoutItem, BravoLayoutItemUtil, BravoResponseData, BravoXmlHelper, ExpressionParam, ExpressionSerializer, LAYOUT_K, RootName, StringWriter, containsPropertyValue, convertStringToType, escapeXml, getPropertyValue };
