import * as rxjs from 'rxjs';
import { Observable } from 'rxjs';
import { BrSafeAny } from '@bravo-infra/core/definition';
import * as _bravo_infra_core_utils_data_extensions from '@bravo-infra/core/utils/data-extensions';

/**
 * A reactive wrapper around the native `BroadcastChannel` API for cross-tab communication,
 * with a fallback to `localStorage` events for environments that do not support it.
 *
 * `BravoBroadcastChannel` enables message broadcasting between multiple browser tabs
 * or windows sharing the same origin. It provides an RxJS `Observable` interface for
 * listening to messages, making it easy to integrate into reactive applications.
 *
 * @template TValue The type of data transmitted through the channel.
 *
 * @example
 * // Create a broadcast channel named "my-channel"
 * const channel = new BravoBroadcastChannel<{ message: string }>('my-channel');
 *
 * // Subscribe to receive messages
 * channel.onDataChanged$.subscribe(data => {
 *   console.log('Received message:', data);
 * });
 *
 * // Send a message
 * channel.postMessage({ message: 'Hello from another tab!' });
 *
 * // Dispose when no longer needed
 * channel.dispose();
 */
declare class BravoBroadcastChannel<TValue = BrSafeAny> {
    #private;
    /** The name of the broadcast channel. */
    get channelName(): string;
    /**
     * Observable that emits messages of type `TValue` when received.
     *
     * @returns {Observable<TValue>} A stream of received messages.
     */
    get onDataChanged$(): rxjs.Observable<TValue>;
    /**
     * Creates a new broadcast channel instance with the given name.
     * Falls back to using `localStorage` events if the `BroadcastChannel` API is unavailable.
     *
     * @param {string} pChannelName - The unique name of the channel used for communication.
     */
    constructor(pChannelName: string);
    /**
     * Disposes of the broadcast channel and releases resources.
     *
     * - Closes the `BroadcastChannel` if used.
     * - Removes the `storage` event listener if using the fallback mechanism.
     * - Completes the `onDataChanged$` observable.
     *
     * @example
     * channel.dispose();
     */
    dispose(): void;
    /**
     * Sends a message to all other tabs or windows listening on the same channel.
     *
     * If the `BroadcastChannel` API is not available, it uses `localStorage` as a transport
     * mechanism by writing and removing a key, which triggers the `storage` event.
     *
     * @param {TValue} pzMessage - The message payload to broadcast.
     *
     * @example
     * channel.postMessage({ user: 'Alice', action: 'joined' });
     */
    postMessage(pzMessage: TValue): void;
}

/**
 * A cache that supports automatic eviction when
 * the maximum size is exceeded. It follows an LRU (Least Recently Used) strategy.
 */
declare class BravoLRUCache<K = BrSafeAny, T = BrSafeAny> {
    #private;
    /**
     * @param pMaxSize Maximum number of items to keep in cache. Defaults to 100.
     */
    constructor(pMaxSize?: number);
    /** Observable that emits whenever the cache changes. */
    get cacheChanged$(): rxjs.Observable<_bravo_infra_core_utils_data_extensions.NotifyCollectionChangedEventArgs<{
        key: K;
        value: T;
    }>>;
    /** Current number of items in the cache. */
    get size(): number;
    getAll(): T[];
    /**
     * Retrieves an item from the cache.
     * Marks the item as recently used if found.
     * @param pKey The key of the item.
     * @returns The cached value, or undefined if not found.
     */
    get(pKey: K): T | undefined;
    has(pKey: K): boolean;
    /**
     * Inserts or updates an item in the cache.
     * Automatically evicts the least recently used item if the cache is full.
     * @param pKey The key to insert or update.
     * @param pValue The value to store.
     */
    set(pKey: K, pValue: T): void;
    /**
     * Removes an item from the cache.
     * @param pKey The key of the item to delete.
     * @returns True if the item was deleted, false otherwise.
     */
    delete(pKey: K): boolean;
    clear(): void;
}

declare class BravoErrorBase extends Error {
    readonly innerException?: Error;
    constructor(pMessage?: string, pInnerException?: Error);
    implementsInterface(pInterfaceName: string): boolean;
}

declare class BravoArgumentNullException extends BravoErrorBase {
    constructor(pMessage?: string);
    implementsInterface(pInterfaceName: string): boolean;
}

declare class BravoDbMessageException extends BravoErrorBase {
    constructor(pMessage?: string);
    implementsInterface(pInterfaceName: string): boolean;
}

declare const BravoErrorsInterfaceNamingConstants: {
    IBravoArgumentNullException: "IBravoArgumentNullException";
    IError: "IError";
    IBravoDbMessageException: "IDbMessageException";
    IBravoException: "IBravoException";
    IBravoMaintenanceException: "IBravoMaintenanceException";
    IBravoPermissionException: "IBravoPermissionException";
    IBravoUserLimitExceededException: "IBravoUserLimitExceededException";
    IBravoFileExistedException: "IBravoFileExistedException";
    IBravoFileInvalidException: "IBravoFileInvalidException";
    IBravoFileNotFoundException: "IBravoFileNotFoundException";
    IBravoInvalidCastException: "IBravoInvalidCastException";
    IBravoInvalidConstraintException: "IBravoInvalidConstraintException";
    IBravoInvalidExpressionException: "IBravoInvalidExpressionException";
    IBravoNullReferenceException: "IBravoNullReferenceException";
};
declare enum BravoExceptionTypeEnum {
    Generic = 0,
    DbConnection = 1,
    DbConcurrency = 2,
    DbLockTimeout = 3,
    DbDeadLock = 4,
    DbQuery = 5,
    DbWarningMessage = 6,
    Permission = 7,
    ConcurrentEditingLayout = 8,
    TokenExpired = 9,
    PasswordIncorrect = 10,
    PasswordPolicy = 11,
    PasswordUsed = 12,
    PasswordUnmatched = 13,
    FileExisted = 14,
    FileNotFound = 15,
    InvalidFile = 16,
    WebPortalError = 17,
    ForgotPasswordException = 18,
    InValidEntry = 19,
    EntryNotFound = 20,
    ColumnDoesNotExist = 21,
    DocumentsAreBeingSigned = 22,
    UnchangedPassword = 23,
    LimitLoginAttempts = 100,
    UserLimitExceeded = 101,
    RootFolderInvalid = 102,
    FileSizeExceedsLimit = 103,
    LimitUploadFilePerTime = 104,
    Maintenance = 510,
    InvalidConnectionProvider = 1000,
    InvalidSSOProvider = 1001,
    InvalidFiscalYear = 1002,
    SystemCheck = 1003
}

declare class BravoFileExistedException extends BravoErrorBase {
    constructor(pMessage?: string);
    implementsInterface(pInterfaceName: string): boolean;
}

declare class BravoFileInvalidException extends BravoErrorBase {
    constructor(pMessage?: string);
    implementsInterface(pInterfaceName: string): boolean;
}

declare class BravoFileNotFoundException extends BravoErrorBase {
    constructor(pMessage?: string);
    implementsInterface(pInterfaceName: string): boolean;
}

declare class BravoInvalidCastException extends BravoErrorBase {
    constructor(pMessage?: string);
    implementsInterface(pInterfaceName: string): boolean;
}

declare class BravoInvalidConstraintException extends BravoErrorBase {
    constructor(pMessage?: string);
    implementsInterface(pInterfaceName: string): boolean;
}

declare class BravoInvalidExpressionException extends BravoErrorBase {
    constructor(pMessage?: string, pInnerException?: Error);
    implementsInterface(pInterfaceName: string): boolean;
}

declare class BravoMaintenanceException extends BravoErrorBase {
    constructor(pMessage?: string);
    implementsInterface(pInterfaceName: string): boolean;
}

declare class BravoNullReferenceException extends BravoErrorBase {
    constructor(pMessage?: string);
    implementsInterface(pInterfaceName: string): boolean;
}

declare class BravoPermissionException extends BravoErrorBase {
    constructor(pMessage?: string);
    implementsInterface(pInterfaceName: string): boolean;
}

declare class BravoUserLimitExceededException extends BravoErrorBase {
    constructor(pMessage?: string);
    implementsInterface(pInterfaceName: string): boolean;
}

/**
 * Base class for event arguments.
 */
declare class BravoEventArgs {
    /**
     * Provides a value to use with events that do not have event data.
     */
    static empty: BravoEventArgs;
}

declare class BravoCancelEventArgs extends BravoEventArgs {
    cancel: boolean;
}

declare class BravoDataEventArgs<S = BrSafeAny, T = BrSafeAny> extends BravoEventArgs {
    readonly sender: S;
    readonly data: T;
    constructor(pSender: S, pData: T);
}

declare class BravoListChangedEventArgs extends BravoEventArgs {
    readonly listChangedType: ListChangedTypeEnum;
    readonly newIndex: number;
    readonly oldIndex?: number;
    readonly propDesc?: BrSafeAny;
    constructor(pListChangedType: ListChangedTypeEnum, pNewIndex: number, pOldIndex?: number, pPropDesc?: BrSafeAny);
}
declare enum ListChangedTypeEnum {
    Reset = 0,
    ItemAdded = 1,
    ItemDeleted = 2,
    ItemMoved = 3,
    ItemChanged = 4,
    PropertyDescriptorAdded = 5,
    PropertyDescriptorDeleted = 6,
    PropertyDescriptorChanged = 7
}

declare class BravoEventQueue {
    #private;
    get isHaveTaskInQueue(): boolean;
    enqueue(pTaskName: string, pTaskCallback: () => Promise<void> | void): void;
    enqueueUnique(pTaskKey: string, pTaskCallback: () => Promise<void> | void): void;
}

declare function httpRequest(pUrl: string, pSettings?: BrSafeAny): XMLHttpRequest;

/**
 * A lightweight asynchronous semaphore implementation using RxJS.
 *
 * The `BravoSemaphore` class limits the number of concurrent operations.
 * It ensures that only a specified number of tasks can run at the same time.
 * When a permit becomes available, queued tasks are notified in order (FIFO).
 *
 * @example
 * const semaphore = new BravoSemaphore(2); // Allows 2 concurrent tasks
 *
 * async function task(id: number) {
 *   await semaphore.start().toPromise(); // Acquire permit
 *   console.log(`Task ${id} started`);
 *   await new Promise(r => setTimeout(r, 1000));
 *   console.log(`Task ${id} finished`);
 *   semaphore.end(); // Release permit
 * }
 *
 * for (let i = 1; i <= 5; i++) {
 *   task(i);
 * }
 */
declare class BravoSemaphore {
    #private;
    /**
     * Creates a new instance of `BravoSemaphore`.
     *
     * @param {number} pMaxConcurrency - The maximum number of concurrent operations allowed.
     */
    constructor(pMaxConcurrency: number);
    /**
     * Attempts to acquire a semaphore permit.
     *
     * If a permit is available, the returned observable emits immediately.
     * Otherwise, it waits until another task releases a permit.
     *
     * @returns {Observable<void>} An observable that completes when the permit is acquired.
     *
     * @example
     * semaphore.start().subscribe(() => {
     *   // Do work here
     *   semaphore.end(); // Must release after work is done
     * });
     */
    start(): Observable<void>;
    /**
     * Releases a previously acquired permit.
     *
     * If there are any queued observers waiting for a permit,
     * the next one in line is notified and allowed to proceed.
     *
     * @example
     * // Always call `end()` after `start()` once your work is complete.
     * semaphore.end();
     */
    end(): void;
}

declare class BravoUsbTokenHelper {
    #private;
    static readRawData(pzSerialNumber: string, pPropName?: string): string | undefined;
    static signData(pSerialNumber: string, pXMLString: string, pItemTagName: string, pOtions?: {
        hashValueTagName?: string;
        signValueTagName?: string;
    }): string | undefined;
    static signXml(pSerialNumber: string, pXMLString: string, pOptions?: {
        isIncludeKeyInfo: boolean;
        signatureId: string;
        referenceUri: string;
    }): string | undefined;
    static verifySignXml(pCertificate: Uint8Array, pzSignedXml: string): string | undefined;
    static signDocument(pSerialNumber: string, pInputFileName: string, pOptions?: {
        reason?: string;
        contact?: string;
        location?: string;
        xOffset: string;
        yOffset: string;
        isShow: boolean;
    }): string | null;
    static signDataString(pzSerialNumber: string, pzDataString: string): string | null;
    static verifySignDataString(pCertificate: BrSafeAny, pOriginalData: string, pSignedData: string): string | undefined;
}

export { BravoArgumentNullException, BravoBroadcastChannel, BravoCancelEventArgs, BravoDataEventArgs, BravoDbMessageException, BravoErrorBase, BravoErrorsInterfaceNamingConstants, BravoEventArgs, BravoEventQueue, BravoExceptionTypeEnum, BravoFileExistedException, BravoFileInvalidException, BravoFileNotFoundException, BravoInvalidCastException, BravoInvalidConstraintException, BravoInvalidExpressionException, BravoLRUCache, BravoListChangedEventArgs, BravoMaintenanceException, BravoNullReferenceException, BravoPermissionException, BravoSemaphore, BravoUsbTokenHelper, BravoUserLimitExceededException, ListChangedTypeEnum, httpRequest };
