import { BravoLangKeyType, BravoCultureType } from '@bravo-infra/core/utils/global-settings';
import * as DateUtil from 'date-fns';
import { DateArg, DateValues, SetOptions, StartOfISOWeekOptions, EndOfISOWeekOptions, StartOfISOWeekYearOptions, EndOfISOWeekYearOptions, GetISOWeekOptions, GetISOWeekYearOptions, ParseISOOptions, FormatISOOptions, FormatISO9075Options, AddDaysOptions, SubDaysOptions, AddMonthsOptions, SubMonthsOptions, AddYearsOptions, StartOfMonthOptions, EndOfMonthOptions, StartOfWeekOptions, EndOfWeekOptions, SetMonthOptions, SetDayOptions, SetYearOptions, SetHoursOptions, SetMinutesOptions, SetSecondsOptions, LastDayOfMonthOptions, IsSameDayOptions, IsSameMonthOptions, IsSameYearOptions, IsTodayOptions, DifferenceInMinutesOptions, DifferenceInHoursOptions, DifferenceInDaysOptions, DifferenceInMonthsOptions, DifferenceInYearsOptions, DifferenceInSecondsOptions, GetDayOptions, GetMonthOptions, GetYearOptions, WeekOptions, FormatOptions, ParseOptions, EachDayOfIntervalOptions } from 'date-fns';

declare class BravoMoment {
    #private;
    static now(): BravoMoment;
    static set(pDate: DateArg<Date>, pValues: DateValues, pOptions?: SetOptions): BravoMoment;
    get patternFormat(): string;
    get locale(): DateUtil.Locale;
    get currentFormat(): string;
    constructor(pInput?: Date | string | number | BravoMoment | undefined, pPatternFormat?: string, pLocal?: DateUtil.Locale);
    static getLocal(pLangKey: BravoLangKeyType): DateUtil.Locale;
    startOfISOWeek(pOptions?: StartOfISOWeekOptions): this;
    endOfISOWeek(pOptions?: EndOfISOWeekOptions): this;
    startOfISOWeekYear(pOptions?: StartOfISOWeekYearOptions): this;
    endOfISOWeekYear(pOptions?: EndOfISOWeekYearOptions): this;
    getISOWeek(pOptions?: GetISOWeekOptions): number;
    getISOWeekYear(pOptions: GetISOWeekYearOptions): number;
    static parseISO(pDate: string, pOptions?: ParseISOOptions): Date;
    formatISO(pOptions?: FormatISOOptions): string;
    formatISO9075(pOptions?: FormatISO9075Options): string;
    addDays(pDays: number, pOptions?: AddDaysOptions<Date>): this;
    subDays(pDays: number, pOptions?: SubDaysOptions<Date>): this;
    addMonths(pMonths: number, pOptions?: AddMonthsOptions<Date>): this;
    subMonths(pMonths: number, pOptions?: SubMonthsOptions<Date>): this;
    addYears(pYears: number, pOptions?: AddYearsOptions<Date>): this;
    subYears(pYears: number): this;
    startOfMonth(pOptions?: StartOfMonthOptions<Date>): this;
    endOfMonth(pOptions?: EndOfMonthOptions<Date>): this;
    startOfWeek(pOptions?: StartOfWeekOptions<Date>): this;
    endOfWeek(pOptions?: EndOfWeekOptions<Date>): this;
    setMonth(pMonth: number, pOptions?: SetMonthOptions<Date>): this;
    setDay(pDay: number, pOptions?: SetDayOptions<Date>): this;
    setYear(pYear: number, pOptions?: SetYearOptions<Date>): this;
    setHours(pHours: number, pOptions?: SetHoursOptions<Date>): this;
    setMinutes(pMinutes: number, pOptions?: SetMinutesOptions<Date>): this;
    setSeconds(pSeconds: number, pOptions?: SetSecondsOptions<Date>): this;
    static lastDayOfMonth(pDate: BravoMoment | Date | string | number, pOptions?: LastDayOfMonthOptions): Date;
    lastDayOfMonth(pOptions?: LastDayOfMonthOptions): this;
    static isValid(pDate: BravoMoment | Date | string | number): boolean;
    isSunday(): boolean;
    isValid(): boolean;
    isSameDay(pDate: BravoMoment | Date | string | number, pOptions?: IsSameDayOptions): boolean;
    isSameMonth(pDate: BravoMoment | Date | string | number, pOptions?: IsSameMonthOptions): boolean;
    isSameYear(pDate: BravoMoment | Date | string | number, pOptions?: IsSameYearOptions): boolean;
    isToday(pOptions?: IsTodayOptions): boolean;
    isToMonth(): boolean;
    isToYear(): boolean;
    static isLeapYear(pYear: number): boolean;
    isDate(): boolean;
    static isDate(pValue: unknown): pValue is Date;
    isBefore(pDate: BravoMoment | Date | string | number): boolean;
    isAfter(pDate: BravoMoment | Date | string | number): boolean;
    isEqual(pDate: BravoMoment | Date | string | number): boolean;
    static isEqual(pDate: BravoMoment | Date | string | number, pDate2: BravoMoment | Date | string | number): boolean;
    static isTimeFormat(pFormat: string): boolean;
    static isDayInMonth(pDay: number, pMonth: number, pYear: number): boolean;
    differenceInMinutes(pDate: BravoMoment | Date | string | number, pOptions?: DifferenceInMinutesOptions): number;
    differenceInHours(pDate: BravoMoment | Date | string | number, pOptions?: DifferenceInHoursOptions): number;
    differenceInDays(pDate: BravoMoment | Date | string | number, pOptions?: DifferenceInDaysOptions): number;
    differenceInMonths(pDate: BravoMoment | Date | string | number, pOptions?: DifferenceInMonthsOptions): number;
    differenceInYears(pDate: BravoMoment | Date | string | number, pOptions?: DifferenceInYearsOptions): number;
    differenceInSeconds(pDate: BravoMoment | Date | string | number, pOptions?: DifferenceInSecondsOptions): number;
    getDay(pOptions?: GetDayOptions): number;
    getMonth(pOptions?: GetMonthOptions): number;
    getYear(pOptions?: GetYearOptions): number;
    getWeeks(pOptions?: WeekOptions): BravoMoment[][];
    getMonths(pattern: string | undefined, pNumberOfRow: number): BravoMoment[][];
    getYears(pNumberOfRow: number, pItemPerRow: number): BravoMoment[][];
    getDays(pattern?: string, pOptions?: FormatOptions): string[];
    getTime(): number;
    getFullYear(): number;
    getDate(): number;
    getHours(): number;
    getMinutes(): number;
    getSeconds(): number;
    getMilliseconds(): number;
    toDate(): Date;
    static ensureFormat(pFormat: string): string;
    static parseDate(pInput: string, pFormat: string, pReferenceDate?: DateArg<Date>, pOptions?: ParseOptions): BravoMoment;
    static eachDayOfInterval(pStartDate: BravoMoment | Date | string | number, pEndDate: BravoMoment | Date | string | number, pOptions?: EachDayOfIntervalOptions): Date[];
    static getQuarterBegin(pDate: BravoMoment | Date | string | number): Date;
    format(pPattern?: string, pOptions?: FormatOptions): string;
    static format(pDate: BravoMoment | Date | string | number, pattern: string, pOptions?: FormatOptions): string;
    toISOString(): string;
    clone(): BravoMoment;
    static asDate(pDate: BravoMoment | Date | string | number): Date;
    static autoParseDate(pDateString: string, pCulture?: BravoCultureType): BravoMoment | null;
    static parseManualDate(pValue: string, pFormat: string, pDefaultDate?: Date): Date | null;
}

declare class BravoDateExtensions {
    static calculateExpiredTime(pDateNow: Date, pDateExpired: Date): number;
    static reviveUtcDate(pKey: unknown, pValue: unknown): unknown;
    static get minValue(): Date;
    /**
     * @deprecated
     * Using BravoDateMoment instead of
     */
    static clone(pDate: Date): Date;
    /**
     * @deprecated
     * Using BravoDateMoment instead of
     */
    static isDate(pValue: unknown): boolean;
    /**
     * @deprecated
     * Using BravoDateMoment instead of
     */
    static isEqual(pDate: BravoMoment | Date | string | number, pDate2: BravoMoment | Date | string | number): boolean;
    /**
     * @deprecated
     * Using BravoMoment instead of
     */
    static date(pDate: Date): Date;
    /**
     * @deprecated
     * Using BravoDateMoment instead of
     */
    static month(pDate: Date): number;
    /**
     * @deprecated
     * Using BravoDateMoment instead of
     */
    static year(pDate: Date): number;
    /**
     * Calculates the day of the year for a given date.
     * @deprecated
     * @param pDate - The date for which to determine the day of the year.
     * @returns The day of the year (1-based), where January 1st is 1 and December 31st is 365 or 366 (for leap years).
     */
    static dayOfYear(pDate: Date): number;
    /**
     * @deprecated
     * Using BravoDateMoment instead of
     */
    static day(pDate: Date): number;
    /**
     * @deprecated
     * Using BravoDateMoment instead of
     */
    static addMonths(pDate: Date, pValue: number): Date;
    /**
     * @deprecated
     * Using BravoDateMoment instead of
     */
    static addDays(pDate: Date, pValue: number): Date;
    static asDate(pDate: any): Date;
    static get now(): Date;
    static get utcNow(): Date;
    /**
     * Converts the given local Date object to its equivalent UTC (universal) time.
     *
     * @param pDate - The local Date object to convert.
     * @returns A new Date object representing the same moment in UTC.
     */
    static toUniversalTime(pDate: Date): Date;
    /**
     * Converts the given date to the local time equivalent.
     *
     * @param pDate - The date to be converted.
     * @returns A new `Date` object representing the local time equivalent of the input date.
     */
    static toLocalTime(pDate: Date): Date;
    /**
     * Converts a .NET binary date value (ticks) to a JavaScript `Date` object.
     *
     * @param pValue - The .NET binary date value (number of ticks since 0001-01-01T00:00:00Z).
     * @returns A JavaScript `Date` object representing the same point in time.
     *
     * @remarks
     * .NET `DateTime` ticks are measured in 100-nanosecond intervals since 0001-01-01T00:00:00Z.
     * This method adjusts for the local timezone offset and the difference between the .NET epoch and the JavaScript epoch.
     */
    static fromBinary(pValue: number): Date;
    /**
     * Converts a JavaScript `Date` object to a .NET binary (ticks) representation.
     *
     * .NET ticks are the number of 100-nanosecond intervals since 0001-01-01T00:00:00Z.
     * This method returns the UTC ticks (not local time).
     *
     * @param pDate - The `Date` object to convert.
     * @returns The .NET binary representation of the date as a `number`.
     */
    static toBinary(pDate: Date): number;
}

declare class BravoTimeSpan {
    #private;
    static get zero(): BravoTimeSpan;
    static get maxValue(): BravoTimeSpan;
    static get minValue(): BravoTimeSpan;
    static fromDays(pValue: number): BravoTimeSpan;
    static fromHours(pValue: number): BravoTimeSpan;
    static fromMilliseconds(pValue: number): BravoTimeSpan;
    static fromMinutes(pValue: number): BravoTimeSpan;
    static fromSeconds(pValue: number): BravoTimeSpan;
    static fromTime(pHours: number, pMinutes: number, pSeconds: number): BravoTimeSpan;
    static fromTime(pDays: number, pHours: number, pMinutes: number, pSeconds: number, pMilliseconds: number): BravoTimeSpan;
    constructor(pMillis: number);
    get days(): number;
    get hours(): number;
    get minutes(): number;
    get seconds(): number;
    get milliseconds(): number;
    get totalDays(): number;
    get totalHours(): number;
    get totalMinutes(): number;
    get totalSeconds(): number;
    get totalMilliseconds(): number;
    add(pTimeSpan: BravoTimeSpan): BravoTimeSpan;
    subtract(pTimeSpan: BravoTimeSpan): BravoTimeSpan;
}
declare class TimeSpanOverflowError extends Error {
    constructor(pMessage?: string);
}

export { BravoDateExtensions, BravoMoment, BravoTimeSpan, TimeSpanOverflowError };
