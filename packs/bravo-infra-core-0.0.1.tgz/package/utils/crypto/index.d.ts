import * as CryptoJS from 'crypto-js';
import { BrSafeAny } from '@bravo-infra/core/definition';

declare class BravoCryptoExtension {
    /**
     * Root key used for hashing operations.
     */
    static readonly defaultRootKey = "0G8hTzpxEcMA";
    /**
     * Encrypts data using RSA with a provided public key (PEM or XML format).
     * @param pData The data to encrypt.
     * @param pPublicKeyPemOrXml The public key in PEM or XML format.
     * @returns The encrypted data as a string.
     */
    static encryptRSA(pData: string, pPublicKeyPemOrXml: string): string;
    /**
     * Encrypts a string using AES encryption with a given key.
     * @param pData The string to encrypt.
     * @param pKey The encryption key.
     * @returns The encrypted string.
     */
    static encryptAES(pData: string, pKey: string): string;
    /**
     * Decrypts an AES-encrypted string using the given key.
     * @param pEncryptedData The encrypted data.
     * @param pKey The decryption key.
     * @returns The decrypted string.
     */
    static decryptAES(pEncryptedData: string, pKey: CryptoJS.lib.WordArray | string): string;
    /**
     * Computes the SHA-256 hash of a given string.
     * @param pInput The input string.
     * @returns The SHA-256 hash as a string.
     */
    static computeSHA256(pInput: string): string;
    /**
     * Computes the MD5 hash of a given string and returns the result as a byte array.
     * @param pInput The input string.
     * @returns A Uint8Array containing the hash bytes.
     */
    static computeMD5HashBytes(pInput: string): Uint8Array | undefined;
    /**
     * Computes the MD5 hash of a given string and returns the result in uppercase hexadecimal format.
     * @param pInput The input string.
     * @returns The MD5 hash as an uppercase hexadecimal string.
     */
    static computeMD5Hash(pInput: string): string;
    /**
     * Computes an MD5-based hash using the default root key.
     * @returns A Uint8Array containing the hash bytes.
     */
    static generateRootKeyHash(): Uint8Array;
    /**
     * Computes a checksum using a raw checksum and an identifier.
     * @param pRawChecksum The raw checksum as a Uint8Array.
     * @param pId The identifier number.
     * @returns The computed checksum as a Uint8Array.
     */
    static computeChecksum(pRawChecksum: Uint8Array, pId: number): Uint8Array;
    /**
     * Computes an MD5 hash for a given input.
     * @param pInput The input string.
     * @returns The computed MD5 hash as a string.
     */
    static computeMD5(pInput: string): string;
    /**
     * Verifies whether the provided checksum matches the computed checksum for a given ID and password.
     * @param pChecksum The checksum to verify.
     * @param pId The identifier number.
     * @param pPassword The password used in the hashing process.
     * @returns True if the checksum is valid, otherwise false.
     */
    static verifyChecksum(pChecksum: string, pId: number, pPassword: string): boolean;
}
/**
 * Generates a short hash name for a given input.
 * @param pContent The input content (string or object).
 * @returns A 9-character substring of the SHA-256 hash.
 */
declare function generateShortHashName(pContent: BrSafeAny): string;

declare class BravoRSACrypto {
    #private;
    /**
     * Generates an RSA key pair with the specified key size.
     */
    generateKeyPair(pKeySize?: number): Promise<void>;
    /**
     * Loads a private key from an XML string.
     */
    loadPrivateKeyFromXml(pXml: string): void;
    /**
     * Loads a public key from an XML string.
     */
    loadPublicKeyFromXml(pXml: string): void;
    /**
     * Loads a private key from a PEM string.
     */
    loadPrivateKeyFromPem(pPrivateKeyPem: string): void;
    loadPublicKeyFromPem(pPublicKeyPem: string): void;
    getPrivateKeyPem(): string;
    getPublicKeyPem(): string;
    /**
     * Signs a string using the private key and returns the Base64 signature.
     */
    sign(pData: string): string;
    /**
     * Signs a file using the private key and returns the Base64 signature.
     */
    signFile(pFile: File | Blob): Promise<string>;
    /**
     * Verifies a signature using the public key.
     */
    verify(pData: string, pSignatureBase64: string): boolean;
    /**
     * Verifies a file signature using the public key.
     */
    verifyFile(pFile: File | Blob, pSignatureBase64: string): Promise<boolean>;
    encrypt(pData: string): string;
    decrypt(pEncryptedBase64: string): string;
}

/**
 * BravoBrowserIdentifier
 *
 * Utility class to obtain a stable browser identifier for the current visitor.
 * It first tries to obtain an identifier from the FingerprintJS library.
 * If that fails (e.g. FingerprintJS not available or an error occurs),
 * it falls back to generating and persisting a UUID in localStorage.
 *
 * Usage:
 *   const id = await BravoBrowserIdentifier.getBrowserIdentifier();
 */
declare class BravoBrowserIdentifier {
    /**
     * Get a browser identifier for the current visitor.
     *
     * This method attempts to load FingerprintJS and return the visitorId.
     * If any error occurs (library not available, network error, etc.),
     * it will read a persisted UUID from localStorage or generate a new one,
     * persist it, and return that fallback value.
     *
     * @returns {Promise<string>} A promise resolving to a stable identifier string.
     */
    static getBrowserIdentifier(): Promise<string>;
    /**
     * Generate a RFC-4122-like version 4 UUID (pseudo-random).
     *
     * NOTE: This implementation uses Math.random and is not suitable for
     * cryptographic purposes. It is intended only as a stable, random-looking
     * fallback identifier.
     *
     * @returns {string} A randomly generated UUID string in the form:
     *                   xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx
     */
    static generateUUID(): string;
}

declare class BravoCryptography {
    #private;
    /**
     * Encrypts a string using a simple XOR cipher with a given key.
     *
     * - The text is first prefixed with a `MAGIC_HEADER`.
     * - The combined string is converted to UTF-8 bytes.
     * - Each byte is XORed with the corresponding byte from the key
     *   (repeating the key if it is shorter).
     * - The result is returned as a Base64-encoded string.
     *
     * ⚠️ Note: XOR cipher is **not secure** for production use,
     * it should only be used for lightweight obfuscation.
     *
     * @param pText - The plain text to encrypt.
     * @param pKey - The key used for XOR encryption.
     * @returns A Base64-encoded string of the encrypted data.
     */
    static encryptXor(pText: string, pKey: string): string;
    static hashBytes(pBytes: Uint8Array): Uint8Array<ArrayBuffer>;
    static hashString(pInput: string, pPrefix?: string): string;
    static encryptBytes(pInput: Uint8Array, pKey: string): string | Uint8Array<ArrayBufferLike>;
    static encryptString(pInput: string, pKey: string): string;
    static decryptBytes(pInput: Uint8Array, pKey: string): Uint8Array<ArrayBufferLike>;
    static decryptString(pInput: string, pKey: string): string;
    static decrypt(pzEncryptedText: string, pKey: string): string;
    static encrypt(pText: string, pKey: string): string;
    static toWordArray(pData: string | Uint8Array): CryptoJS.lib.WordArray;
    static fromWordArray(pWordArray: CryptoJS.lib.WordArray): Uint8Array<ArrayBuffer>;
}

export { BravoBrowserIdentifier, BravoCryptoExtension, BravoCryptography, BravoRSACrypto, generateShortHashName };
