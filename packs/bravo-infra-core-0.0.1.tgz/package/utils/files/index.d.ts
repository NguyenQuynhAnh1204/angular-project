import saveAs from 'file-saver';
import * as fflate from 'fflate';

declare enum FileTypeEnum {
    Unknown = 0,
    Pdf = 1,
    Bmp = 2,
    Jpg = 3,
    Gif = 4,
    Tif = 5,
    Png = 6,
    Psd = 7,
    Wmf = 8,
    Ico = 9,
    Mp3 = 10,
    Avi = 11,
    Swf = 12,
    Flv = 13,
    Mp4 = 14,
    Mov = 15,
    Wmv = 16,
    Wma = 17,
    Zip = 18,
    Docx = 19,
    Xlsx = 20,
    Pptx = 21,
    Xps = 22,
    Rar = 23,
    Doc = 24,
    Rtf = 25,
    Xls = 26,
    Ppt = 27,
    Eps = 28,
    Wav = 29,
    Flac = 30,
    Mkv = 31,
    Xml = 32,
    Msi = 33,
    Txt = 34,
    Dot = 35,
    Sql = 36,
    Folder = 37
}
declare enum FileFilterEnum {
    DocumentFiles = 1,
    ImageFiles = 2,
    VideoFiles = 4,
    AllFiles = 8
}
declare enum TypeFileInputEnum {
    Attached = 0,
    File = 1,
    Path = 2
}
declare enum FileOverwriteOptionEnum {
    NoOverwrite = 0,
    Overwrite = 1,
    AutoRename = 2
}
declare enum FileActionEnum {
    Add = 0,
    Delete = 1,
    Remove = 99
}
declare enum FileAccessModeEnum {
    Private = 0,
    Public = 1
}

declare class BravoFileExtensions {
    static readonly ImgTypesCommon: string[];
    static readonly PublicFolder = "pub";
    static readonly TempFolder = "temp";
    static readonly AssetsImg = "assets/img";
    static readonly AllFileFilter = "*.*";
    static readonly OpenDocumentFileFilter = "*.pdf;*.doc;*.dot;*.docx;*.docm;*.dotx;*.dotm;*.xls;*.xlt;*.xlsx;*.xlsm;*.xltx;*.xltm;*.xlsb;*.xlam;*.csv;*.ppt;*.pptx;*.pptm;*.ppsx;*.ppsm;*.potx;*.potm;*.ppam;*.xps;*.odt;*.ods;*.odp;*.rtf;*.xml;*.txt";
    static readonly OpenImageFileFilter = "*.bmp;*.jpg;*.jpeg;*.gif;*.png;*.tif";
    static readonly OpenVideoFilesFilter = "*.mp4;*.avi;*.mov;*.mkv;*.wmv;*.flv;*.mpeg;*.mpg";
    /**
     * Extracts the base name of a file (without extension) from a file path.
     *
     * This function handles both simple filenames and full file paths by:
     * 1. Extracting only the filename portion from the path
     * 2. Removing the file extension if present
     *
     * @param pFilePath - The full path or name of the file
     * @returns The file name without its extension
     *
     * @example
     * ```typescript
     * BravoFileExtensions.getFileNameWithoutExtension('document.pdf')        // Returns: 'document'
     * BravoFileExtensions.getFileNameWithoutExtension('folder/file.txt')     // Returns: 'file'
     * BravoFileExtensions.getFileNameWithoutExtension('path/to/image.jpg')   // Returns: 'image'
     * BravoFileExtensions.getFileNameWithoutExtension('file')                // Returns: 'file'
     * BravoFileExtensions.getFileNameWithoutExtension('archive.tar.gz')      // Returns: 'archive.tar'
     * BravoFileExtensions.getFileNameWithoutExtension('.gitignore')          // Returns: '.gitignore'
     * ```
     */
    static getFileNameWithoutExtension(pFilePath: string): string;
    /**
     * Returns a display-friendly file name from a path, optionally removing the file name if it's a server path or link.
     *
     * @param pPath - The file path or URL.
     * @returns The display file name or path.
     *
     * @example
     * BravoFileExtensions.getDisplayFileName('folder/file.txt'); // 'file.txt'
     * BravoFileExtensions.getDisplayFileName('http://example.com/file.txt', true); // 'file.txt'
     */
    static getFileNameOnly(pPath: string): string;
    /**
     * Returns the file extension from a given filename.
     *
     * @param pFilename - The name of the file from which to extract the extension.
     * @returns The file extension as a string. If no extension is found, returns the original filename.
     */
    static getExtension(pFilename: string): string;
    /**
     * Returns the path to the SVG icon in the assets folder corresponding to the file extension or type of the given path.
     *
     * This method determines the file extension from the provided path and maps it to a predefined file type.
     * If the file type is unknown, it checks if the path matches a URL or server file path pattern and assigns a generic icon.
     * Otherwise, it defaults to a generic file icon.
     *
     * @param pPath - The file path or URL to determine the icon for.
     * @returns The relative path to the SVG icon in the assets/images directory.
     */
    static getFileIconInAssetsByPath(pPath: string): string;
    /**
     * Builds a dynamic regular expression to match file extensions based on a comma-separated list of accepted types.
     *
     * @param pAcceptedTypes - A comma-separated string of file extensions (e.g., "jpg,png,gif").
     * @returns A case-insensitive RegExp that matches file names ending with one of the specified extensions.
     *
     * @example
     * const regex = FileExtensionUtil.buildDynamicFileTypeRegex("jpg,png,gif");
     * console.log(regex.test("image.JPG")); // true
     * console.log(regex.test("document.pdf")); // false
     */
    static buildDynamicFileTypeRegex(pAcceptedTypes: string): RegExp;
    /**
     * Validates whether the given file path has an allowed file extension.
     *
     * @param pFilePath - The file path to validate.
     * @param pAllowedExtensions - A comma-separated string of allowed file extensions (e.g., "jpg,png,gif").
     * @returns `true` if the file path ends with one of the allowed extensions; otherwise, `false`.
     *
     * @example
     * ```typescript
     * validateFileExtension('image.jpg', 'jpg,png'); // returns true
     * validateFileExtension('document.pdf', 'jpg,png'); // returns false
     * validateFileExtension('folder/photo.PNG', 'jpg,png'); // returns true (case-insensitive)
     * validateFileExtension('archive.tar.gz', 'gz,zip'); // returns true
     * ```
     */
    static validateFileExtension(pFilePath: string, pAllowedExtensions: string): boolean;
    /**
     * Checks whether the allowed extensions string represents "accept all".
     * Accepted wildcard forms:
     *   "*"   → any extension
     *   "*.*" → any extension
     *   ".*"  → any extension
     *
     * @param {string} pAllowedExtensions - Raw extension string from config or user input.
     * @returns {boolean} True if it means accept-all.
     */
    static isAcceptAllExtensions(pAllowedExtensions: string): boolean;
    /**
     * Merges two file accept strings (e.g., ".jpg,.png" and ".gif,.png") into a single, deduplicated, normalized string.
     *
     * @param pAccept1 - The first accept string (comma-separated file extensions).
     * @param pAccept2 - The second accept string (comma-separated file extensions).
     * @returns A comma-separated string of unique, normalized file extensions.
     *
     * @example
     * BravoFileExtensions.mergeFileAccepts('.jpg,.png', '.gif,.png'); // ".jpg,.png,.gif"
     * BravoFileExtensions.mergeFileAccepts('jpg,png', 'gif,png');     // ".jpg,.png,.gif"
     */
    static mergeFileAccepts(pAccept1: string, pAccept2: string): string;
    /**
     * Finds the intersection (subset) of file types between two accept strings.
     *
     * @param pAcceptParent - The parent accept string (comma-separated file extensions).
     * @param pAcceptChild - The child accept string (comma-separated file extensions).
     * @returns A comma-separated string of file extensions that are present in both acceptParent and acceptChild.
     *
     * @example
     * BravoFileExtensions.findSubsetFileTypes('.jpg,.png,.gif', '.png,.bmp'); // ".png"
     * BravoFileExtensions.findSubsetFileTypes('jpg,png,gif', 'png,bmp');      // ".png"
     */
    static findSubsetFileTypes(pAcceptParent: string, pAcceptChild: string): string;
    /**
     * Normalizes a comma-separated string of file types/extensions.
     * Ensures each extension starts with a dot and is lowercase, trims whitespace, and joins them back into a string.
     *
     * @param pFileTypesStr - The input string of file types/extensions (e.g., "jpg, PNG, .gif").
     * @returns A normalized, comma-separated string of file extensions (e.g., ".jpg,.png,.gif").
     *
     * @example
     * BravoFileExtensions.buildAcceptTypeStringWithCheck('jpg, PNG, .gif'); // ".jpg,.png,.gif"
     * BravoFileExtensions.buildAcceptTypeStringWithCheck('.JPG,.pdf');      // ".jpg,.pdf"
     */
    static buildAcceptTypeStringWithCheck(pFileTypesStr: string): string;
    /**
     * Checks if the given accept string allows all file types.
     *
     * @param pAcceptTypes - The accept string to check (e.g., "*", "*.*", ".jpg,.png").
     * @returns `true` if all file types are accepted, otherwise `false`.
     *
     * @example
     * BravoFileExtensions.isFilesAcceptsAll('*');    // true
     * BravoFileExtensions.isFilesAcceptsAll('*.*');  // true
     * BravoFileExtensions.isFilesAcceptsAll('.jpg'); // false
     */
    static isFilesAcceptsAll(pAcceptTypes: string): pAcceptTypes is "*.*" | "*";
    /**
     * Merges client and server file accept strings, returning only the allowed file types.
     * If the client accepts all ("*" or "*.*"), returns the server's allowed types.
     * Otherwise, returns the intersection of client and server types.
     *
     * @param pFileAcceptClient - The client accept string (e.g., ".jpg,.png" or "*").
     * @param pFileAcceptClientServer - The server accept string (e.g., ".jpg,.png").
     * @returns A comma-separated string of allowed file extensions.
     *
     * @example
     * BravoFileExtensions.mergeAcceptFileTypeFromClientAndServer('*', '.jpg,.png'); // ".jpg,.png"
     * BravoFileExtensions.mergeAcceptFileTypeFromClientAndServer('.jpg,.gif', '.jpg,.png'); // ".jpg"
     */
    static mergeAcceptFileTypeFromClientAndServer(pFileAcceptClient: string, pFileAcceptClientServer: string): string;
    /**
     * Validates an array of files against a size limit, separating valid and invalid files.
     *
     * @param pVal - The array of File objects to validate.
     * @param pSizeLimit - The maximum allowed file size in bytes.
     * @returns An object with two arrays: `filesValid` (files within the size limit) and `filesInvalid` (files exceeding the limit).
     *
     * @example
     * const files = [new File(['a'], 'a.txt', {size: 100}), new File(['b'], 'b.txt', {size: 2000})];
     * BravoFileExtensions.validateFilesSize(files, 1024);
     * // => { filesValid: [File('a.txt')], filesInvalid: [File('b.txt')] }
     */
    static validateFilesSize(pVal: File[], pSizeLimit: number): {
        filesValid: File[];
        filesInvalid: File[];
    };
    /**
     * Validates an array of files against allowed file extensions, separating valid and invalid files.
     *
     * @param pFiles - The array of File objects to validate.
     * @param pFileAccept - A comma-separated string of allowed file extensions (e.g., "jpg,png,gif" or "*").
     * @returns An object with two arrays: `filesValid` (files with allowed extensions) and `filesInvalid` (files with disallowed extensions).
     *
     * @example
     * const files = [
     *   new File(['a'], 'a.jpg'),
     *   new File(['b'], 'b.txt'),
     *   new File(['c'], 'c.png')
     * ];
     * BravoFileExtensions.validateFilesTypePicked(files, 'jpg,png');
     * // => { filesValid: [File('a.jpg'), File('c.png')], filesInvalid: [File('b.txt')] }
     */
    static validateFilesTypePicked(pFiles: File[], pFileAccept: string): {
        filesValid: File[];
        filesInvalid: File[];
    };
    /**
     * Checks if the given path is a public file path (i.e., starts with the public folder).
     *
     * @param pPath - The file path to check.
     * @returns `true` if the path is in the public folder, otherwise `false`.
     *
     * @example
     * BravoFileExtensions.isPublic('pub/images/logo.png'); // true
     * BravoFileExtensions.isPublic('temp/file.txt');       // false
     */
    static isPublic(pPath: string): boolean | "";
    /**
     * Builds a file accept string for a file dialog based on the provided filter flags and (optionally) a server-allowed file type string.
     *
     * Combines document, image, and video file filters as specified by the EFileFilter flags.
     * If the AllFiles flag is set, includes all file types.
     * Cleans up the resulting accept string for use in file dialogs.
     * If a server-allowed file type string is provided, merges the client and server accept strings to ensure only allowed types are returned.
     *
     * @param pDialogFileFilter - The EFileFilter flags specifying which file types to allow (bitwise OR of DocumentFiles, ImageFiles, VideoFiles, AllFiles).
     * @param pAcceptFileTypeFromServer - (Optional) A comma-separated string of file types/extensions allowed by the server.
     * @returns A comma-separated string of allowed file extensions for the file dialog.
     *
     * @example
     * // Allow documents and images only
     * BravoFileExtensions.applyDialogFilter(EFileFilter.DocumentFiles | EFileFilter.ImageFiles, '');
     * // => "*.pdf;*.doc;...;*.jpg;*.jpeg;*.png;..."
     *
     * // Allow all files, but restrict to server-allowed types
     * BravoFileExtensions.applyDialogFilter(EFileFilter.AllFiles, '.jpg,.png');
     * // => ".jpg,.png"
     */
    static applyDialogFilter(pDialogFileFilter: FileFilterEnum, pAcceptFileTypeFromServer?: string): string;
    /**
     * Normalize a directory path by:
     * - Removing any trailing slashes (`/`) or backslashes (`\`).
     * - Converting backslashes (`\`) to forward slashes (`/`) in the directory part.
     * - Preserving the file name (if present).
     *
     * Examples:
     * ```ts
     * normalizeDirectoryPath("C:\\Users\\John\\Desktop\\file.txt");
     * // => "C:/Users/John/Desktop/file.txt"
     *
     * normalizeDirectoryPath("/home/user/docs/");
     * // => "/home/user/docs"
     *
     * normalizeDirectoryPath("file.txt");
     * // => "file.txt"
     * ```
     *
     * @param pPath - The input path string to normalize.
     * @returns The normalized path string. Returns an empty string if input is falsy.
     */
    static normalizeDirectoryPath(pPath: string): string;
    /**
     * Determines if a file is an image using multiple strategies:
     * - MIME type (preferred, if available)
     * - File extension (fallback)
     * - Magic bytes / file signature (last resort)
     *
     * @param {File} pFile - The file to check.
     * @returns {Promise<boolean>} Resolves to true if the file is detected as an image, otherwise false.
     */
    static isImage(pFile: File): Promise<boolean>;
    /**
     * Checks if the file is an image by its MIME type.
     *
     * @param {File} pFile - The file to check.
     * @returns {boolean} True if the file has an `image/*` MIME type, otherwise false.
     */
    static isImageByType(pFile: File): boolean | "";
    /**
     * Checks if the file is an image by inspecting its magic bytes (file header).
     * Supports formats: JPEG, PNG, GIF, BMP, TIFF, WebP, AVIF/HEIF, and SVG.
     *
     * @param {File} pFile - The file (Blob or File) to check.
     * @returns {Promise<boolean>} Resolves to true if the file matches an image signature, otherwise false.
     */
    static isImageByMagic(pFile: File): Promise<boolean>;
    /**
     * Checks if the file is an image based on its file extension.
     * Supported extensions: jpg, jpeg, png, gif, webp, svg, bmp, tiff, ico, avif.
     *
     * @param {File} pFile - The file to check.
     * @returns {boolean} True if the file extension indicates an image type, otherwise false.
     */
    static isImageByExtension(pFile: File): boolean;
    static isTempFolder(pFilePath: string): boolean;
    static saveFile(pData: string | Blob, pFilename?: string | undefined, pOptions?: saveAs.FileSaverOptions | undefined): void;
}

type FileAccept = Blob | Uint8Array | ArrayBuffer | Object | Base64URLString | File | string;
/**
 * Utility class for creating, reading, and managing ZIP archives using fflate.
 *
 * @example
 * // Create a new ZIP file
 * const zip = BravoZipTool.create();
 * zip.addEntry('example.txt', 'Hello world!');
 * const base64Zip = zip.save('base64');
 *
 * @example
 * // Open an existing ZIP file
 * const zipData = new Uint8Array(...); // some zip data
 * const zip = BravoZipTool.open(zipData);
 * const content = zip.readEntry('example.txt');
 */
declare class BravoZipTool {
    #private;
    /**
     * Gets the internal ZIP file object (uncompressed entries).
     */
    get zipFile(): fflate.Unzipped | undefined;
    /**
     * Creates a new, empty ZIP tool instance.
     *
     * @returns {BravoZipTool} A new instance of ZipTool with an empty ZIP structure.
     */
    static create(): BravoZipTool;
    /**
     * Opens an existing ZIP archive from a Uint8Array.
     *
     * @param {Uint8Array} pData - The ZIP file data as a Uint8Array.
     * @returns {BravoZipTool} A new ZipTool instance initialized with the extracted ZIP entries.
     */
    static open(pData: Uint8Array): BravoZipTool;
    /**
     * Adds a new entry to the ZIP file.
     *
     * @param {string} pzEntryName - The name of the entry (e.g., "file.txt").
     * @param {Uint8Array | string} pData - The file content as a Uint8Array or a string.
     */
    addEntry(pzEntryName: string, pData: Uint8Array | string): void;
    /**
     * Reads a specific entry from the ZIP file.
     *
     * @param {string} pzEntryName - The name of the entry to read.
     * @param {'uint8array' | 'text'} [pResultType='text'] - The output format.
     * @returns {Uint8Array | string | undefined} The entry content in the specified format, or undefined if not found.
     */
    readEntry(pzEntryName: string, pResultType?: 'uint8array' | 'text'): unknown;
    /**
     * Extracts and returns the first entry from the ZIP file.
     *
     * @returns {Uint8Array | undefined} The data of the first entry, or undefined if the ZIP is empty.
     */
    extractFirstEntry(): Uint8Array<ArrayBufferLike> | undefined;
    /**
     * Saves the ZIP file as either a Base64 string or a Uint8Array.
     *
     * @param {'base64' | 'uint8array'} [pType='base64'] - The desired output format.
     * @returns {string | Uint8Array} The compressed ZIP data in the specified format.
     */
    save(pType?: 'base64' | 'uint8array'): string | Uint8Array<ArrayBufferLike>;
    /**
     * Disposes of the current ZIP file data, freeing memory.
     */
    dispose(): void;
    /**
     * Counts the number of entries in the ZIP file.
     *
     * @returns {number | undefined} The number of entries, or undefined if no ZIP is loaded.
     */
    countsEntries(): number | undefined;
    /**
     * Gets a list of all entry names in the ZIP file.
     *
     * @returns {string[] | undefined} An array of entry names, or undefined if no ZIP is loaded.
     */
    getEntryNames(): string[] | undefined;
}

export { BravoFileExtensions, BravoZipTool, FileAccessModeEnum, FileActionEnum, FileFilterEnum, FileOverwriteOptionEnum, FileTypeEnum, TypeFileInputEnum };
export type { FileAccept };
