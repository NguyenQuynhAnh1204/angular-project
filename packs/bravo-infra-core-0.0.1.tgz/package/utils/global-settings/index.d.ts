import * as _angular_core from '@angular/core';
import { Injector } from '@angular/core';

declare enum BravoLangEnum {
    Vietnamese = 1066,
    English = 1033,
    Japanese = 1041,
    Chinese = 2052,
    Korean = 1042,
    Custom = 127
}
type BravoLangType = keyof typeof BravoLangEnum;
declare const VietNameseKey: "vi";
declare const EnglishKey: "en";
declare const JapaneseKey: "ja";
declare const ChineseKey: "zh";
declare const KoreanKey: "ko";
declare const CustomKey: "custom";
type BravoCultureType = 'vi-VN' | 'en-US' | 'ja-JP' | 'zh-CN' | 'ko-KR';
type BravoLangKeyType = typeof VietNameseKey | typeof EnglishKey | typeof JapaneseKey | typeof KoreanKey | typeof ChineseKey | typeof CustomKey;
declare const BravoLangKeyArray: ("vi" | "en" | "ja" | "zh" | "ko" | "custom")[];
declare const LCIDToLangMap: Record<BravoLangEnum, BravoLangKeyType>;
declare const CultureMap: Record<string, BravoCultureType>;
interface INumberFormatConfig {
    prefix: string;
    spec: string;
    specRaw: string;
    prec: number | null;
    scale: number;
    suffix: string;
    curr: string | null;
}
type NumberFormatType = 'n0' | 'n2' | 'c0' | 'c2' | 'p0' | 'p2' | string;
type WeekStartOnType = 0 | 1;

interface IConfiguration {
    apiPortalUrl: string;
    notificationServerUrl: string;
    ssoConfig: string;
    staticFolderConfig: string;
}
declare const NUMBER_FORMAT: {
    '.': string;
    ',': string;
    '-': string;
    '+': string;
    '%': string;
    percent: {
        pattern: string[];
    };
    currency: {
        decimals: number;
        symbol: string;
        pattern: string[];
    };
};
declare const DATE_FORMAT_PATTERNS: {
    d: string;
    D: string;
    f: string;
    F: string;
    t: string;
    T: string;
    M: string;
    m: string;
    Y: string;
    y: string;
    g: string;
    G: string;
    s: string;
    o: string;
    O: string;
    U: string;
};
declare const DATE_PARTS_REGION: {
    'en-US': string[];
    'vi-VN': string[];
    'ja-JP': string[];
    'ko-KR': string[];
    'zh-CN': string[];
};
interface IBravoAppSetting {
    /** */
    browserIdentifier: string;
    prefixLibAssets: string;
    idleMinuteInterval: number;
    currentLang: BravoLangEnum;
    currentLangString: BravoLangType;
    currentLangKey: BravoLangKeyType;
    /**
     * get currentLang id flowing index mapping with backend
     * in the following order:
     *      BravoLangEnum.Vietnamese,
            BravoLangEnum.English,
            BravoLangEnum.Japanese,
            BravoLangEnum.Chinese,
            BravoLangEnum.Korean,
     *  */
    currentLangId: number;
    /**get valid file extension setting of backend */
    validFileExt: string;
    staticFolderConfig: string;
    apiPortalUrl: string;
    notificationServerUrl: string;
    fontScale: number;
    ssoConfig: string;
    currentCulture: BravoCultureType;
    getLangCollection(): Array<BravoLangEnum>;
    getCultureInfo(pLanguage: BravoLangEnum): BravoCultureType;
    fixDateTimeString(pStr: string, pLangCi: BravoLangEnum): string;
    locale: BravoLangKeyType;
    dateFormat: string;
    weekStartOn: WeekStartOnType;
    numericFormat: NumberFormatType;
    datePartsRegions: typeof DATE_PARTS_REGION;
    numberFormatCache: {
        [key: string]: INumberFormatConfig;
    };
    numberFormat: typeof NUMBER_FORMAT;
    /**Format shortcut pattern */
    dateFormatPatterns: typeof DATE_FORMAT_PATTERNS;
    /**Sử dụng để lấy date format pattern */
    getDateFormatPattern(pKey: keyof typeof DATE_FORMAT_PATTERNS): string;
    /**Sử dụng để đặt date format pattern */
    setDateFormatPattern(pKey: keyof typeof DATE_FORMAT_PATTERNS, pValue: string): void;
}
declare class BravoAppSettings implements IBravoAppSetting {
    #private;
    readonly prefixLibAssets = "ui";
    protected static _injector: Injector;
    static get settings(): BravoAppSettings;
    protected _browserIdentifier: string;
    get browserIdentifier(): string;
    get idleMinuteInterval(): number;
    set idleMinuteInterval(pValue: number);
    protected readonly _currentLang: _angular_core.WritableSignal<BravoLangEnum>;
    get currentLang(): BravoLangEnum;
    set currentLang(pVal: BravoLangEnum);
    get currentLangString(): BravoLangType;
    get currentLangKey(): BravoLangKeyType;
    get currentLangId(): number;
    get isDevMode(): boolean;
    set isDevMode(pVal: boolean);
    get validFileExt(): string;
    set validFileExt(pValue: string);
    /**get static folder config of backend*/
    get staticFolderConfig(): string;
    set staticFolderConfig(pValue: string);
    get apiPortalUrl(): string;
    set apiPortalUrl(pValue: string);
    get notificationServerUrl(): string;
    set notificationServerUrl(pValue: string);
    protected readonly _fontScale: _angular_core.WritableSignal<number>;
    get fontScale(): number;
    set fontScale(pValue: number);
    get ssoConfig(): string;
    set ssoConfig(pValue: string);
    get prefixNameStore(): string;
    set prefixNameStore(pVal: string);
    get currentCulture(): BravoCultureType;
    getLangCollection(): Array<BravoLangEnum>;
    getCultureInfo(pLanguage: BravoLangEnum): BravoCultureType;
    fixDateTimeString(pStr: string, pLangCi: BravoLangEnum): string;
    get locale(): BravoLangKeyType;
    set locale(pValue: BravoLangKeyType);
    get dateFormat(): string;
    set dateFormat(pValue: string);
    get weekStartOn(): WeekStartOnType;
    set weekStartOn(pValue: WeekStartOnType);
    get numericFormat(): string;
    set numericFormat(pValue: string);
    readonly datePartsRegions: Record<BravoCultureType, string[]>;
    readonly numberFormatCache: {
        [key: string]: INumberFormatConfig;
    };
    readonly numberFormat: {
        '.': string;
        ',': string;
        '-': string;
        '+': string;
        '%': string;
        percent: {
            pattern: string[];
        };
        currency: {
            decimals: number;
            symbol: string;
            pattern: string[];
        };
    };
    /**Format shortcut pattern */
    readonly dateFormatPatterns: {
        d: string;
        D: string;
        f: string;
        F: string;
        t: string;
        T: string;
        M: string;
        m: string;
        Y: string;
        y: string;
        g: string;
        G: string;
        s: string;
        o: string;
        O: string;
        U: string;
    };
    /**Sử dụng để lấy date format pattern */
    getDateFormatPattern(pKey: keyof typeof DATE_FORMAT_PATTERNS): string;
    /**Sử dụng để đặt date format pattern */
    setDateFormatPattern(pKey: keyof typeof DATE_FORMAT_PATTERNS, pValue: string): string;
    buildKeyStore(pKey: string): string;
    /**Using when get configuration of app */
    static setupConfiguration(pConfigResponse: IConfiguration): void;
}

export { BravoAppSettings, BravoLangEnum, BravoLangKeyArray, ChineseKey, CultureMap, CustomKey, EnglishKey, JapaneseKey, KoreanKey, LCIDToLangMap, VietNameseKey };
export type { BravoCultureType, BravoLangKeyType, BravoLangType, IBravoAppSetting, IConfiguration, INumberFormatConfig, NumberFormatType, WeekStartOnType };
