import { BravoExpressionEvaluator } from '@bravo-infra/core/expression';
import { CommandTypeEnum, BravoDataTable } from '@bravo-infra/core/data';
import { BravoLayoutData, BravoLayoutItem } from '@bravo-infra/core/serializations';

declare class ParameterSetting {
    private _name;
    get name(): string;
    set name(pVal: string);
    private _value;
    get value(): unknown;
    set value(pVal: unknown);
    private _layoutKey;
    get layoutKey(): string;
    set layoutKey(pVal: string);
    constructor(params?: {
        name?: string;
        value?: unknown;
        layoutKey?: string;
    });
    copyTo(pSetting: ParameterSetting): void;
}

declare class CommandSetting {
    private _commandType;
    get commandType(): CommandTypeEnum;
    set commandType(pVal: CommandTypeEnum);
    private _commandName;
    get commandName(): string;
    set commandName(pVal: string);
    private _expr;
    get expr(): string;
    set expr(pVal: string);
    private _layoutKey;
    get layoutKey(): string;
    set layoutKey(pVal: string);
    private _parameterCollection;
    get parameterCollection(): Array<ParameterSetting>;
    private _columns;
    get columns(): Map<string, string>;
    copyTo(pSetting: CommandSetting): void;
}

declare enum JoinTypeEnum {
    Inner = 0,
    Left = 1,
    Right = 2,
    Full = 3
}
declare enum SelectTypeEnum {
    All = 0,
    Distinct = 1,
    Except = 2,
    Intersect = 3,
    If = 4
}
declare enum ForEachJoinEnum {
    All = 0,
    Distinct = 1,
    Except = 2,
    Intersect = 3
}
declare enum CombineOperatorEnum {
    And = 0,
    Or = 1
}

declare class ExpressionSetting {
    constructor(pzExpression?: string, pzExpr?: string);
    private _expr;
    get expr(): string;
    set expr(pVal: string);
    private _value;
    get value(): string;
    set value(pVal: string);
    private _collection;
    get collection(): Array<ExpressionSetting>;
    private _layoutKey;
    get layoutKey(): string;
    set layoutKey(pVal: string);
    copyTo(pSetting: ExpressionSetting): void;
}

declare class FilterSetting {
    constructor(pzFilterKey?: string, pzExpr?: string, pCombineOperator?: CombineOperatorEnum);
    private _combineOperator;
    get combineOperator(): CombineOperatorEnum;
    set combineOperator(pVal: CombineOperatorEnum);
    private _expr;
    get expr(): string;
    set expr(pVal: string);
    private _collection;
    get collection(): Array<FilterSetting>;
    private _filterKey;
    get filterKey(): string | null;
    set filterKey(pVal: string);
    private _layoutKey;
    get layoutKey(): string;
    set layoutKey(pVal: string);
    private _operand;
    get operand(): string;
    set operand(pVal: string);
    private _operator;
    get operator(): string;
    set operator(pVal: string);
    private _value1;
    get value1(): string;
    set value1(pVal: string);
    private _value2;
    get value2(): string;
    set value2(pVal: string);
    copyTo(pSetting: FilterSetting): void;
}

declare class TableSetting {
    private _dbName;
    get dbName(): string;
    set dbName(pVal: string);
    private _schema;
    get schema(): string;
    set schema(pVal: string);
    private _name;
    get name(): string;
    set name(pVal: string);
    private _alias;
    get alias(): string;
    set alias(pVal: string);
    private _dataCode;
    get dataCode(): string;
    set dataCode(pVal: string);
    private _source;
    get source(): string;
    set source(pVal: string);
    private _selectType;
    get selectType(): SelectTypeEnum;
    set selectType(pVal: SelectTypeEnum);
    private _ifCondition;
    get ifCondition(): string;
    set ifCondition(pVal: string);
    private _joinType;
    get joinType(): JoinTypeEnum;
    set joinType(pVal: JoinTypeEnum);
    private _joinCondition;
    get joinCondition(): string;
    set joinCondition(pVal: string);
    private _joinExpr;
    get joinExpr(): string;
    set joinExpr(pVal: string);
    private _joinCollection;
    get joinCollection(): Array<TableSetting>;
    private _sourceCollection;
    get sourceCollection(): Array<TableSetting>;
    private _commandCollection;
    get commandCollection(): Array<CommandSetting>;
    private _beforeCommit;
    get beforeCommit(): Array<CommandSetting>;
    private _afterCommit;
    get afterCommit(): Array<CommandSetting>;
    private _columns;
    get columns(): string;
    set columns(pVal: string);
    private _sort;
    get sort(): string;
    set sort(pVal: string);
    private _sortCollection;
    get sortCollection(): Array<ExpressionSetting>;
    private _group;
    get group(): string;
    set group(pVal: string);
    private _groupCollection;
    get groupCollection(): Array<ExpressionSetting>;
    private _filterKey;
    get filterKey(): string;
    set filterKey(pVal: string);
    private _filterCollection;
    get filterCollection(): Array<FilterSetting>;
    private _having;
    get having(): string;
    set having(pVal: string);
    private _havingCollection;
    get havingCollection(): Array<FilterSetting>;
    private _limit;
    get limit(): number;
    set limit(pVal: number);
    private _forEach;
    get forEach(): string;
    set forEach(pVal: string);
    private _forJoin;
    get forEachJoin(): ForEachJoinEnum;
    set forEachJoin(pVal: ForEachJoinEnum);
    private _expr;
    get expr(): string;
    set expr(pVal: string);
    private _layoutKey;
    get layoutKey(): string;
    set layoutKey(pVal: string);
    private _parentTable;
    get parentTable(): string;
    set parentTable(pzTable: string);
    private _childKey;
    get childKey(): string;
    set childKey(pVal: string);
    private _parentKey;
    get parentKey(): string;
    set parentKey(pVal: string);
    private _primaryKey;
    get primaryKey(): string;
    set primaryKey(pzPrimaryKey: string);
    private _isTemp;
    get isTemp(): boolean;
    set isTemp(pbIsTemp: boolean);
    private _extendedProperties;
    get extendedProperties(): Map<unknown, unknown>;
    copyTo(pSetting: TableSetting): void;
}

declare class BravoDbQueryHelper {
    #private;
    static buildFilter(pTable: TableSetting, pExpr?: BravoExpressionEvaluator): string;
    static buildFilter(pFilter: FilterSetting, pExpr?: BravoExpressionEvaluator): string;
    static buildSort(pTable: TableSetting, pExpr?: BravoExpressionEvaluator): string;
    static buildSort(pSort: ExpressionSetting, pExpr?: BravoExpressionEvaluator): string;
    static collectLayoutExprs(pTable: TableSetting): Set<string>;
    static containsColumn(pTable: TableSetting, pzColumnName: string): boolean;
    static getColumnExpr(pSetting: TableSetting, pzColumnName: string): string | null;
    static parseColumns(pColumnList: string): Map<string, string>;
    static getColumnName(pColumnName: string): string;
    static getColumnExpression(pTable: TableSetting, pzColumnName: string, pAliasExpressionOnly?: boolean): string;
    static parseSort(pzSort: string): Map<string, {
        sortOrder: boolean | null;
        expr: string;
    }>;
}

declare class TableSettingExtensions {
    #private;
    static TableDbNamePartitioned: string;
    static TableSchema: string;
    static TableName: string;
    static TableAlias: string;
    static TableDataCode: string;
    static TableSelectType: string;
    static TableIfCondition: string;
    static TableLimitRows: string;
    static TableJoinCollection: string;
    static TableJoinType: string;
    static TableJoinCondition: string;
    static TableFilterCollection: string;
    static TableHaving: string;
    static TableHavingCollection: string;
    static TableGroupBy: string;
    static TableGroupByCollection: string;
    static TableSort: string;
    static TableSortCollection: string;
    static TableForEach: string;
    static TableForEachJoin: string;
    static TableColumns: string;
    static TableSource: string;
    static TableChildKey: string;
    static TableParentKey: string;
    static TablePrimaryKey: string;
    static TableSourceCollection: string;
    static TableFilterKey: string;
    static TableCollection: string;
    static TableCommandCollection: string;
    static TableCommandType: string;
    static TableCommandName: string;
    static TableParameterCollection: string;
    static TableChildCollection: string;
    static TableBeforeCommitEvent: string;
    static TableAfterCommitEvent: string;
    static TableExpressionCollection: string;
    static Expression: string;
    static CombineOperator: string;
    static DataMember: string;
    static ColCollectionProp: string;
    static RowCollectionProp: string;
    static ControlCollectionProp: string;
    static TextProp: string;
    static NameProp: string;
    static StyleProp: string;
    static UserDataProp: string;
    static TextFormatProp: string;
    static ItemCollectionProp: string;
    static TabPageCollectionProp: string;
    static getTableSetting(pTable?: BravoDataTable): TableSetting;
    static isValidMobileCollectionControlLayoutData(pLayoutData: BravoLayoutData): boolean;
    static isValidCollectionControlLayoutData(pLayoutData: BravoLayoutData): boolean;
    static isValidDataControlLayoutData(pLayoutData: BravoLayoutData): boolean;
    static isValidLookupLayoutData(pLayoutData: BravoLayoutData): boolean;
    static findTable(pTableSettingCollection: TableSetting[], pTableNameOrAlias: string): TableSetting | null;
    static getSourceName(pTableSetting: TableSetting): string;
    static scanDataControls(pLayoutData: BravoLayoutData, pTableSettingCollection: TableSetting[], pScanCaption?: boolean, pScanLookup?: boolean, pScanSetting?: boolean, ...pAdditionalLayoutCollection: BravoLayoutData[]): Map<TableSetting, Map<string, ControlLayoutSetting>>;
    private static _scanLayoutDataControls;
    static scanCollectionControlDataControls(pLayoutData: BravoLayoutData, pTableSetting: TableSetting, pScanCaption?: boolean, pScanLookup?: boolean, pScanSetting?: boolean): Map<string, ControlLayoutSetting> | undefined;
    private static _scanLayoutCollectionControlDataControls;
    private static _addDataControl;
    static createTableSetting(pTableLayoutItem: BravoLayoutItem, pTemplateLayoutData?: BravoLayoutData): TableSetting;
    private static _readLayoutTableSetting;
    private static _readLayoutCommands;
    private static _readLayoutFilters;
    private static _readLayoutExpressions;
}
declare class ControlLayoutSetting {
    caption?: BravoLayoutItem;
    lookup?: BravoLayoutItem;
    setting?: BravoLayoutItem;
    constructor(pArgs: {
        caption?: BravoLayoutItem;
        lookup?: BravoLayoutItem;
        setting?: BravoLayoutItem;
    });
}

export { BravoDbQueryHelper, CombineOperatorEnum, CommandSetting, ControlLayoutSetting, ExpressionSetting, FilterSetting, ForEachJoinEnum, JoinTypeEnum, ParameterSetting, SelectTypeEnum, TableSetting, TableSettingExtensions };
