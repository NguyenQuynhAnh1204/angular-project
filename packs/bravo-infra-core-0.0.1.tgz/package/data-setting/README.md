# data-setting

This library was generated with [Nx](https://nx.dev).

## Running unit tests

Run `nx test data-setting` to execute the unit tests.
