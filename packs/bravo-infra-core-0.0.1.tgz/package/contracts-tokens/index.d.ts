import { InjectionToken, Injector } from '@angular/core';
import { FileAccessModeEnum, FileOverwriteOptionEnum } from '@bravo-infra/core/utils/files';
import { Observable } from 'rxjs';
import { BravoDataTable, IsolationLevelEnum, BravoDataSet, BravoDataRow, CommandTypeEnum, BravoDataCommand, BravoDataParameter, ParameterDirectionEnum } from '@bravo-infra/core/data';
import { BravoResponseData } from '@bravo-infra/core/serializations';

/**
 * Represents the general state of a file transfer operation.
 */
type StateType = 'PENDING' | 'IN_PROGRESS' | 'ERROR' | 'DONE';
/**
 * Describes progress, metadata, and status of a download operation.
 */
interface IDownload {
    /** The downloaded file content, if available. */
    content: Blob | null;
    /** Current download progress percentage (0–100). */
    progress: number;
    /** The current transfer state. */
    state: StateType;
    /** Estimated remaining time in seconds. */
    remainingTime: number;
    /** Estimated remaining size in bytes. */
    remainingSize: number;
    /** Total file size in bytes. */
    size: number;
    /** Bytes loaded so far. */
    loaded: number;
}
/**
 * Represents the state and progress of an upload operation.
 */
interface IUploadSate extends Omit<IDownload, 'message' | 'content' | 'size' | 'loaded'> {
    /** Reference or URL of the uploaded file, if available. */
    content: string | null;
}
/**
 * Defines the contract for a stream-based file service.
 *
 * This interface abstracts file upload, download, and URI generation logic.
 * Implementations can differ (REST API, local file system, Firebase, etc.),
 * and can be provided to consumers via Angular’s dependency injection.
 */
interface IBravoStreamFileContract {
    /**
     * Uploads a file stream to the server with configurable options.
     *
     * @param pFileName - The name of the file to upload.
     * @param pFileContent - The file object containing content to upload.
     * @param pConfig - Configuration object specifying upload behavior.
     * @param pConfig.subFolder - Target subfolder where the file should be stored.
     * @param pConfig.fileAccessMode - File access mode (e.g., public, private).
     * @param pConfig.fileOverwriteOption - Strategy when a file with the same name exists.
     * @param pConfig.isTempFile - Whether the file is stored temporarily.
     *
     * @returns Observable that emits {@link IUploadSate} updates representing
     *          progress and completion of the upload.
     */
    uploadFileStream(pFileName: string, pFileContent: File, pConfig: {
        subFolder: string;
        fileAccessMode: FileAccessModeEnum;
        fileOverwriteOption: FileOverwriteOptionEnum;
        isTempFile: boolean;
    }): Observable<IUploadSate>;
    /**
     * Downloads a file stream from the server.
     *
     * @param pFileName - The name of the file to download.
     * @returns Observable that emits {@link IDownload} updates containing
     *          progress information and the downloaded Blob.
     */
    downloadFileStream(pFileName: string): Observable<IDownload>;
    /**
     * Deletes a file from the server or storage location.
     *
     * @param pFiles - The names or path of the file to delete.
     * @returns Observable that emits the deletion response or result.
     */
    deleteFile(pFiles: Array<string>): Observable<object>;
    /**
     * Builds a full file URI from a file name and optional access token.
     *
     * - Normalizes file paths.
     * - Handles static folder mapping.
     * - Appends encrypted tokens for private files.
     *
     * @param pFileName - The input file name or relative path.
     * @param pAccessToken - Optional access token; falls back to default if omitted.
     * @returns The fully resolved file URI string.
     */
    getFileUri(pFileName: string, pAccessToken?: string): string;
    /**
     * Determines whether the current user is the owner of the accessed URL.
     *
     * @returns `true` if the current user owns the file or URL; otherwise `false`.
     */
    isOwnerUrl(pUrl: string): boolean;
}
/**
 * Injection token representing the {@link IBravoStreamFileContract} contract.
 *
 * This token allows Angular DI to inject different implementations of
 * file streaming logic (e.g., API-based, mock, or local storage).
 *
 * @example
 * ```ts
 * providers: [
 *   { provide: USE_STREAM_FILE_CONTRACT, useClass: StreamApiService }
 * ]
 * ```
 */
declare const USE_STREAM_FILE_CONTRACT: InjectionToken<IBravoStreamFileContract>;

/**
 * Parameters for filtering and retrieving notification data.
 */
interface IBravoNotificationDataParam {
    /** List of notification IDs. */
    listNotificationId: string[];
    /** Number of items per page. */
    pageSize: number;
    /**
     * Notification group code (used for categorization).
     */
    notificationGroupCode: string;
    /**
     * Notification status flag.
     * See {@link NotificationStatusFlagEnum}.
     */
    statusFlag: NotificationStatusFlagEnum;
    /**
     * Pagination offset (used for infinite scroll on mobile).
     */
    offset: number;
    /**
     * Search keyword or text filter.
     */
    searchText: string;
    /**
     * Tag type identifier.
     */
    tagType: number;
}
/**
 * Represents a notification marking item.
 */
interface IBravoNotificationMarkItem {
    /** Notification ID. */
    notificationId?: string;
    /** Marking value (e.g., read/unread flag). */
    mark?: number;
}
/**
 * Enumeration of notification status flags.
 */
declare enum NotificationStatusFlagEnum {
    /** Notification has been sent. */
    Sent = 1,
    /** Notification has been received. */
    Received = 2,
    /** Notification has been read. */
    Read = 7
}
declare class BravoNotificationMarkItem implements IBravoNotificationMarkItem {
    notificationId?: string;
    mark?: number;
    constructor(pNotificationId: string, pMark: number);
}
declare class BravoNotificationDataParam implements IBravoNotificationDataParam {
    listNotificationId: string[];
    pageSize: number;
    /**
     * Notification group code
     */
    notificationGroupCode: string;
    /**
     * Status flag
     */
    statusFlag: number;
    /**
     * Used for pagination on mobile (infinite scroll)
     */
    offset: number;
    /**
     * Search text
     */
    searchText: string;
    /**
     * Tag type
     */
    tagType: number;
    constructor(pArgs?: {
        listNotificationId?: string[];
        pageSize?: number;
        notificationGroupCode?: string;
        statusFlag?: number;
        offset?: number;
        searchText?: string;
        tagType?: number;
    });
}
/**
 * Interface defining the Bravo Notification Contract operations.
 */
interface IBravoNotificationContract {
    /**
     * Retrieves notification data based on filter parameters.
     * @param pParams - Optional filtering parameters.
     * @returns An Observable containing a {@link BravoDataTable}.
     */
    getDataByFilter(pParams?: Partial<IBravoNotificationDataParam>): Observable<BravoDataTable>;
    /**
     * Retrieves the list of notification tabs or categories.
     * @returns An Observable containing a {@link BravoDataTable}.
     */
    getListTab(): Observable<BravoDataTable>;
    /**
     * Retrieves the total number of notifications by status flag.
     * @param pStatusFlag - Optional notification status flag.
     * @returns An Observable containing the total count as a string.
     */
    getTotalByMarkFlag(pStatusFlag?: NotificationStatusFlagEnum): Observable<string>;
    /**
     * Marks a list of notifications by their IDs.
     * @param pNotifications - Array of notifications to mark.
     * @returns An Observable indicating the operation result.
     */
    markByListId(pNotifications: IBravoNotificationMarkItem[]): Observable<unknown>;
    /**
     * Marks all notifications as read.
     * @returns An Observable indicating the operation result.
     */
    markAsReadAll(): Observable<unknown>;
    /**
     * Marks all notifications as deleted.
     * @returns An Observable indicating the operation result.
     */
    markAllAsDeleted(): Observable<unknown>;
    /**
     * Updates the active status (isActive) of notifications by ID.
     * @param pIds - List of notification IDs to update.
     * @returns An Observable indicating the operation result.
     */
    updateIsActive(pIds: string[]): Observable<unknown>;
}
/**
 * Injection token used to provide or inject the Notification Contract implementation.
 *
 * This token represents the abstract contract {@link IBravoNotificationContract}
 * which defines the methods for retrieving and updating notification data.
 *
 * It allows UI or other modules to depend on the contract interface
 * instead of directly depending on a specific API or data layer implementation.
 *
 * @example
 * ```ts
 * // Provide implementation in a module or service
 * providers: [
 *   { provide: USE_NOTIFICATION_CONTRACT, useClass: BravoNotificationApiService }
 * ]
 *
 * // Inject in a component or another service
 * constructor(
 *   @Inject(USE_NOTIFICATION_CONTRACT) private readonly notificationContract: IBravoNotificationContract
 * ) {}
 * ```
 */
declare const USE_NOTIFICATION_CONTRACT: InjectionToken<IBravoNotificationContract>;

declare enum BravoDataAccessModeEnum {
    ReadOnly = 0,
    Write = 1
}
declare enum BravoIsActiveEnum {
    Deactive = 0,
    Active = 1,
    Unspecified = 2
}
interface IBravoGeneric {
    readonly injector: Injector;
    applyOwnerCommandPermission: boolean;
    applicationCommandName: string;
    customConnectionName: string;
    defaultTransactionLevel: IsolationLevelEnum;
    dataAccessMode: BravoDataAccessModeEnum;
    cachingCategoryName: string | undefined;
    get businessEntity(): BravoDataSet;
    get isExecuting(): boolean;
    get isCaching(): boolean;
    get sourceName(): string;
    get sourceTable(): BravoDataTable | undefined;
    addTempTable(pzTableName: string): BravoDataTable;
    cancelAll(): void;
    getDbField(pTableName: string, pColumnName: string, pIncludeAlias: boolean): string;
    setApplicationCommandName(pOption: {
        pCommandKey: string;
        pCommandKey0?: string;
        pLayoutName?: string;
        pOwnerCommandKey?: string;
        pDataSourceLayoutName?: string;
        pTemplateName?: string;
    }): void;
    dispose(): void;
    startCaching(): void;
    endCaching(): void;
}

/**TODO: bổ sung docs */
declare enum ComparisonEnum {
    None = 0,
    /**Get a exact value */
    Exact = 1,
    /**Get list including exact value */
    ExactList = 2,
    /**Search accent-liked string */
    AccentLike = 3,
    /**Search ignore-accent-liked string */
    NonAccentLike = 4,
    /** Search multi accent-liked strings using or combination */
    CombineAccentLike = 5,
    /**Search multi ignore-accent-liked strings using or combination */
    CombineNonAccentLike = 6
}
interface IBravoLookupContract extends IBravoGeneric {
    fetchLookupData(pLookupMember: string, pLookupTextCollection: string[], pComparison: ComparisonEnum, pLookupSettings: BravoLookupSettingParams, pPageIndex?: number): Observable<BravoResponseData<BravoDataTable> | undefined>;
    fetchLookupByValues(pLookupValue: unknown[], pLookupSettings: BravoLookupSettingParams, pValueMember?: string | undefined, pFilterByIsActive?: BravoIsActiveEnum): Observable<BravoDataTable>;
    fetchLookupByValuesSync(pLookupValue: unknown[], pLookupSettings: BravoLookupSettingParams, pLookMember?: string | undefined, pFilterByIsActive?: BravoIsActiveEnum): BravoDataTable | undefined;
    getLookupConfigByKey(pLookupKey: string): BravoDataRow | null;
}
declare const USE_LOOKUP_FACTORY_CONTRACT: InjectionToken<() => IBravoLookupContract>;
declare enum PagingModeEnum {
    /** */
    Normal = 0,
    /** */
    JoinPrimaryKey = 1
}
declare const USE_LOOKUP_BINDING_MEMBER: InjectionToken<IBravoLookupContract>;
declare class BravoLookupSettingParams {
    private _lookupSource;
    get lookupSource(): string;
    set lookupSource(pVal: string);
    private _bindingMembersString;
    get bindingMembersString(): string[];
    set bindingMembersString(pVal: string[]);
    private _isDisplayByLanguage;
    get isDisplayByLanguage(): boolean;
    set isDisplayByLanguage(pVal: boolean);
    private _displayTextMember;
    get displayTextMember(): string;
    set displayTextMember(pVal: string);
    private _extraMembers;
    get extraMembers(): string[];
    set extraMembers(pVal: string[]);
    private _filterKeyParam?;
    get filterKeyParam(): string | undefined;
    set filterKeyParam(pVal: string | undefined);
    private _filterKey;
    get filterKey(): string;
    set filterKey(pVal: string);
    private _selectKeyParam?;
    get selectKeyParam(): string | undefined;
    set selectKeyParam(pVal: string | undefined);
    private _selectKey;
    get selectKey(): string;
    set selectKey(pVal: string);
    private _hiddenValueMember;
    get hiddenValueMember(): string;
    set hiddenValueMember(pVal: string);
    private _isLookupDistinct;
    get isLookupDistinct(): boolean;
    set isLookupDistinct(pnValue: boolean);
    private _lookupExtraMembers;
    get lookupExtraMembers(): boolean;
    set lookupExtraMembers(pVal: boolean);
    private _pageSize;
    get pageSize(): number;
    set pageSize(pVal: number);
    private _pagingMode;
    get pagingMode(): PagingModeEnum;
    set pagingMode(pVal: PagingModeEnum);
    private _sort;
    get sort(): string;
    set sort(pVal: string);
    private _valueMember;
    get valueMember(): string;
    set valueMember(pVal: string);
}

declare const USE_EVALUATOR: InjectionToken<IBravoExecutionService>;
declare class BravoCalloutData {
    readonly stepName: string;
    readonly command: BravoDataCommand;
    private _isReturnDataSet;
    get isReturnDataSet(): boolean;
    set isReturnDataSet(pValue: boolean);
    constructor(pzStepName: string, pCommand: BravoDataCommand, pbReturnDataSet: boolean);
}
interface IBravoExecutionService extends IBravoGeneric {
    defaultSelectCommandTimeout: number;
    addCommand(pzCommandKey: string, pzCommandText: string, pCommandType?: CommandTypeEnum): BravoDataCommand;
    getCommand(pCommandKey: string): BravoDataCommand | undefined;
    containsCommand(pzCommandKey: string): boolean;
    setParameterValue(pzCommand: BravoDataCommand | string, pParameterName: string, pParameterValue: unknown): void;
    getParameter(pCommand: BravoDataCommand | string, pzParameterName: string): BravoDataParameter | undefined;
    addParameter(pCommand: BravoDataCommand | string, pParameterName: string, pParameterValue?: unknown, pParameterDirection?: ParameterDirectionEnum): BravoDataParameter;
    getReturnParam(pCommand: BravoDataCommand | string): BravoDataParameter | undefined;
    containsParameter(pCommand: BravoDataCommand | string, pzParameterName: string): boolean;
    insertParameter(pCommand: BravoDataCommand | string, pParameterName: string, pParameterValue?: unknown, pParameterDirection?: ParameterDirectionEnum): BravoDataParameter;
    getDataSet(pzCommandKey?: string, pArgs?: unknown[], pIgnoreSchema?: boolean, pCacheExpiryTime?: number): BravoDataSet | undefined;
    getData(pzCommandKey: string, pArgs?: unknown[], pbIgnoreSchema?: boolean, pCacheExpiryTime?: number): BravoDataTable | undefined;
    readValues(pzCommandKey: string, pArgs?: unknown[]): unknown[] | undefined;
    executeNonQuery(pCommand: string | BravoDataCommand, pArgs?: unknown[]): number;
    deriveParameters(pCommandKey: BravoDataCommand | string): number;
    callOut(pCalloutData: Array<BravoCalloutData>): Map<string, object>;
}

declare enum BravoLayoutTypeEnum {
    Layout = 0,
    FormTemplate = 1,
    GlobalTemplate = 2,
    DataSource = 3,
    SubLayout = 4
}
declare enum BravoLayoutExprTypeEnum {
    Default = 0,
    Expr = 1,
    ParameterValue = 2
}
declare class BravoLayoutExprStruct {
    expr?: string;
    type: BravoLayoutExprTypeEnum;
}
declare const USE_LAYOUT: InjectionToken<IBravoLayoutService>;
interface IBravoLayoutService extends IBravoGeneric {
    tableLayoutExprs: Map<string, BravoLayoutExprStruct[]>;
    getLayoutRow(pLayoutKey: number | string): BravoDataRow | undefined;
    containsLayoutName(pzLayoutName: string): boolean;
    containsLayoutId(pnLayoutId: number): boolean;
    getLayoutData(pLayoutRow: BravoDataRow): Uint8Array | null;
    addLayoutRow(pFormName?: string, pLayoutName?: string, pLayoutData?: unknown, pLayoutType?: number): number;
    initSource(pParams: {
        table?: BravoDataTable;
        layoutId?: number;
        formName?: string;
        templateName?: string;
        layoutNameList?: string[];
        isLoadCompanyLogo?: boolean;
        isLoadGlobalDataSource?: boolean;
        isLoadTemplate?: boolean;
    }): Observable<BravoDataTable>;
}

export { BravoCalloutData, BravoDataAccessModeEnum, BravoIsActiveEnum, BravoLayoutExprStruct, BravoLayoutExprTypeEnum, BravoLayoutTypeEnum, BravoLookupSettingParams, BravoNotificationDataParam, BravoNotificationMarkItem, ComparisonEnum, NotificationStatusFlagEnum, PagingModeEnum, USE_EVALUATOR, USE_LAYOUT, USE_LOOKUP_BINDING_MEMBER, USE_LOOKUP_FACTORY_CONTRACT, USE_NOTIFICATION_CONTRACT, USE_STREAM_FILE_CONTRACT };
export type { IBravoExecutionService, IBravoGeneric, IBravoLayoutService, IBravoLookupContract, IBravoNotificationContract, IBravoNotificationDataParam, IBravoNotificationMarkItem, IBravoStreamFileContract, IDownload, IUploadSate, StateType };
