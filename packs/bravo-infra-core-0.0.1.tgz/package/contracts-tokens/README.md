# contracts-tokens

This library was generated with [Nx](https://nx.dev).

## Running unit tests

Run `nx test contracts-tokens` to execute the unit tests.
