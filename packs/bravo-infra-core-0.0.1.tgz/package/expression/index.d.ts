import * as rxjs from 'rxjs';
import { BravoDataRow, IBravoDataRow, IBravoDataTable, IBravoDataSet, IBravoDataColumn } from '@bravo-infra/core/data';
import { BravoCultureType, BravoLangEnum } from '@bravo-infra/core/utils/global-settings';
import { BravoEventArgs } from '@bravo-infra/core/helper';
import { IBravoExpressionBase } from '@bravo-infra/core/definition';

declare enum DatePartEnum {
    year = 0,
    yy = 1,
    yyyy = 2,
    quarter = 3,
    qq = 4,
    q = 5,
    month = 6,
    mm = 7,
    m = 8,
    dayofyear = 9,
    dy = 10,
    y = 11,
    day = 12,
    dd = 13,
    d = 14,
    week = 15,
    wk = 16,
    ww = 17,
    weekday = 18,
    dw = 19,
    hour = 20,
    hh = 21,
    minute = 22,
    mi = 23,
    n = 24,
    second = 25,
    ss = 26,
    s = 27,
    millisecond = 28,
    ms = 29,
    microsecond = 30,
    mcs = 31,
    mid = 32
}

declare enum OperatorEnum {
    Unknown = 0,// This for internal process
    UnknownFunction = 1,
    Declare = 2,// This for internal process
    Set = 3,// This for internal process
    Value = 4,// This for internal process
    Addition = 5,// +
    Subtraction = 6,// -
    Multiplication = 7,// *
    Division = 8,// /
    Modulus = 9,// %
    Eval = 10,
    Arguments = 11,//,
    Parent = 12,// Parent
    Child = 13,// Child
    MemberAccess = 14,// .
    GreaterThan = 15,// >
    LessThan = 16,// <
    Equal = 17,// =
    Notequal = 18,// <>
    Equality = 19,// ==
    Inequality = 20,// !=
    GreaterThanOrEqual = 21,// >=
    LessThanOrEqual = 22,// <=
    And = 23,
    Or = 24,
    Like = 25,
    In = 26,
    Between = 27,
    Is = 28,
    UnaryPlus = 29,// +
    UnaryNegation = 30,// -
    LogicalNot = 31,// !
    Not = 32,
    Iif = 33,
    Case = 34,
    IsNull = 35,
    Coalesce = 36,
    Convert = 37,
    Empty = 38,
    IsInteger = 39,
    IsNumeric = 40,
    IsDatetime = 41,
    Sqr = 42,
    Abs = 43,
    Sin = 44,
    Cos = 45,
    Round = 46,
    RoundUp = 47,
    RoundDown = 48,
    Ceiling = 49,
    Floor = 50,
    Pow = 51,
    MaxOf = 52,
    MinOf = 53,
    Max = 54,
    Min = 55,
    Sum = 56,
    SumIf = 57,
    Avg = 58,
    Concat = 59,
    Count = 60,
    CountIf = 61,
    Mode = 62,
    Vlookup = 63,
    Hlookup = 64,
    Exists = 65,
    Left = 66,
    Right = 67,
    PadL = 68,
    PadLeft = 69,
    PadR = 70,
    PadRight = 71,
    SubStr = 72,
    SubString = 73,
    CharIndex = 74,
    Replace = 75,
    Stuff = 76,
    Len = 77,
    Length = 78,
    Trim = 79,
    Ltrim = 80,
    Rtrim = 81,
    Str = 82,
    Upper = 83,
    Lower = 84,
    RemoveAccent = 85,
    SpellNumber = 86,
    GeneratePassword = 87,
    RegexMatch = 88,
    RegexReplace = 89,
    RegexExtract = 90,
    DateAdd = 91,
    DateDiff = 92,
    DatePart = 93,
    Hour = 94,
    Minute = 95,
    Second = 96,
    Day = 97,
    Month = 98,
    Year = 99,
    Quarter = 100,
    GetDate = 101,
    GetUtcDate = 102,
    GetDatetime = 103,
    GetUtcDatetime = 104,
    Date = 105,
    Time = 106,
    StartDateOfYear = 107,
    SOYear = 108,
    EndDateOfYear = 109,
    EOYear = 110,
    StartDateOfMonth = 111,
    SOMonth = 112,
    EndDateOfMonth = 113,
    EOMonth = 114,
    StartDateOfQuarter = 115,
    SOQuarter = 116,
    EndDateOfQuarter = 117,
    EOQuarter = 118,
    IsFiscalDate = 119,
    IsSpecialDate = 120,
    Format = 121,
    FormatCurrency = 122,
    FormatQuantity = 123,
    FormatDateRange = 124,
    LangId = 125,
    LangName = 126,
    NameByLang = 127,
    System = 128,
    Config = 129,
    Currency = 130,
    User = 131,
    Branch = 132,
    BranchFilter = 133,
    FiscalYear = 134,
    SignatureText = 135,
    SignatureImage = 136,
    SignatureData = 137,
    CurrentValue = 138,
    TableChanged = 139,
    RowState = 140,
    RowOldValue = 141,
    RowError = 142,
    UpdatedColumn = 143,
    Text = 144,
    ColumnName = 145,
    TableName = 146,
    LastCommand = 147,
    OsMachineName = 148,
    OsDomainName = 149,
    OsUserName = 150,
    ServerName = 151,
    DatabaseName = 152,
    FormCommandName = 153,
    FormUserName = 154,
    LayoutName = 155,
    LayoutId = 156,
    VerifyChecksum = 157,
    TokenRawData = 158,
    TokenSignData = 159,
    TokenSignXml = 160,
    TokenVerifyXml = 161,
    TokenSignDocument = 162,
    Encrypt = 163,
    Decrypt = 164,
    HashValue = 165,
    ImageThumbnail = 166,
    Platform = 167,
    NewId = 168,
    TokenSignString = 169,
    TokenVerifyString = 170,
    GenerateToken = 171,
    VerifyToken = 172,
    Portal = 173,
    Logo = 174,
    Collate = 175,
    As = 176,
    Unicode = 177,
    LayoutTableName = 178,
    DataFormat = 179,
    GetXmlData = 180,
    GetXmlSelectedData = 181,
    GetJsonData = 182,
    GetJsonSelectedData = 183,
    EncodeHtml = 184,
    DecodeHtml = 185,
    Inlist = 186,
    ResourceText = 187,
    PortalConfig = 188
}

declare enum OperatorLevelEnum {
    Operator = 0,
    Function = 1
}

declare enum OperatorTypeEnum {
    Unary = 0,
    Binary = 1
}

declare enum SqlDbTypeEnum {
    BigInt = 0,
    Binary = 1,
    Bit = 2,
    Char = 3,
    DateTime = 4,
    Decimal = 5,
    Float = 6,
    Image = 7,
    Int = 8,
    Money = 9,
    NChar = 10,
    NText = 11,
    NVarChar = 12,
    Real = 13,
    UniqueIdentifier = 14,
    SmallDateTime = 15,
    SmallInt = 16,
    SmallMoney = 17,
    Text = 18,
    Timestamp = 19,
    TinyInt = 20,
    VarBinary = 21,
    VarChar = 22,
    Variant = 23,
    Xml = 25,
    Udt = 29,
    Structured = 30,
    Date = 31,
    Time = 32,
    DateTime2 = 33,
    DateTimeOffset = 34
}

declare class BravoExpression {
    #private;
    static cachedExpressionCollection: Map<string, Array<BravoExpression>>;
    static create(pExpression: string): BravoExpression[];
    static buildExpressionString(pExprs: BravoExpression[]): string | undefined;
    static get Operators(): OperatorDescriptor[];
    /**
     * Return the operator descriptor
     */
    getOperator(pOperatorName: string): OperatorDescriptor | null;
    /**
     * Return the operator name
     */
    getOperatorName(pOperator: OperatorEnum): string;
    /**
     * Return the operator type
     */
    static getOperatorType(pOperator: OperatorEnum): OperatorTypeEnum;
    static isAggregateFunction(pOperator: OperatorEnum): boolean;
    private _operator;
    private _expressions;
    private _value;
    constructor(pOperator?: OperatorEnum, pExpressions?: BravoExpression[], pValue?: unknown);
    get Operator(): OperatorEnum;
    get Expressions(): BravoExpression[];
    get Value(): unknown;
    readonly attributes: BravoExpression[];
    ReplaceWith(pExpression: BravoExpression): void;
    buildString(): string;
}
declare const Empty: BravoExpression;
declare class OperatorDescriptor {
    private _name;
    private _type;
    private _operator;
    private _level;
    private _description?;
    constructor(pOperator: OperatorEnum, pName: string, pType: OperatorTypeEnum, pLevel?: OperatorLevelEnum, pDescription?: string);
    get Name(): string;
    get Type(): OperatorTypeEnum;
    get Operator(): OperatorEnum;
    get Level(): OperatorLevelEnum;
    get Description(): string | undefined;
}
declare class Token {
    private _type;
    private _text;
    private _startLocation;
    private _endLocation;
    constructor(pStartLocation: number, pEndLocation: number, pText: string, pType: TokenTypeEnum);
    get Type(): TokenTypeEnum;
    get Text(): string;
    get StartLocation(): number;
    get EndLocation(): number;
}
declare class ClauseExpression extends BravoExpression {
    static readonly Select = "select";
    static readonly All = "all";
    static readonly Distinct = "distinct";
    static readonly Top = "top";
    static readonly Percent = "percent";
    static readonly SelectList = "select_list";
    static readonly AllColumns = "*";
    static readonly From = "from";
    static readonly TableSource = "table_source";
    static readonly Join = "join";
    static readonly Join_Inner = "inner join";
    static readonly LeftJoin = "left join";
    static readonly LeftJoin_Outer = "left outer join";
    static readonly RightJoin = "right join";
    static readonly RightJoin_Outer = "right outer join";
    static readonly On = "on";
    static readonly GroupBy = "group by";
    static readonly ColumnExpression = "column-expression";
    static readonly Where = "where";
    static readonly SearchCondition = "search_condition";
    static readonly OrderBy = "order by";
    static readonly OrderByExpression = "order_by_expression";
    static readonly RowNumber = "row_number";
    static readonly AscendingOrder = "asc";
    static readonly DescendingOrder = "desc";
    static readonly Over = "over";
    static readonly PartitionBy = "partition by";
    static readonly Case = "case";
    static readonly When = "when";
    static readonly Then = "then";
    static readonly Else = "else";
    static readonly End = "end";
    static readonly clauseTokens: string[];
    private static readonly _keywords;
    static isFunction(pFunc: string): boolean;
    static isJoin(pJoin: string): boolean;
    static isOption(pStr: string, pK: string): boolean;
    static match(pTokens: Array<Token>, pRefPos: {
        pos: number;
    }, pOutParams: {
        keyword: string;
        revert: number;
    }): boolean;
    private readonly _options;
    zName: string;
    constructor(pName: string, pExpression?: BravoExpression);
    addOption(pClause: ClauseExpression): void;
    addOption(pKey: string, pExpression?: BravoExpression): void;
    buildString(): string;
    private _buildFromClause;
    private _buildSelect;
    containsOption(pKey: string): boolean;
    getOption(pKey: string): ClauseExpression | undefined;
    getOptions(pKey?: string): ClauseExpression[];
    getJoinOptions(): ClauseExpression[];
    removeOptions(pKey: string): void;
}
interface IObjectType<T> {
    [key: number]: T;
}
declare class Stack<T> {
    private _stack;
    private _count;
    constructor();
    get isEmpty(): boolean;
    get size(): number;
    push(pValue: T): void;
    pop(): T;
    peek(): T;
    clear(): void;
    print(): string;
}
declare enum TokenTypeEnum {
    WhiteSpace = 0,
    Word = 1,
    Quote = 2,
    UnicodeQuote = 3,
    Operator = 4,
    Function = 5,
    Numeric = 6,
    Name = 7,
    Terminator = 8
}

declare class ColumnValueEventArgs extends BravoEventArgs {
    readonly columnName: string;
    readonly dataRow: BravoDataRow;
    value: unknown;
    constructor(pDataRow: BravoDataRow, pColumnName: string);
}

declare class ParameterValueEventArgs extends BravoEventArgs {
    readonly name: string;
    value: unknown;
    constructor(pName: string);
}

declare class PropertyValueEventArgs extends BravoEventArgs {
    readonly propertyName: string;
    readonly propertyOwner: unknown;
    value: unknown;
    constructor(pPropertyOwner: unknown, pzPropertyName: string);
}

declare class ValueEventArgs extends BravoEventArgs {
    readonly Operator: OperatorEnum;
    readonly arguments: unknown[];
    value: unknown;
    constructor(pOperator: OperatorEnum, pArguments?: unknown[]);
}

interface IBravoExpressionEvaluator extends IBravoExpressionBase {
    isTrue(pzExpression: string, pDataItem?: IBravoDataRow | Record<string, unknown>): boolean;
    evaluate(pzExpression: string, pDataItem?: IBravoDataRow | Record<string, unknown>): unknown;
    evaluateText(pzText: string, pDataItem?: IBravoDataRow | Record<string, unknown>, pCulture?: BravoCultureType): string;
    evaluateRtfText(pzText: string, pDataItem?: IBravoDataRow | Record<string, unknown>, pCulture?: BravoCultureType): string;
}

declare const ExprPattern: RegExp;
declare const RtfExprPattern: RegExp;
declare const ExprGroupPattern = "(?:{=)(?<expr>[^}]+)(?:})";
declare const QuoteExprPattern = "(?:{=)(?<='{=)(?<quote_expr>[^}]+)(?:})";
declare const TableSourceKey = "Source";
declare const TableAliasKey = "Alias";
declare const TableExpressionCollection = "Expressions";
declare const INVALID_VALUE = "#VALUE";
declare class BravoExpressionEvaluator implements IBravoExpressionEvaluator {
    #private;
    private static readonly _valueRequired$;
    /**
     * Static event occurs when a global system value is required
     */
    static get valueRequired$(): rxjs.Observable<ValueEventArgs>;
    static containsExpression(pzText: string): boolean;
    static escapeRtfUnicode(pzText: string): string;
    /**
     * Print the expression diagram
     */
    static print(pExpression: BravoExpression | BravoExpression[]): string;
    static quoteExpression(pzExpression: string): string;
    static unquoteExpression(pzExpression: string): string;
    static useAliasName(pTable: IBravoDataTable): boolean;
    static getAliasName(pTable: IBravoDataTable): string;
    /**
     * Return table name from alias if available
     */
    static getTableName(pzAlias: string, pDataSet: IBravoDataSet): string;
    static getSourceName(pzAlias: string, pDataSet: IBravoDataSet): string;
    static getSourceName(pTable: IBravoDataTable): string;
    static getDbColumnExpression(pColumn: IBravoDataColumn, pIncludeAlias?: boolean): string;
    /**
     * Return the value is expression keyword
     */
    private static _isKeyword;
    /**
     * The generic version
     */
    private static _convert;
    /**
     * Compare object
     */
    static compare(pLhs: unknown, pRhs: unknown): number;
    private static _getPriorityType;
    private static _isTrueValue;
    /**
     * Return result of like function
     * @param pPattern
     * @param pValue
     */
    private static _like;
    private static _getLikeToken;
    /**
     * Addition (+) operator
     * @param pLhs
     * @param pRhs
     */
    static addition(pLhs: unknown, pRhs: unknown): number | null;
    /**
     * Subtraction (-) operator
     * @param pLhs
     * @param pRhs
     */
    static subtraction(pLhs: unknown, pRhs: unknown): number | null;
    /**
     * Multiplication (*) operator
     * @param pLhs
     * @param pRhs
     */
    static multiplication(pLhs: unknown, pRhs: unknown): number;
    /**
     * Division (/) operator
     * @param pLhs
     * @param pRhs
     */
    static division(pLhs: unknown, pRhs: unknown): number;
    /**
     * Modulus (%) operator
     * @param pLhs
     * @param pRhs
     */
    static modulus(pLhs: unknown, pRhs: unknown): number;
    /**
     * Abs operator
     * @param pValue
     */
    static abs(pValue: unknown): number | null | undefined;
    static fix(pNum: number): number;
    static datePart(pDatePart: DatePartEnum, pDate: unknown): number;
    private static _dateAdd;
    private static _dateDiff;
    private static _convertDate;
    static spellAmountUnit(pnNumber: number, pLanguage: BravoLangEnum): string;
    static spellNumber(pnNumber: number, pLanguage: BravoLangEnum, pnDecimals?: number, pzBasicCurrencyUnit?: string, pzFractionalCurrencyUnit?: string): string;
    private static _numberToWords;
    private static _spellNumberEn;
    private static _spellNumberVi;
    /**
     * Get unevaluate argument expression
     * @param pExpression
     */
    static getArgumentExpressions(pExpression: BravoExpression): BravoExpression[];
    /**
     * Get unevaluate argument expression
     * @param pExpression
     * @param pList
     */
    private static _loadArgumentExpression;
    private static _getMemberAccessExpressions;
    private static _loadMemberAccessExpression;
    private readonly _dataRowRequired$;
    get dataRowRequired$(): rxjs.Observable<ParameterValueEventArgs>;
    private readonly _localValueRequired$;
    get localValueRequired$(): rxjs.Observable<ValueEventArgs>;
    private readonly _defaultValueRequired$;
    get defaultValueRequired$(): rxjs.Observable<ValueEventArgs>;
    private readonly _aggregateSourceRequired$;
    get aggregateSourceRequired$(): rxjs.Observable<ParameterValueEventArgs>;
    private readonly _columnValueRequired$;
    get columnValueRequired$(): rxjs.Observable<ColumnValueEventArgs>;
    private readonly _propertyValueRequired$;
    get propertyValueRequired$(): rxjs.Observable<PropertyValueEventArgs>;
    private _evaluatingObject;
    private _evaluatingDataRow?;
    private _aggregateCalculating;
    dispose(): void;
    /**
     * Enable tracing values while evaluating expression.
     */
    bEnableTracing: boolean;
    private _tracer?;
    /**
     * Return tracing values while evaluating expression.
     */
    get tracer(): string;
    private _variables?;
    /**
     * Declare variables.
     */
    get variables(): Map<string, unknown>;
    isTrue(pzExpression: string | undefined, pDataItem?: unknown): boolean;
    /**
     * Evaluate BrSafeAny expression in format {=expr} existing in an indicated string
     * @param pzText
     * @param pDataItem object || DataRow
     */
    evaluateText(pzText: string | undefined, pDataItem?: unknown, pCulture?: BravoCultureType | null): string;
    /**
     * Evaluate BrSafeAny expression in format {=expr} existing in an indicated string
     * @param pzText
     * @param pDataItem object || DataRow
     */
    evaluateRtfText(pzText: string, pDataItem?: unknown, pCulture?: BravoCultureType | null): string;
    zEvaluateTextErrorValue?: string;
    defaultCulture: BravoCultureType | null;
    /**
     * Evaluate BrSafeAny expression in format {=expr} existing in an indicated string
     * @param pzText
     * @param pDataItem
     * @param pbClearTracing
     * @param pbRtfFormat
     */
    private _internalEvaluateText;
    evaluate(pzExpression: string | undefined, pDataItem?: unknown): unknown;
    private _evaluateCollection;
    /**
     * Evaluate the expression
     * @param pExpression
     */
    evaluateExpression(pExpression: BravoExpression): unknown;
    private _getCurrentDateTime;
    private _evaluateSourceDataExpression;
    private _evaluateValueExpression;
    private _evaluateObject;
    private _evaluateDataRow;
    private static _getAggregateSource;
    private _evaluateAggregateExpression;
    private readonly _parentRowRequired$;
    get parentRowRequired$(): rxjs.Observable<ParameterValueEventArgs>;
    protected _raiseOnParentRowRequired(pEval?: BravoExpressionEvaluator | null): BravoDataRow | null;
    private readonly _parameterValueRequired$;
    get parameterValueRequired$(): rxjs.Observable<ParameterValueEventArgs>;
    protected _raiseOnParameterValueRequired(pzName: string, pEval?: BravoExpressionEvaluator | null): unknown;
    getFormat(pzFormat: string): string;
    static isTableExpression(pExpr: BravoExpression): boolean;
}

export { BravoExpression, BravoExpressionEvaluator, ClauseExpression, ColumnValueEventArgs, DatePartEnum, Empty, ExprGroupPattern, ExprPattern, INVALID_VALUE, OperatorDescriptor, OperatorEnum, OperatorLevelEnum, OperatorTypeEnum, ParameterValueEventArgs, PropertyValueEventArgs, QuoteExprPattern, RtfExprPattern, SqlDbTypeEnum, Stack, TableAliasKey, TableExpressionCollection, TableSourceKey, Token, ValueEventArgs };
export type { IBravoExpressionEvaluator, IObjectType };
