import { CollectionView, CollectionViewGroup, SortDescription, PropertyGroupDescription, ObservableArray as ObservableArray$1, NotifyCollectionChangedEventArgs, NotifyCollectionChangedAction, Event } from '@mescius/wijmo';
import { BravoStringExtensions, BravoNumberExtensions, BravoArrayExtensions, BravoBooleanExtensions, BravoConverterExtensions, BravoEnumExtensions, tryCast, BravoStringBuilder, NotifyCollectionChangedActionEnum, ObservableArray, isString, JsonProperty, JsonConstants, JsonObject, isUndefined, BravoRegexes, BravoObjectExtensions, BravoUTF8 } from '@bravo-infra/core/utils/data-extensions';
import { BravoInvalidCastException, BravoCancelEventArgs, BravoArgumentNullException, BravoDataEventArgs, BravoListChangedEventArgs, ListChangedTypeEnum, BravoEventArgs } from '@bravo-infra/core/helper';
import { BravoMoment, BravoDateExtensions } from '@bravo-infra/core/utils/dates';
import { BravoAppSettings } from '@bravo-infra/core/utils/global-settings';
import { __decorate, __metadata } from 'tslib';
import { InputSetter } from '@bravo-infra/core/ng-extensions';
import { Subject } from 'rxjs';

class BravoCollectionView extends CollectionView {
}

class BravoCollectionViewGroup extends CollectionViewGroup {
}

class BravoSortDescription extends SortDescription {
}

class BravoPropertyGroupDescription extends PropertyGroupDescription {
}

class BravoConstraint {
    dispose() {
        //
    }
    #name;
    get constraintName() {
        return this.#name;
    }
    set constraintName(pVal) {
        if (pVal == null)
            pVal = '';
        this.#name = pVal;
    }
    _inCollection = false;
    get inCollection() {
        return this._inCollection;
    }
    set inCollection(pValue) {
        this._inCollection = pValue;
    }
}

var TypeCodeEnum;
(function (TypeCodeEnum) {
    TypeCodeEnum[TypeCodeEnum["Empty"] = 0] = "Empty";
    TypeCodeEnum[TypeCodeEnum["Object"] = 1] = "Object";
    TypeCodeEnum[TypeCodeEnum["DBNull"] = 2] = "DBNull";
    TypeCodeEnum[TypeCodeEnum["Boolean"] = 3] = "Boolean";
    TypeCodeEnum[TypeCodeEnum["Char"] = 4] = "Char";
    TypeCodeEnum[TypeCodeEnum["SByte"] = 5] = "SByte";
    TypeCodeEnum[TypeCodeEnum["Byte"] = 6] = "Byte";
    TypeCodeEnum[TypeCodeEnum["Int16"] = 7] = "Int16";
    TypeCodeEnum[TypeCodeEnum["UInt16"] = 8] = "UInt16";
    TypeCodeEnum[TypeCodeEnum["Int32"] = 9] = "Int32";
    TypeCodeEnum[TypeCodeEnum["UInt32"] = 10] = "UInt32";
    TypeCodeEnum[TypeCodeEnum["Int64"] = 11] = "Int64";
    TypeCodeEnum[TypeCodeEnum["UInt64"] = 12] = "UInt64";
    TypeCodeEnum[TypeCodeEnum["Single"] = 13] = "Single";
    TypeCodeEnum[TypeCodeEnum["Double"] = 14] = "Double";
    TypeCodeEnum[TypeCodeEnum["Decimal"] = 15] = "Decimal";
    TypeCodeEnum[TypeCodeEnum["DateTime"] = 16] = "DateTime";
    TypeCodeEnum[TypeCodeEnum["String"] = 18] = "String";
    TypeCodeEnum[TypeCodeEnum["ByteArray"] = 19] = "ByteArray";
})(TypeCodeEnum || (TypeCodeEnum = {}));

var DataRowStateEnum;
(function (DataRowStateEnum) {
    DataRowStateEnum[DataRowStateEnum["Detached"] = 1] = "Detached";
    DataRowStateEnum[DataRowStateEnum["Unchanged"] = 2] = "Unchanged";
    DataRowStateEnum[DataRowStateEnum["Added"] = 4] = "Added";
    DataRowStateEnum[DataRowStateEnum["Deleted"] = 8] = "Deleted";
    DataRowStateEnum[DataRowStateEnum["Modified"] = 16] = "Modified";
})(DataRowStateEnum || (DataRowStateEnum = {}));

var DataRowVersionEnum;
(function (DataRowVersionEnum) {
    DataRowVersionEnum[DataRowVersionEnum["Original"] = 256] = "Original";
    DataRowVersionEnum[DataRowVersionEnum["Current"] = 512] = "Current";
    DataRowVersionEnum[DataRowVersionEnum["Proposed"] = 1024] = "Proposed";
    DataRowVersionEnum[DataRowVersionEnum["Default"] = 1536] = "Default";
})(DataRowVersionEnum || (DataRowVersionEnum = {}));

var DataRowActionEnum;
(function (DataRowActionEnum) {
    DataRowActionEnum[DataRowActionEnum["Nothing"] = 0] = "Nothing";
    DataRowActionEnum[DataRowActionEnum["Delete"] = 1] = "Delete";
    DataRowActionEnum[DataRowActionEnum["Change"] = 2] = "Change";
    DataRowActionEnum[DataRowActionEnum["Rollback"] = 4] = "Rollback";
    DataRowActionEnum[DataRowActionEnum["Commit"] = 8] = "Commit";
    DataRowActionEnum[DataRowActionEnum["Add"] = 16] = "Add";
    DataRowActionEnum[DataRowActionEnum["ChangeOriginal"] = 32] = "ChangeOriginal";
    DataRowActionEnum[DataRowActionEnum["ChangeCurrentAndOriginal"] = 64] = "ChangeCurrentAndOriginal";
})(DataRowActionEnum || (DataRowActionEnum = {}));

var RuleEnum;
(function (RuleEnum) {
    RuleEnum[RuleEnum["None"] = 0] = "None";
    RuleEnum[RuleEnum["Cascade"] = 1] = "Cascade";
    RuleEnum[RuleEnum["SetNull"] = 2] = "SetNull";
    RuleEnum[RuleEnum["SetDefault"] = 3] = "SetDefault";
})(RuleEnum || (RuleEnum = {}));

// TODO:Cuongnc add doc
var MissingSchemaActionEnum;
(function (MissingSchemaActionEnum) {
    MissingSchemaActionEnum[MissingSchemaActionEnum["Add"] = 1] = "Add";
    MissingSchemaActionEnum[MissingSchemaActionEnum["Ignore"] = 2] = "Ignore";
    MissingSchemaActionEnum[MissingSchemaActionEnum["Error"] = 3] = "Error";
    MissingSchemaActionEnum[MissingSchemaActionEnum["AddWithKey"] = 4] = "AddWithKey";
})(MissingSchemaActionEnum || (MissingSchemaActionEnum = {}));

var BravoXmlStringTypeEnum;
(function (BravoXmlStringTypeEnum) {
    BravoXmlStringTypeEnum[BravoXmlStringTypeEnum["AttributeMapping"] = 0] = "AttributeMapping";
    BravoXmlStringTypeEnum[BravoXmlStringTypeEnum["ElementMappingWithSchema"] = 1] = "ElementMappingWithSchema";
})(BravoXmlStringTypeEnum || (BravoXmlStringTypeEnum = {}));
var XmlWriteModeEnum;
(function (XmlWriteModeEnum) {
    //
    // Summary:
    //     Writes the current contents of the System.Data.DataSet as XML data with the relational
    //     structure as inline XSD schema. If the System.Data.DataSet has only a schema
    //     with no data, only the inline schema is written. If the System.Data.DataSet does
    //     not have a current schema, nothing is written.
    XmlWriteModeEnum[XmlWriteModeEnum["WriteSchema"] = 0] = "WriteSchema";
    //
    // Summary:
    //     Writes the current contents of the System.Data.DataSet as XML data, without an
    //     XSD schema. If no data is loaded into the System.Data.DataSet, nothing is written.
    XmlWriteModeEnum[XmlWriteModeEnum["IgnoreSchema"] = 1] = "IgnoreSchema";
    //
    // Summary:
    //     Writes the entire System.Data.DataSet as a DiffGram, including original and current
    //     values. To generate a DiffGram containing only changed values, call System.Data.DataSet.GetChanges,
    //     and then call System.Data.DataSet.WriteXml(System.IO.Stream) as a DiffGram on
    //     the returned System.Data.DataSet.
    XmlWriteModeEnum[XmlWriteModeEnum["DiffGram"] = 2] = "DiffGram";
})(XmlWriteModeEnum || (XmlWriteModeEnum = {}));
var XmlReadModeEnum;
(function (XmlReadModeEnum) {
    //
    // Summary:
    //     Default.
    XmlReadModeEnum[XmlReadModeEnum["Auto"] = 0] = "Auto";
    //
    // Summary:
    //     Reads any inline schema and loads the data. If the System.Data.DataSet already
    //     contains schema, new tables may be added to the schema, but an exception is thrown
    //     if any tables in the inline schema already exist in the System.Data.DataSet.
    XmlReadModeEnum[XmlReadModeEnum["ReadSchema"] = 1] = "ReadSchema";
    //
    // Summary:
    //     Ignores any inline schema and reads data into the existing System.Data.DataSet
    //     schema. If any data does not match the existing schema, it is discarded (including
    //     data from differing namespaces defined for the System.Data.DataSet). If the data
    //     is a DiffGram, IgnoreSchema has the same functionality as DiffGram.
    XmlReadModeEnum[XmlReadModeEnum["IgnoreSchema"] = 2] = "IgnoreSchema";
    //
    // Summary:
    //     Ignores any inline schema, infers schema from the data and loads the data. If
    //     the System.Data.DataSet already contains a schema, the current schema is extended
    //     by adding new tables or adding columns to existing tables. An exception is thrown
    //     if the inferred table already exists but with a different namespace, or if any
    //     of the inferred columns conflict with existing columns.
    XmlReadModeEnum[XmlReadModeEnum["InferSchema"] = 3] = "InferSchema";
    //
    // Summary:
    //     Reads a DiffGram, applying changes from the DiffGram to the System.Data.DataSet.
    //     The semantics are identical to those of a System.Data.DataSet.Merge(System.Data.DataSet)
    //     operation. As with the System.Data.DataSet.Merge(System.Data.DataSet) operation,
    //     System.Data.DataRow.RowState values are preserved. Input to System.Data.DataSet.ReadXml(System.Xml.XmlReader)
    //     with DiffGrams should only be obtained using the output from System.Data.DataSet.WriteXml(System.IO.Stream)
    //     as a DiffGram.
    XmlReadModeEnum[XmlReadModeEnum["DiffGram"] = 4] = "DiffGram";
    //
    // Summary:
    //     Reads XML fragments, such as those generated by executing FOR XML queries, against
    //     an instance of SQL Server. When System.Data.EXmlReadMode is set to Fragment, the
    //     default namespace is read as the inline schema.
    XmlReadModeEnum[XmlReadModeEnum["Fragment"] = 5] = "Fragment";
    //
    // Summary:
    //     Ignores any inline schema, infers a strongly typed schema from the data, and
    //     loads the data. If the type cannot be inferred from the data, it is interpreted
    //     as string data. If the System.Data.DataSet already contains a schema, the current
    //     schema is extended, either by adding new tables or by adding columns to existing
    //     tables. An exception is thrown if the inferred table already exists but with
    //     a different namespace, or if any of the inferred columns conflict with existing
    //     columns.
    XmlReadModeEnum[XmlReadModeEnum["InferTypedSchema"] = 6] = "InferTypedSchema";
})(XmlReadModeEnum || (XmlReadModeEnum = {}));

var DataViewRowStateEnum;
(function (DataViewRowStateEnum) {
    DataViewRowStateEnum[DataViewRowStateEnum["None"] = 0] = "None";
    DataViewRowStateEnum[DataViewRowStateEnum["Unchanged"] = 2] = "Unchanged";
    DataViewRowStateEnum[DataViewRowStateEnum["Added"] = 4] = "Added";
    DataViewRowStateEnum[DataViewRowStateEnum["Deleted"] = 8] = "Deleted";
    DataViewRowStateEnum[DataViewRowStateEnum["ModifiedCurrent"] = 16] = "ModifiedCurrent";
    DataViewRowStateEnum[DataViewRowStateEnum["CurrentRows"] = 22] = "CurrentRows";
    DataViewRowStateEnum[DataViewRowStateEnum["ModifiedOriginal"] = 32] = "ModifiedOriginal";
    DataViewRowStateEnum[DataViewRowStateEnum["OriginalRows"] = 42] = "OriginalRows";
})(DataViewRowStateEnum || (DataViewRowStateEnum = {}));

var DbTypeEnum;
(function (DbTypeEnum) {
    DbTypeEnum[DbTypeEnum["AnsiString"] = 0] = "AnsiString";
    DbTypeEnum[DbTypeEnum["Binary"] = 1] = "Binary";
    DbTypeEnum[DbTypeEnum["Byte"] = 2] = "Byte";
    DbTypeEnum[DbTypeEnum["Boolean"] = 3] = "Boolean";
    DbTypeEnum[DbTypeEnum["Currency"] = 4] = "Currency";
    DbTypeEnum[DbTypeEnum["Date"] = 5] = "Date";
    DbTypeEnum[DbTypeEnum["DateTime"] = 6] = "DateTime";
    DbTypeEnum[DbTypeEnum["Decimal"] = 7] = "Decimal";
    DbTypeEnum[DbTypeEnum["Double"] = 8] = "Double";
    DbTypeEnum[DbTypeEnum["Guid"] = 9] = "Guid";
    DbTypeEnum[DbTypeEnum["Int16"] = 10] = "Int16";
    DbTypeEnum[DbTypeEnum["Int32"] = 11] = "Int32";
    DbTypeEnum[DbTypeEnum["Int64"] = 12] = "Int64";
    DbTypeEnum[DbTypeEnum["Object"] = 13] = "Object";
    DbTypeEnum[DbTypeEnum["SByte"] = 14] = "SByte";
    DbTypeEnum[DbTypeEnum["Single"] = 15] = "Single";
    DbTypeEnum[DbTypeEnum["String"] = 16] = "String";
    DbTypeEnum[DbTypeEnum["Time"] = 17] = "Time";
    DbTypeEnum[DbTypeEnum["UInt16"] = 18] = "UInt16";
    DbTypeEnum[DbTypeEnum["UInt32"] = 19] = "UInt32";
    DbTypeEnum[DbTypeEnum["UInt64"] = 20] = "UInt64";
    DbTypeEnum[DbTypeEnum["VarNumeric"] = 21] = "VarNumeric";
    DbTypeEnum[DbTypeEnum["AnsiStringFixedLength"] = 22] = "AnsiStringFixedLength";
    DbTypeEnum[DbTypeEnum["StringFixedLength"] = 23] = "StringFixedLength";
    DbTypeEnum[DbTypeEnum["Xml"] = 25] = "Xml";
    DbTypeEnum[DbTypeEnum["DateTime2"] = 26] = "DateTime2";
    DbTypeEnum[DbTypeEnum["DateTimeOffset"] = 27] = "DateTimeOffset";
})(DbTypeEnum || (DbTypeEnum = {}));

var SerializeOptionEnum;
(function (SerializeOptionEnum) {
    SerializeOptionEnum[SerializeOptionEnum["Data"] = 1] = "Data";
    SerializeOptionEnum[SerializeOptionEnum["Schema"] = 2] = "Schema";
    SerializeOptionEnum[SerializeOptionEnum["Relations"] = 4] = "Relations";
    SerializeOptionEnum[SerializeOptionEnum["ExtendedProperties"] = 8] = "ExtendedProperties";
    SerializeOptionEnum[SerializeOptionEnum["ViewSort"] = 16] = "ViewSort";
    SerializeOptionEnum[SerializeOptionEnum["SuspendConstraint"] = 32] = "SuspendConstraint";
    SerializeOptionEnum[SerializeOptionEnum["AcceptChanges"] = 64] = "AcceptChanges";
    SerializeOptionEnum[SerializeOptionEnum["Insert"] = 128] = "Insert";
    SerializeOptionEnum[SerializeOptionEnum["CreateNonExistTable"] = 256] = "CreateNonExistTable";
    //ExcludedProperties = 512,
    SerializeOptionEnum[SerializeOptionEnum["RowState"] = 512] = "RowState";
    //DetachedRow = 1024,
    SerializeOptionEnum[SerializeOptionEnum["Default"] = 99] = "Default";
    SerializeOptionEnum[SerializeOptionEnum["All"] = 123] = "All";
})(SerializeOptionEnum || (SerializeOptionEnum = {}));

var ParameterDirectionEnum;
(function (ParameterDirectionEnum) {
    ParameterDirectionEnum[ParameterDirectionEnum["Input"] = 1] = "Input";
    ParameterDirectionEnum[ParameterDirectionEnum["Output"] = 2] = "Output";
    ParameterDirectionEnum[ParameterDirectionEnum["InputOutput"] = 3] = "InputOutput";
    ParameterDirectionEnum[ParameterDirectionEnum["ReturnValue"] = 6] = "ReturnValue";
})(ParameterDirectionEnum || (ParameterDirectionEnum = {}));

var CommandTypeEnum;
(function (CommandTypeEnum) {
    CommandTypeEnum[CommandTypeEnum["Procedure"] = 0] = "Procedure";
    CommandTypeEnum[CommandTypeEnum["Function"] = 1] = "Function";
    CommandTypeEnum[CommandTypeEnum["Insert"] = 2] = "Insert";
    CommandTypeEnum[CommandTypeEnum["Update"] = 3] = "Update";
    CommandTypeEnum[CommandTypeEnum["Api"] = 4] = "Api";
})(CommandTypeEnum || (CommandTypeEnum = {}));

var UpdateRowSourceEnum;
(function (UpdateRowSourceEnum) {
    UpdateRowSourceEnum[UpdateRowSourceEnum["None"] = 0] = "None";
    UpdateRowSourceEnum[UpdateRowSourceEnum["OutputParameters"] = 1] = "OutputParameters";
    UpdateRowSourceEnum[UpdateRowSourceEnum["FirstReturnedRecord"] = 2] = "FirstReturnedRecord";
    UpdateRowSourceEnum[UpdateRowSourceEnum["Both"] = 3] = "Both";
})(UpdateRowSourceEnum || (UpdateRowSourceEnum = {}));

var IsolationLevelEnum;
(function (IsolationLevelEnum) {
    //
    // Summary:
    //     A different isolation level than the one specified is being used, but the level
    //     cannot be determined.
    IsolationLevelEnum[IsolationLevelEnum["Unspecified"] = -1] = "Unspecified";
    //
    // Summary:
    //     The pending changes from more highly isolated transactions cannot be overwritten.
    IsolationLevelEnum[IsolationLevelEnum["Chaos"] = 16] = "Chaos";
    //
    // Summary:
    //     A dirty read is possible, meaning that no shared locks are issued and no exclusive
    //     locks are honored.
    IsolationLevelEnum[IsolationLevelEnum["ReadUncommitted"] = 256] = "ReadUncommitted";
    //
    // Summary:
    //     Shared locks are held while the data is being read to avoid dirty reads, but
    //     the data can be changed before the end of the transaction, resulting in non-repeatable
    //     reads or phantom data.
    IsolationLevelEnum[IsolationLevelEnum["ReadCommitted"] = 4096] = "ReadCommitted";
    //
    // Summary:
    //     Locks are placed on all data that is used in a query, preventing other users
    //     from updating the data. Prevents non-repeatable reads but phantom rows are still
    //     possible.
    IsolationLevelEnum[IsolationLevelEnum["RepeatableRead"] = 65536] = "RepeatableRead";
    //
    // Summary:
    //     A range lock is placed on the System.Data.DataSet, preventing other users from
    //     updating or inserting rows into the dataset until the transaction is complete.
    IsolationLevelEnum[IsolationLevelEnum["Serializable"] = 1048576] = "Serializable";
    //
    // Summary:
    //     Reduces blocking by storing a version of data that one application can read while
    //     another is modifying the same data. Indicates that from one transaction you cannot
    //     see changes made in other transactions, even if you requery.
    IsolationLevelEnum[IsolationLevelEnum["Snapshot"] = 16777216] = "Snapshot";
})(IsolationLevelEnum || (IsolationLevelEnum = {}));

class BravoDataConvertUtil {
    static getType(pValue) {
        if (BravoStringExtensions.isString(pValue))
            return TypeCodeEnum.String;
        if (BravoNumberExtensions.isIntegerType(pValue))
            return TypeCodeEnum.Int32;
        if (BravoNumberExtensions.isNumericValue(pValue))
            return TypeCodeEnum.Decimal;
        if (BravoMoment.isDate(pValue))
            return TypeCodeEnum.DateTime;
        if (BravoArrayExtensions.isArray(pValue))
            return TypeCodeEnum.ByteArray;
        return TypeCodeEnum.Object;
    }
    static isDateValid(pValue, pFormat) {
        let parsedDate;
        if (!pFormat) {
            parsedDate = new Date(pValue);
        }
        else {
            parsedDate = BravoMoment.parseDate(pValue, pFormat).toDate();
        }
        return BravoMoment.isValid(parsedDate) ? parsedDate : false;
    }
    static isNumericType(pType) {
        return (pType == TypeCodeEnum.Byte ||
            pType == TypeCodeEnum.Decimal ||
            pType == TypeCodeEnum.Double ||
            pType == TypeCodeEnum.Int16 ||
            pType == TypeCodeEnum.Int32 ||
            pType == TypeCodeEnum.Int64 ||
            pType == TypeCodeEnum.SByte ||
            pType == TypeCodeEnum.Single ||
            pType == TypeCodeEnum.UInt16 ||
            pType == TypeCodeEnum.UInt32 ||
            pType == TypeCodeEnum.UInt64);
    }
    static isNumericValue(pValue, pOutArgs) {
        if (pValue == null) {
            pOutArgs.num = 0;
            return false;
        }
        let valStr = BravoStringExtensions.format('{0}', pValue).trim();
        let isPercentage = false;
        const percentSign = '%';
        if (valStr.startsWith(percentSign) || valStr.endsWith(percentSign)) {
            isPercentage = true;
            valStr = BravoStringExtensions.trimChars(valStr, percentSign).trim();
        }
        if (valStr.includes(','))
            valStr = valStr.replace(/,/g, '');
        try {
            const val = this.convertValue(valStr, TypeCodeEnum.Decimal);
            if (val != null && !isNaN(val)) {
                pOutArgs.num = isPercentage ? val / 100 : val;
                return true;
            }
        }
        catch (ex) {
            console.error(ex);
            return false;
        }
        pOutArgs.num = 0;
        return false;
    }
    static convertValue(pValue, pType, pCulture) {
        if (pValue == null || pValue == undefined)
            return pValue;
        if (pType == TypeCodeEnum.Boolean)
            return BravoBooleanExtensions.asBoolean(pValue);
        if (pType == TypeCodeEnum.DateTime) {
            if (BravoMoment.isDate(pValue))
                return new BravoMoment(pValue).toDate();
            try {
                if (!BravoStringExtensions.isString(pValue))
                    pValue = pValue.toString();
                const culture = (pCulture?.substring(0, 2) || 'en-US');
                return BravoMoment.autoParseDate(pValue, culture)?.toDate();
            }
            catch {
                throw new BravoInvalidCastException();
            }
        }
        if ((pType == TypeCodeEnum.Byte || pType == TypeCodeEnum.Int16) && BravoBooleanExtensions.isBoolean(pValue))
            return BravoBooleanExtensions.asBoolean(pValue);
        if (this.isNumericType(pType)) {
            if (BravoNumberExtensions.isNumber(pValue))
                return BravoNumberExtensions.asNumber(pValue);
            const val = Number(pValue);
            if (!isNaN(val))
                return val;
            throw new Error('Input string was not in a correct format');
        }
        if (pType == TypeCodeEnum.ByteArray && BravoStringExtensions.isString(pValue))
            return BravoConverterExtensions.fromBase64String(pValue);
        if (pType != TypeCodeEnum.String) {
            if (pValue instanceof Uint8Array)
                return pValue;
            if (pValue instanceof Array)
                return pValue;
            if (pValue instanceof Map)
                return pValue;
            if (pType == TypeCodeEnum.Object && BravoStringExtensions.isString(pValue))
                return pValue;
            if (BravoStringExtensions.isNullOrEmpty(pValue))
                return pValue;
        }
        if (pType == TypeCodeEnum.Object)
            return pValue;
        return `${pValue}`;
    }
    static compareValue(pVal1, pVal2, pType, pbIgnoreCaseString = false) {
        if ((pVal1 === null || pVal1 === undefined) && (pVal2 === null || pVal2 === undefined))
            return true;
        if (pType == TypeCodeEnum.String) {
            let val1 = BravoStringExtensions.format('{0}', pVal1);
            if (val1.length > 1)
                val1 = val1.trimEnd();
            let val2 = BravoStringExtensions.format('{0}', pVal2);
            if (val2.length > 1)
                val2 = val2.trimEnd();
            if (BravoStringExtensions.compareStrings(val1, val2, pbIgnoreCaseString))
                return true;
        }
        if (this.isNumericType(pType)) {
            if (pVal1 != null && pVal1 != undefined && pVal2 != null && pVal2 != undefined) {
                if (pType == TypeCodeEnum.Byte &&
                    BravoNumberExtensions.isNumber(pVal1) &&
                    BravoNumberExtensions.isNumber(pVal2) &&
                    pVal1 >= 0 &&
                    pVal1 <= 1 &&
                    pVal2 >= 0 &&
                    pVal2 <= 1)
                    return BravoBooleanExtensions.asBoolean(pVal1) == BravoBooleanExtensions.asBoolean(pVal2);
                return BravoNumberExtensions.asNumber(pVal1) == BravoNumberExtensions.asNumber(pVal2);
            }
            // B0148-722: fix zezo int, zero decimal
            if (pType == TypeCodeEnum.Decimal) {
                if ((pVal1 == null || pVal1 == undefined) && Object.is(pVal2, 0))
                    return true;
                if ((pVal2 == null || pVal2 == undefined) && Object.is(pVal1, 0))
                    return true;
            }
        }
        if (pType == TypeCodeEnum.DateTime &&
            pVal1 != null &&
            pVal1 != undefined &&
            pVal2 != null &&
            pVal2 != undefined) {
            try {
                if (BravoMoment.isDate(pVal1) && BravoMoment.isDate(pVal2)) {
                    return BravoMoment.asDate(pVal1).getTime() == BravoMoment.asDate(pVal2).getTime();
                }
                else {
                    const date1 = BravoMoment.isDate(pVal1)
                        ? pVal1
                        : this.convertValue(pVal1, TypeCodeEnum.DateTime);
                    const date2 = BravoMoment.isDate(pVal2)
                        ? pVal2
                        : this.convertValue(pVal2, TypeCodeEnum.DateTime);
                    return BravoMoment.isEqual(date1, date2);
                }
            }
            catch {
                return false;
            }
        }
        if (pVal1 instanceof Array && pVal2 instanceof Array) {
            if (pVal1.length != pVal2.length)
                return false;
            for (let i = 0; i < pVal1.length; i++)
                if (!this.compareValue(pVal1[i], pVal2[i], pType, pbIgnoreCaseString))
                    return false;
            return true;
        }
        if (pVal1 instanceof Map && pVal2 instanceof Map) {
            if (pVal1.size != pVal2.size)
                return false;
            for (const [key, val] of pVal1)
                if (!pVal2.has(key) || !this.compareValue(val, pVal2.get(key), pType, pbIgnoreCaseString))
                    return false;
            return true;
        }
        return pVal1 === pVal2;
    }
    static isDateTimeValue(pValue, pOutArgs, pCulture) {
        if (pOutArgs == null)
            return false;
        if (pValue instanceof Date) {
            pOutArgs.datetime = pValue;
            return true;
        }
        try {
            pOutArgs.datetime = this.convertValue(pValue, TypeCodeEnum.DateTime, pCulture);
            if (pOutArgs.datetime instanceof Date)
                return true;
            return false;
        }
        catch {
            return false;
        }
    }
    static convertTypeCodeFromString(pzTypeCode) {
        if (pzTypeCode == 'System.Byte[]')
            return TypeCodeEnum.ByteArray;
        if (pzTypeCode.startsWith('System.'))
            pzTypeCode = pzTypeCode.substring('System.'.length);
        const outArgs = { resultValue: TypeCodeEnum.String };
        if (BravoEnumExtensions.isEnumType(TypeCodeEnum, pzTypeCode, outArgs))
            return outArgs.resultValue;
        return TypeCodeEnum.String;
    }
    static convertDbTypeToType(pDbType) {
        switch (pDbType) {
            case DbTypeEnum.AnsiString:
            case DbTypeEnum.AnsiStringFixedLength:
            case DbTypeEnum.String:
            case DbTypeEnum.StringFixedLength:
            case DbTypeEnum.Xml:
                return TypeCodeEnum.String;
            case DbTypeEnum.Binary:
                return TypeCodeEnum.ByteArray;
            case DbTypeEnum.Boolean:
                return TypeCodeEnum.Boolean;
            case DbTypeEnum.Byte:
                return TypeCodeEnum.Byte;
            case DbTypeEnum.Date:
            case DbTypeEnum.Time:
            case DbTypeEnum.DateTime:
                return TypeCodeEnum.DateTime;
            case DbTypeEnum.Decimal:
                return TypeCodeEnum.Decimal;
            case DbTypeEnum.Double:
                return TypeCodeEnum.Double;
            // case DbTypeEnum.Guid:
            //     return typeof (Guid);
            case DbTypeEnum.Int16:
                return TypeCodeEnum.Int16;
            case DbTypeEnum.Int32:
                return TypeCodeEnum.Int32;
            case DbTypeEnum.Int64:
                return TypeCodeEnum.Int64;
            case DbTypeEnum.SByte:
                return TypeCodeEnum.SByte;
            case DbTypeEnum.Single:
                return TypeCodeEnum.Single;
            case DbTypeEnum.UInt16:
                return TypeCodeEnum.UInt16;
            case DbTypeEnum.UInt32:
                return TypeCodeEnum.UInt32;
            case DbTypeEnum.UInt64:
                return TypeCodeEnum.UInt64;
            default:
                return TypeCodeEnum.Object;
        }
    }
}

class BravoFormatterUtil {
    static format(pValue, pFormat, pLocaleKey, pCultureKey) {
        if (pCultureKey)
            console.warn('Binhnv note: note support cultureKey when using format!!!!!!!!!');
        if (BravoStringExtensions.isString(pValue)) {
            return pValue;
        }
        else if (BravoDateExtensions.isDate(pValue)) {
            pFormat = pFormat || BravoAppSettings.settings.dateFormatPatterns.d;
            return BravoMoment.format(pValue, pFormat, { locale: pLocaleKey });
        }
        else if (BravoNumberExtensions.isNumber(pValue)) {
            // if (pFormat && pFormat.includes('#')) return this.customNumberFormat(pValue, pFormat);
            return BravoNumberExtensions.format(pValue, pFormat);
        }
        else {
            return pValue != null ? pValue.toString() : '';
        }
    }
}

const BravoDataInterfaceNamingConstants = {
    IDataTable: 'IDataTable',
    IDataSet: 'IDataSet',
    IDataRow: 'IDataRow',
    IDataRowView: 'IDataRowView',
    IDataColumn: 'IDataColumn',
    IDataRelation: 'IDataRelation',
    IDataView: 'IDataView',
    IDataCommand: 'IDataCommand',
    IUniqueConstraint: 'IUniqueConstraint',
    IForeignKeyConstraint: 'IForeignKeyConstraint',
    IBindingList: 'IBindingList',
    IBravoCollectionView: 'ICollectionView',
    IBravoEditableCollectionView: 'IEditableCollectionView',
};

const BravoDataConstants = {
    DEFAULT_UPDATECOMMANDTIMEOUT: 1800,
    DEFAULT_SELECTCOMMANDTIMEOUT: 300,
};

class BravoDataColumnChangeEventArgs extends BravoCancelEventArgs {
    constructor(pRow, pCol, pValue, pItem) {
        super();
        this._row = pRow;
        this._col = pCol;
        this._proposedValue = pValue;
        this._item = pItem;
    }
    _item;
    get item() {
        return this._item;
    }
    _col;
    get col() {
        return this._col;
    }
    _row;
    get row() {
        return this._row;
    }
    _proposedValue;
    get proposedValue() {
        return this._proposedValue;
    }
    set proposedValue(pValue) {
        this._proposedValue = pValue;
    }
}

class BravoDataRowChangeEventArgs extends BravoCancelEventArgs {
    row;
    action;
    constructor(pRow, pAction) {
        super();
        this.row = pRow;
        this.action = pAction;
    }
}

const SortPattern = /\[([^\]]*)\]|(\w*)(\s(ASC|DESC)*)*/i;
function getKeyValues(pKey, pVal, pVersion) {
    if (!pKey)
        return [];
    const cols = pKey.getColumnNames();
    const array = new Array(cols.length);
    for (let col = 0; col < cols.length; col++) {
        const colName = cols[col];
        const row = tryCast(pVal, BravoDataInterfaceNamingConstants.IDataRow);
        if (row)
            array[col] = row.getValue(colName, pVersion);
        else if (pVal)
            array[col] = pVal[colName];
    }
    return array;
}
function arraysIdentical(pArray1, pArray2) {
    let i = pArray1.length;
    if (i != pArray2.length)
        return false;
    while (i--) {
        if (pArray1[i] != pArray2[i])
            return false;
    }
    return true;
}
function buildSortString(pData) {
    const sorts = pData?.sortDescriptions;
    if (!sorts || sorts.length < 1)
        return BravoStringExtensions.empty;
    const columns = new Map();
    sorts.forEach(pSort => {
        if (pSort instanceof BravoSortDescription) {
            if (!columns.has(pSort.property) && pSort.property) {
                columns.set(pSort.property, BravoStringExtensions.format('{0} {1}', pSort.property, pSort.ascending ? '' : 'DESC').trim());
            }
        }
    });
    const sbSort = new BravoStringBuilder();
    for (const value of columns.values()) {
        if (sbSort.length > 0)
            sbSort.append(',');
        sbSort.append(value);
    }
    return sbSort.toString();
}
function buildSort(pCollection, pSort) {
    pCollection.sortDescriptions.clear();
    if (!pSort)
        return;
    let isSort = false;
    const exprs = pSort.split(',');
    let table;
    const dataView = tryCast(pCollection, BravoDataInterfaceNamingConstants.IDataView);
    if (dataView)
        table = dataView.table;
    else
        table = tryCast(pCollection, BravoDataInterfaceNamingConstants.IDataTable);
    for (const orderExpr of exprs) {
        if (!orderExpr)
            continue;
        const match = orderExpr.trim().match(SortPattern);
        if (!match || match.length < 1)
            continue;
        const colName = BravoStringExtensions.isNullOrEmpty(match[1]) ? match[2] : match[1];
        if (!colName)
            continue;
        if (!table || !table.columns)
            continue;
        const col = table.columns.get(colName);
        if (!col)
            continue;
        const propName = col.columnName;
        if (pCollection.sortDescriptions.findIndex(pSort => pSort.property == propName) != -1)
            continue;
        const sort = new BravoSortDescription(propName, !orderExpr.includes('DESC'));
        pCollection.sortDescriptions.push(sort);
        if (!isSort)
            isSort = true;
    }
    return isSort;
}
function sortBy(pItemName, pValue1, pValue2, pReverse = false) {
    const val1 = tryCast(pValue1, BravoDataInterfaceNamingConstants.IDataRow)
        ? pValue1.getValue(pItemName)
        : pValue1[pItemName], val2 = tryCast(pValue2, BravoDataInterfaceNamingConstants.IDataRow)
        ? pValue2.getValue(pItemName)
        : pValue2[pItemName];
    const sign = !pReverse ? 1 : -1;
    if (val1 instanceof Date && val2 instanceof Date) {
        const dateA = val1.getTime();
        const dateB = val2.getTime();
        return dateA > dateB ? sign * 1 : sign * -1;
    }
    else if (typeof val1 == 'string' && typeof val2 == 'string') {
        return sign * val1.localeCompare(val2);
    }
    else if (typeof val1 == 'number' && typeof val2 == 'number') {
        if (val1 < val2)
            return sign * -1;
        if (val1 > val2)
            return sign * 1;
    }
    return 0;
}
function toDataRelationName(pzName) {
    if (/\bFK_\w+\b/g.test(pzName))
        return pzName;
    return BravoStringExtensions.format('FK_{0}', pzName);
}
function getType(pValue) {
    if (BravoStringExtensions.isString(pValue))
        return TypeCodeEnum.String;
    if (BravoNumberExtensions.isIntegerType(pValue))
        return TypeCodeEnum.Int32;
    if (BravoNumberExtensions.isNumericValue(pValue))
        return TypeCodeEnum.Decimal;
    if (BravoMoment.isDate(pValue))
        return TypeCodeEnum.DateTime;
    if (BravoArrayExtensions.isArray(pValue))
        return TypeCodeEnum.ByteArray;
    return TypeCodeEnum.Object;
}
function convertTypeToDbType(pType) {
    if (pType == TypeCodeEnum.String)
        return DbTypeEnum.String;
    else if (pType == TypeCodeEnum.ByteArray)
        return DbTypeEnum.Binary;
    else if (pType == TypeCodeEnum.Byte)
        return DbTypeEnum.Byte;
    else if (pType == TypeCodeEnum.Boolean)
        return DbTypeEnum.Boolean;
    else if (pType == TypeCodeEnum.DateTime)
        return DbTypeEnum.DateTime;
    else if (pType == TypeCodeEnum.Decimal)
        return DbTypeEnum.Decimal;
    else if (pType == TypeCodeEnum.Double)
        return DbTypeEnum.Double;
    else if (pType == TypeCodeEnum.Int16)
        return DbTypeEnum.Int16;
    else if (pType == TypeCodeEnum.Int32)
        return DbTypeEnum.Int32;
    else if (pType == TypeCodeEnum.Int64)
        return DbTypeEnum.Int64;
    else if (pType == TypeCodeEnum.UInt16)
        return DbTypeEnum.UInt16;
    else if (pType == TypeCodeEnum.UInt32)
        return DbTypeEnum.UInt32;
    else if (pType == TypeCodeEnum.UInt64)
        return DbTypeEnum.UInt64;
    else
        return DbTypeEnum.Object;
}
function setCurrentEditItem(pCollection, pDataRow, pValueItem, pzKey, pForceUpdate = false) {
    if (!pDataRow || !pValueItem)
        return;
    let table;
    if (tryCast(pCollection, BravoDataInterfaceNamingConstants.IDataView))
        table = pCollection.table;
    else if (tryCast(pCollection, BravoDataInterfaceNamingConstants.IDataTable))
        table = pCollection;
    const collection = tryCast(pCollection, 'ICollectionView');
    if (!table || !collection)
        return;
    let key;
    if (!pzKey) {
        const fieldChanged = collection._getChangedFields(pValueItem, collection._edtClone);
        if (fieldChanged == null)
            return;
        key = fieldChanged[0];
    }
    else {
        if (!pForceUpdate && collection._edtClone && collection._edtClone[pzKey] === pValueItem[pzKey])
            return;
        key = pzKey;
    }
    const content = {
        key: key,
        value: pValueItem[key],
    };
    if (!BravoStringExtensions.isNullOrEmpty(content.key) && collection.currentPosition != -1) {
        const col = table.columns.get(content.key);
        collection._edtClone = {};
        collection._extend(collection._edtClone, collection._edtItem);
        let e = new BravoDataColumnChangeEventArgs(pDataRow, col, content.value);
        table.onColumnChanging(e);
        if (e.cancel) {
            collection.cancelEdit();
            return;
        }
        if (pValueItem[content.key] != e.proposedValue) {
            pValueItem[content.key] = e.proposedValue;
            if (collection._edtClone)
                collection._edtClone[content.key] = e.proposedValue;
        }
        const colIndex = table.columns.getIndex(content.key);
        if (pDataRow.rowState != DataRowStateEnum.Added) {
            if (pDataRow.rowState == DataRowStateEnum.Unchanged)
                pDataRow.originalItems = [...pDataRow.currentItems];
            pDataRow.currentItems[colIndex] = e.proposedValue;
        }
        else {
            if (pDataRow.currentItems == null)
                pDataRow.currentItems = new Array(table.columns.count);
            pDataRow.currentItems[colIndex] = e.proposedValue;
        }
        e = new BravoDataColumnChangeEventArgs(pDataRow, col, e.proposedValue, pValueItem);
        table.onColumnChanged(e);
    }
}

const MAX_COLUMNS = 32;
class BravoDataKey {
    constructor(pColumns, pCopyColumns) {
        if (!pColumns) {
            throw new BravoArgumentNullException('pColumns');
        }
        if (pColumns.length == 0 || pColumns.length > MAX_COLUMNS) {
            throw new Error();
        }
        if (pCopyColumns) {
            this._columns = new Array(pColumns.length);
            for (let n = 0; n < pColumns.length; n++) {
                this.columns[n] = pColumns[n];
            }
        }
        else {
            this._columns = pColumns;
        }
    }
    //*columns
    _columns;
    get columns() {
        return this._columns;
    }
    get columnsReference() {
        return this.columns;
    }
    //*table
    get table() {
        return this.columns[0].table;
    }
    columnsEqual(pKey) {
        return BravoDataKey._columnsEqual(this.columns, pKey.columns);
    }
    static _columnsEqual(pColumn1, pColumn2) {
        if (pColumn1 === pColumn2) {
            return true;
        }
        else if (!pColumn1 || !pColumn2) {
            return false;
        }
        else if (pColumn1.length != pColumn2.length) {
            return false;
        }
        for (let i = 0; i < pColumn1.length; i++) {
            let isCheck = false;
            for (let j = 0; j < pColumn2.length; j++) {
                if (pColumn1[i] != pColumn2[j]) {
                    isCheck = true;
                    break;
                }
            }
            if (isCheck) {
                return false;
            }
        }
        return true;
    }
    getColumnNames() {
        const values = new Array(this.columns.length);
        for (let n = 0; n < this.columns.length; n++) {
            values[n] = this.columns[n].columnName;
        }
        return values;
    }
    toArray() {
        const values = new Array(this.columns.length);
        for (let n = 0; n < this.columns.length; n++) {
            values[n] = this.columns[n];
        }
        return values;
    }
    dispose() {
        if (this._columns) {
            this._columns = [];
        }
    }
}

class BravoForeignKeyConstraint extends BravoConstraint {
    #childKey;
    get childKey() {
        return this.#childKey;
    }
    get columns() {
        return this.#childKey.toArray();
    }
    get table() {
        return this.#childKey.table;
    }
    get childColumnsName() {
        return this.#childKey.getColumnNames();
    }
    #parentKey;
    get parentKey() {
        return this.#parentKey;
    }
    get relatedColumns() {
        return this.#parentKey.toArray();
    }
    get relatedTable() {
        return this.#parentKey.table;
    }
    #updateRule = RuleEnum.None;
    get updateRule() {
        return this.#updateRule;
    }
    set updateRule(pVal) {
        this.#updateRule = pVal;
    }
    #deleteRule = RuleEnum.None;
    get deleteRule() {
        return this.#deleteRule;
    }
    set deleteRule(pVal) {
        this.#deleteRule = pVal;
    }
    constructor(pName, pParentColumns, pChildColumns) {
        super();
        this.create(pName, pParentColumns, pChildColumns);
    }
    create(pName, parentColumns, pChildColumns) {
        if (parentColumns.length != 0 && pChildColumns.length != 0) {
            if (parentColumns.length != pChildColumns.length) {
                throw new Error();
            }
            this.#parentKey = new BravoDataKey(parentColumns, true);
            this.#childKey = new BravoDataKey(pChildColumns, true);
            this.constraintName = pName;
        }
    }
    cascadeUpdate(pRow, pCol, pValue) {
        switch (this.updateRule) {
            case RuleEnum.None:
                break;
            case RuleEnum.Cascade: {
                const rows = this.table.rows;
                const keyValues = getKeyValues(this.parentKey, pRow);
                if (pCol) {
                    const index = this.parentKey.columnsReference.findIndex(pColRef => pColRef.columnName == pCol);
                    if (index >= 0) {
                        for (const row of rows) {
                            const keyChildValues = getKeyValues(this.childKey, row);
                            if (!arraysIdentical(keyValues, keyChildValues))
                                continue;
                            const childCol = this.childKey.columnsReference[index];
                            if (!childCol)
                                continue;
                            row.setValue(childCol.columnName, pValue);
                        }
                    }
                }
                else {
                    for (const row of rows) {
                        const keyChildValues = getKeyValues(this.childKey, row);
                        if (!arraysIdentical(keyValues, keyChildValues))
                            continue;
                        row.delete();
                    }
                }
                break;
            }
        }
    }
    checkConstraint(pRow, pAction) {
        if (pAction != NotifyCollectionChangedActionEnum.Change) {
            return true;
        }
        const keyValues = getKeyValues(this.childKey, pRow);
        const rows = this.relatedTable.rows;
        if (rows) {
            for (const row of rows) {
                const key = getKeyValues(this.parentKey, row);
                if (!arraysIdentical(keyValues, key)) {
                    return false;
                }
            }
        }
        return true;
    }
    dispose() {
        if (this.#childKey)
            this.#childKey.dispose();
        if (this.#parentKey)
            this.#parentKey.dispose();
        super.dispose();
    }
}

class BravoUniqueConstraint extends BravoConstraint {
    #isPrimaryKey = false;
    get isPrimaryKey() {
        return this.#isPrimaryKey;
    }
    #key;
    get key() {
        return this.#key;
    }
    get columns() {
        return this.key.toArray();
    }
    get inCollection() {
        return this._inCollection;
    }
    set inCollection(pVal) {
        this._inCollection = pVal;
        if (this.#key.columnsReference.length == 1)
            this.#key.columnsReference[0].unique = pVal;
    }
    constructor(pName, pIsPrimaryKey = false, ...pColumns) {
        super();
        this.#isPrimaryKey = pIsPrimaryKey;
        if (!pName && pColumns.length > 0)
            pName = BravoStringExtensions.format('IX_{0}_{1}', pColumns[0].table.name, pColumns[0].columnName);
        if (pName)
            this.create(pName, ...pColumns);
    }
    create(pConstraintName, ...pColumns) {
        this.#key = new BravoDataKey([...pColumns], true);
        this.constraintName = pConstraintName;
        this._checkUniqueByConstraint(pColumns);
    }
    _checkUniqueByConstraint(pColumns) {
        if (!pColumns || pColumns.length < 1)
            return false;
        const seen = new Set();
        const dataTable = pColumns[0].table;
        if (!dataTable)
            return false;
        const rows = dataTable.rows.filter(pRow => pRow.rowState != DataRowStateEnum.Detached);
        for (const row of rows) {
            const val = BravoUniqueConstraint._getKey(pColumns, row);
            if (seen.has(val))
                throw new Error(BravoStringExtensions.format('UniqueConstraint contains non-unique values {0}', dataTable.name));
            seen.add(val);
        }
        return true;
    }
    dispose() {
        if (this.#key)
            this.#key.dispose();
        super.dispose();
    }
    static _getKey(pColumns, pRow) {
        const keyDst = {};
        const length = pColumns.length;
        let colName;
        for (let index = 0; index < length; index++) {
            colName = pColumns[index].columnName;
            keyDst[colName] = pRow.getValue(colName);
        }
        return JSON.stringify(keyDst);
    }
    implementsInterface(pInterfaceName) {
        return pInterfaceName === BravoDataInterfaceNamingConstants.IUniqueConstraint;
    }
}

class BravoConstraintCollection extends ObservableArray {
    #defaultNameIndex = 0;
    add(pConstraint, pAddUniqueWhenAddingForeign) {
        if (pConstraint instanceof BravoForeignKeyConstraint) {
            if (pAddUniqueWhenAddingForeign) {
                let key = pConstraint.relatedTable.constraints?.findKeyConstraint(pConstraint.relatedColumns);
                if (!key) {
                    if (!pConstraint.constraintName)
                        pConstraint.constraintName = this.#assignName();
                    key = new BravoUniqueConstraint(undefined, false, ...pConstraint.relatedColumns);
                    pConstraint.relatedTable.constraints?.add(key);
                }
            }
        }
        pConstraint.inCollection = true;
        this.push(pConstraint);
    }
    #assignName() {
        const newName = this.#makeName(this.#defaultNameIndex);
        this.#defaultNameIndex++;
        return newName;
    }
    #makeName(pIndex) {
        if (1 == pIndex) {
            return 'Constraint1';
        }
        return 'Constraint' + pIndex.toString();
    }
    findKeyConstraint(pColumns) {
        const constraintCount = this.length;
        for (let i = 0; i < constraintCount; i++) {
            const constraint = tryCast(this[i], BravoDataInterfaceNamingConstants.IUniqueConstraint);
            if (constraint && arraysIdentical(constraint.key.columnsReference, pColumns))
                return constraint;
        }
        return null;
    }
    findForeignKeyConstraint(pParentColumns, pChildColumns) {
        const constraintCount = this.length;
        for (let i = 0; i < constraintCount; i++) {
            const constraint = tryCast(this[i], BravoDataInterfaceNamingConstants.IForeignKeyConstraint);
            if (constraint &&
                arraysIdentical(constraint.parentKey.columnsReference, pParentColumns) &&
                arraysIdentical(constraint.childKey.columnsReference, pChildColumns))
                return constraint;
        }
        return null;
    }
    dispose() {
        for (let i = 0; i < this.length; i++) {
            const constraint = this[i];
            if (constraint instanceof BravoConstraint) {
                constraint.dispose();
            }
        }
    }
}

class BravoDataColumn {
    #table;
    get table() {
        return this.#table;
    }
    #colName;
    get columnName() {
        return this.#colName;
    }
    set columnName(pValue) {
        this.#colName = pValue;
    }
    #dataType = TypeCodeEnum.String;
    get dataType() {
        return this.#dataType;
    }
    set dataType(pValue) {
        this.#dataType = pValue;
    }
    #maxLength;
    get maxLength() {
        return this.#maxLength;
    }
    set maxLength(pValue) {
        this.#maxLength = pValue;
    }
    #defaultValue;
    get defaultValue() {
        return this.#defaultValue;
    }
    set defaultValue(pVal) {
        this.#defaultValue = pVal;
    }
    #errors = 0;
    get errors() {
        return this.#errors;
    }
    set errors(pVal) {
        this.#errors = pVal;
    }
    #ordinal = 0;
    get ordinal() {
        return this.#ordinal;
    }
    #autoInc;
    get autoInc() {
        return this.#autoInc ?? (this.#autoInc = new AutoIncrementValue());
    }
    get autoIncrement() {
        return this.#autoInc && this.#autoInc.auto;
    }
    set autoIncrement(pVal) {
        if (this.autoIncrement != pVal) {
            this.autoInc.auto = pVal;
        }
    }
    get autoIncrementSeed() {
        return this.#autoInc ? this.#autoInc.seed : 0;
    }
    set autoIncrementSeed(pVal) {
        if (this.autoIncrementSeed != pVal)
            this.autoInc.seed = pVal;
    }
    get autoIncrementStep() {
        return this.#autoInc ? this.#autoInc.step : 1;
    }
    set autoIncrementStep(pVal) {
        if (this.autoIncrementStep != pVal)
            this.autoInc.step = pVal;
    }
    #allowDBNull = true;
    get allowDBNull() {
        return this.#allowDBNull;
    }
    set allowDBNull(pVal) {
        this.#allowDBNull = pVal;
    }
    #caption;
    get caption() {
        return this.#caption;
    }
    set caption(pVal) {
        this.#caption = pVal;
    }
    #readOnly = false;
    get readOnly() {
        return this.#readOnly;
    }
    set readOnly(pVal) {
        this.#readOnly = pVal;
    }
    #unique = false;
    get unique() {
        return this.#unique;
    }
    set unique(pVal) {
        if (this.#unique == pVal)
            return;
        this.#unique = pVal;
        if (this.table) {
            if (pVal) {
                const name = BravoStringExtensions.format('IX_{0}_{1}', this.table.name, this.columnName);
                if (!this.table.constraints.findKeyConstraint([this])) {
                    const cs = new BravoUniqueConstraint(name, false, this);
                    this.table.constraints.add(cs);
                }
            }
        }
    }
    #expression;
    get expression() {
        return this.#expression;
    }
    set expression(pVal) {
        this.#expression = pVal;
    }
    #extendedProperties;
    get extendedProperties() {
        if (!this.#extendedProperties)
            this.#extendedProperties = new Map();
        return this.#extendedProperties;
    }
    init(pItem) {
        if (pItem[this.columnName] != null)
            return;
        if (this.autoIncrement) {
            const val = this.autoInc.current;
            this.autoInc.moveAfter();
            pItem[this.columnName] = val;
        }
        else
            pItem[this.columnName] = this.defaultValue;
    }
    setUnique(pVal, pbManualCheck = false) {
        this.#unique = pVal;
        if (this.#unique && !pbManualCheck)
            this.#checkUnique();
    }
    #checkUnique() {
        if (!this.table || !this.table.rows || !this.table.columns.contains(this.columnName))
            return;
        if (this.table?.dataSet && !this.table.dataSet.enforceConstraints)
            return;
        const seen = new Set();
        const rows = this.table.rows.filter(pRow => pRow.rowState != DataRowStateEnum.Detached);
        for (const row of rows) {
            const val = row.getValue(this.columnName);
            if (seen.has(val))
                throw new Error(BravoStringExtensions.format("Column '{0}' contains non-unique values {1}", this.columnName, this.table.name));
            seen.add(val);
        }
    }
    constructor(pName, pType) {
        this.columnName = pName;
        this.dataType = pType || TypeCodeEnum.String;
    }
    setTable(pTable) {
        if (this.#table != pTable) {
            this.#table = pTable;
        }
    }
    setOrdinal(pos) {
        this.#ordinal = pos;
    }
    copy(pColumn) {
        this.defaultValue = pColumn.defaultValue;
        this.allowDBNull = pColumn.allowDBNull;
        this.autoIncrement = pColumn.autoIncrement;
        this.autoIncrementSeed = pColumn.autoIncrementSeed;
        this.autoIncrementStep = pColumn.autoIncrementStep;
        this.caption = pColumn.caption;
        this.maxLength = pColumn.maxLength;
        this.readOnly = pColumn.readOnly;
        this.setUnique(pColumn.unique);
    }
    dispose() {
        if (this.#extendedProperties) {
            this.#extendedProperties.clear();
            this.#extendedProperties = undefined;
        }
    }
    implementsInterface(pInterfaceName) {
        return BravoStringExtensions.compareStrings(pInterfaceName, BravoDataInterfaceNamingConstants.IDataColumn);
    }
}
class AutoIncrementValue {
    #auto = false;
    get auto() {
        return this.#auto;
    }
    set auto(pVal) {
        this.#auto = pVal;
    }
    #current = 0;
    get current() {
        return this.#current;
    }
    set current(pVal) {
        this.#current = pVal;
    }
    #seed = 0;
    get seed() {
        return this.#seed;
    }
    set seed(pValue) {
        if (this.current == this.#seed || this.#boundaryCheck(pValue))
            this.current = pValue;
        this.#seed = pValue;
    }
    #step = 1;
    get step() {
        return this.#step;
    }
    set step(pValue) {
        if (0 == pValue)
            throw new Error('Argument Exception: Step = 0');
        if (this.#step !== pValue && this.current != this.seed)
            this.current = this.current - this.#step + pValue;
        this.#step = pValue;
    }
    moveAfter() {
        this.current = this.current + this.step;
    }
    #boundaryCheck(pValue) {
        return (this.step < 0 && pValue <= this.current) || (0 < this.step && this.current <= pValue);
    }
    setCurrentAndIncrement(pVal) {
        if (this.#boundaryCheck(pVal))
            this.current = pVal + this.step;
    }
}

class BravoDataColumnCollection extends ObservableArray {
    #table;
    get count() {
        return this.length;
    }
    _isUsingExpression = false;
    get isUsingExpression() {
        return this._isUsingExpression;
    }
    constructor(pTable) {
        super();
        this.#table = pTable;
    }
    add(pColumn, pType, pExpression) {
        let column;
        if (!isString(pColumn)) {
            column = pColumn;
            column.setTable(this.#table);
            this.push(column);
        }
        else {
            const dataColumn = new BravoDataColumn(pColumn);
            dataColumn.setTable(this.#table);
            column = this.add(dataColumn);
        }
        if (pType !== undefined)
            column.dataType = pType;
        if (pExpression) {
            column.expression = pExpression;
            if (!this._isUsingExpression)
                this._isUsingExpression = true;
        }
        return column;
    }
    remove(pColumn) {
        const index = this.getIndex(pColumn);
        if (index >= 0) {
            this.removeAt(index);
            return true;
        }
        return super.remove(pColumn);
    }
    get(pColumnName) {
        return this.find(pCol => BravoStringExtensions.compareStrings(pCol.columnName, pColumnName, true));
    }
    getIndex(pColumn) {
        if (!isString(pColumn))
            return this.indexOf(pColumn);
        return this.findIndex(pCol => BravoStringExtensions.compareStrings(pCol.columnName, pColumn, true));
    }
    contains(pName) {
        if (this.find(pCol => BravoStringExtensions.compareStrings(pCol.columnName, pName, true)))
            return true;
        return false;
    }
    dispose() {
        if (this.#table)
            this.#table = null;
        for (let index = this.length - 1; index >= 0; index--) {
            let column = this[index];
            if (column) {
                column.dispose();
                column = null;
            }
        }
        this.clear();
    }
}

let BravoDataParameter = class BravoDataParameter {
    _implicitDbType = DbTypeEnum.String;
    _getDbType() {
        if (this._explicitDbType != -1)
            return this._explicitDbType;
        if (this.value != null)
            return convertTypeToDbType(getType(this.value));
        return DbTypeEnum.String;
    }
    _explicitDbType;
    get dbType() {
        if (this._explicitDbType != -1)
            return this._explicitDbType;
        if (this._implicitDbType == null)
            this._implicitDbType = this._getDbType();
        return this._implicitDbType;
    }
    set dbType(pVal) {
        this._explicitDbType = pVal;
    }
    _direction = ParameterDirectionEnum.Input;
    get direction() {
        return this._direction;
    }
    set direction(pVal) {
        this._direction = pVal;
    }
    isNullable = true;
    size = 0;
    sourceColumn;
    _sourceVersion = DataRowVersionEnum.Current;
    get sourceVersion() {
        return this._sourceVersion;
    }
    set sourceVersion(pVal) {
        this._sourceVersion = pVal;
    }
    parameterName;
    value;
    scale;
    precision;
};
__decorate([
    JsonProperty(JsonConstants.DbTypePropName),
    __metadata("design:type", Object)
], BravoDataParameter.prototype, "_explicitDbType", void 0);
__decorate([
    JsonProperty({ name: JsonConstants.DirectionPropName, defaultValue: ParameterDirectionEnum.Input }),
    __metadata("design:type", Number)
], BravoDataParameter.prototype, "_direction", void 0);
__decorate([
    InputSetter({ enumType: ParameterDirectionEnum, transform: BravoEnumExtensions.enumAttribute }),
    __metadata("design:type", Number),
    __metadata("design:paramtypes", [Number])
], BravoDataParameter.prototype, "direction", null);
__decorate([
    JsonProperty({ name: JsonConstants.IsNullablePropName, defaultValue: true }),
    __metadata("design:type", Object)
], BravoDataParameter.prototype, "isNullable", void 0);
__decorate([
    JsonProperty({ name: JsonConstants.SizePropName, defaultValue: 0 }),
    __metadata("design:type", Object)
], BravoDataParameter.prototype, "size", void 0);
__decorate([
    JsonProperty(JsonConstants.SourceColumnPropName),
    __metadata("design:type", String)
], BravoDataParameter.prototype, "sourceColumn", void 0);
__decorate([
    JsonProperty({ name: JsonConstants.SourceVersionPropName, defaultValue: DataRowVersionEnum.Current }),
    __metadata("design:type", Number)
], BravoDataParameter.prototype, "_sourceVersion", void 0);
__decorate([
    InputSetter({ transform: BravoEnumExtensions.enumAttribute, enumType: DataRowVersionEnum }),
    __metadata("design:type", Number),
    __metadata("design:paramtypes", [Number])
], BravoDataParameter.prototype, "sourceVersion", null);
__decorate([
    JsonProperty(JsonConstants.ParameterNamePropName),
    __metadata("design:type", String)
], BravoDataParameter.prototype, "parameterName", void 0);
__decorate([
    JsonProperty({ name: JsonConstants.ParameterValuePropName }),
    __metadata("design:type", Object)
], BravoDataParameter.prototype, "value", void 0);
__decorate([
    JsonProperty(JsonConstants.ScalePropName),
    __metadata("design:type", Object)
], BravoDataParameter.prototype, "scale", void 0);
__decorate([
    JsonProperty(JsonConstants.PrecisionPropName),
    __metadata("design:type", Object)
], BravoDataParameter.prototype, "precision", void 0);
BravoDataParameter = __decorate([
    JsonObject()
], BravoDataParameter);
class BravoParameterCollection extends Array {
    get(pzParameterName) {
        return this.find(p => BravoStringExtensions.compareStrings(pzParameterName, p.parameterName, true));
    }
}

var BravoDataCommand_1;
let BravoDataCommand = BravoDataCommand_1 = class BravoDataCommand {
    commandTimeout = BravoDataConstants.DEFAULT_SELECTCOMMANDTIMEOUT;
    commandType = CommandTypeEnum.Procedure;
    updatedRowSource = UpdateRowSourceEnum.Both;
    commandText;
    parameters;
    transactionLevel = IsolationLevelEnum.ReadUncommitted;
    connection;
    constructor() {
        this.commandTimeout = BravoDataConstants.DEFAULT_SELECTCOMMANDTIMEOUT;
        this.commandType = CommandTypeEnum.Procedure;
        this.updatedRowSource = UpdateRowSourceEnum.Both;
        this.commandText = BravoStringExtensions.empty;
        this.parameters = new BravoParameterCollection();
        this.transactionLevel = IsolationLevelEnum.Unspecified;
    }
    clone() {
        const command = new BravoDataCommand_1();
        command.commandTimeout = this.commandTimeout;
        command.commandType = this.commandType;
        command.updatedRowSource = this.updatedRowSource;
        command.commandText = this.commandText;
        command.parameters = this.parameters;
        command.transactionLevel = this.transactionLevel;
        return command;
    }
    implementsInterface(pInterfaceName) {
        return BravoStringExtensions.compareStrings(pInterfaceName, BravoDataInterfaceNamingConstants.IDataCommand);
    }
};
__decorate([
    JsonProperty({
        name: JsonConstants.CommandTimeoutPropName,
        defaultValue: BravoDataConstants.DEFAULT_SELECTCOMMANDTIMEOUT,
    }),
    __metadata("design:type", Number)
], BravoDataCommand.prototype, "commandTimeout", void 0);
__decorate([
    JsonProperty({ name: JsonConstants.CommandTypePropName, defaultValue: CommandTypeEnum.Procedure }),
    __metadata("design:type", Number)
], BravoDataCommand.prototype, "commandType", void 0);
__decorate([
    JsonProperty({ name: JsonConstants.UpdatedRowSourcePropName, defaultValue: UpdateRowSourceEnum.Both }),
    __metadata("design:type", Number)
], BravoDataCommand.prototype, "updatedRowSource", void 0);
__decorate([
    JsonProperty(JsonConstants.CommandTextPropName),
    __metadata("design:type", String)
], BravoDataCommand.prototype, "commandText", void 0);
__decorate([
    JsonProperty({ name: JsonConstants.ParametersPropName, dataStructure: 'array', type: BravoDataParameter }),
    __metadata("design:type", BravoParameterCollection)
], BravoDataCommand.prototype, "parameters", void 0);
__decorate([
    JsonProperty({ name: JsonConstants.TransactionLevelPropName, defaultValue: IsolationLevelEnum.ReadUncommitted }),
    __metadata("design:type", Number)
], BravoDataCommand.prototype, "transactionLevel", void 0);
BravoDataCommand = BravoDataCommand_1 = __decorate([
    JsonObject(),
    __metadata("design:paramtypes", [])
], BravoDataCommand);

const DbParamPrefixOld = '@_';
const DbParamPrefix = '@';
const ReturnValueParam = 'RETURN_VALUE';
class BravoDataParameterUtil {
    static convertParameterName(pzName) {
        // Fix wrong prefix SQL return parameter @_ to @
        if (BravoStringExtensions.compareStrings(pzName, DbParamPrefix + ReturnValueParam))
            return pzName;
        // Fix wrong prefix SQL return parameter @_ to @
        if (BravoStringExtensions.compareStrings(pzName, DbParamPrefixOld + ReturnValueParam) ||
            BravoStringExtensions.compareStrings(pzName, ReturnValueParam))
            return DbParamPrefix + ReturnValueParam;
        // Keep old prefix for other parameters for compatible reason
        return pzName.startsWith(DbParamPrefixOld) || pzName.startsWith(DbParamPrefix)
            ? pzName
            : DbParamPrefixOld + pzName;
    }
    static extractParameterName(pzParameterName) {
        if (BravoStringExtensions.compareStrings(pzParameterName, DbParamPrefixOld + ReturnValueParam) ||
            BravoStringExtensions.compareStrings(pzParameterName, DbParamPrefix + ReturnValueParam))
            return ReturnValueParam;
        if (pzParameterName.startsWith(DbParamPrefixOld))
            return pzParameterName.substring(DbParamPrefixOld.length);
        else if (pzParameterName.startsWith(DbParamPrefix))
            return pzParameterName.substring(DbParamPrefix.length);
        else
            return pzParameterName;
    }
}

class BravoDataRelation {
    createConstraints;
    #childKey;
    get childKey() {
        return this.#childKey;
    }
    #parentKey;
    get parentKey() {
        return this.#parentKey;
    }
    get parentColumns() {
        return this.#parentKey?.toArray() ?? [];
    }
    get childColumns() {
        return this.#childKey?.toArray() ?? [];
    }
    get parentTable() {
        return this.#parentKey?.table;
    }
    get childTable() {
        return this.#childKey?.table;
    }
    #relationName;
    get relationName() {
        return this.#relationName;
    }
    #parentConstrainKey;
    get parentConstrainKey() {
        return this.#parentConstrainKey;
    }
    #childConstrainKey;
    get childConstrainKey() {
        return this.#childConstrainKey;
    }
    #dataSet;
    get dataSet() {
        return this.#dataSet;
    }
    setDataSet(pDataSet) {
        this.#dataSet = pDataSet;
    }
    setParentKeyConstraint(pVal) {
        this.#parentConstrainKey = pVal;
    }
    setChildKeyConstraint(pVal) {
        this.#childConstrainKey = pVal;
    }
    constructor(pRelationName, pParentColumns, pChildColumns, pCreateConstraints = false) {
        this.#create(pRelationName, pParentColumns, pChildColumns, pCreateConstraints);
    }
    #create(pRelationName, pParentColumns, pChildColumns, pCreateConstraints) {
        this.#parentKey = pParentColumns && new BravoDataKey(pParentColumns, true);
        this.#childKey = pChildColumns && new BravoDataKey(pChildColumns, true);
        if (pParentColumns && pChildColumns && pParentColumns.length != pChildColumns.length) {
            throw new Error(BravoStringExtensions.format('ParentTable: {0}, ChildTable: {1}', this.parentTable?.name, this.childTable?.name));
        }
        this.#relationName = !pRelationName ? '' : pRelationName;
        this.createConstraints = pCreateConstraints;
    }
    dispose() {
        if (this.#childKey) {
            this.#childKey.dispose();
        }
        if (this.#parentKey) {
            this.#parentKey.dispose();
        }
        if (this.#parentConstrainKey) {
            this.#parentConstrainKey.dispose();
        }
        if (this.#childConstrainKey) {
            this.#childConstrainKey.dispose();
        }
    }
    implementsInterface(pInterfaceName) {
        return BravoStringExtensions.compareStrings(pInterfaceName, BravoDataInterfaceNamingConstants.IDataRelation);
    }
}

class BravoDataRelationCollection extends ObservableArray {
    get(pKey) {
        const index = this._internalIndexOf(pKey);
        return this[index];
    }
    add(pRelation, pParentColumn, pChildColumn) {
        if (!BravoStringExtensions.isString(pRelation)) {
            this._addCore(pRelation);
            return pRelation;
        }
        const dataRelation = new BravoDataRelation(pRelation, pParentColumn, pChildColumn, true);
        this.add(dataRelation);
        return dataRelation;
    }
    getDataSet() {
        return;
    }
    _addCore(pRelation) {
        return;
    }
    contains(pName) {
        return this._internalIndexOf(pName) >= 0;
    }
    _internalIndexOf(pName) {
        if (pName && 0 < pName.length) {
            const len = this.length;
            for (let i = 0; i < len; i++) {
                const dataRelation = this[i];
                if (BravoStringExtensions.compareStrings(pName, dataRelation.relationName, true))
                    return i;
            }
        }
        return -1;
    }
    isChildTable(pzTableName) {
        const len = this.length;
        for (let i = 0; i < len; i++) {
            const dataRelation = this[i];
            if (dataRelation.childTable &&
                BravoStringExtensions.compareStrings(pzTableName, dataRelation.childTable.name, true))
                return true;
        }
        return false;
    }
    dispose() {
        for (let i = 0; i < this.length; i++) {
            const dataRelation = this[i];
            if (dataRelation) {
                dataRelation.dispose();
            }
        }
        this.clear();
    }
}
class BravoDataTableRelationCollection extends BravoDataRelationCollection {
    #table;
    #relations;
    _isParentCollection;
    constructor(pTable, pIsParentCollection) {
        super();
        if (pTable == null) {
            throw new Error();
        }
        this.#table = pTable;
        this.#relations = new Array();
        this._isParentCollection = pIsParentCollection;
    }
    _addCore(pRelation) {
        super._addCore(pRelation);
        this.getDataSet().relations?.add(pRelation);
    }
    getDataSet() {
        return this.#table.dataSet;
    }
    get(pKey) {
        if (BravoNumberExtensions.isNumber(pKey)) {
            if (pKey >= 0 && pKey < this.length) {
                return this[pKey];
            }
        }
        else if (BravoStringExtensions.isString(pKey)) {
            const num = this._internalIndexOf(pKey);
            if (num == -2) {
                throw new Error();
            }
            if (num >= 0) {
                return this[num];
            }
        }
        return;
    }
    dispose() {
        super.dispose();
        if (this.#relations) {
            for (let i = this.#relations.length - 1; i >= 0; i--) {
                const relation = this.#relations[i];
                if (relation)
                    relation.dispose();
            }
            this.#relations.length = 0;
        }
    }
}
class BravoDataSetRelationCollection extends BravoDataRelationCollection {
    _dataSet;
    constructor(pDataSet) {
        super();
        this._dataSet = pDataSet;
    }
    _addCore(pRelation) {
        if (pRelation.childTable?.dataSet != this._dataSet || pRelation.parentTable?.dataSet != this._dataSet)
            throw new Error();
        super.push(pRelation);
        pRelation.parentTable.childRelations.push(pRelation);
        pRelation.childTable.parentRelations.push(pRelation);
        pRelation.setDataSet(this._dataSet);
        let foreignKey = pRelation.childTable.constraints.findForeignKeyConstraint(pRelation.parentColumns, pRelation.childColumns);
        if (pRelation.createConstraints) {
            if (foreignKey == null) {
                foreignKey = new BravoForeignKeyConstraint(BravoStringExtensions.empty, pRelation.parentColumns, pRelation.childColumns);
                pRelation.childTable.constraints.add(foreignKey, true);
                try {
                    foreignKey.constraintName = pRelation.relationName;
                }
                catch (_ex) {
                    throw _ex;
                }
            }
        }
        const key = pRelation.parentTable.constraints.findKeyConstraint(pRelation.parentColumns);
        if (key)
            pRelation.setParentKeyConstraint(key);
        if (foreignKey)
            pRelation.setChildKeyConstraint(foreignKey);
    }
    getDataSet() {
        return this._dataSet;
    }
}

class BravoDataError {
    _zRowError = BravoStringExtensions.empty;
    get text() {
        return this._zRowError;
    }
    set text(pValue) {
        this.#setText(pValue);
    }
    _errorList;
    get errorList() {
        if (!this._errorList)
            this._errorList = new Array();
        return this._errorList;
    }
    get count() {
        if (!this._errorList)
            return 0;
        return this._errorList.length;
    }
    get hasErrors() {
        if (this._zRowError.length == 0)
            return this.count != 0;
        return true;
    }
    constructor(pzRowError) {
        if (pzRowError)
            this.#setText(pzRowError);
    }
    setColumnError(pColumn, pzError) {
        if (!pzError || pzError.length == 0) {
            this.clear(pColumn);
        }
        else {
            let error;
            const index = this.#indexOf(pColumn);
            if (index == -1) {
                error = new ColumnError();
                this.errorList.push(error);
            }
            else {
                error = this.errorList[index];
            }
            error.column = pColumn;
            error.error = pzError;
            pColumn.errors++;
        }
    }
    getColumnError(pColumn) {
        for (let i = 0; i < this.count; i++) {
            if (this.errorList[i].column == pColumn)
                return this.errorList[i].error;
        }
        return BravoStringExtensions.empty;
    }
    getColumnsInError() {
        const array = new Array(this.count);
        for (let i = 0; i < this.count; i++) {
            array[i] = this.errorList[i].column;
        }
        return array;
    }
    clear(pColumn) {
        if (this.count != 0) {
            for (let i = 0; i < this.count; i++) {
                if (!pColumn || this.errorList[i].column == pColumn) {
                    this.errorList[i].column.errors--;
                    this.errorList.splice(i, 1);
                }
            }
            // this.errorList.clear();
            this._zRowError = BravoStringExtensions.empty;
        }
    }
    #indexOf(pColumn) {
        for (let i = 0; i < this.count; i++) {
            if (this.errorList[i].column == pColumn) {
                return i;
            }
        }
        return -1;
    }
    #setText(pzError) {
        if (!pzError)
            pzError = BravoStringExtensions.empty;
        this._zRowError = pzError;
    }
}
class ColumnError {
    column;
    error;
}

const RowIndexProp = '_______idxr';
class BravoDataRow {
    item;
    static isRowIndexProp(pzKey) {
        return BravoStringExtensions.compareStrings(pzKey, RowIndexProp);
    }
    constructor(pTable, pItem) {
        this.#table = pTable;
        this._columns = pTable.columns;
        if (pTable.columns.length < 1 && pItem) {
            for (const key in pItem) {
                pTable.columns.add(key);
            }
        }
        if (pItem)
            this.item = pItem;
    }
    _columns;
    #lastRowState;
    #rowState = DataRowStateEnum.Unchanged;
    get rowState() {
        return this.#rowState;
    }
    set rowState(pState) {
        this.#lastRowState = this.#rowState;
        this.#rowState = pState;
    }
    #error;
    get hasErrors() {
        return this.#error ? this.#error.hasErrors : false;
    }
    #table;
    get table() {
        return this.#table;
    }
    #currentItems;
    get currentItems() {
        if (!this.#currentItems)
            this.#currentItems = new Array();
        return this.#currentItems;
    }
    set currentItems(pValue) {
        this.#currentItems = pValue;
    }
    #originalItems;
    get originalItems() {
        if (!this.#originalItems)
            this.#originalItems = new Array();
        return this.#originalItems;
    }
    set originalItems(pValue) {
        this.#originalItems = pValue;
    }
    get defaultItems() {
        if (!this._columns || this._columns.count < 1)
            return;
        const defaultItems = new Array();
        for (const column of this._columns) {
            defaultItems.push(column.defaultValue);
        }
        return defaultItems;
    }
    _rowError;
    get rowError() {
        return this._rowError;
    }
    set rowError(pValue) {
        this._rowError = pValue;
    }
    endEdit(pColumn) {
        // const _e = new DataEventArgs(this.item);
        // this.table.onRecordChanging(_e);
        try {
            this.table.raiseCommitEdit(new BravoDataEventArgs(this, pColumn));
            this.commitRow(pColumn);
        }
        finally {
            // this.table.onRecordChanged();
        }
    }
    commitRow(pColumn) {
        const defaultView = this.table.defaultView;
        if (!defaultView)
            return;
        const bindingList = tryCast(defaultView, BravoDataInterfaceNamingConstants.IBindingList);
        if (bindingList) {
            const pos = defaultView.items.indexOf(this.item);
            if (pos >= 0)
                bindingList.onListChanged(new BravoListChangedEventArgs(ListChangedTypeEnum.ItemChanged, pos, pos, pColumn));
        }
        if (this.rowState == DataRowStateEnum.Unchanged) {
            this.setModified();
            this.table.onRowChanged(null, this, DataRowActionEnum.Change);
        }
        if (this.rowState == DataRowStateEnum.Added)
            this.table.onRowChanged(null, this, DataRowActionEnum.Change);
    }
    getParentRow(pRelation, pVersion = DataRowVersionEnum.Current) {
        const parentTable = pRelation.parentTable;
        const rows = parentTable?.select(null, null, DataViewRowStateEnum.CurrentRows);
        if (rows instanceof Array && pRelation.childKey && pRelation.parentKey) {
            let row, parentKey;
            const childKey = getKeyValues(pRelation.childKey, this, pVersion);
            for (row of rows) {
                parentKey = getKeyValues(pRelation.parentKey, row, pVersion);
                if (arraysIdentical(childKey, parentKey))
                    break;
            }
            if (row)
                return row;
        }
        return parentTable?.row;
    }
    getChildRowsByRelationName(pRelationName, pVersion = DataRowVersionEnum.Current) {
        if (this.table.childRelations == null || this.table.childRelations.length < 1)
            return;
        const relation = this.table.childRelations.find(pRelation => pRelation && BravoStringExtensions.compareStrings(pRelation.relationName, pRelationName, true));
        if (!relation)
            return [];
        return this.getChildRows(relation, pVersion);
    }
    getChildRows(pRelation, pVersion = DataRowVersionEnum.Current) {
        const childTable = pRelation.childTable;
        const rs = new Array();
        if (childTable && pRelation.parentKey && pRelation.childKey) {
            const rows = childTable.select(null, null, DataViewRowStateEnum.CurrentRows), parentKey = getKeyValues(pRelation.parentKey, this, pVersion);
            for (const row of rows) {
                if (row.rowState == DataRowStateEnum.Deleted || row.rowState == DataRowStateEnum.Detached)
                    continue;
                const childKey = getKeyValues(pRelation.childKey, row, pVersion);
                if (arraysIdentical(parentKey, childKey))
                    rs.push(row);
            }
        }
        return rs;
    }
    getValue(pKey, pVersion = DataRowVersionEnum.Default, pbConvert = true) {
        let index = -1;
        if (BravoStringExtensions.isString(pKey))
            index = this._columns.getIndex(pKey);
        else if (tryCast(pKey, BravoDataInterfaceNamingConstants.IDataColumn))
            index = this._columns.indexOf(pKey);
        else if (BravoNumberExtensions.isNumber(pKey))
            index = pKey;
        const col = this._columns[index], type = col ? col.dataType : TypeCodeEnum.String;
        let value;
        if (index >= 0 && index < this._columns.count) {
            if (pVersion == DataRowVersionEnum.Current)
                value = this.currentItems[index];
            else if (pVersion == DataRowVersionEnum.Original)
                value = this.originalItems[index];
            else if (pVersion == DataRowVersionEnum.Default) {
                const currentVal = this.currentItems[index];
                value = currentVal != null ? currentVal : this.defaultItems && this.defaultItems[index];
            }
        }
        if (pbConvert)
            return !isUndefined(value) ? BravoDataConvertUtil.convertValue(value, type) : null;
        return value;
    }
    isNull(pColumn, pVersion = DataRowVersionEnum.Default) {
        return this.getValue(pColumn, pVersion) != null ? false : true;
    }
    delete() {
        if (this.rowState != DataRowStateEnum.Deleted) {
            if (this.item) {
                if (this.table.sourceCollection && this.table.sourceCollection.includes(this.item)) {
                    // let _nIndex = this.table.sourceCollection.indexOf(this.item);
                    // let _lastItem = this.table.currentItem;
                    // if (this.table.currentPosition != _nIndex) this.table.currentPosition = _nIndex;
                    try {
                        // this.table.onListChanged(new ListChangedEventArgs(ListChangedType.ItemDeleted, _nIndex));
                        this.table.remove(this.item);
                    }
                    finally {
                        // if (this.table.currentItem != _lastItem)
                        //     this.table.moveCurrentTo(_lastItem)
                    }
                }
            }
            if (this.#originalItems == null || this.originalItems.length <= 0)
                this.originalItems = [...this.currentItems];
        }
    }
    rejectChanges() {
        if (this.rowState != DataRowStateEnum.Deleted)
            return;
        this.rowState = this.#lastRowState ?? DataRowStateEnum.Unchanged;
        if (this.#originalItems && this.originalItems.length > 0) {
            this.#currentItems = [...this.originalItems];
        }
        if (this.item && this.table.sourceCollection && !this.table.sourceCollection.includes(this.item)) {
            this.table.sourceCollection.push(this.item);
        }
    }
    setAdded() {
        if (this.rowState == DataRowStateEnum.Unchanged) {
            this.rowState = DataRowStateEnum.Added;
            if (this.#originalItems != null)
                this.#originalItems = undefined;
        }
    }
    setModified() {
        if (this.rowState == DataRowStateEnum.Unchanged) {
            this.rowState = DataRowStateEnum.Modified;
            if (this.#originalItems == null || this.originalItems.length <= 0)
                this.originalItems = [...this.currentItems];
        }
    }
    setValue(pKey, pValue) {
        let index = -1, columnName = BravoStringExtensions.empty;
        if (BravoStringExtensions.isString(pKey)) {
            index = this._columns.getIndex(pKey);
            columnName = this._columns[index].columnName;
        }
        else if (BravoNumberExtensions.isNumber(pKey) && pKey >= 0 && pKey < this._columns.count) {
            index = pKey;
            columnName = this._columns[pKey].columnName;
        }
        else if (tryCast(pKey, BravoDataInterfaceNamingConstants.IDataColumn)) {
            const col = tryCast(pKey, BravoDataInterfaceNamingConstants.IDataColumn);
            index = this._columns.indexOf(col);
            columnName = col.columnName;
        }
        if (index >= 0 && index < this._columns.count) {
            const oldValue = this.getValue(columnName);
            if (oldValue === pValue)
                return;
            let e = new BravoDataColumnChangeEventArgs(this, this._columns[index], pValue);
            this.table.onColumnChanging(e);
            if (e.cancel) {
                return;
            }
            if (this.rowState == DataRowStateEnum.Unchanged) {
                this.originalItems = [...this.currentItems];
            }
            else if (this.rowState == DataRowStateEnum.Added && this.currentItems == null) {
                this.currentItems = new Array(this._columns.count);
            }
            this.item[columnName] = this.currentItems[index] = e.proposedValue;
            e = new BravoDataColumnChangeEventArgs(this, this._columns[index], e.proposedValue, this.item);
            this.table.onColumnChanged(e);
        }
    }
    hasVersion(pVersion) {
        switch (pVersion) {
            case DataRowVersionEnum.Original:
                if (this.#originalItems != null && this.#originalItems.length > 0)
                    return true;
                break;
            case DataRowVersionEnum.Current:
                if (this.#currentItems != null && this.#currentItems.length > 0)
                    return true;
                break;
            case DataRowVersionEnum.Default:
                if (this.defaultItems != null && this.defaultItems.length > 0)
                    return true;
                break;
        }
        return false;
    }
    setColumnError(pColumn, pzError) {
        if (BravoNumberExtensions.isNumber(pColumn))
            pColumn = this._columns[pColumn];
        else if (BravoStringExtensions.isString(pColumn))
            pColumn = this._columns.get(pColumn);
        if (pColumn instanceof BravoDataColumn) {
            if (!this.#error)
                this.#error = new BravoDataError();
            if (this.getColumnError(pColumn) != pzError)
                this.#error.setColumnError(pColumn, pzError);
        }
    }
    getColumnError(pColumn) {
        if (BravoNumberExtensions.isNumber(pColumn))
            pColumn = this._columns[pColumn];
        else if (BravoStringExtensions.isString(pColumn))
            pColumn = this._columns.get(pColumn);
        if (pColumn instanceof BravoDataColumn) {
            if (!this.#error)
                this.#error = new BravoDataError();
            return this.#error.getColumnError(pColumn);
        }
        return BravoStringExtensions.empty;
    }
    #clearError(pColumn) {
        if (this.#error)
            this.#error.clear(pColumn);
    }
    clearErrors() {
        if (!this._columns || this._columns.length < 1)
            return;
        for (const col of this._columns) {
            this.#clearError(col);
        }
    }
    getColumnsInError() {
        return this.#error?.getColumnsInError();
    }
    acceptChanges() {
        if (this.rowState == DataRowStateEnum.Unchanged)
            return;
        if (this.rowState != DataRowStateEnum.Detached &&
            this.rowState != DataRowStateEnum.Deleted &&
            this._columns.count > 0) {
            this.rowState = DataRowStateEnum.Unchanged;
            for (let _i = 0; _i < this._columns.count; _i++) {
                this.originalItems[_i] = this.currentItems[_i];
            }
        }
        this.#table.commitRow(this);
    }
    implementsInterface(pInterfaceName) {
        return BravoStringExtensions.compareStrings(pInterfaceName, BravoDataInterfaceNamingConstants.IDataRow);
    }
}

class BravoDataRowCollection extends ObservableArray {
    #table;
    constructor(pTable) {
        super();
        this.#table = pTable;
    }
    get count() {
        return this.length;
    }
    add(pRow) {
        if (!this.#table)
            return;
        let row;
        if (!pRow) {
            const item = this.#table.addNew();
            row = this.#table.rows.find(pRow => pRow.item == item);
        }
        else {
            row = pRow;
            if (row instanceof BravoDataRow && !this.includes(row)) {
                this.push(row);
                this.#table?.endEdit(row);
            }
        }
        if (row && row.rowState != DataRowStateEnum.Added)
            row.rowState = DataRowStateEnum.Added;
    }
    push(...pRows) {
        pRows.map((pRow, pIndex) => {
            if (pRow && pRow.item)
                pRow.item[RowIndexProp] = pIndex + this.length;
        });
        return super.push(...pRows);
    }
    static getRow(pItem, pRowCollection) {
        if (!pItem || pRowCollection.length < 1)
            return;
        const index = BravoNumberExtensions.asNumber(pItem[RowIndexProp]);
        if (index == null || index < 0 || index >= pRowCollection.length)
            return;
        return pRowCollection[index];
    }
}

class BravoDataTable extends BravoCollectionView {
    constructor({ pName, pSourceCollection, pExpressionEvaluator, } = {}) {
        super(pSourceCollection, null);
        this.#name = pName ?? 'Table1';
        this.#constraintCollection = new BravoConstraintCollection();
        this.#expressionEvaluator = pExpressionEvaluator;
    }
    isOverrideCreateGroup = false;
    #expressionEvaluator;
    get expressionEvaluator() {
        return this.#expressionEvaluator ?? this.dataSet?.expressionEvaluator;
    }
    _refreshViewRelation$ = new Subject();
    get refreshViewRelation$() {
        return this._refreshViewRelation$.asObservable();
    }
    onRefreshViewRelation() {
        this._refreshViewRelation$.next(BravoEventArgs.empty);
    }
    _refreshingViewRelation$ = new Subject();
    get refreshingViewRelation$() {
        return this._refreshingViewRelation$.asObservable();
    }
    onRefreshingViewRelation() {
        this._refreshingViewRelation$.next(BravoEventArgs.empty);
    }
    _recordChanging$ = new Subject();
    get recordChanging$() {
        return this._recordChanging$.asObservable();
    }
    onRecordChanging(pEventArgs) {
        if (this.#removing || this._committing)
            return;
        this._recordChanging$.next(pEventArgs);
    }
    _recordChanged$ = new Subject();
    get recordChanged$() {
        return this._recordChanged$.asObservable();
    }
    onRecordChanged() {
        if (this.#removing || this._committing)
            return;
        this._recordChanged$.next(BravoEventArgs.empty);
    }
    _commitEdit$ = new Subject();
    get commitEdit$() {
        return this._commitEdit$.asObservable();
    }
    raiseCommitEdit(pEventArgs) {
        return this._commitEdit$.next(pEventArgs);
    }
    _listChanged$ = new Subject();
    get listChanged$() {
        return this._listChanged$.asObservable();
    }
    onListChanged(pEventArgs) {
        this._listChanged$.next(pEventArgs);
    }
    _columnChanging$ = new Subject();
    get columnChanging$() {
        return this._columnChanging$.asObservable();
    }
    onColumnChanging(pEventArgs) {
        this._columnChanging$.next(pEventArgs);
        if (this.#childRelationCollection && this.childRelations.length > 0) {
            for (let i = 0; i < this.childRelations.length; i++) {
                const relation = tryCast(this.childRelations[i], BravoDataInterfaceNamingConstants.IDataRelation);
                if (relation && relation.childConstrainKey && relation.childConstrainKey.columns) {
                    relation.childConstrainKey.cascadeUpdate(pEventArgs.row, pEventArgs.col.columnName, pEventArgs.proposedValue);
                }
            }
        }
    }
    _columnChanged$ = new Subject();
    get columnChanged$() {
        return this._columnChanged$.asObservable();
    }
    onColumnChanged(pEventArgs) {
        this._columnChanged$.next(pEventArgs);
    }
    _rowChanging$ = new Subject();
    get rowChanging$() {
        return this._rowChanging$.asObservable();
    }
    onRowChanging(pEventArgs, pRow, pAction) {
        if (pEventArgs == null)
            pEventArgs = new BravoDataRowChangeEventArgs(pRow, pAction);
        this._rowChanging$.next(pEventArgs);
        return pEventArgs;
    }
    _rowChanged$ = new Subject();
    get rowChanged$() {
        return this._rowChanged$.asObservable();
    }
    onRowChanged(pEventArgs, pRow, pAction) {
        if (pEventArgs == null)
            pEventArgs = new BravoDataRowChangeEventArgs(pRow, pAction);
        this._rowChanged$.next(pEventArgs);
        return pEventArgs;
    }
    _rowDeleting$ = new Subject();
    get rowDeleting$() {
        return this._rowDeleting$.asObservable();
    }
    _onRowDeleting(pEventArgs) {
        if (this.#childRelationCollection && this.childRelations.length > 0) {
            for (let i = 0; i < this.childRelations.length; i++) {
                const relation = tryCast(this.childRelations[i], BravoDataInterfaceNamingConstants.IDataRelation);
                if (relation && relation.childConstrainKey && relation.childConstrainKey.columns) {
                    relation.childConstrainKey.cascadeUpdate(pEventArgs.row);
                }
            }
        }
        this._rowDeleting$.next(pEventArgs);
        return !pEventArgs.cancel;
    }
    _rowDeleted$ = new Subject();
    get rowDeleted$() {
        return this._rowDeleted$.asObservable();
    }
    _onRowDeleted(pEventArgs) {
        this._rowDeleted$.next(pEventArgs);
    }
    _currentChanged$ = new Subject();
    get currentChanged$() {
        return this._currentChanged$.asObservable();
    }
    #childRelationCollection;
    get childRelations() {
        if (!this.#childRelationCollection) {
            this.#childRelationCollection = new BravoDataTableRelationCollection(this, false);
        }
        return this.#childRelationCollection;
    }
    #parentRelationCollection;
    get parentRelations() {
        if (!this.#parentRelationCollection) {
            this.#parentRelationCollection = new BravoDataTableRelationCollection(this, true);
        }
        return this.#parentRelationCollection;
    }
    #defaultView;
    get defaultView() {
        if (this.#defaultView)
            return this.#defaultView;
        return this;
    }
    #dataSet;
    get dataSet() {
        return this.#dataSet;
    }
    setDataSet(pDataSet) {
        if (this.#dataSet != pDataSet)
            this.#dataSet = pDataSet;
    }
    #constraintCollection;
    get constraints() {
        return this.#constraintCollection;
    }
    #cols;
    get columns() {
        if (!this.#cols)
            this.#cols = new BravoDataColumnCollection(this);
        return this.#cols;
    }
    #rows = new BravoDataRowCollection(this);
    get rows() {
        return this.#rows;
    }
    get row() {
        if (this.currentPosition == -1 || !this.#rows)
            return;
        return BravoDataRowCollection.getRow(this.currentItem, this.rows);
    }
    #primaryKey;
    get primaryKey() {
        if (this.#primaryKey == null)
            this.#primaryKey = new Array();
        return this.#primaryKey;
    }
    set primaryKey(pVal) {
        this.#primaryKey = pVal;
    }
    #name;
    get name() {
        return this.#name;
    }
    set name(pVal) {
        this.#name = pVal;
    }
    #displayExpression;
    get displayExpression() {
        return this.#displayExpression ?? BravoStringExtensions.empty;
    }
    set displayExpression(pVal) {
        this.#displayExpression = pVal;
    }
    #extendedProperties;
    get extendedProperties() {
        if (!this.#extendedProperties)
            this.#extendedProperties = new Map();
        return this.#extendedProperties;
    }
    get viewSort() {
        return buildSortString(this);
    }
    set viewSort(pVal) {
        if (this.canSort && buildSort(this, pVal))
            this.refresh();
    }
    get hasErrors() {
        for (let i = 0; this.#rows && i < this.rows.length; i++) {
            if (this.rows[i].hasErrors)
                return true;
        }
        return false;
    }
    _rowFilterFn(pExpr, pExpressionEval, pItem) {
        if (pExpr == null)
            return true;
        try {
            return pExpressionEval.isTrue(pExpr, pItem);
        }
        catch (ex) {
            console.warn(ex);
            return false;
        }
    }
    addNew() {
        const item = super.addNew();
        const row = BravoDataRowCollection.getRow(item, this.rows);
        if (row == null)
            return super.addNew();
        return item;
    }
    newRow() {
        const newItem = this.addNew();
        if (this.sourceCollection == null)
            return;
        const i = this.sourceCollection.indexOf(newItem);
        if (i >= 0 && i < this.sourceCollection.length) {
            return BravoDataRowCollection.getRow(newItem, this.rows);
        }
        return;
    }
    newRowTemplate(pItem) {
        if (pItem == null)
            pItem = {};
        const row = new BravoDataRow(this, pItem);
        const parentRelation = this.parentRelations.get(this.name);
        for (const col of this.columns) {
            col.init(pItem);
            if (parentRelation &&
                parentRelation.childColumns.includes(col) &&
                parentRelation.parentTable &&
                parentRelation.parentTable.rows.length > 0) {
                let parentRow = parentRelation.parentTable.row;
                if (!parentRow)
                    parentRow = parentRelation.parentTable.rows[0];
                if (parentRow) {
                    const index = parentRelation.childColumns.indexOf(col);
                    const parentKey = parentRelation.parentColumns[index].columnName;
                    pItem[col.columnName] = parentRow.getValue(parentKey);
                }
            }
            row.currentItems.push(pItem[col.columnName]);
        }
        row.rowState = DataRowStateEnum.Detached;
        return row;
    }
    select(pFilterExpression, pSort, pRecordStates = DataViewRowStateEnum.CurrentRows, pExpressionEvaluator) {
        if (this.rows == null || this.rows.length < 1)
            return new Array();
        let rows = [...this.rows];
        if (pFilterExpression) {
            if (!pExpressionEvaluator)
                pExpressionEvaluator = this.expressionEvaluator;
            if (!pExpressionEvaluator)
                throw new BravoArgumentNullException('pExpressionEvaluator');
            rows = rows.filter(this._rowFilterFn.bind(this, pFilterExpression, pExpressionEvaluator));
        }
        if (pSort) {
            const exprs = pSort.split(',');
            for (const order of exprs) {
                if (!order)
                    continue;
                const match = order.trim().match(BravoRegexes.SortPattern);
                if (!match || match.length < 1)
                    continue;
                const colName = BravoStringExtensions.isNullOrEmpty(match[1]) ? match[2] : match[1];
                if (!this.columns.contains(colName))
                    continue;
                rows = rows.sort((pVal1, pVal2) => sortBy(colName, pVal1, pVal2, order.includes('DESC')));
            }
        }
        if (pRecordStates == DataViewRowStateEnum.None)
            return rows;
        return rows.reduce((pRows, pRow) => {
            if (!pRows.includes(pRow)) {
                if ((pRecordStates & DataViewRowStateEnum.CurrentRows) == DataViewRowStateEnum.CurrentRows &&
                    (pRow.rowState == DataRowStateEnum.Added ||
                        pRow.rowState == DataRowStateEnum.Unchanged ||
                        pRow.rowState == DataRowStateEnum.Modified))
                    pRows.push(pRow);
                else if ((pRecordStates & DataViewRowStateEnum.ModifiedCurrent) == DataViewRowStateEnum.ModifiedCurrent &&
                    pRow.rowState == DataRowStateEnum.Modified &&
                    pRow.hasVersion(DataRowVersionEnum.Current))
                    pRows.push(pRow);
                else if ((pRecordStates & DataViewRowStateEnum.ModifiedOriginal) == DataViewRowStateEnum.ModifiedOriginal &&
                    pRow.rowState == DataRowStateEnum.Modified &&
                    pRow.hasVersion(DataRowVersionEnum.Original))
                    pRows.push(pRow);
                else if ((pRecordStates & DataViewRowStateEnum.Added) == DataViewRowStateEnum.Added &&
                    pRow.rowState == DataRowStateEnum.Added)
                    pRows.push(pRow);
                else if ((pRecordStates & DataViewRowStateEnum.Deleted) == DataViewRowStateEnum.Deleted &&
                    pRow.rowState == DataRowStateEnum.Deleted)
                    pRows.push(pRow);
                else if ((pRecordStates & DataViewRowStateEnum.OriginalRows) == DataViewRowStateEnum.OriginalRows &&
                    (pRow.rowState == DataRowStateEnum.Unchanged || pRow.rowState == DataRowStateEnum.Deleted))
                    pRows.push(pRow);
                else if ((pRecordStates & DataViewRowStateEnum.Unchanged) == DataViewRowStateEnum.Unchanged &&
                    pRow.rowState == DataRowStateEnum.Unchanged)
                    pRows.push(pRow);
            }
            return pRows;
        }, []);
    }
    find(...pKeys) {
        if (this.primaryKey == null || this.primaryKey.length < 1)
            return;
        if (this.primaryKey.length != pKeys.length)
            return;
        const item = this.primaryKey.reduce((previousValue, pCol, pIndex) => {
            return {
                ...previousValue,
                [pCol.columnName]: BravoDataConvertUtil.convertValue(pKeys[pIndex], pCol.dataType),
            };
        }, {});
        const key = JSON.stringify(item);
        for (let n = 0; n < this.rows.length; n++) {
            const row = this.rows[n];
            if (row == null || row.rowState == DataRowStateEnum.Deleted || row.rowState == DataRowStateEnum.Detached)
                continue;
            const keySrc = BravoDataTable._getKey(this.primaryKey, row.item);
            if (BravoStringExtensions.compareStrings(key, keySrc, true))
                return row;
        }
        return;
    }
    endEdit(pItem) {
        let row = tryCast(pItem, BravoDataInterfaceNamingConstants.IDataRow);
        if (!row)
            row = BravoDataRowCollection.getRow(pItem, this.rows);
        if (row == null)
            return;
        const item = row.item;
        if (this.sourceCollection instanceof Array && this.sourceCollection.indexOf(item) < 0) {
            this.sourceCollection.push(item);
        }
        if (this.rows.indexOf(row) < 0)
            this.rows.push(row);
        const args = new BravoDataRowChangeEventArgs(row, DataRowActionEnum.Add);
        this.onRowChanging(args, row, DataRowActionEnum.Add);
        if (args.cancel) {
            this.cancelNew();
            return;
        }
        if (row.rowState != DataRowStateEnum.Added)
            row.rowState = DataRowStateEnum.Added;
        if (this.isAddingNew)
            this.commitNew();
        this.onRowChanged(args, row, DataRowActionEnum.Add);
    }
    commitEdit(pColumn) {
        if (pColumn) {
            const bindingList = tryCast(this.defaultView, BravoDataInterfaceNamingConstants.IBindingList);
            if (bindingList)
                bindingList.onListChanged(new BravoListChangedEventArgs(ListChangedTypeEnum.ItemChanged, this.defaultView.currentPosition, this.defaultView.currentPosition, pColumn));
            if (this.defaultView.isEditingItem) {
                const col = this.columns.getIndex(pColumn);
                const row = BravoDataRowCollection.getRow(this.defaultView._edtItem, this.rows);
                if (row && col >= 0 && col < this.columns.length) {
                    if (row.rowState == DataRowStateEnum.Unchanged) {
                        row.setModified();
                        this.onRowChanged(null, row, DataRowActionEnum.Change);
                    }
                    if (row.rowState == DataRowStateEnum.Added)
                        this.onRowChanged(null, row, DataRowActionEnum.Change);
                }
            }
            return;
        }
        super.commitEdit();
    }
    commitNew() {
        if (this.isAddingNew)
            this.onListChanged(new BravoListChangedEventArgs(ListChangedTypeEnum.ItemAdded, this.currentPosition, -1));
        super.commitNew();
    }
    cancelNew() {
        const item = this._newItem;
        if (item != null) {
            const rowIndex = this.rows.findIndex(pRow => pRow.item == item);
            if (rowIndex >= 0 && rowIndex < this.rows.length)
                this.rows.splice(rowIndex, 1);
        }
        super.cancelNew();
    }
    acceptChanges() {
        const rows = this.rows;
        for (let i = 0; i < rows.length; i++) {
            if (rows[i])
                rows[i].acceptChanges();
        }
        this._newItem = null;
        this._edtItem = null;
    }
    commitRow(pRow) {
        const args = this.onRowChanging(null, pRow, DataRowActionEnum.Commit);
        this.onRowChanged(args, pRow, DataRowActionEnum.Commit);
    }
    newItemCreator = () => {
        const item = {};
        for (const col of this.columns) {
            col.init(item);
        }
        return item;
    };
    #removing = false;
    remove(pItem) {
        this.#removing = true;
        const index = this.sourceCollection?.indexOf(pItem);
        try {
            if (pItem != null) {
                const row = BravoDataRowCollection.getRow(pItem, this.rows);
                if (row) {
                    const eventArgs = new BravoDataRowChangeEventArgs(row, DataRowActionEnum.Delete);
                    if (this._onRowDeleting(eventArgs)) {
                        if (row.rowState == DataRowStateEnum.Added) {
                            row.rowState = DataRowStateEnum.Detached;
                        }
                        else {
                            row.rowState = DataRowStateEnum.Deleted;
                            if (row.originalItems.length <= 0)
                                row.originalItems = [...row.currentItems];
                        }
                        this._onRowDeleted(eventArgs);
                    }
                }
            }
            if (this.defaultView == this)
                super.remove(pItem);
            else
                this.defaultView.remove(pItem);
        }
        finally {
            this.#removing = false;
            if (index >= 0) {
                this.onListChanged(new BravoListChangedEventArgs(ListChangedTypeEnum.ItemDeleted, index));
            }
        }
    }
    getErrors() {
        const rowsErrors = new Array();
        for (let i = 0; i < this.rows.length; i++) {
            const row = this.rows[i];
            if (!row || row.rowState == DataRowStateEnum.Deleted || row.rowState == DataRowStateEnum.Detached)
                continue;
            if (row.hasErrors)
                rowsErrors.push(row);
        }
        return rowsErrors;
    }
    clone() {
        const table = new BravoDataTable({ pName: this.name, pExpressionEvaluator: this.expressionEvaluator });
        table.#cols = new BravoDataColumnCollection(table);
        for (const col of this.columns) {
            const colCopy = table.#cols.add(new BravoDataColumn(col.columnName, col.dataType));
            colCopy.copy(col);
        }
        if (this.extendedProperties.size > 0) {
            this.extendedProperties.forEach((pValue, pKey) => {
                if (!table.extendedProperties.has(pKey))
                    table.extendedProperties.set(pKey, pValue);
            });
        }
        return table;
    }
    dispose() {
        this.clear();
        if (this.#cols)
            this.#cols.dispose();
        if (this.#rows)
            this.#rows.length = 0;
        if (this._pgView)
            this._pgView.length = 0;
        if (this.sourceCollection)
            this.sourceCollection.length = 0;
        if (this.#childRelationCollection)
            this.#childRelationCollection.dispose();
        if (this.#parentRelationCollection)
            this.#parentRelationCollection.dispose();
        if (this.#extendedProperties) {
            this.#extendedProperties.clear();
            this.#extendedProperties = undefined;
        }
        if (this.#expressionEvaluator) {
            this.#expressionEvaluator = undefined;
        }
        this._currentChanged$.unsubscribe();
    }
    onCurrentChanged(pEventArgs) {
        super.onCurrentChanged(pEventArgs);
        if (this._currentChanged$)
            this._currentChanged$.next(pEventArgs);
        if (!this.isUpdating && this.childRelations && this.childRelations.length > 0) {
            for (let i = 0; i < this.childRelations.length; i++) {
                const relation = tryCast(this.childRelations[i], BravoDataInterfaceNamingConstants.IDataRelation);
                if (!relation || !relation.childKey)
                    continue;
                relation.childTable.refresh();
            }
        }
    }
    moveCurrentToPosition(pIndex) {
        const oldPos = this._idx;
        const result = super.moveCurrentToPosition(pIndex);
        if (pIndex >= -1 && pIndex < this._pgView.length && pIndex != oldPos) {
            const eventArgs = new BravoListChangedEventArgs(ListChangedTypeEnum.ItemMoved, pIndex, oldPos);
            this.onListChanged(eventArgs);
        }
        return result;
    }
    _sameValue(pVal1, pVal2, pLevel) {
        if (pVal1 instanceof Uint8Array || pVal2 instanceof Uint8Array)
            return BravoDataConvertUtil.compareValue(pVal1, pVal2, TypeCodeEnum.ByteArray);
        return super._sameValue(pVal1, pVal2, pLevel);
    }
    _extend(pDest, pSource, pLevel) {
        if (pLevel == null)
            pLevel = 0;
        if (pLevel === 0)
            pLevel = 2;
        for (const key in pSource) {
            try {
                const val = pSource[key];
                if (val instanceof Uint8Array) {
                    pDest[key] = new Uint8Array(val);
                }
                else if (BravoArrayExtensions.isArray(val)) {
                    pDest[key] = [...BravoArrayExtensions.asArray(val)];
                }
                else if (pLevel > 0 && BravoObjectExtensions.isObject(val)) {
                    pDest[key] = {};
                    this._extend(pDest[key], val, pLevel - 1);
                }
                else {
                    pDest[key] = val;
                }
            }
            catch {
                /* empty */
            }
        }
        return pDest;
    }
    loadDataRow(pItem, pbAcceptChanges) {
        const row = this._mergeRow(pItem);
        if (pbAcceptChanges)
            this.acceptChanges();
        return row;
    }
    merge(pTable, pPreserveChanges = false, pMissingSchemaAction = MissingSchemaActionEnum.Add, pSetDefaultValue = true) {
        if (pTable instanceof Array) {
            this._mergeArray(pTable, pPreserveChanges, pMissingSchemaAction);
            return;
        }
        if (pMissingSchemaAction == MissingSchemaActionEnum.AddWithKey) {
            for (const col of pTable.columns) {
                if (this.columns.contains(col.columnName))
                    continue;
                this._mergeColumn(this.columns, col);
            }
        }
        if (!pTable || !pTable.sourceCollection || pTable.sourceCollection.length <= 0)
            return;
        this.beginUpdate();
        try {
            const wasEmpty = this.rows.length == 0;
            for (const row of pTable.rows) {
                if (row && (row.rowState == DataRowStateEnum.Deleted || row.rowState == DataRowStateEnum.Detached))
                    continue;
                this._mergeRow(row, pPreserveChanges, wasEmpty, pSetDefaultValue);
            }
        }
        finally {
            this.endUpdate();
        }
    }
    _mergeColumn(pColumns, pColumn) {
        let col = pColumns.get(pColumn.columnName);
        if (!col)
            col = this.columns.add(pColumn.columnName, pColumn.dataType);
        col.copy(pColumn);
        if (col.unique && pColumn.table.primaryKey.includes(pColumn)) {
            if (col.table.primaryKey && !col.table.primaryKey.includes(col))
                col.table.primaryKey.push(col);
            else if (!col.table.primaryKey)
                col.table.primaryKey = [col];
        }
    }
    mergeRows(pRows, pPreserveChanges = false, pMissingSchemaAction = MissingSchemaActionEnum.Add) {
        if (pRows.length < 1)
            return;
        if (pMissingSchemaAction == MissingSchemaActionEnum.AddWithKey) {
            const table = pRows[0].table;
            for (const col of table.columns) {
                this._mergeColumn(this.columns, col);
            }
        }
        for (const row of pRows) {
            if (!BravoStringExtensions.compareStrings(row.table.name, this.name))
                continue;
            this._mergeRow(row, pPreserveChanges);
        }
    }
    _mergeArray(pData, pPreserveChanges = false, pMissingSchemaAction = MissingSchemaActionEnum.Add) {
        if (pMissingSchemaAction == MissingSchemaActionEnum.Add ||
            pMissingSchemaAction == MissingSchemaActionEnum.AddWithKey) {
            const item = pData[0];
            if (item) {
                for (const colName in item) {
                    if (!this.columns.contains(colName))
                        this.columns.add(colName);
                }
            }
        }
        for (let i = 0; i < pData.length; i++) {
            const item = pData[i];
            this._mergeRow(item, pPreserveChanges);
        }
    }
    _mergeRow(pDataItem, preserveChanges = false, pbEmpty = true, pbSetDefaultValue = true) {
        let item = !tryCast(pDataItem, BravoDataInterfaceNamingConstants.IDataRow)
            ? pDataItem
            : null, rowState = DataRowStateEnum.Unchanged;
        let allowEdit = true;
        const row = tryCast(pDataItem, BravoDataInterfaceNamingConstants.IDataRow);
        if (row) {
            item = row.item;
            if (!pbEmpty) {
                for (const col of this.primaryKey) {
                    if (!row.table.columns.contains(col.columnName)) {
                        allowEdit = false;
                        break;
                    }
                }
            }
            else {
                allowEdit = false;
            }
            if (row.rowState != null)
                rowState = row.rowState;
        }
        else {
            allowEdit = false;
        }
        if (allowEdit) {
            const index = this.sourceCollection instanceof Array
                ? BravoDataTable.findIndexByPrimaryKey(this, this.sourceCollection, item)
                : -1;
            if (index >= 0) {
                const currentItem = this.sourceCollection[index];
                this.editItem(currentItem);
                if (item) {
                    for (const key in item) {
                        const col = this.columns.get(key);
                        if (!col || col.readOnly || BravoDataRow.isRowIndexProp(key))
                            continue;
                        if (!this._edtItem)
                            this._edtItem = {};
                        this.currentEditItem[key] = item[key];
                    }
                }
                if (preserveChanges) {
                    this.commitEdit();
                }
                return;
            }
        }
        const rowNew = this._addRow(item, preserveChanges, rowState, pbSetDefaultValue);
        if (preserveChanges) {
            this.commitEdit();
            this.commitNew();
        }
        return rowNew;
    }
    _addRow(pItem, pPreserveChanges = false, pRowState = DataRowStateEnum.Added, pbSetDefaultValue = true) {
        if (pPreserveChanges)
            this.commitNew();
        // honor canAddNew
        if (!this.canAddNew) {
            return null;
        }
        // create new item
        let item = null;
        const src = this.sourceCollection;
        if (pbSetDefaultValue && this.newItemCreator) {
            item = this.newItemCreator();
        }
        else if (src && src.length) {
            item = new src[0].constructor();
        }
        else {
            item = {};
        }
        let row = null;
        if (item != null) {
            for (const keyRaw in pItem) {
                const key = BravoObjectExtensions.containsProperty(item, keyRaw);
                const col = this.columns.get(key);
                if (Object.prototype.hasOwnProperty.call(item, key) &&
                    Object.prototype.hasOwnProperty.call(pItem, keyRaw) &&
                    col) {
                    item[key] = BravoDataConvertUtil.convertValue(pItem[keyRaw], col.dataType);
                }
            }
            if (Object.keys(item).length == 0)
                item = pItem;
            // remember the new item
            this._newItem = item;
            row = new BravoDataRow(this, item);
            // add the new item to the collection
            this._updating++;
            const arr = tryCast(this.sourceCollection, ObservableArray$1);
            if (arr)
                arr['_updating']++;
            this.sourceCollection.push(item); // **
            this.rows.push(row);
            for (const col of this.columns) {
                if (pPreserveChanges)
                    col.init(item);
                row.currentItems.push(item[col.columnName]);
            }
            if (arr)
                arr['_updating']--;
            this._updating--;
            // add the new item to the bottom of the current view
            if (this._pgView != this.sourceCollection) {
                this._pgView.push(item);
            }
            // add the new item to the last group and to the data items
            if (this.groups && this.groups.length) {
                let g = this.groups[this.groups.length - 1];
                g.items.push(item);
                while (g.groups && g.groups.length) {
                    g = g.groups[g.groups.length - 1];
                    g.items.push(item);
                }
            }
            if (pPreserveChanges) {
                if (item)
                    this.moveCurrentTo(item);
                const eventArgs = new BravoDataRowChangeEventArgs(row, DataRowActionEnum.Add);
                this.onRowChanging(eventArgs, row, DataRowActionEnum.Add);
                if (eventArgs.cancel) {
                    this.cancelNew();
                    return;
                }
                if (row.rowState != pRowState)
                    row.rowState = pRowState;
                this.onRowChanged(eventArgs, row, DataRowActionEnum.Add);
            }
            else {
                if (row.rowState != pRowState)
                    row.rowState = pRowState;
            }
        }
        return row;
    }
    copy() {
        const table = new BravoDataTable({ pName: this.name, pExpressionEvaluator: this.expressionEvaluator });
        for (const column of this.columns) {
            const colCopy = table.columns.add(column.columnName, column.dataType);
            colCopy.copy(column);
        }
        if (this.rows instanceof Array) {
            table.deferUpdate(() => {
                for (const row of this.rows) {
                    const rowCopy = table._addRow({ ...row.item }, true, DataRowStateEnum.Added, false);
                    table.commitNew();
                    if (rowCopy) {
                        rowCopy.rowState = row.rowState;
                        if (row.originalItems)
                            rowCopy.originalItems = [...row.originalItems];
                    }
                }
            });
        }
        if (this.extendedProperties.size > 0) {
            this.extendedProperties.forEach((pValue, pKey) => {
                if (!table.extendedProperties.has(pKey))
                    table.extendedProperties.set(pKey, pValue);
            });
        }
        if (this.primaryKey) {
            for (const primaryKey of this.primaryKey) {
                const col = table.columns.get(primaryKey.columnName);
                if (col)
                    table.primaryKey.push(col);
            }
        }
        return table;
    }
    clear() {
        this.clearChanges();
        if (this.sourceCollection != null)
            this.sourceCollection.length = 0;
        if (this.#rows)
            this.#rows.clear();
        if (this._pgView)
            this._pgView.length = 0;
        this._idx = -1;
        this._newItem = null;
        this._edtItem = null;
        this.onListChanged(new BravoListChangedEventArgs(ListChangedTypeEnum.Reset, -1, -1));
    }
    onCollectionChanged(pEventArgs = NotifyCollectionChangedEventArgs.reset) {
        if (this.sourceCollection && this.sourceCollection.length > 0) {
            if (this.#cols == null)
                this.#cols = new BravoDataColumnCollection(this);
            if (pEventArgs instanceof NotifyCollectionChangedEventArgs) {
                this.handleCollectionChanged(this.sourceCollection, pEventArgs);
            }
        }
        super.onCollectionChanged(pEventArgs);
    }
    handleCollectionChanged(pSource, pEventArgs) {
        switch (pEventArgs.action) {
            case NotifyCollectionChangedAction.Add: {
                if (pEventArgs.item == null)
                    break;
                const row = new BravoDataRow(this, pEventArgs.item);
                const parentRelation = this.parentRelations.get(toDataRelationName(this.name));
                for (const col of this.columns) {
                    if (col.autoIncrement)
                        pEventArgs.item[col.columnName] =
                            this.rows.length * col.autoIncrementSeed + col.autoIncrementStep;
                    if (parentRelation &&
                        parentRelation.childColumns.includes(col) &&
                        parentRelation.parentTable &&
                        parentRelation.parentTable.rows.length > 0) {
                        let parentRow = parentRelation.parentTable.row;
                        if (!parentRow)
                            parentRow = parentRelation.parentTable.rows[0];
                        if (parentRow) {
                            const index = parentRelation.childColumns.indexOf(col);
                            const parentKey = parentRelation.parentColumns[index].columnName;
                            pEventArgs.item[col.columnName] = parentRow.getValue(parentKey);
                        }
                    }
                    row.currentItems.push(pEventArgs.item[col.columnName]);
                }
                row.rowState = DataRowStateEnum.Added;
                this.rows.push(row);
                break;
            }
        }
    }
    refreshBindingData() {
        for (const row of this.rows) {
            if (row == null)
                continue;
            for (let n = 0; n < this.columns.count; n++) {
                const col = this.columns[n];
                try {
                    if (row.item[col.columnName] !== row.currentItems[n])
                        row.item[col.columnName] = row.currentItems[n];
                    if (col.expression)
                        row.currentItems[n] = row.item[col.columnName] = col.expression;
                }
                catch {
                    /* empty */
                }
            }
        }
    }
    implementsInterface(pInterfaceName) {
        if (pInterfaceName == BravoDataInterfaceNamingConstants.IBindingList ||
            BravoStringExtensions.compareStrings(pInterfaceName, BravoDataInterfaceNamingConstants.IDataTable))
            return true;
        return super.implementsInterface(pInterfaceName);
    }
    getCollection() {
        return this;
    }
    writeJson() {
        if (this.columns.length < 1 || this.rows.length < 1 || this.items.length < 1)
            return null;
        const array = [];
        for (const item of this.items) {
            array.push(item);
        }
        return JSON.stringify(array, (pKey, pValue) => {
            if (pValue instanceof Uint8Array)
                return BravoConverterExtensions.toBase64String(pValue);
            else
                return pValue;
        });
    }
    static findIndexByPrimaryKey(pTable, pCollection, pItem, primaryKey) {
        if (primaryKey == null)
            primaryKey = pTable.primaryKey;
        if (!primaryKey || primaryKey.length <= 0 || pCollection.length <= 0 || pItem == null)
            return -2;
        const keyDst = {};
        for (const col of primaryKey) {
            keyDst[col.columnName] = pItem[col.columnName];
        }
        const keyDstString = JSON.stringify(keyDst);
        let index = -1;
        const len = pCollection.length;
        for (let n = 0; n < len; n++) {
            const item = pCollection[n], keySrc = {};
            for (const col of primaryKey) {
                keySrc[col.columnName] = item[col.columnName];
            }
            if (keyDstString == JSON.stringify(keySrc)) {
                index = n;
                break;
            }
        }
        return index;
    }
    static _getKey(pColumns, pItem) {
        const keyDst = {};
        const len = pColumns.length;
        let colName;
        for (let i = 0; i < len; i++) {
            colName = pColumns[i].columnName;
            keyDst[colName] = pItem[colName];
        }
        return JSON.stringify(keyDst);
    }
}

class BravoDataTableCollection extends ObservableArray {
    _dataSet;
    constructor(pDataSet) {
        super();
        this._dataSet = pDataSet;
    }
    add(pTable) {
        let table;
        if (pTable == null)
            table = new BravoDataTable({ pExpressionEvaluator: this._dataSet.expressionEvaluator });
        else if (BravoStringExtensions.isString(pTable))
            table = new BravoDataTable({ pName: pTable, pExpressionEvaluator: this._dataSet.expressionEvaluator });
        else
            table = pTable;
        const index = this.findIndex(pTable => pTable.name == table.name);
        if (index != -1)
            this.removeAt(index);
        this.push(table);
        table.setDataSet(this._dataSet);
        return table;
    }
    contains(pTableName) {
        return this.some(pTable => BravoStringExtensions.compareStrings(pTable.name, pTableName, true));
    }
    get(pTableName) {
        return this.find(pTable => BravoStringExtensions.compareStrings(pTable.name, pTableName, true));
    }
}

class BravoDataSet {
    #isInitProgress = false;
    get isInitialized() {
        return this.#isInitProgress;
    }
    #caseSensitive = false;
    get caseSensitive() {
        return this.#caseSensitive;
    }
    set caseSensitive(pValue) {
        this.#caseSensitive = pValue;
    }
    #expressionEvaluator;
    get expressionEvaluator() {
        return this.#expressionEvaluator;
    }
    prefix;
    #tables;
    get tables() {
        return this.#tables;
    }
    get hasErrors() {
        if (this.#tables == null || this.#tables.length < 1)
            return false;
        for (let i = 0; i < this.tables.length; i++) {
            const table = tryCast(this.tables[i], BravoDataInterfaceNamingConstants.IDataTable);
            if (table.hasErrors)
                return true;
        }
        return false;
    }
    _extendedProperties;
    get extendedProperties() {
        if (!this._extendedProperties)
            this._extendedProperties = new Map();
        return this._extendedProperties;
    }
    _relationCollection;
    get relations() {
        return this._relationCollection;
    }
    #name;
    get name() {
        return this.#name;
    }
    set name(pVal) {
        this.#name = pVal;
    }
    #enforceConstraints = true;
    get enforceConstraints() {
        return this.#enforceConstraints;
    }
    set enforceConstraints(pVal) {
        this.#enforceConstraints = pVal;
    }
    #ignoreDefaultValue = false;
    get ignoreDefaultValue() {
        return this.#ignoreDefaultValue;
    }
    set ignoreDefaultValue(pVal) {
        this.#ignoreDefaultValue = pVal;
    }
    constructor({ pName, pExpressionEvaluator } = {}) {
        this.#expressionEvaluator = pExpressionEvaluator;
        this.#tables = new BravoDataTableCollection(this);
        this._relationCollection = new BravoDataSetRelationCollection(this);
        this.name = pName;
    }
    beginUpdate() {
        if (!this.tables || this.tables.length < 1)
            return;
        for (let i = 0; i < this.tables.length; i++) {
            const table = tryCast(this.tables[i], BravoDataInterfaceNamingConstants.IDataTable);
            if (!table)
                continue;
            table.beginUpdate();
        }
    }
    endUpdate() {
        if (!this.tables || this.tables.length < 1)
            return;
        for (let i = 0; i < this.tables.length; i++) {
            const table = tryCast(this.tables[i], BravoDataInterfaceNamingConstants.IDataTable);
            if (!table)
                continue;
            table.endUpdate();
        }
    }
    beginInit() {
        this.#isInitProgress = true;
    }
    clone() {
        const dataSet = new BravoDataSet({
            pExpressionEvaluator: this.expressionEvaluator,
        });
        for (const table of this.#tables) {
            const tableClone = table.clone();
            dataSet.tables.add(tableClone);
        }
        this.#copyExtraSchemaDataSet(dataSet);
        return dataSet;
    }
    copy() {
        const dataSet = new BravoDataSet({
            pExpressionEvaluator: this.expressionEvaluator,
        });
        for (const table of this.#tables) {
            const tableCopy = table.copy();
            dataSet.tables.add(tableCopy);
        }
        this.#copyExtraSchemaDataSet(dataSet);
        return dataSet;
    }
    #copyExtraSchemaDataSet(pDataSet) {
        for (const relation of this._relationCollection) {
            const parentColumns = new Array();
            const childColumns = new Array();
            const parentTable = relation.parentTable ? pDataSet.tables.get(relation.parentTable.name) : null;
            const childTable = relation.childTable ? pDataSet.tables.get(relation.childTable.name) : null;
            if (parentTable && relation.parentColumns) {
                relation.parentColumns.forEach(pCol => {
                    const parentCol = parentTable.columns.get(pCol.columnName);
                    if (parentCol)
                        parentColumns.push(parentCol);
                });
            }
            if (childTable && relation.childColumns) {
                relation.childColumns.forEach(pCol => {
                    const childCol = childTable.columns.get(pCol.columnName);
                    if (childCol)
                        childColumns.push(childCol);
                });
            }
            if (!relation.childConstrainKey)
                continue;
            const relationCopy = pDataSet._relationCollection.add(relation.relationName, parentColumns, childColumns);
            relationCopy.childConstrainKey.updateRule = relation.childConstrainKey.updateRule;
            relationCopy.childConstrainKey.deleteRule = relation.childConstrainKey.deleteRule;
        }
        if (this.extendedProperties.size > 0) {
            this.extendedProperties.forEach((pValue, pKey) => {
                if (pDataSet.extendedProperties.has(pKey))
                    pDataSet.extendedProperties.set(pKey, pValue);
            });
        }
    }
    merge(pData, pPreserveChanges = false, pMissingSchemaAction = MissingSchemaActionEnum.Add, pSetDefaultValue = true) {
        const dataSet = tryCast(pData, BravoDataInterfaceNamingConstants.IDataSet);
        if (dataSet) {
            for (const tableDes of dataSet.tables) {
                if (this.tables.contains(tableDes.name)) {
                    const tableSrc = this.tables.get(tableDes.name);
                    if (tableSrc)
                        tableSrc.merge(tableDes, pPreserveChanges, pMissingSchemaAction, pSetDefaultValue);
                }
                else {
                    if (pMissingSchemaAction == MissingSchemaActionEnum.Add ||
                        pMissingSchemaAction == MissingSchemaActionEnum.AddWithKey) {
                        const table = tableDes.clone();
                        this.tables.add(table);
                        table.merge(tableDes, pPreserveChanges, pMissingSchemaAction, pSetDefaultValue);
                    }
                }
            }
        }
        else {
            const table = tryCast(pData, BravoDataInterfaceNamingConstants.IDataTable);
            if (table == null)
                return;
            const table0 = this.tables.get(table.name);
            if (table0)
                table0.merge(table, pPreserveChanges, pMissingSchemaAction, pSetDefaultValue);
        }
    }
    mergeRows(pRows, pPreserveChanges = false, pMissingSchemaAction = MissingSchemaActionEnum.Add) {
        const tables = new Array();
        for (const row of pRows) {
            if (row == null)
                continue;
            const table = row.table;
            let table0 = this.tables.get(table.name);
            if (table0 == null) {
                table0 = table.clone();
                table0 = this.tables.add(table0);
            }
            if (!tables.includes(table0))
                tables.push(table0);
        }
        for (const table of tables) {
            table.mergeRows(pRows.filter(pRow => pRow.table.name == table.name), pPreserveChanges, pMissingSchemaAction);
        }
    }
    clear() {
        for (let n = 0; n < this.tables.length; n++) {
            const table = this.tables[n];
            const isLastUpdate = table.isUpdating;
            if (!isLastUpdate)
                table.beginUpdate();
            try {
                table.clear();
            }
            finally {
                if (!isLastUpdate)
                    table.endUpdate();
            }
        }
    }
    dispose() {
        for (let n = this.tables.length - 1; n >= 0; n--) {
            const table = this.tables[n];
            table.dispose();
        }
        if (this.#tables)
            this.#tables.clear();
        if (this.#expressionEvaluator) {
            this.#expressionEvaluator = undefined;
        }
    }
    endInit() {
        this.#isInitProgress = false;
    }
    writeJson(pbFormat = false, pbReturnBuffer = true) {
        if (this.tables.length < 0)
            return null;
        const tableCollection = new Array();
        for (const table of this.tables) {
            if (table.columns.length > 0 && table.rows.length > 0) {
                tableCollection.push(table);
            }
        }
        const obj = {};
        for (const tb of tableCollection) {
            const tbJson = tb.writeJson();
            if (!tbJson)
                continue;
            const item = JSON.parse(tbJson, function (pProp, pValue) {
                if (pProp.match(new RegExp(/^[\d]/)) && !(pValue instanceof Object)) {
                    const newProp = BravoStringExtensions.format('z{0}', pProp);
                    this[newProp] = pValue;
                    return;
                }
                return pValue;
            });
            obj[tb.name] = item;
        }
        const json = pbFormat ? JSON.stringify(obj, null, 2) : JSON.stringify(obj);
        return pbReturnBuffer ? BravoUTF8.getBytes(json) : json;
    }
    acceptChanges() {
        for (let n = 0; n < this.tables.length; n++) {
            const table = this.tables[n];
            if (!table)
                continue;
            table.acceptChanges();
            if (table.currentPosition < 0)
                table.moveCurrentToFirst();
        }
    }
    hasChanges(pRowState) {
        if (this.#tables == null || this.#tables.length < 1)
            return false;
        if (pRowState == null)
            pRowState = DataRowStateEnum.Added | DataRowStateEnum.Modified | DataRowStateEnum.Deleted;
        for (let i = 0; i < this.tables.length; i++) {
            const tb = tryCast(this.tables[i], BravoDataInterfaceNamingConstants.IDataTable);
            for (let j = 0; j < tb.rows.length; j++) {
                const row = tb.rows[j];
                if ((row.rowState & pRowState) != 0)
                    return true;
            }
        }
        return false;
    }
    writeXml(pMode = XmlWriteModeEnum.IgnoreSchema) {
        // const _xml = BravoXmlHelper.writeXmlDataSet(this as IDataSet, pMode);
        // return BravoUTF8.getBytes(_xml);
    }
    readXml(pzContent, mode = XmlReadModeEnum.Auto) {
        // BravoXmlHelper.readXmlDataSet(this, pzContent, mode);
    }
    implementsInterface(pInterfaceName) {
        return BravoStringExtensions.compareStrings(pInterfaceName, BravoDataInterfaceNamingConstants.IDataSet);
    }
}

class BravoDataRowView {
    row;
    _dataSource;
    constructor(pSource, pRow) {
        this.row = pRow;
        this._dataSource = pSource;
    }
    get dataView() {
        return tryCast(this._dataSource, BravoDataInterfaceNamingConstants.IDataView);
    }
    setValue(pKey, pValue) {
        if (!this.dataView || !this.row)
            return;
        this.row.setValue(pKey, pValue);
    }
    endEdit() {
        if (!this.row || !this.dataView || !this.dataView.table)
            return;
        const row = this.row;
        const dataView = this.dataView;
        const table = this.dataView.table;
        const args = new BravoDataRowChangeEventArgs(row, DataRowActionEnum.Add);
        table.onRowChanging(args, row, DataRowActionEnum.Add);
        if (args.cancel) {
            dataView.cancelNew();
            return;
        }
        if (row.rowState != DataRowStateEnum.Added)
            row.rowState = DataRowStateEnum.Added;
        if (dataView._newItem)
            dataView.commitNew();
        if (dataView._edtItem)
            dataView.commitEdit();
        table.onRowChanged(args, row, DataRowActionEnum.Add);
    }
}

class BravoDataView extends BravoCollectionView {
    //#region static method
    static _filterWithRelation(pItem, pItem1, pExpr) {
        if (!pItem || !pItem1)
            return false;
        const keys = Array.from(pExpr.keys());
        for (const key of keys) {
            const childKey = key;
            const parentKey = pExpr.get(key);
            if (childKey && parentKey && pItem[childKey] != pItem1[parentKey])
                return false;
        }
        return true;
    }
    //#endregion static method
    _listChanged$ = new Subject();
    get listChanged$() {
        return this._listChanged$.asObservable();
    }
    onListChanged(pEventArgs) {
        if (this._listChanged$ != null)
            this._listChanged$.next(pEventArgs);
    }
    getCollection() {
        return this;
    }
    getRows() {
        if (!this.table)
            return;
        const rows = new Array();
        for (let i = 0; i < this.itemCount; i++) {
            const row = BravoDataRowCollection.getRow(this.items[i], this.table.rows);
            if (row)
                rows.push(row);
        }
        return rows;
    }
    _table;
    get table() {
        return this._table;
    }
    _expressionEvaluator;
    get expressionEvaluator() {
        return this._expressionEvaluator;
    }
    _rowFilter = BravoStringExtensions.empty;
    get rowFilter() {
        return this._rowFilter;
    }
    set rowFilter(pVal) {
        if (BravoStringExtensions.compareStrings(this._rowFilter, pVal))
            return;
        this._rowFilter = pVal;
        if (!this._rowFilter)
            this._filter = () => true;
        else
            this._filter = this._rowFilterFn.bind(this.expressionEvaluator, this);
        if (this.canFilter)
            this.refresh();
    }
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    get currentEditItem() {
        return this._edtItem;
    }
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    set currentEditItem(pVal) {
        if (!this.isEditingItem)
            return;
        const tb = this.table;
        if (!tb)
            return;
        const row = tb.rows.find(pRow => Object.is(pRow.item, this.currentItem));
        if (row)
            setCurrentEditItem(this, row, pVal);
    }
    get sort() {
        return buildSortString(this);
    }
    set sort(pVal) {
        if (this.canSort && buildSort(this, pVal))
            this.refresh();
    }
    constructor(pSourceCollection, pOptions) {
        super(undefined, pOptions);
        this.trackChanges = true;
        let src;
        if (tryCast(pSourceCollection, BravoDataInterfaceNamingConstants.IDataTable)) {
            this._table = pSourceCollection;
            this._table.refreshViewRelation$.subscribe(this._handleTableRefreshViewRelation.bind(this));
            /* this._table.collectionChanged.addHandler((s, e: wjc.NotifyCollectionChangedEventArgs) => {
                super.onCollectionChanged(e);
            }) */
            this._table.commitEdit$.subscribe((pEventArgs) => {
                if (pEventArgs.data != null) {
                    const index = this.items.indexOf(pEventArgs.sender.item);
                    this.onListChanged(new BravoListChangedEventArgs(ListChangedTypeEnum.ItemChanged, index, index, pEventArgs.data));
                }
            });
            this._table.currentChanged.addHandler(pSender => {
                const table = tryCast(pSender, BravoDataInterfaceNamingConstants.IDataTable);
                if (table == null)
                    return;
                if (table.isUpdating || this.isUpdating)
                    return;
                const index = this.items.indexOf(table.currentItem);
                if (index >= 0 && index != this._idx) {
                    this.moveCurrentToPosition(index);
                }
            });
            if (this.itemsEdited)
                this.itemsEdited.collectionChanged.addHandler((pSender, pEventArgs) => {
                    if (this.table)
                        this.table.handleCollectionChanged(this.sourceCollection, new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Change, pEventArgs.item, this.sourceCollection.indexOf(pEventArgs.item)));
                });
            src = this._table.sourceCollection;
            this._idx = this._table.currentPosition;
            // if (src && !(src instanceof Array)) src = [...pSourceCollection];
        }
        else {
            src = pSourceCollection;
        }
        this.sourceCollection = src ? src : new ObservableArray$1();
    }
    _handleTableRefreshViewRelation() {
        if (this.table) {
            if (this.isAddingNew)
                this.commitNew();
            if (this.isEditingItem)
                this.commitEdit();
            this.refresh();
            if (this.currentPosition == -1)
                this.moveCurrentToFirst();
            this.onListChanged(new BravoListChangedEventArgs(ListChangedTypeEnum.Reset, -1, -1));
        }
    }
    commitNew() {
        if (this.isAddingNew)
            this.onListChanged(new BravoListChangedEventArgs(ListChangedTypeEnum.ItemAdded, this.currentPosition, -1));
        super.commitNew();
    }
    moveCurrentToPosition(pIndex) {
        const oldPos = this._idx;
        const index = super.moveCurrentToPosition(pIndex);
        if (pIndex >= -1 && pIndex < this._pgView.length && pIndex != oldPos) {
            const e = new BravoListChangedEventArgs(ListChangedTypeEnum.ItemMoved, pIndex, oldPos);
            this.onListChanged(e);
        }
        if (this.table && this.table.currentItem != this.currentItem)
            this.table.moveCurrentTo(this.currentItem);
        return index;
    }
    _sameValue(pVal1, pVal2, pLevel) {
        if (pVal1 instanceof Uint8Array || pVal2 instanceof Uint8Array)
            return BravoDataConvertUtil.compareValue(pVal1, pVal2, TypeCodeEnum.ByteArray);
        return super._sameValue(pVal1, pVal2, pLevel);
    }
    _extend(pDest, pSource, pLevel) {
        if (pLevel === 0)
            pLevel = 2;
        for (const key in pSource) {
            try {
                const val = pSource[key];
                if (val instanceof Uint8Array) {
                    pDest[key] = new Uint8Array(val);
                }
                else if (BravoArrayExtensions.isArray(val)) {
                    pDest[key] = [...BravoArrayExtensions.asArray(val)];
                }
                else if (pLevel != null &&
                    pLevel > 0 &&
                    !(val instanceof Uint8Array) &&
                    BravoObjectExtensions.isObject(val)) {
                    pDest[key] = {};
                    this._extend(pDest[key], val, pLevel - 1);
                }
                else {
                    pDest[key] = val;
                }
            }
            catch {
                /** empty */
            }
        }
        return pDest;
    }
    newItemCreator = () => {
        const item = {};
        if (!this.table)
            return item;
        for (const col of this.table.columns) {
            item[col.columnName] = col.defaultValue;
        }
        return item;
    };
    remove(pItem) {
        const index = this.sourceCollection?.indexOf(pItem);
        if (this.table)
            this.table.remove(pItem);
        super.remove(pItem);
        if (index >= 0) {
            this.onListChanged(new BravoListChangedEventArgs(ListChangedTypeEnum.ItemDeleted, index));
        }
    }
    _createGroups(pItems) {
        let root = null;
        if (!this._grpDesc || this._grpDesc.length == 0)
            return null;
        if ((this.table && !this.table.isOverrideCreateGroup) || this._grpDesc.length > 1) {
            root = super._createGroups(pItems);
            return root;
        }
        let lastGroup = null;
        if (root == null)
            root = [];
        for (let i = 0; i < pItems.length; i++) {
            const item = pItems[i], levels = this._grpDesc.length;
            let groups = root;
            let path = '';
            for (let level = 0; level < levels; level++) {
                const groupDesc = this._grpDesc[level], name = groupDesc.groupNameFromItem(item, level), last = level == levels - 1;
                const group = this.getGroup(groupDesc, groups, name, level, last, lastGroup);
                // keep group path (all names in the hierarchy)
                path += '/' + name;
                group._path = path;
                // add data items to last level groups
                if (last) {
                    group.items.push(item);
                }
                // move on to the next group
                groups = group.groups;
                lastGroup = group;
            }
        }
        return root;
    }
    getGroup(gd, groups, name, level, isBottomLevel, lastGroup) {
        let g = null;
        if (lastGroup == null || !BravoStringExtensions.compareStrings(lastGroup.name, name)) {
            g = new BravoCollectionViewGroup(gd, name, level, isBottomLevel);
            groups.push(g);
        }
        return g != null ? g : lastGroup;
    }
    _compareItems() {
        if (this._srtCmp == null)
            this._srtCmp = this._sortCmp.bind(this);
        return super._compareItems();
    }
    _sortCmp(pVal1, pVal2) {
        if (pVal1 != null && pVal2 == null)
            return +1;
        if (pVal1 == null && pVal2 != null)
            return -1;
        return null;
    }
    _performFilter(pItems) {
        if (this.table && this.table.parentRelations.length > 0)
            pItems = pItems.filter(this._filterRelation, this);
        return super._performFilter(pItems);
    }
    _filterRelation(pItem) {
        if (!this.table || this.table.parentRelations.length < 1)
            return true;
        for (let i = 0; i < this.table.parentRelations.length; i++) {
            const relation = tryCast(this.table.parentRelations[i], BravoDataInterfaceNamingConstants.IDataRelation);
            if (relation == null)
                continue;
            const keys = new Map();
            const childKeys = relation.childKey?.getColumnNames() ?? [];
            const parentKeys = relation.parentKey?.getColumnNames() ?? [];
            childKeys.map((pValue, pIndex) => keys.set(pValue, parentKeys[pIndex]));
            if (BravoDataView._filterWithRelation(pItem, relation.parentTable?.currentItem, keys))
                return true;
        }
        return false;
    }
    onCurrentChanged(pEventArgs) {
        super.onCurrentChanged(pEventArgs);
        if (this.table) {
            if (this.table.childRelations.length > 0) {
                for (let i = 0; i < this.table.childRelations.length; i++) {
                    const relation = tryCast(this.table.childRelations[i], BravoDataInterfaceNamingConstants.IDataRelation);
                    if (!relation || !relation.childTable)
                        continue;
                    relation.childTable.onRefreshingViewRelation();
                    this.table.currentItem = this.currentItem;
                    relation.childTable.onRefreshViewRelation();
                }
            }
        }
    }
    onCollectionChanged(pEventArgs) {
        if (pEventArgs instanceof NotifyCollectionChangedEventArgs) {
            if (pEventArgs.action == NotifyCollectionChangedAction.Change) {
                if (this.items.indexOf(pEventArgs.item) < 0)
                    return;
            }
        }
        // if (this.table && e instanceof wjc.NotifyCollectionChangedEventArgs)
        //     this.table.handleCollectionChanged(this.sourceCollection, e);
        super.onCollectionChanged(pEventArgs);
    }
    addNew() {
        const item = super.addNew();
        if (this.table) {
            const source = tryCast(this.table.sourceCollection, ObservableArray$1);
            if (!source)
                return item;
            const e = new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Add, item, source.indexOf(item));
            this.table.handleCollectionChanged(this.sourceCollection, e);
            if (source.indexOf(item) < 0)
                source.push(item);
            const dr = BravoDataRowCollection.getRow(item, this.table.rows);
            const drv = new BravoDataRowView(this, dr);
            return drv;
        }
        return item;
    }
    _rowFilterFn(pItem, pExpressionEval) {
        if (!this._rowFilter || !pExpressionEval)
            return true;
        try {
            let item;
            if (this.table)
                item = BravoDataRowCollection.getRow(pItem, this.table.rows);
            if (item == null)
                item = pItem;
            return pExpressionEval.isTrue(this._rowFilter, item);
        }
        catch (ex) {
            console.warn(this._rowFilter, ex);
            return false;
        }
    }
    dispose() {
        for (const prop in this) {
            try {
                const evt = this[prop];
                if (evt instanceof Event) {
                    evt.removeAllHandlers();
                }
            }
            catch {
                /** empty */
            }
        }
        if (this._table)
            this._table = undefined;
    }
    implementsInterface(pInterfaceName) {
        return (BravoStringExtensions.compareStrings(pInterfaceName, BravoDataInterfaceNamingConstants.IDataView) ||
            BravoStringExtensions.compareStrings(pInterfaceName, BravoDataInterfaceNamingConstants.IBindingList) ||
            super.implementsInterface(pInterfaceName));
    }
}

/**
 * Generated bundle index. Do not edit.
 */

export { BravoCollectionView, BravoCollectionViewGroup, BravoConstraint, BravoConstraintCollection, BravoDataColumn, BravoDataColumnChangeEventArgs, BravoDataColumnCollection, BravoDataCommand, BravoDataConstants, BravoDataConvertUtil, BravoDataInterfaceNamingConstants, BravoDataParameter, BravoDataParameterUtil, BravoDataRelation, BravoDataRelationCollection, BravoDataRow, BravoDataRowChangeEventArgs, BravoDataRowCollection, BravoDataRowView, BravoDataSet, BravoDataSetRelationCollection, BravoDataTable, BravoDataTableCollection, BravoDataTableRelationCollection, BravoDataView, BravoForeignKeyConstraint, BravoFormatterUtil, BravoParameterCollection, BravoPropertyGroupDescription, BravoSortDescription, BravoUniqueConstraint, BravoXmlStringTypeEnum, CommandTypeEnum, DataRowActionEnum, DataRowStateEnum, DataRowVersionEnum, DataViewRowStateEnum, DbTypeEnum, IsolationLevelEnum, MissingSchemaActionEnum, ParameterDirectionEnum, RowIndexProp, RuleEnum, SerializeOptionEnum, SortPattern, TypeCodeEnum, UpdateRowSourceEnum, XmlReadModeEnum, XmlWriteModeEnum, arraysIdentical, buildSort, buildSortString, convertTypeToDbType, getKeyValues, getType, setCurrentEditItem, sortBy, toDataRelationName };
//# sourceMappingURL=bravo-infra-core-data.mjs.map
