import { BravoRegexes, BravoStringExtensions, BravoUTF8, BravoConverterExtensions } from '@bravo-infra/core/utils/data-extensions';
import { BravoAppSettings } from '@bravo-infra/core/utils/global-settings';
import saveAs from 'file-saver';
import * as fflate from 'fflate';

var FileTypeEnum;
(function (FileTypeEnum) {
    FileTypeEnum[FileTypeEnum["Unknown"] = 0] = "Unknown";
    FileTypeEnum[FileTypeEnum["Pdf"] = 1] = "Pdf";
    FileTypeEnum[FileTypeEnum["Bmp"] = 2] = "Bmp";
    FileTypeEnum[FileTypeEnum["Jpg"] = 3] = "Jpg";
    FileTypeEnum[FileTypeEnum["Gif"] = 4] = "Gif";
    FileTypeEnum[FileTypeEnum["Tif"] = 5] = "Tif";
    FileTypeEnum[FileTypeEnum["Png"] = 6] = "Png";
    FileTypeEnum[FileTypeEnum["Psd"] = 7] = "Psd";
    FileTypeEnum[FileTypeEnum["Wmf"] = 8] = "Wmf";
    FileTypeEnum[FileTypeEnum["Ico"] = 9] = "Ico";
    FileTypeEnum[FileTypeEnum["Mp3"] = 10] = "Mp3";
    FileTypeEnum[FileTypeEnum["Avi"] = 11] = "Avi";
    FileTypeEnum[FileTypeEnum["Swf"] = 12] = "Swf";
    FileTypeEnum[FileTypeEnum["Flv"] = 13] = "Flv";
    FileTypeEnum[FileTypeEnum["Mp4"] = 14] = "Mp4";
    FileTypeEnum[FileTypeEnum["Mov"] = 15] = "Mov";
    FileTypeEnum[FileTypeEnum["Wmv"] = 16] = "Wmv";
    FileTypeEnum[FileTypeEnum["Wma"] = 17] = "Wma";
    FileTypeEnum[FileTypeEnum["Zip"] = 18] = "Zip";
    FileTypeEnum[FileTypeEnum["Docx"] = 19] = "Docx";
    FileTypeEnum[FileTypeEnum["Xlsx"] = 20] = "Xlsx";
    FileTypeEnum[FileTypeEnum["Pptx"] = 21] = "Pptx";
    FileTypeEnum[FileTypeEnum["Xps"] = 22] = "Xps";
    FileTypeEnum[FileTypeEnum["Rar"] = 23] = "Rar";
    FileTypeEnum[FileTypeEnum["Doc"] = 24] = "Doc";
    FileTypeEnum[FileTypeEnum["Rtf"] = 25] = "Rtf";
    FileTypeEnum[FileTypeEnum["Xls"] = 26] = "Xls";
    FileTypeEnum[FileTypeEnum["Ppt"] = 27] = "Ppt";
    FileTypeEnum[FileTypeEnum["Eps"] = 28] = "Eps";
    FileTypeEnum[FileTypeEnum["Wav"] = 29] = "Wav";
    FileTypeEnum[FileTypeEnum["Flac"] = 30] = "Flac";
    FileTypeEnum[FileTypeEnum["Mkv"] = 31] = "Mkv";
    FileTypeEnum[FileTypeEnum["Xml"] = 32] = "Xml";
    FileTypeEnum[FileTypeEnum["Msi"] = 33] = "Msi";
    FileTypeEnum[FileTypeEnum["Txt"] = 34] = "Txt";
    FileTypeEnum[FileTypeEnum["Dot"] = 35] = "Dot";
    FileTypeEnum[FileTypeEnum["Sql"] = 36] = "Sql";
    FileTypeEnum[FileTypeEnum["Folder"] = 37] = "Folder";
})(FileTypeEnum || (FileTypeEnum = {}));
var FileFilterEnum;
(function (FileFilterEnum) {
    FileFilterEnum[FileFilterEnum["DocumentFiles"] = 1] = "DocumentFiles";
    FileFilterEnum[FileFilterEnum["ImageFiles"] = 2] = "ImageFiles";
    FileFilterEnum[FileFilterEnum["VideoFiles"] = 4] = "VideoFiles";
    FileFilterEnum[FileFilterEnum["AllFiles"] = 8] = "AllFiles";
})(FileFilterEnum || (FileFilterEnum = {}));
var TypeFileInputEnum;
(function (TypeFileInputEnum) {
    TypeFileInputEnum[TypeFileInputEnum["Attached"] = 0] = "Attached";
    TypeFileInputEnum[TypeFileInputEnum["File"] = 1] = "File";
    TypeFileInputEnum[TypeFileInputEnum["Path"] = 2] = "Path";
})(TypeFileInputEnum || (TypeFileInputEnum = {}));
var FileOverwriteOptionEnum;
(function (FileOverwriteOptionEnum) {
    FileOverwriteOptionEnum[FileOverwriteOptionEnum["NoOverwrite"] = 0] = "NoOverwrite";
    FileOverwriteOptionEnum[FileOverwriteOptionEnum["Overwrite"] = 1] = "Overwrite";
    FileOverwriteOptionEnum[FileOverwriteOptionEnum["AutoRename"] = 2] = "AutoRename";
})(FileOverwriteOptionEnum || (FileOverwriteOptionEnum = {}));
var FileActionEnum;
(function (FileActionEnum) {
    FileActionEnum[FileActionEnum["Add"] = 0] = "Add";
    FileActionEnum[FileActionEnum["Delete"] = 1] = "Delete";
    FileActionEnum[FileActionEnum["Remove"] = 99] = "Remove";
})(FileActionEnum || (FileActionEnum = {}));
var FileAccessModeEnum;
(function (FileAccessModeEnum) {
    FileAccessModeEnum[FileAccessModeEnum["Private"] = 0] = "Private";
    FileAccessModeEnum[FileAccessModeEnum["Public"] = 1] = "Public";
})(FileAccessModeEnum || (FileAccessModeEnum = {}));

class BravoFileExtensions {
    static ImgTypesCommon = ['.jpeg', '.jpg', '.png', '.gif', '.bmp', '.svg', '.tiff', '.webp'];
    static PublicFolder = 'pub';
    static TempFolder = 'temp';
    static AssetsImg = 'assets/img';
    static AllFileFilter = '*.*';
    static OpenDocumentFileFilter = '*.pdf;*.doc;*.dot;*.docx;*.docm;*.dotx;*.dotm;*.xls;*.xlt;*.xlsx;*.xlsm;*.xltx;*.xltm;*.xlsb;*.xlam;*.csv;*.ppt;*.pptx;*.pptm;*.ppsx;*.ppsm;*.potx;*.potm;*.ppam;*.xps;*.odt;*.ods;*.odp;*.rtf;*.xml;*.txt';
    static OpenImageFileFilter = '*.bmp;*.jpg;*.jpeg;*.gif;*.png;*.tif';
    static OpenVideoFilesFilter = '*.mp4;*.avi;*.mov;*.mkv;*.wmv;*.flv;*.mpeg;*.mpg';
    /**
     * Extracts the base name of a file (without extension) from a file path.
     *
     * This function handles both simple filenames and full file paths by:
     * 1. Extracting only the filename portion from the path
     * 2. Removing the file extension if present
     *
     * @param pFilePath - The full path or name of the file
     * @returns The file name without its extension
     *
     * @example
     * ```typescript
     * BravoFileExtensions.getFileNameWithoutExtension('document.pdf')        // Returns: 'document'
     * BravoFileExtensions.getFileNameWithoutExtension('folder/file.txt')     // Returns: 'file'
     * BravoFileExtensions.getFileNameWithoutExtension('path/to/image.jpg')   // Returns: 'image'
     * BravoFileExtensions.getFileNameWithoutExtension('file')                // Returns: 'file'
     * BravoFileExtensions.getFileNameWithoutExtension('archive.tar.gz')      // Returns: 'archive.tar'
     * BravoFileExtensions.getFileNameWithoutExtension('.gitignore')          // Returns: '.gitignore'
     * ```
     */
    static getFileNameWithoutExtension(pFilePath) {
        // Extract only the filename from the path (handle both / and \ separators)
        const fileName = pFilePath.split(/[/\\]/).pop() || pFilePath;
        // Remove the extension (last dot and everything after it)
        const lastDotIndex = fileName.lastIndexOf('.');
        // If no dot found, or dot is at the start (hidden files like .gitignore), return as is
        if (lastDotIndex <= 0) {
            return fileName;
        }
        return fileName.substring(0, lastDotIndex);
    }
    /**
     * Returns a display-friendly file name from a path, optionally removing the file name if it's a server path or link.
     *
     * @param pPath - The file path or URL.
     * @returns The display file name or path.
     *
     * @example
     * BravoFileExtensions.getDisplayFileName('folder/file.txt'); // 'file.txt'
     * BravoFileExtensions.getDisplayFileName('http://example.com/file.txt', true); // 'file.txt'
     */
    static getFileNameOnly(pPath) {
        const isPathSeverOrLink = BravoRegexes.Url.test(pPath) || BravoRegexes.FilePathServer.test(pPath);
        if (isPathSeverOrLink)
            pPath = pPath.replace(BravoRegexes.FileNameFromPath, '');
        return pPath;
    }
    /**
     * Returns the file extension from a given filename.
     *
     * @param pFilename - The name of the file from which to extract the extension.
     * @returns The file extension as a string. If no extension is found, returns the original filename.
     */
    static getExtension(pFilename) {
        return pFilename.substring(pFilename.lastIndexOf('.') + 1, pFilename.length) || pFilename;
    }
    /**
     * Returns the path to the SVG icon in the assets folder corresponding to the file extension or type of the given path.
     *
     * This method determines the file extension from the provided path and maps it to a predefined file type.
     * If the file type is unknown, it checks if the path matches a URL or server file path pattern and assigns a generic icon.
     * Otherwise, it defaults to a generic file icon.
     *
     * @param pPath - The file path or URL to determine the icon for.
     * @returns The relative path to the SVG icon in the assets/images directory.
     */
    static getFileIconInAssetsByPath(pPath) {
        let fileType = FileTypeEnum.Unknown;
        let fileExtension = this.getExtension(pPath);
        if (fileExtension)
            if (fileExtension)
                fileType =
                    FileTypeEnum[FileTypeEnum[BravoStringExtensions.firstUpperCase(fileExtension)]] ||
                        FileTypeEnum.Unknown;
            else
                fileType = FileTypeEnum.Unknown;
        if (fileType === FileTypeEnum.Unknown) {
            if (BravoRegexes.Url.test(pPath) || BravoRegexes.FilePathServer.test(pPath))
                fileExtension = 'file-attach';
            else
                fileExtension = 'file';
        }
        return `assets/${BravoAppSettings.settings.prefixLibAssets}/images/files/${fileExtension}.svg`;
    }
    /**
     * Builds a dynamic regular expression to match file extensions based on a comma-separated list of accepted types.
     *
     * @param pAcceptedTypes - A comma-separated string of file extensions (e.g., "jpg,png,gif").
     * @returns A case-insensitive RegExp that matches file names ending with one of the specified extensions.
     *
     * @example
     * const regex = FileExtensionUtil.buildDynamicFileTypeRegex("jpg,png,gif");
     * console.log(regex.test("image.JPG")); // true
     * console.log(regex.test("document.pdf")); // false
     */
    static buildDynamicFileTypeRegex(pAcceptedTypes) {
        const typesArray = pAcceptedTypes.split(',').map(pType => pType.trim());
        const dynamicRegex = new RegExp(`\\.(${typesArray.join('|')})$`, 'i');
        return dynamicRegex;
    }
    /**
     * Validates whether the given file path has an allowed file extension.
     *
     * @param pFilePath - The file path to validate.
     * @param pAllowedExtensions - A comma-separated string of allowed file extensions (e.g., "jpg,png,gif").
     * @returns `true` if the file path ends with one of the allowed extensions; otherwise, `false`.
     *
     * @example
     * ```typescript
     * validateFileExtension('image.jpg', 'jpg,png'); // returns true
     * validateFileExtension('document.pdf', 'jpg,png'); // returns false
     * validateFileExtension('folder/photo.PNG', 'jpg,png'); // returns true (case-insensitive)
     * validateFileExtension('archive.tar.gz', 'gz,zip'); // returns true
     * ```
     */
    static validateFileExtension(pFilePath, pAllowedExtensions) {
        if (!pAllowedExtensions || !pAllowedExtensions.trim())
            return false;
        if (this.isAcceptAllExtensions(pAllowedExtensions))
            return true;
        const extensions = pAllowedExtensions
            .split(',')
            .map(pExt => BravoStringExtensions.trimChars(pExt.trim()).replace(/^\./, ''))
            .filter(Boolean);
        const pattern = new RegExp(`^(?:[^\\\\/:*?"<>|]+[\\/\\\\])*[^\\\\/:*?"<>|]+\\.(${extensions.join('|')})$`, 'iu');
        return pattern.test(pFilePath);
    }
    /**
     * Checks whether the allowed extensions string represents "accept all".
     * Accepted wildcard forms:
     *   "*"   → any extension
     *   "*.*" → any extension
     *   ".*"  → any extension
     *
     * @param {string} pAllowedExtensions - Raw extension string from config or user input.
     * @returns {boolean} True if it means accept-all.
     */
    static isAcceptAllExtensions(pAllowedExtensions) {
        if (!pAllowedExtensions || !pAllowedExtensions.trim())
            return false;
        const items = pAllowedExtensions.split(',').map(x => x.trim());
        const wildcardForms = new Set(['*', '*.*', '.*']);
        // All items MUST be wildcard forms to count as accept-all
        return items.every(pX => wildcardForms.has(pX));
    }
    /**
     * Merges two file accept strings (e.g., ".jpg,.png" and ".gif,.png") into a single, deduplicated, normalized string.
     *
     * @param pAccept1 - The first accept string (comma-separated file extensions).
     * @param pAccept2 - The second accept string (comma-separated file extensions).
     * @returns A comma-separated string of unique, normalized file extensions.
     *
     * @example
     * BravoFileExtensions.mergeFileAccepts('.jpg,.png', '.gif,.png'); // ".jpg,.png,.gif"
     * BravoFileExtensions.mergeFileAccepts('jpg,png', 'gif,png');     // ".jpg,.png,.gif"
     */
    static mergeFileAccepts(pAccept1, pAccept2) {
        const typesArray1 = this.buildAcceptTypeStringWithCheck(pAccept1)
            .split(',')
            .map(pItem => pItem.trim());
        const typesArray2 = this.buildAcceptTypeStringWithCheck(pAccept2)
            .split(',')
            .map(pItem => pItem.trim());
        const mergedTypesArray = Array.from(new Set([...typesArray1, ...typesArray2]));
        return mergedTypesArray.join(',');
    }
    /**
     * Finds the intersection (subset) of file types between two accept strings.
     *
     * @param pAcceptParent - The parent accept string (comma-separated file extensions).
     * @param pAcceptChild - The child accept string (comma-separated file extensions).
     * @returns A comma-separated string of file extensions that are present in both acceptParent and acceptChild.
     *
     * @example
     * BravoFileExtensions.findSubsetFileTypes('.jpg,.png,.gif', '.png,.bmp'); // ".png"
     * BravoFileExtensions.findSubsetFileTypes('jpg,png,gif', 'png,bmp');      // ".png"
     */
    static findSubsetFileTypes(pAcceptParent, pAcceptChild) {
        const parentArray = this.buildAcceptTypeStringWithCheck(pAcceptParent)
            .split(',')
            .map(pItem => pItem.trim());
        const childArray = this.buildAcceptTypeStringWithCheck(pAcceptChild)
            .split(',')
            .map(pItem => pItem.trim());
        const subsetTypes = childArray.filter(pType => parentArray.includes(pType));
        return subsetTypes.join(','); // Returns a string, not an array
    }
    /**
     * Normalizes a comma-separated string of file types/extensions.
     * Ensures each extension starts with a dot and is lowercase, trims whitespace, and joins them back into a string.
     *
     * @param pFileTypesStr - The input string of file types/extensions (e.g., "jpg, PNG, .gif").
     * @returns A normalized, comma-separated string of file extensions (e.g., ".jpg,.png,.gif").
     *
     * @example
     * BravoFileExtensions.buildAcceptTypeStringWithCheck('jpg, PNG, .gif'); // ".jpg,.png,.gif"
     * BravoFileExtensions.buildAcceptTypeStringWithCheck('.JPG,.pdf');      // ".jpg,.pdf"
     */
    static buildAcceptTypeStringWithCheck(pFileTypesStr) {
        return pFileTypesStr
            .split(',')
            .map(pType => {
            pType = pType.trim(); // Remove extra whitespace
            // Ensure the extension starts with a dot
            return pType.startsWith('.') ? pType.toLocaleLowerCase() : `.${pType}`.toLowerCase();
        })
            .join(',');
    }
    /**
     * Checks if the given accept string allows all file types.
     *
     * @param pAcceptTypes - The accept string to check (e.g., "*", "*.*", ".jpg,.png").
     * @returns `true` if all file types are accepted, otherwise `false`.
     *
     * @example
     * BravoFileExtensions.isFilesAcceptsAll('*');    // true
     * BravoFileExtensions.isFilesAcceptsAll('*.*');  // true
     * BravoFileExtensions.isFilesAcceptsAll('.jpg'); // false
     */
    static isFilesAcceptsAll(pAcceptTypes) {
        return pAcceptTypes === '*' || pAcceptTypes === '*.*';
    }
    /**
     * Merges client and server file accept strings, returning only the allowed file types.
     * If the client accepts all ("*" or "*.*"), returns the server's allowed types.
     * Otherwise, returns the intersection of client and server types.
     *
     * @param pFileAcceptClient - The client accept string (e.g., ".jpg,.png" or "*").
     * @param pFileAcceptClientServer - The server accept string (e.g., ".jpg,.png").
     * @returns A comma-separated string of allowed file extensions.
     *
     * @example
     * BravoFileExtensions.mergeAcceptFileTypeFromClientAndServer('*', '.jpg,.png'); // ".jpg,.png"
     * BravoFileExtensions.mergeAcceptFileTypeFromClientAndServer('.jpg,.gif', '.jpg,.png'); // ".jpg"
     */
    static mergeAcceptFileTypeFromClientAndServer(pFileAcceptClient, pFileAcceptClientServer) {
        if (pFileAcceptClient === pFileAcceptClientServer)
            return pFileAcceptClientServer;
        const serverValidFileExt = pFileAcceptClientServer;
        if (serverValidFileExt) {
            if (pFileAcceptClient === '*' || pFileAcceptClient === '*.*' || pFileAcceptClient === '.*') {
                return this.buildAcceptTypeStringWithCheck(serverValidFileExt);
            }
            else
                return this.findSubsetFileTypes(serverValidFileExt, pFileAcceptClient);
        }
        return this.buildAcceptTypeStringWithCheck(pFileAcceptClient);
    }
    /**
     * Validates an array of files against a size limit, separating valid and invalid files.
     *
     * @param pVal - The array of File objects to validate.
     * @param pSizeLimit - The maximum allowed file size in bytes.
     * @returns An object with two arrays: `filesValid` (files within the size limit) and `filesInvalid` (files exceeding the limit).
     *
     * @example
     * const files = [new File(['a'], 'a.txt', {size: 100}), new File(['b'], 'b.txt', {size: 2000})];
     * BravoFileExtensions.validateFilesSize(files, 1024);
     * // => { filesValid: [File('a.txt')], filesInvalid: [File('b.txt')] }
     */
    static validateFilesSize(pVal, pSizeLimit) {
        const filesInvalid = Array.from(pVal).filter(pItem => pItem.size > pSizeLimit);
        const filesValid = Array.from(pVal).filter(pItem => pItem.size <= pSizeLimit);
        //trigger event file not valid
        return {
            filesValid,
            filesInvalid,
        };
    }
    /**
     * Validates an array of files against allowed file extensions, separating valid and invalid files.
     *
     * @param pFiles - The array of File objects to validate.
     * @param pFileAccept - A comma-separated string of allowed file extensions (e.g., "jpg,png,gif" or "*").
     * @returns An object with two arrays: `filesValid` (files with allowed extensions) and `filesInvalid` (files with disallowed extensions).
     *
     * @example
     * const files = [
     *   new File(['a'], 'a.jpg'),
     *   new File(['b'], 'b.txt'),
     *   new File(['c'], 'c.png')
     * ];
     * BravoFileExtensions.validateFilesTypePicked(files, 'jpg,png');
     * // => { filesValid: [File('a.jpg'), File('c.png')], filesInvalid: [File('b.txt')] }
     */
    static validateFilesTypePicked(pFiles, pFileAccept) {
        let filesInvalid = [];
        let filesValid = pFiles;
        if (this.isFilesAcceptsAll(pFileAccept))
            return {
                filesValid,
                filesInvalid,
            };
        filesValid = Array.from(pFiles).filter(pFile => this.validateFileExtension(pFile.name, pFileAccept));
        if (filesValid.length !== pFiles.length)
            filesInvalid = [
                ...filesValid.filter(pItem => !pFiles.includes(pItem)),
                ...pFiles.filter(pItem => !filesValid.includes(pItem)),
            ];
        return {
            filesValid,
            filesInvalid,
        };
    }
    /**
     * Checks if the given path is a public file path (i.e., starts with the public folder).
     *
     * @param pPath - The file path to check.
     * @returns `true` if the path is in the public folder, otherwise `false`.
     *
     * @example
     * BravoFileExtensions.isPublic('pub/images/logo.png'); // true
     * BravoFileExtensions.isPublic('temp/file.txt');       // false
     */
    static isPublic(pPath) {
        const isPublic = pPath && (pPath.trim().replace(/^\/|\\$/g, '') + '/').startsWith(`${this.PublicFolder}/`);
        return isPublic;
    }
    /**
     * Builds a file accept string for a file dialog based on the provided filter flags and (optionally) a server-allowed file type string.
     *
     * Combines document, image, and video file filters as specified by the EFileFilter flags.
     * If the AllFiles flag is set, includes all file types.
     * Cleans up the resulting accept string for use in file dialogs.
     * If a server-allowed file type string is provided, merges the client and server accept strings to ensure only allowed types are returned.
     *
     * @param pDialogFileFilter - The EFileFilter flags specifying which file types to allow (bitwise OR of DocumentFiles, ImageFiles, VideoFiles, AllFiles).
     * @param pAcceptFileTypeFromServer - (Optional) A comma-separated string of file types/extensions allowed by the server.
     * @returns A comma-separated string of allowed file extensions for the file dialog.
     *
     * @example
     * // Allow documents and images only
     * BravoFileExtensions.applyDialogFilter(EFileFilter.DocumentFiles | EFileFilter.ImageFiles, '');
     * // => "*.pdf;*.doc;...;*.jpg;*.jpeg;*.png;..."
     *
     * // Allow all files, but restrict to server-allowed types
     * BravoFileExtensions.applyDialogFilter(EFileFilter.AllFiles, '.jpg,.png');
     * // => ".jpg,.png"
     */
    static applyDialogFilter(pDialogFileFilter, pAcceptFileTypeFromServer) {
        let fileTypeAccept = '';
        if ((pDialogFileFilter & FileFilterEnum.DocumentFiles) != 0 &&
            (pDialogFileFilter & FileFilterEnum.ImageFiles) != 0 &&
            (pDialogFileFilter & FileFilterEnum.VideoFiles) != 0) {
            fileTypeAccept +=
                this.OpenDocumentFileFilter + ',' + this.OpenImageFileFilter + ',' + this.OpenVideoFilesFilter;
        }
        else {
            if ((pDialogFileFilter & FileFilterEnum.DocumentFiles) != 0) {
                if (fileTypeAccept)
                    fileTypeAccept += ',';
                fileTypeAccept += this.OpenDocumentFileFilter;
            }
            if ((pDialogFileFilter & FileFilterEnum.ImageFiles) != 0) {
                if (fileTypeAccept)
                    fileTypeAccept += ',';
                fileTypeAccept += this.OpenImageFileFilter;
            }
            if ((pDialogFileFilter & FileFilterEnum.VideoFiles) != 0) {
                if (fileTypeAccept)
                    fileTypeAccept += ',';
                fileTypeAccept += this.OpenVideoFilesFilter;
            }
        }
        if ((pDialogFileFilter & FileFilterEnum.AllFiles) != 0) {
            if (fileTypeAccept)
                fileTypeAccept += ',';
            fileTypeAccept += this.AllFileFilter;
        }
        if (fileTypeAccept && fileTypeAccept !== '*.*') {
            fileTypeAccept = fileTypeAccept.replace(/(;\*\.)/g, ',.');
            fileTypeAccept = fileTypeAccept.replace(/(\*\.)/g, '.');
        }
        if (!pAcceptFileTypeFromServer)
            return fileTypeAccept;
        return this.mergeAcceptFileTypeFromClientAndServer(fileTypeAccept, pAcceptFileTypeFromServer);
    }
    /**
     * Normalize a directory path by:
     * - Removing any trailing slashes (`/`) or backslashes (`\`).
     * - Converting backslashes (`\`) to forward slashes (`/`) in the directory part.
     * - Preserving the file name (if present).
     *
     * Examples:
     * ```ts
     * normalizeDirectoryPath("C:\\Users\\John\\Desktop\\file.txt");
     * // => "C:/Users/John/Desktop/file.txt"
     *
     * normalizeDirectoryPath("/home/user/docs/");
     * // => "/home/user/docs"
     *
     * normalizeDirectoryPath("file.txt");
     * // => "file.txt"
     * ```
     *
     * @param pPath - The input path string to normalize.
     * @returns The normalized path string. Returns an empty string if input is falsy.
     */
    static normalizeDirectoryPath(pPath) {
        if (!pPath)
            return '';
        // Bỏ dấu / hoặc \ ở cuối (nếu có)
        const normalizedPath = pPath.replace(/[\\/]+$/, '');
        // Tìm vị trí dấu / hoặc \ cuối cùng để tách tên file
        const lastSlashIndex = Math.max(normalizedPath.lastIndexOf('/'), normalizedPath.lastIndexOf('\\'));
        if (lastSlashIndex === -1) {
            return pPath; // Không có thư mục cha
        }
        const dir = normalizedPath.substring(0, lastSlashIndex);
        const file = normalizedPath.substring(lastSlashIndex + 1);
        // Chỉ thay trong thư mục
        const normalizedDir = dir.replace(/\\/g, '/');
        return `${normalizedDir}/${file}`;
    }
    /**
     * Determines if a file is an image using multiple strategies:
     * - MIME type (preferred, if available)
     * - File extension (fallback)
     * - Magic bytes / file signature (last resort)
     *
     * @param {File} pFile - The file to check.
     * @returns {Promise<boolean>} Resolves to true if the file is detected as an image, otherwise false.
     */
    static async isImage(pFile) {
        //MIME
        if (this.isImageByType(pFile))
            return true;
        // fallback: extension
        if (this.isImageByExtension(pFile))
            return true;
        // magic bytes
        return await this.isImageByMagic(pFile);
    }
    /**
     * Checks if the file is an image by its MIME type.
     *
     * @param {File} pFile - The file to check.
     * @returns {boolean} True if the file has an `image/*` MIME type, otherwise false.
     */
    static isImageByType(pFile) {
        return pFile && pFile.type && pFile.type.startsWith('image/');
    }
    /**
     * Checks if the file is an image by inspecting its magic bytes (file header).
     * Supports formats: JPEG, PNG, GIF, BMP, TIFF, WebP, AVIF/HEIF, and SVG.
     *
     * @param {File} pFile - The file (Blob or File) to check.
     * @returns {Promise<boolean>} Resolves to true if the file matches an image signature, otherwise false.
     */
    static async isImageByMagic(pFile) {
        if (!pFile || !(pFile instanceof Blob))
            return false;
        // read first 32 bytes
        const header = await pFile.slice(0, 64).arrayBuffer();
        const bytes = new Uint8Array(header);
        const textStart = new TextDecoder().decode(bytes.slice(0, 64)).trim();
        // JPEG: FF D8 FF
        if (bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff)
            return true;
        // PNG: 89 50 4E 47 0D 0A 1A 0A
        if (bytes[0] === 0x89 && bytes[1] === 0x50 && bytes[2] === 0x4e && bytes[3] === 0x47)
            return true;
        // GIF: "GIF87a" or "GIF89a"
        if (textStart.startsWith('GIF87a') || textStart.startsWith('GIF89a'))
            return true;
        // BMP: "BM"
        if (textStart.startsWith('BM'))
            return true;
        // TIFF: II* or MM*
        if ((bytes[0] === 0x49 && bytes[1] === 0x49 && bytes[2] === 0x2a) ||
            (bytes[0] === 0x4d && bytes[1] === 0x4d && bytes[2] === 0x00 && bytes[3] === 0x2a))
            return true;
        // WebP: "RIFF"...."WEBP" (bytes 0-3 == 'RIFF' and 8-11 == 'WEBP')
        if (textStart.slice(0, 4) === 'RIFF' && textStart.slice(8, 12) === 'WEBP')
            return true;
        // AVIF/HEIF: contains "ftyp" with brand like "avif", "avis" or "heic" etc.
        const ftypStr = textStart.slice(4, 16);
        if (ftypStr.includes('ftyp') && /avif|avis|heic|mif1|msf1|heix/i.test(textStart))
            return true;
        // SVG: bắt đầu bằng '<' và chứa '<svg'
        if (textStart.startsWith('<') && /<svg[\s>]/i.test(textStart))
            return true;
        return false;
    }
    /**
     * Checks if the file is an image based on its file extension.
     * Supported extensions: jpg, jpeg, png, gif, webp, svg, bmp, tiff, ico, avif.
     *
     * @param {File} pFile - The file to check.
     * @returns {boolean} True if the file extension indicates an image type, otherwise false.
     */
    static isImageByExtension(pFile) {
        const ext = this.getExtension(pFile.name);
        return ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg', 'bmp', 'tiff', 'ico', 'avif'].includes(ext);
    }
    static isTempFolder(pFilePath) {
        return BravoRegexes.TempDirPattern.test(pFilePath) || BravoRegexes.PublicTempDirPattern.test(pFilePath);
    }
    static saveFile(pData, pFilename, pOptions) {
        saveAs(pData, pFilename, pOptions);
    }
}

/**
 * Utility class for creating, reading, and managing ZIP archives using fflate.
 *
 * @example
 * // Create a new ZIP file
 * const zip = BravoZipTool.create();
 * zip.addEntry('example.txt', 'Hello world!');
 * const base64Zip = zip.save('base64');
 *
 * @example
 * // Open an existing ZIP file
 * const zipData = new Uint8Array(...); // some zip data
 * const zip = BravoZipTool.open(zipData);
 * const content = zip.readEntry('example.txt');
 */
class BravoZipTool {
    #zipFile;
    /**
     * Gets the internal ZIP file object (uncompressed entries).
     */
    get zipFile() {
        return this.#zipFile;
    }
    /**
     * Creates a new, empty ZIP tool instance.
     *
     * @returns {BravoZipTool} A new instance of ZipTool with an empty ZIP structure.
     */
    static create() {
        const zipTool = new BravoZipTool();
        zipTool.#zipFile = {};
        return zipTool;
    }
    /**
     * Opens an existing ZIP archive from a Uint8Array.
     *
     * @param {Uint8Array} pData - The ZIP file data as a Uint8Array.
     * @returns {BravoZipTool} A new ZipTool instance initialized with the extracted ZIP entries.
     */
    static open(pData) {
        const zipTool = new BravoZipTool();
        zipTool.#zipFile = fflate.unzipSync(pData);
        return zipTool;
    }
    /**
     * Adds a new entry to the ZIP file.
     *
     * @param {string} pzEntryName - The name of the entry (e.g., "file.txt").
     * @param {Uint8Array | string} pData - The file content as a Uint8Array or a string.
     */
    addEntry(pzEntryName, pData) {
        let data = pData instanceof Uint8Array ? pData : null;
        if (BravoStringExtensions.isString(pData))
            data = BravoUTF8.getBytes(pData);
        if (!this.zipFile)
            this.#zipFile = {};
        if (this.#zipFile && data)
            this.#zipFile[pzEntryName] = data;
    }
    /**
     * Reads a specific entry from the ZIP file.
     *
     * @param {string} pzEntryName - The name of the entry to read.
     * @param {'uint8array' | 'text'} [pResultType='text'] - The output format.
     * @returns {Uint8Array | string | undefined} The entry content in the specified format, or undefined if not found.
     */
    readEntry(pzEntryName, pResultType = 'text') {
        let file;
        for (const key in this.zipFile) {
            if (BravoStringExtensions.compareStrings(pzEntryName, key)) {
                file = this.zipFile[key];
                break;
            }
        }
        if (pResultType == 'text')
            return BravoUTF8.getString(file);
        return file;
    }
    /**
     * Extracts and returns the first entry from the ZIP file.
     *
     * @returns {Uint8Array | undefined} The data of the first entry, or undefined if the ZIP is empty.
     */
    extractFirstEntry() {
        for (const key in this.zipFile) {
            return this.zipFile[key];
        }
        return;
    }
    /**
     * Saves the ZIP file as either a Base64 string or a Uint8Array.
     *
     * @param {'base64' | 'uint8array'} [pType='base64'] - The desired output format.
     * @returns {string | Uint8Array} The compressed ZIP data in the specified format.
     */
    save(pType = 'base64') {
        const result = fflate.zipSync(this.#zipFile);
        return pType == 'base64' ? BravoConverterExtensions.toBase64String(result) : result;
    }
    /**
     * Disposes of the current ZIP file data, freeing memory.
     */
    dispose() {
        if (this.zipFile) {
            this.#zipFile = undefined;
        }
    }
    /**
     * Counts the number of entries in the ZIP file.
     *
     * @returns {number | undefined} The number of entries, or undefined if no ZIP is loaded.
     */
    countsEntries() {
        return this.zipFile && Object.keys(this.zipFile).length;
    }
    /**
     * Gets a list of all entry names in the ZIP file.
     *
     * @returns {string[] | undefined} An array of entry names, or undefined if no ZIP is loaded.
     */
    getEntryNames() {
        return this.zipFile && Object.keys(this.zipFile);
    }
}

/**
 * Generated bundle index. Do not edit.
 */

export { BravoFileExtensions, BravoZipTool, FileAccessModeEnum, FileActionEnum, FileFilterEnum, FileOverwriteOptionEnum, FileTypeEnum, TypeFileInputEnum };
//# sourceMappingURL=bravo-infra-core-utils-files.mjs.map
