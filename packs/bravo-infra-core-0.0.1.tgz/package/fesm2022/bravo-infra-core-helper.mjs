import { Subject, Observable, queueScheduler } from 'rxjs';
import { ObservableMap, BravoStringExtensions, BravoBooleanExtensions, BravoObjectExtensions, asFunction, BravoNumberExtensions, BravoConverterExtensions } from '@bravo-infra/core/utils/data-extensions';
import { HttpErrorResponse } from '@angular/common/http';
import { observeOn } from 'rxjs/operators';

/**
 * A reactive wrapper around the native `BroadcastChannel` API for cross-tab communication,
 * with a fallback to `localStorage` events for environments that do not support it.
 *
 * `BravoBroadcastChannel` enables message broadcasting between multiple browser tabs
 * or windows sharing the same origin. It provides an RxJS `Observable` interface for
 * listening to messages, making it easy to integrate into reactive applications.
 *
 * @template TValue The type of data transmitted through the channel.
 *
 * @example
 * // Create a broadcast channel named "my-channel"
 * const channel = new BravoBroadcastChannel<{ message: string }>('my-channel');
 *
 * // Subscribe to receive messages
 * channel.onDataChanged$.subscribe(data => {
 *   console.log('Received message:', data);
 * });
 *
 * // Send a message
 * channel.postMessage({ message: 'Hello from another tab!' });
 *
 * // Dispose when no longer needed
 * channel.dispose();
 */
class BravoBroadcastChannel {
    /** Internal BroadcastChannel instance (if supported by the environment). */
    #broadCast;
    /** The name of the channel, shared across tabs/windows. */
    #channelName;
    /** The name of the broadcast channel. */
    get channelName() {
        return this.#channelName;
    }
    /** Emits whenever a new message is received through the broadcast or localStorage mechanism. */
    #dataChanged$ = new Subject();
    /**
     * Observable that emits messages of type `TValue` when received.
     *
     * @returns {Observable<TValue>} A stream of received messages.
     */
    get onDataChanged$() {
        return this.#dataChanged$.asObservable();
    }
    /**
     * Creates a new broadcast channel instance with the given name.
     * Falls back to using `localStorage` events if the `BroadcastChannel` API is unavailable.
     *
     * @param {string} pChannelName - The unique name of the channel used for communication.
     */
    constructor(pChannelName) {
        if ('BroadcastChannel' in self) {
            // Use native BroadcastChannel when supported
            this.#broadCast = new BroadcastChannel(pChannelName);
            this.#broadCast.onmessage = this.#handleOnBroadCastChanged.bind(this);
        }
        else {
            // Fallback for browsers/environments without BroadcastChannel
            window.removeEventListener('storage', this.#bindHandleLocalStorageChanged);
            window.addEventListener('storage', this.#bindHandleLocalStorageChanged);
        }
        this.#channelName = pChannelName;
    }
    /**
     * Disposes of the broadcast channel and releases resources.
     *
     * - Closes the `BroadcastChannel` if used.
     * - Removes the `storage` event listener if using the fallback mechanism.
     * - Completes the `onDataChanged$` observable.
     *
     * @example
     * channel.dispose();
     */
    dispose() {
        if (this.#broadCast)
            this.#broadCast.close();
        else
            window.removeEventListener('storage', this.#bindHandleLocalStorageChanged);
        this.#dataChanged$.complete();
    }
    /**
     * Sends a message to all other tabs or windows listening on the same channel.
     *
     * If the `BroadcastChannel` API is not available, it uses `localStorage` as a transport
     * mechanism by writing and removing a key, which triggers the `storage` event.
     *
     * @param {TValue} pzMessage - The message payload to broadcast.
     *
     * @example
     * channel.postMessage({ user: 'Alice', action: 'joined' });
     */
    postMessage(pzMessage) {
        if (this.#broadCast) {
            this.#broadCast.postMessage(pzMessage);
        }
        else {
            localStorage.setItem(this.channelName, JSON.stringify(pzMessage));
            localStorage.removeItem(this.channelName);
        }
    }
    /**
     * Handles messages received via the native `BroadcastChannel`.
     *
     * @param {MessageEvent} pEvt - The broadcast message event.
     * @private
     */
    #handleOnBroadCastChanged(pEvt) {
        // Ignore messages sent from the same window
        if (pEvt.data && pEvt.data.windowGuid == window.name)
            return;
        this.#dataChanged$.next(pEvt.data);
    }
    /**
     * Bound reference to the localStorage change handler.
     * Used to properly add/remove event listeners.
     * @private
     */
    #bindHandleLocalStorageChanged = this.#handleOnLocalStorageChanged.bind(this);
    /**
     * Handles messages propagated via `localStorage` events (fallback mechanism).
     *
     * @param {StorageEvent} pEvt - The storage event containing the new data.
     * @private
     */
    #handleOnLocalStorageChanged(pEvt) {
        // Ensure event belongs to this channel and has valid data
        if (pEvt.storageArea != localStorage || !pEvt.key || !this.channelName || pEvt.key === this.channelName)
            return;
        if (pEvt.newValue == null)
            return;
        this.#dataChanged$.next(pEvt.newValue);
    }
}

/**
 * A cache that supports automatic eviction when
 * the maximum size is exceeded. It follows an LRU (Least Recently Used) strategy.
 */
class BravoLRUCache {
    #cache = new ObservableMap();
    #maxSize;
    #usageOrder = [];
    /**
     * @param pMaxSize Maximum number of items to keep in cache. Defaults to 100.
     */
    constructor(pMaxSize = 100) {
        this.#maxSize = pMaxSize;
    }
    /** Observable that emits whenever the cache changes. */
    get cacheChanged$() {
        return this.#cache.collectionChanged$;
    }
    /** Current number of items in the cache. */
    get size() {
        return this.#cache.size;
    }
    getAll() {
        return Array.from(this.#cache.values());
    }
    /**
     * Retrieves an item from the cache.
     * Marks the item as recently used if found.
     * @param pKey The key of the item.
     * @returns The cached value, or undefined if not found.
     */
    get(pKey) {
        const value = this.#cache.get(pKey);
        if (value) {
            this.#markAsUsed(pKey);
        }
        return value;
    }
    has(pKey) {
        return this.#cache.has(pKey);
    }
    /**
     * Inserts or updates an item in the cache.
     * Automatically evicts the least recently used item if the cache is full.
     * @param pKey The key to insert or update.
     * @param pValue The value to store.
     */
    set(pKey, pValue) {
        if (!this.#cache.has(pKey) && this.size >= this.#maxSize) {
            this.#evict();
        }
        this.#cache.set(pKey, pValue);
        this.#markAsUsed(pKey);
    }
    /**
     * Removes an item from the cache.
     * @param pKey The key of the item to delete.
     * @returns True if the item was deleted, false otherwise.
     */
    delete(pKey) {
        const deleted = this.#cache.delete(pKey);
        if (deleted) {
            this.#usageOrder = this.#usageOrder.filter(k => k !== `${pKey}`);
        }
        return deleted;
    }
    /** Marks an item as recently used (LRU tracking). */
    #markAsUsed(pKey) {
        this.#usageOrder = this.#usageOrder.filter(pKey2 => pKey2 !== pKey);
        this.#usageOrder.push(pKey);
    }
    /** Evicts the least recently used item from the cache. */
    #evict() {
        const oldestKey = this.#usageOrder.shift();
        if (oldestKey) {
            this.#cache.delete(oldestKey);
        }
    }
    clear() {
        this.#cache.clear();
    }
}

const BravoErrorsInterfaceNamingConstants = {
    IBravoArgumentNullException: 'IBravoArgumentNullException',
    IError: 'IError',
    IBravoDbMessageException: 'IDbMessageException',
    IBravoException: 'IBravoException',
    IBravoMaintenanceException: 'IBravoMaintenanceException',
    IBravoPermissionException: 'IBravoPermissionException',
    IBravoUserLimitExceededException: 'IBravoUserLimitExceededException',
    IBravoFileExistedException: 'IBravoFileExistedException',
    IBravoFileInvalidException: 'IBravoFileInvalidException',
    IBravoFileNotFoundException: 'IBravoFileNotFoundException',
    IBravoInvalidCastException: 'IBravoInvalidCastException',
    IBravoInvalidConstraintException: 'IBravoInvalidConstraintException',
    IBravoInvalidExpressionException: 'IBravoInvalidExpressionException',
    IBravoNullReferenceException: 'IBravoNullReferenceException',
};
var BravoExceptionTypeEnum;
(function (BravoExceptionTypeEnum) {
    BravoExceptionTypeEnum[BravoExceptionTypeEnum["Generic"] = 0] = "Generic";
    BravoExceptionTypeEnum[BravoExceptionTypeEnum["DbConnection"] = 1] = "DbConnection";
    BravoExceptionTypeEnum[BravoExceptionTypeEnum["DbConcurrency"] = 2] = "DbConcurrency";
    BravoExceptionTypeEnum[BravoExceptionTypeEnum["DbLockTimeout"] = 3] = "DbLockTimeout";
    BravoExceptionTypeEnum[BravoExceptionTypeEnum["DbDeadLock"] = 4] = "DbDeadLock";
    BravoExceptionTypeEnum[BravoExceptionTypeEnum["DbQuery"] = 5] = "DbQuery";
    BravoExceptionTypeEnum[BravoExceptionTypeEnum["DbWarningMessage"] = 6] = "DbWarningMessage";
    BravoExceptionTypeEnum[BravoExceptionTypeEnum["Permission"] = 7] = "Permission";
    BravoExceptionTypeEnum[BravoExceptionTypeEnum["ConcurrentEditingLayout"] = 8] = "ConcurrentEditingLayout";
    BravoExceptionTypeEnum[BravoExceptionTypeEnum["TokenExpired"] = 9] = "TokenExpired";
    BravoExceptionTypeEnum[BravoExceptionTypeEnum["PasswordIncorrect"] = 10] = "PasswordIncorrect";
    BravoExceptionTypeEnum[BravoExceptionTypeEnum["PasswordPolicy"] = 11] = "PasswordPolicy";
    BravoExceptionTypeEnum[BravoExceptionTypeEnum["PasswordUsed"] = 12] = "PasswordUsed";
    BravoExceptionTypeEnum[BravoExceptionTypeEnum["PasswordUnmatched"] = 13] = "PasswordUnmatched";
    BravoExceptionTypeEnum[BravoExceptionTypeEnum["FileExisted"] = 14] = "FileExisted";
    BravoExceptionTypeEnum[BravoExceptionTypeEnum["FileNotFound"] = 15] = "FileNotFound";
    BravoExceptionTypeEnum[BravoExceptionTypeEnum["InvalidFile"] = 16] = "InvalidFile";
    BravoExceptionTypeEnum[BravoExceptionTypeEnum["WebPortalError"] = 17] = "WebPortalError";
    BravoExceptionTypeEnum[BravoExceptionTypeEnum["ForgotPasswordException"] = 18] = "ForgotPasswordException";
    BravoExceptionTypeEnum[BravoExceptionTypeEnum["InValidEntry"] = 19] = "InValidEntry";
    BravoExceptionTypeEnum[BravoExceptionTypeEnum["EntryNotFound"] = 20] = "EntryNotFound";
    BravoExceptionTypeEnum[BravoExceptionTypeEnum["ColumnDoesNotExist"] = 21] = "ColumnDoesNotExist";
    BravoExceptionTypeEnum[BravoExceptionTypeEnum["DocumentsAreBeingSigned"] = 22] = "DocumentsAreBeingSigned";
    BravoExceptionTypeEnum[BravoExceptionTypeEnum["UnchangedPassword"] = 23] = "UnchangedPassword";
    BravoExceptionTypeEnum[BravoExceptionTypeEnum["LimitLoginAttempts"] = 100] = "LimitLoginAttempts";
    BravoExceptionTypeEnum[BravoExceptionTypeEnum["UserLimitExceeded"] = 101] = "UserLimitExceeded";
    BravoExceptionTypeEnum[BravoExceptionTypeEnum["RootFolderInvalid"] = 102] = "RootFolderInvalid";
    BravoExceptionTypeEnum[BravoExceptionTypeEnum["FileSizeExceedsLimit"] = 103] = "FileSizeExceedsLimit";
    BravoExceptionTypeEnum[BravoExceptionTypeEnum["LimitUploadFilePerTime"] = 104] = "LimitUploadFilePerTime";
    BravoExceptionTypeEnum[BravoExceptionTypeEnum["Maintenance"] = 510] = "Maintenance";
    BravoExceptionTypeEnum[BravoExceptionTypeEnum["InvalidConnectionProvider"] = 1000] = "InvalidConnectionProvider";
    BravoExceptionTypeEnum[BravoExceptionTypeEnum["InvalidSSOProvider"] = 1001] = "InvalidSSOProvider";
    BravoExceptionTypeEnum[BravoExceptionTypeEnum["InvalidFiscalYear"] = 1002] = "InvalidFiscalYear";
    BravoExceptionTypeEnum[BravoExceptionTypeEnum["SystemCheck"] = 1003] = "SystemCheck";
})(BravoExceptionTypeEnum || (BravoExceptionTypeEnum = {}));

class BravoErrorBase extends Error {
    innerException;
    constructor(pMessage, pInnerException) {
        super(pMessage);
        this.name = BravoErrorsInterfaceNamingConstants.IError;
        this.innerException = pInnerException;
    }
    implementsInterface(pInterfaceName) {
        return pInterfaceName === BravoErrorsInterfaceNamingConstants.IError;
    }
}

class BravoArgumentNullException extends BravoErrorBase {
    constructor(pMessage) {
        super(pMessage);
        this.name = BravoErrorsInterfaceNamingConstants.IBravoArgumentNullException;
    }
    implementsInterface(pInterfaceName) {
        return (super.implementsInterface(pInterfaceName) ||
            pInterfaceName === BravoErrorsInterfaceNamingConstants.IBravoArgumentNullException);
    }
}

class BravoDbMessageException extends BravoErrorBase {
    constructor(pMessage) {
        super(pMessage);
        this.name = BravoErrorsInterfaceNamingConstants.IBravoDbMessageException;
    }
    implementsInterface(pInterfaceName) {
        return (super.implementsInterface(pInterfaceName) ||
            BravoErrorsInterfaceNamingConstants.IBravoDbMessageException === pInterfaceName);
    }
}

class BravoFileExistedException extends BravoErrorBase {
    constructor(pMessage) {
        super(pMessage);
        this.name = BravoErrorsInterfaceNamingConstants.IBravoFileExistedException;
    }
    implementsInterface(pInterfaceName) {
        return (super.implementsInterface(pInterfaceName) ||
            pInterfaceName === BravoErrorsInterfaceNamingConstants.IBravoFileExistedException);
    }
}

class BravoFileInvalidException extends BravoErrorBase {
    constructor(pMessage) {
        super(pMessage);
        this.name = BravoErrorsInterfaceNamingConstants.IBravoFileInvalidException;
    }
    implementsInterface(pInterfaceName) {
        return (super.implementsInterface(pInterfaceName) ||
            pInterfaceName === BravoErrorsInterfaceNamingConstants.IBravoFileInvalidException);
    }
}

class BravoFileNotFoundException extends BravoErrorBase {
    constructor(pMessage) {
        super(pMessage);
        this.name = BravoErrorsInterfaceNamingConstants.IBravoFileNotFoundException;
    }
    implementsInterface(pInterfaceName) {
        return (super.implementsInterface(pInterfaceName) ||
            pInterfaceName === BravoErrorsInterfaceNamingConstants.IBravoFileNotFoundException);
    }
}

class BravoInvalidCastException extends BravoErrorBase {
    constructor(pMessage) {
        super(pMessage);
        this.name = BravoErrorsInterfaceNamingConstants.IBravoInvalidCastException;
    }
    implementsInterface(pInterfaceName) {
        return (super.implementsInterface(pInterfaceName) ||
            pInterfaceName === BravoErrorsInterfaceNamingConstants.IBravoInvalidCastException);
    }
}

class BravoInvalidConstraintException extends BravoErrorBase {
    constructor(pMessage) {
        super(pMessage);
        this.name = BravoErrorsInterfaceNamingConstants.IBravoInvalidConstraintException;
    }
    implementsInterface(pInterfaceName) {
        return (super.implementsInterface(pInterfaceName) ||
            pInterfaceName === BravoErrorsInterfaceNamingConstants.IBravoInvalidConstraintException);
    }
}

class BravoInvalidExpressionException extends BravoErrorBase {
    constructor(pMessage, pInnerException) {
        super(pMessage, pInnerException);
        this.name = BravoErrorsInterfaceNamingConstants.IBravoInvalidExpressionException;
    }
    implementsInterface(pInterfaceName) {
        return (super.implementsInterface(pInterfaceName) ||
            pInterfaceName === BravoErrorsInterfaceNamingConstants.IBravoInvalidExpressionException);
    }
}

class BravoMaintenanceException extends BravoErrorBase {
    constructor(pMessage) {
        super(pMessage);
        this.name = BravoErrorsInterfaceNamingConstants.IBravoMaintenanceException;
    }
    implementsInterface(pInterfaceName) {
        return (super.implementsInterface(pInterfaceName) ||
            pInterfaceName === BravoErrorsInterfaceNamingConstants.IBravoMaintenanceException);
    }
}

class BravoNullReferenceException extends BravoErrorBase {
    constructor(pMessage) {
        super(pMessage);
        this.name = BravoErrorsInterfaceNamingConstants.IBravoNullReferenceException;
    }
    implementsInterface(pInterfaceName) {
        return (super.implementsInterface(pInterfaceName) ||
            pInterfaceName === BravoErrorsInterfaceNamingConstants.IBravoNullReferenceException);
    }
}

class BravoPermissionException extends BravoErrorBase {
    constructor(pMessage) {
        super(pMessage);
        this.name = BravoErrorsInterfaceNamingConstants.IBravoPermissionException;
    }
    implementsInterface(pInterfaceName) {
        return (super.implementsInterface(pInterfaceName) ||
            pInterfaceName === BravoErrorsInterfaceNamingConstants.IBravoPermissionException);
    }
}

class BravoUserLimitExceededException extends BravoErrorBase {
    constructor(pMessage) {
        super(pMessage);
        this.name = BravoErrorsInterfaceNamingConstants.IBravoUserLimitExceededException;
    }
    implementsInterface(pInterfaceName) {
        return (super.implementsInterface(pInterfaceName) ||
            pInterfaceName === BravoErrorsInterfaceNamingConstants.IBravoUserLimitExceededException);
    }
}

/**
 * Base class for event arguments.
 */
class BravoEventArgs {
    /**
     * Provides a value to use with events that do not have event data.
     */
    static empty = new BravoEventArgs();
}

class BravoCancelEventArgs extends BravoEventArgs {
    cancel = false;
}

class BravoDataEventArgs extends BravoEventArgs {
    sender;
    data;
    constructor(pSender, pData) {
        super();
        this.sender = pSender;
        this.data = pData;
    }
}

class BravoListChangedEventArgs extends BravoEventArgs {
    listChangedType;
    newIndex;
    oldIndex;
    propDesc;
    constructor(pListChangedType, pNewIndex, pOldIndex, pPropDesc) {
        super();
        this.listChangedType = pListChangedType;
        this.newIndex = pNewIndex;
        this.oldIndex = pOldIndex;
        this.propDesc = pPropDesc;
    }
}
var ListChangedTypeEnum;
(function (ListChangedTypeEnum) {
    /// <devdoc>
    ///    <para>[To be supplied.]</para>
    /// </devdoc>
    ListChangedTypeEnum[ListChangedTypeEnum["Reset"] = 0] = "Reset";
    /// <devdoc>
    ///    <para>[To be supplied.]</para>
    /// </devdoc>
    ListChangedTypeEnum[ListChangedTypeEnum["ItemAdded"] = 1] = "ItemAdded";
    /// <devdoc>
    ///    <para>[To be supplied.]</para>
    /// </devdoc>
    ListChangedTypeEnum[ListChangedTypeEnum["ItemDeleted"] = 2] = "ItemDeleted";
    /// <devdoc>
    ///    <para>[To be supplied.]</para>
    /// </devdoc>
    ListChangedTypeEnum[ListChangedTypeEnum["ItemMoved"] = 3] = "ItemMoved";
    /// <devdoc>
    ///    <para>[To be supplied.]</para>
    /// </devdoc>
    ListChangedTypeEnum[ListChangedTypeEnum["ItemChanged"] = 4] = "ItemChanged";
    /// <devdoc>
    ///    <para>[To be supplied.]</para>
    /// </devdoc>
    ListChangedTypeEnum[ListChangedTypeEnum["PropertyDescriptorAdded"] = 5] = "PropertyDescriptorAdded";
    /// <devdoc>
    ///    <para>[To be supplied.]</para>
    /// </devdoc>
    ListChangedTypeEnum[ListChangedTypeEnum["PropertyDescriptorDeleted"] = 6] = "PropertyDescriptorDeleted";
    /// <devdoc>
    ///    <para>[To be supplied.]</para>
    /// </devdoc>
    ListChangedTypeEnum[ListChangedTypeEnum["PropertyDescriptorChanged"] = 7] = "PropertyDescriptorChanged";
})(ListChangedTypeEnum || (ListChangedTypeEnum = {}));

class BravoEventQueue {
    #queue = [];
    #isProcessing = false;
    #uniqueTaskKeys = new Set();
    get isHaveTaskInQueue() {
        return this.#queue.length > 0 || this.#isProcessing;
    }
    enqueue(pTaskName, pTaskCallback) {
        console.log(`🟡 [QUEUE] Added task: ${pTaskName}`);
        this.#queue.push(async () => {
            console.log(`🔵 [STACK] start run task: ${pTaskName}`);
            await pTaskCallback();
            console.log(`✅ [STACK] completed task: ${pTaskName}`);
        });
        this.#processQueue();
    }
    enqueueUnique(pTaskKey, pTaskCallback) {
        if (this.#uniqueTaskKeys.has(pTaskKey)) {
            console.log(`⚠️ [QUEUE] Skip duplicated unique task: ${pTaskKey}`);
            return;
        }
        console.log(`🟢 [QUEUE] Added UNIQUE task: ${pTaskKey}`);
        this.#uniqueTaskKeys.add(pTaskKey);
        this.#queue.push(async () => {
            console.log(`🔵 [STACK] start run UNIQUE task: ${pTaskKey}`);
            try {
                await pTaskCallback();
            }
            finally {
                console.log(`✅ [STACK] completed UNIQUE task: ${pTaskKey}`);
                this.#uniqueTaskKeys.delete(pTaskKey);
            }
        });
        this.#processQueue();
    }
    async #processQueue() {
        if (this.#isProcessing)
            return;
        this.#isProcessing = true;
        while (this.#queue.length > 0) {
            const task = this.#queue.shift();
            if (task)
                await task();
        }
        this.#isProcessing = false;
    }
}

function httpRequest(pUrl, pSettings) {
    function makeReq() {
        if (!pSettings)
            pSettings = {};
        if (pSettings.maxRetryAttempts == null)
            pSettings.maxRetryAttempts = 3;
        if (pSettings.scalingDuration == null)
            pSettings.scalingDuration = 1000;
        // select method and basic options
        const method = pSettings.method ? BravoStringExtensions.asString(pSettings.method).toUpperCase() : 'GET', isAsynk = pSettings.async != null ? BravoBooleanExtensions.asBoolean(pSettings.async) : true;
        let data = pSettings.data;
        // convert data to url parameters for GET requests
        if (data != null && method == 'GET') {
            const s = [];
            for (const k in data) {
                let val = data[k];
                if (val instanceof Date) {
                    val = val.toJSON();
                }
                s.push(k + '=' + val);
            }
            if (s.length) {
                let sep = pUrl.indexOf('?') < 0 ? '?' : '&';
                pUrl += sep + s.join('&');
            }
            data = null;
        }
        // create the request
        const xhr = new XMLHttpRequest();
        xhr['URL_DEBUG'] = pUrl; // add some debug info
        xhr['isCompress'] = pSettings.isCompress;
        try {
            if (pSettings.withCredentials)
                xhr.withCredentials = pSettings.withCredentials;
            // if the data is not a string, stringify it
            let isJson = false;
            if (!(data instanceof ArrayBuffer) &&
                data != null &&
                !BravoStringExtensions.isString(data) &&
                !(data instanceof FormData)) {
                isJson = BravoObjectExtensions.isObject(data);
                data = JSON.stringify(data);
            }
            // callbacks
            xhr.onload = function () {
                if (xhr.readyState == 4) {
                    if (xhr.status < 300) {
                        if (pSettings.success) {
                            asFunction(pSettings.success)(xhr);
                        }
                    }
                    else if (!handleError(xhr, pSettings, makeReq)) {
                        if (pSettings.error) {
                            asFunction(pSettings.error)(xhr);
                        }
                        else {
                            throw new HttpErrorResponse({ error: xhr.response });
                        }
                    }
                    if (pSettings.complete) {
                        asFunction(pSettings.complete)(xhr);
                    }
                }
            };
            xhr.onerror = function () {
                if (!handleError(xhr, pSettings, makeReq)) {
                    if (BravoObjectExtensions.isFunction(pSettings.error)) {
                        pSettings.error(xhr);
                    }
                    else {
                        throw 'HttpRequest Error: ' + xhr.status + ' ' + xhr.statusText;
                    }
                }
            };
            // send the request
            xhr.open(method, pUrl, isAsynk, pSettings.user, pSettings.password);
            if (pSettings.user && pSettings.password) {
                xhr.setRequestHeader('Authorization', 'Basic ' + btoa(pSettings.user + ':' + pSettings.password));
            }
            else if (pSettings.authorization) {
                xhr.setRequestHeader('Authorization', pSettings.authorization);
            }
            if (pSettings.contentType)
                xhr.setRequestHeader('Content-Type', pSettings.contentType);
            if (pSettings.responseType) {
                xhr.responseType = pSettings.responseType;
            }
            else if (isJson) {
                xhr.setRequestHeader('Content-Type', 'application/json');
            }
            if (pSettings.requestHeaders) {
                for (const key in pSettings.requestHeaders) {
                    xhr.setRequestHeader(key, pSettings.requestHeaders[key]);
                }
            }
            if (BravoNumberExtensions.isNumber(pSettings.timeout))
                xhr.timeout = pSettings.timeout;
            if (BravoObjectExtensions.isFunction(pSettings.beforeSend))
                pSettings.beforeSend(xhr);
            xhr.send(data);
        }
        catch (ex) {
            /* if (ex.name != 'NetworkError' || handleError(xhr, settings, makeReq)) {
                throw ex;
            } */
        }
        // return the request
        return xhr;
    }
    return makeReq();
}
const excludedStatusCodes = [500, 401, 400, 403, 404];
const syncWait = (pMs) => {
    const end = Date.now() + pMs;
    while (Date.now() < end)
        continue;
};
function handleError(pXhr, pSettings, pMakeReq) {
    if (excludedStatusCodes.find(pStatus => pStatus === pXhr.status))
        return false;
    pSettings.maxRetryAttempts--;
    if (pSettings.maxRetryAttempts > 0) {
        console.log('Retrying...');
        if (pSettings.async) {
            setTimeout(function () {
                pMakeReq();
            }, pSettings.scalingDuration);
        }
        else {
            syncWait(pSettings.scalingDuration);
            pMakeReq();
        }
        return true;
    }
    return false;
}

/**
 * A lightweight asynchronous semaphore implementation using RxJS.
 *
 * The `BravoSemaphore` class limits the number of concurrent operations.
 * It ensures that only a specified number of tasks can run at the same time.
 * When a permit becomes available, queued tasks are notified in order (FIFO).
 *
 * @example
 * const semaphore = new BravoSemaphore(2); // Allows 2 concurrent tasks
 *
 * async function task(id: number) {
 *   await semaphore.start().toPromise(); // Acquire permit
 *   console.log(`Task ${id} started`);
 *   await new Promise(r => setTimeout(r, 1000));
 *   console.log(`Task ${id} finished`);
 *   semaphore.end(); // Release permit
 * }
 *
 * for (let i = 1; i <= 5; i++) {
 *   task(i);
 * }
 */
class BravoSemaphore {
    /** Number of currently available permits. */
    #permits;
    /** Queue of waiting observers waiting to acquire a permit. */
    #waitingQueue = [];
    /**
     * Creates a new instance of `BravoSemaphore`.
     *
     * @param {number} pMaxConcurrency - The maximum number of concurrent operations allowed.
     */
    constructor(pMaxConcurrency) {
        this.#permits = pMaxConcurrency;
    }
    /**
     * Attempts to acquire a semaphore permit.
     *
     * If a permit is available, the returned observable emits immediately.
     * Otherwise, it waits until another task releases a permit.
     *
     * @returns {Observable<void>} An observable that completes when the permit is acquired.
     *
     * @example
     * semaphore.start().subscribe(() => {
     *   // Do work here
     *   semaphore.end(); // Must release after work is done
     * });
     */
    start() {
        return new Observable(pObserver => {
            const tryAcquire = () => {
                if (this.#permits > 0) {
                    // A permit is available — acquire immediately
                    this.#permits--;
                    pObserver.next();
                    pObserver.complete();
                }
                else {
                    // No permit available — enqueue
                    const waiter = new Subject();
                    this.#waitingQueue.push(waiter);
                    // Observe on queueScheduler to ensure ordered execution
                    waiter.pipe(observeOn(queueScheduler)).subscribe(() => {
                        this.#permits--;
                        pObserver.next();
                        pObserver.complete();
                    });
                }
            };
            tryAcquire();
        });
    }
    /**
     * Releases a previously acquired permit.
     *
     * If there are any queued observers waiting for a permit,
     * the next one in line is notified and allowed to proceed.
     *
     * @example
     * // Always call `end()` after `start()` once your work is complete.
     * semaphore.end();
     */
    end() {
        this.#permits++;
        if (this.#waitingQueue.length > 0) {
            const nextWaiter = this.#waitingQueue.shift();
            if (nextWaiter)
                nextWaiter.next(() => { }); // Notify next waiter
        }
    }
}

class BravoUsbTokenHelper {
    static #url = 'http://localhost:8080/api/UsbToken/';
    static readRawData(pzSerialNumber, pPropName) {
        try {
            const params = {
                id: pzSerialNumber,
                propName: BravoStringExtensions.format('{0}', pPropName),
            };
            const url = this.#url + 'getTokenRawData';
            const xhr = httpRequest(url, {
                method: 'GET',
                async: false,
                data: params,
            });
            return xhr.status == 200 && xhr.responseText ? xhr.responseText : undefined;
        }
        catch (_ex) {
            if (_ex instanceof DOMException)
                throw new Error(_ex.message);
            throw _ex;
        }
    }
    static signData(pSerialNumber, pXMLString, pItemTagName, pOtions = {
        hashValueTagName: 'hashValue',
        signValueTagName: 'signValue',
    }) {
        if (BravoStringExtensions.isNullOrEmpty(pXMLString) ||
            BravoStringExtensions.isNullOrEmpty(pItemTagName) ||
            BravoStringExtensions.isNullOrEmpty(pOtions.hashValueTagName) ||
            BravoStringExtensions.isNullOrEmpty(pOtions.signValueTagName))
            throw new BravoArgumentNullException('All parameters are required and cannot be empty.');
        const jsonData = {
            SerialNumber: pSerialNumber,
            XmlString: pXMLString,
            ItemTagName: pItemTagName,
            HashValueTagName: pOtions.hashValueTagName,
            SignValueTagName: pOtions.signValueTagName,
        };
        const url = this.#url + 'signData';
        const xhr = httpRequest(url, {
            method: 'POST',
            async: false,
            data: jsonData,
        });
        return xhr.status == 200 && xhr.responseText ? xhr.responseText : undefined;
    }
    static signXml(pSerialNumber, pXMLString, pOptions = {
        isIncludeKeyInfo: false,
        signatureId: '',
        referenceUri: '',
    }) {
        const jsonData = {
            SerialNumber: pSerialNumber,
            XmlString: pXMLString,
            IncludeKeyInfo: pOptions.isIncludeKeyInfo,
            SignatureId: pOptions.signatureId,
            ReferenceUri: pOptions.referenceUri,
        };
        const url = this.#url + 'signXml';
        const xhr = httpRequest(url, {
            method: 'POST',
            async: false,
            data: jsonData,
        });
        return xhr.status == 200 && xhr.responseText ? xhr.responseText : undefined;
    }
    static verifySignXml(pCertificate, pzSignedXml) {
        const jsonData = {
            Certificate: BravoConverterExtensions.toBase64String(pCertificate),
            SignedXml: pzSignedXml,
        };
        const url = this.#url + 'verifySignXml';
        const xhr = httpRequest(url, {
            method: 'POST',
            async: false,
            data: jsonData,
        });
        return xhr.status == 200 && xhr.responseText ? xhr.responseText : undefined;
    }
    static signDocument(pSerialNumber, pInputFileName, pOptions = {
        xOffset: '0',
        yOffset: '0',
        isShow: true,
    }) {
        const jsonData = {
            SerialNumber: pSerialNumber,
            InputFileName: pInputFileName,
            Reason: pOptions?.reason,
            Contact: pOptions?.contact,
            Location: pOptions?.location,
            XOffset: pOptions.xOffset,
            YOffset: pOptions.yOffset,
            Show: pOptions.isShow,
        };
        const url = this.#url + 'signDocument';
        const xhr = httpRequest(url, {
            method: 'POST',
            async: false,
            data: jsonData,
        });
        if (xhr.status == 200 && xhr.responseText)
            return xhr.responseText;
        return null;
    }
    static signDataString(pzSerialNumber, pzDataString) {
        const jsonData = {
            SerialNumber: pzSerialNumber,
            DataString: pzDataString,
        };
        const url = this.#url + 'signDataString';
        const xhr = httpRequest(url, {
            method: 'POST',
            async: false,
            data: jsonData,
        });
        if (xhr.status == 200 && xhr.responseText)
            return xhr.responseText;
        return null;
    }
    static verifySignDataString(pCertificate, pOriginalData, pSignedData) {
        const jsonData = {
            Certificate: pCertificate instanceof Uint8Array ? BravoConverterExtensions.toBase64String(pCertificate) : null,
            SerialNumber: pCertificate instanceof Uint8Array ? null : pCertificate,
            OriginalData: pOriginalData,
            SignedData: pOriginalData,
        };
        const url = this.#url + 'verifySignDataString';
        const xhr = httpRequest(url, {
            method: 'POST',
            async: false,
            data: jsonData,
        });
        return xhr.status == 200 && xhr.responseText ? xhr.responseText : undefined;
    }
}

/**
 * Generated bundle index. Do not edit.
 */

export { BravoArgumentNullException, BravoBroadcastChannel, BravoCancelEventArgs, BravoDataEventArgs, BravoDbMessageException, BravoErrorBase, BravoErrorsInterfaceNamingConstants, BravoEventArgs, BravoEventQueue, BravoExceptionTypeEnum, BravoFileExistedException, BravoFileInvalidException, BravoFileNotFoundException, BravoInvalidCastException, BravoInvalidConstraintException, BravoInvalidExpressionException, BravoLRUCache, BravoListChangedEventArgs, BravoMaintenanceException, BravoNullReferenceException, BravoPermissionException, BravoSemaphore, BravoUsbTokenHelper, BravoUserLimitExceededException, ListChangedTypeEnum, httpRequest };
//# sourceMappingURL=bravo-infra-core-helper.mjs.map
