import { InjectionToken } from '@angular/core';
import { __decorate, __metadata } from 'tslib';
import { JsonProperty, JsonObject, BravoArrayExtensions } from '@bravo-infra/core/utils/data-extensions';
import { ExpressionSerializer, ExpressionParam } from '@bravo-infra/core/serializations';

/**
 * Injection token representing the {@link IBravoStreamFileContract} contract.
 *
 * This token allows Angular DI to inject different implementations of
 * file streaming logic (e.g., API-based, mock, or local storage).
 *
 * @example
 * ```ts
 * providers: [
 *   { provide: USE_STREAM_FILE_CONTRACT, useClass: StreamApiService }
 * ]
 * ```
 */
const USE_STREAM_FILE_CONTRACT = new InjectionToken('USE_STREAM_FILE');

/**
 * Enumeration of notification status flags.
 */
var NotificationStatusFlagEnum;
(function (NotificationStatusFlagEnum) {
    /** Notification has been sent. */
    NotificationStatusFlagEnum[NotificationStatusFlagEnum["Sent"] = 1] = "Sent";
    /** Notification has been received. */
    NotificationStatusFlagEnum[NotificationStatusFlagEnum["Received"] = 2] = "Received";
    /** Notification has been read. */
    NotificationStatusFlagEnum[NotificationStatusFlagEnum["Read"] = 7] = "Read";
})(NotificationStatusFlagEnum || (NotificationStatusFlagEnum = {}));
let BravoNotificationMarkItem = class BravoNotificationMarkItem {
    notificationId;
    mark;
    constructor(pNotificationId, pMark) {
        this.notificationId = pNotificationId;
        this.mark = pMark;
    }
};
__decorate([
    JsonProperty('nti'),
    __metadata("design:type", String)
], BravoNotificationMarkItem.prototype, "notificationId", void 0);
__decorate([
    JsonProperty('mar'),
    __metadata("design:type", Number)
], BravoNotificationMarkItem.prototype, "mark", void 0);
BravoNotificationMarkItem = __decorate([
    JsonObject(),
    __metadata("design:paramtypes", [String, Number])
], BravoNotificationMarkItem);
let BravoNotificationDataParam = class BravoNotificationDataParam {
    listNotificationId;
    pageSize = 10;
    /**
     * Notification group code
     */
    notificationGroupCode;
    /**
     * Status flag
     */
    statusFlag;
    /**
     * Used for pagination on mobile (infinite scroll)
     */
    offset = 0;
    /**
     * Search text
     */
    searchText;
    /**
     * Tag type
     */
    tagType;
    constructor(pArgs) {
        if (!pArgs)
            return;
        if (pArgs.listNotificationId != null)
            this.listNotificationId = pArgs.listNotificationId;
        if (pArgs.pageSize != null)
            this.pageSize = pArgs.pageSize;
        if (pArgs.notificationGroupCode != null)
            this.notificationGroupCode = pArgs.notificationGroupCode;
        if (pArgs.statusFlag != null)
            this.statusFlag = pArgs.statusFlag;
        if (pArgs.offset != null)
            this.offset = pArgs.offset;
        if (pArgs.searchText != null)
            this.searchText = pArgs.searchText;
        if (pArgs.tagType != null)
            this.tagType = pArgs.tagType;
    }
};
__decorate([
    JsonProperty('lni'),
    __metadata("design:type", Array)
], BravoNotificationDataParam.prototype, "listNotificationId", void 0);
__decorate([
    JsonProperty('psz'),
    __metadata("design:type", Object)
], BravoNotificationDataParam.prototype, "pageSize", void 0);
__decorate([
    JsonProperty('ngc'),
    __metadata("design:type", String)
], BravoNotificationDataParam.prototype, "notificationGroupCode", void 0);
__decorate([
    JsonProperty('fls'),
    __metadata("design:type", Number)
], BravoNotificationDataParam.prototype, "statusFlag", void 0);
__decorate([
    JsonProperty('ofs'),
    __metadata("design:type", Object)
], BravoNotificationDataParam.prototype, "offset", void 0);
__decorate([
    JsonProperty('set'),
    __metadata("design:type", String)
], BravoNotificationDataParam.prototype, "searchText", void 0);
__decorate([
    JsonProperty('tat'),
    __metadata("design:type", Number)
], BravoNotificationDataParam.prototype, "tagType", void 0);
BravoNotificationDataParam = __decorate([
    JsonObject(),
    __metadata("design:paramtypes", [Object])
], BravoNotificationDataParam);
/**
 * Injection token used to provide or inject the Notification Contract implementation.
 *
 * This token represents the abstract contract {@link IBravoNotificationContract}
 * which defines the methods for retrieving and updating notification data.
 *
 * It allows UI or other modules to depend on the contract interface
 * instead of directly depending on a specific API or data layer implementation.
 *
 * @example
 * ```ts
 * // Provide implementation in a module or service
 * providers: [
 *   { provide: USE_NOTIFICATION_CONTRACT, useClass: BravoNotificationApiService }
 * ]
 *
 * // Inject in a component or another service
 * constructor(
 *   @Inject(USE_NOTIFICATION_CONTRACT) private readonly notificationContract: IBravoNotificationContract
 * ) {}
 * ```
 */
const USE_NOTIFICATION_CONTRACT = new InjectionToken('USE_NOTIFICATION_CONTRACT');

/**TODO: bổ sung docs */
var ComparisonEnum;
(function (ComparisonEnum) {
    ComparisonEnum[ComparisonEnum["None"] = 0] = "None";
    /**Get a exact value */
    ComparisonEnum[ComparisonEnum["Exact"] = 1] = "Exact";
    /**Get list including exact value */
    ComparisonEnum[ComparisonEnum["ExactList"] = 2] = "ExactList";
    /**Search accent-liked string */
    ComparisonEnum[ComparisonEnum["AccentLike"] = 3] = "AccentLike";
    /**Search ignore-accent-liked string */
    ComparisonEnum[ComparisonEnum["NonAccentLike"] = 4] = "NonAccentLike";
    /** Search multi accent-liked strings using or combination */
    ComparisonEnum[ComparisonEnum["CombineAccentLike"] = 5] = "CombineAccentLike";
    /**Search multi ignore-accent-liked strings using or combination */
    ComparisonEnum[ComparisonEnum["CombineNonAccentLike"] = 6] = "CombineNonAccentLike";
})(ComparisonEnum || (ComparisonEnum = {}));
const USE_LOOKUP_FACTORY_CONTRACT = new InjectionToken('USE_LOOKUP_FACTORY_CONTRACT');
var PagingModeEnum;
(function (PagingModeEnum) {
    /** */
    PagingModeEnum[PagingModeEnum["Normal"] = 0] = "Normal";
    /** */
    PagingModeEnum[PagingModeEnum["JoinPrimaryKey"] = 1] = "JoinPrimaryKey";
})(PagingModeEnum || (PagingModeEnum = {}));
const USE_LOOKUP_BINDING_MEMBER = new InjectionToken('USE_LOOKUP_BINDING_MEMBER');
let BravoLookupSettingParams = class BravoLookupSettingParams {
    //#region params
    //*lookupSource
    _lookupSource = '';
    get lookupSource() {
        return this._lookupSource;
    }
    set lookupSource(pVal) {
        this._lookupSource = pVal;
    }
    _bindingMembersString = [];
    get bindingMembersString() {
        return this._bindingMembersString;
    }
    set bindingMembersString(pVal) {
        this._bindingMembersString = pVal;
    }
    _isDisplayByLanguage = false;
    get isDisplayByLanguage() {
        return this._isDisplayByLanguage;
    }
    set isDisplayByLanguage(pVal) {
        this._isDisplayByLanguage = pVal;
    }
    _displayTextMember = '';
    get displayTextMember() {
        return this._displayTextMember;
    }
    set displayTextMember(pVal) {
        this._displayTextMember = pVal;
    }
    _extraMembers = [];
    get extraMembers() {
        return this._extraMembers;
    }
    set extraMembers(pVal) {
        this._extraMembers = pVal;
    }
    _filterKeyParam;
    get filterKeyParam() {
        return this._filterKeyParam;
    }
    set filterKeyParam(pVal) {
        this._filterKeyParam = pVal;
    }
    _filterKey = '';
    get filterKey() {
        return this._filterKey;
    }
    set filterKey(pVal) {
        this._filterKey = pVal;
    }
    _selectKeyParam;
    get selectKeyParam() {
        return this._selectKeyParam;
    }
    set selectKeyParam(pVal) {
        this._selectKeyParam = pVal;
    }
    _selectKey = '';
    get selectKey() {
        return this._selectKey;
    }
    set selectKey(pVal) {
        this._selectKey = pVal;
    }
    _hiddenValueMember = '';
    get hiddenValueMember() {
        return this._hiddenValueMember;
    }
    set hiddenValueMember(pVal) {
        this._hiddenValueMember = pVal;
    }
    _isLookupDistinct = false;
    get isLookupDistinct() {
        return this._isLookupDistinct;
    }
    set isLookupDistinct(pnValue) {
        this._isLookupDistinct = pnValue;
    }
    _lookupExtraMembers = true;
    get lookupExtraMembers() {
        return this._lookupExtraMembers;
    }
    set lookupExtraMembers(pVal) {
        this._lookupExtraMembers = pVal;
    }
    _pageSize = 10;
    get pageSize() {
        return this._pageSize;
    }
    set pageSize(pVal) {
        this._pageSize = pVal;
    }
    _pagingMode = PagingModeEnum.Normal;
    get pagingMode() {
        return this._pagingMode;
    }
    set pagingMode(pVal) {
        this._pagingMode = pVal;
    }
    _sort = '';
    get sort() {
        return this._sort;
    }
    set sort(pVal) {
        this._sort = pVal;
    }
    _valueMember = '';
    get valueMember() {
        return this._valueMember;
    }
    set valueMember(pVal) {
        this._valueMember = pVal;
    }
};
__decorate([
    JsonProperty('stn'),
    __metadata("design:type", Object)
], BravoLookupSettingParams.prototype, "_lookupSource", void 0);
__decorate([
    JsonProperty({
        name: 'bdm',
        afterSerialize: p => (BravoArrayExtensions.isArray(p) && p.length < 1 ? undefined : p),
    }),
    __metadata("design:type", Array)
], BravoLookupSettingParams.prototype, "_bindingMembersString", void 0);
__decorate([
    JsonProperty({ name: 'idbl', defaultValue: false }),
    __metadata("design:type", Object)
], BravoLookupSettingParams.prototype, "_isDisplayByLanguage", void 0);
__decorate([
    JsonProperty('dtm'),
    __metadata("design:type", Object)
], BravoLookupSettingParams.prototype, "_displayTextMember", void 0);
__decorate([
    JsonProperty({
        name: 'etm',
        afterSerialize: p => (BravoArrayExtensions.isArray(p) && p.length < 1 ? undefined : p),
    }),
    __metadata("design:type", Array)
], BravoLookupSettingParams.prototype, "_extraMembers", void 0);
__decorate([
    JsonProperty({
        name: 'ftk',
        dataStructure: 'array',
        type: ExpressionParam,
        beforeSerialize: p => ExpressionSerializer.fromExpression(p),
    }),
    __metadata("design:type", String)
], BravoLookupSettingParams.prototype, "_filterKeyParam", void 0);
__decorate([
    JsonProperty({
        name: 'slk',
        dataStructure: 'array',
        type: ExpressionParam,
        beforeSerialize: p => ExpressionSerializer.fromExpression(p),
    }),
    __metadata("design:type", String)
], BravoLookupSettingParams.prototype, "_selectKeyParam", void 0);
__decorate([
    JsonProperty('hvm'),
    __metadata("design:type", Object)
], BravoLookupSettingParams.prototype, "_hiddenValueMember", void 0);
__decorate([
    JsonProperty({ name: 'ild', defaultValue: false }),
    __metadata("design:type", Object)
], BravoLookupSettingParams.prototype, "_isLookupDistinct", void 0);
__decorate([
    JsonProperty({ name: 'ilem', defaultValue: true }),
    __metadata("design:type", Object)
], BravoLookupSettingParams.prototype, "_lookupExtraMembers", void 0);
__decorate([
    JsonProperty({ name: 'psz', defaultValue: 100 }),
    __metadata("design:type", Object)
], BravoLookupSettingParams.prototype, "_pageSize", void 0);
__decorate([
    JsonProperty({ name: 'pgm', defaultValue: PagingModeEnum.Normal }),
    __metadata("design:type", Object)
], BravoLookupSettingParams.prototype, "_pagingMode", void 0);
__decorate([
    JsonProperty({
        name: 'sot',
        dataStructure: 'array',
        type: ExpressionParam,
        beforeSerialize: p => ExpressionSerializer.fromExpression(p),
    }),
    __metadata("design:type", Object)
], BravoLookupSettingParams.prototype, "_sort", void 0);
__decorate([
    JsonProperty('vlm'),
    __metadata("design:type", Object)
], BravoLookupSettingParams.prototype, "_valueMember", void 0);
BravoLookupSettingParams = __decorate([
    JsonObject()
], BravoLookupSettingParams);

var BravoDataAccessModeEnum;
(function (BravoDataAccessModeEnum) {
    BravoDataAccessModeEnum[BravoDataAccessModeEnum["ReadOnly"] = 0] = "ReadOnly";
    BravoDataAccessModeEnum[BravoDataAccessModeEnum["Write"] = 1] = "Write";
})(BravoDataAccessModeEnum || (BravoDataAccessModeEnum = {}));
var BravoIsActiveEnum;
(function (BravoIsActiveEnum) {
    BravoIsActiveEnum[BravoIsActiveEnum["Deactive"] = 0] = "Deactive";
    BravoIsActiveEnum[BravoIsActiveEnum["Active"] = 1] = "Active";
    BravoIsActiveEnum[BravoIsActiveEnum["Unspecified"] = 2] = "Unspecified";
})(BravoIsActiveEnum || (BravoIsActiveEnum = {}));

const USE_EVALUATOR = new InjectionToken('USE_EVALUATOR');
class BravoCalloutData {
    stepName;
    command;
    _isReturnDataSet = false;
    get isReturnDataSet() {
        return this._isReturnDataSet;
    }
    set isReturnDataSet(pValue) {
        this._isReturnDataSet = pValue;
    }
    constructor(pzStepName, pCommand, pbReturnDataSet) {
        this.stepName = pzStepName;
        this.command = pCommand;
        this.isReturnDataSet = pbReturnDataSet;
    }
}

var BravoLayoutTypeEnum;
(function (BravoLayoutTypeEnum) {
    BravoLayoutTypeEnum[BravoLayoutTypeEnum["Layout"] = 0] = "Layout";
    BravoLayoutTypeEnum[BravoLayoutTypeEnum["FormTemplate"] = 1] = "FormTemplate";
    BravoLayoutTypeEnum[BravoLayoutTypeEnum["GlobalTemplate"] = 2] = "GlobalTemplate";
    BravoLayoutTypeEnum[BravoLayoutTypeEnum["DataSource"] = 3] = "DataSource";
    BravoLayoutTypeEnum[BravoLayoutTypeEnum["SubLayout"] = 4] = "SubLayout";
})(BravoLayoutTypeEnum || (BravoLayoutTypeEnum = {}));
var BravoLayoutExprTypeEnum;
(function (BravoLayoutExprTypeEnum) {
    BravoLayoutExprTypeEnum[BravoLayoutExprTypeEnum["Default"] = 0] = "Default";
    BravoLayoutExprTypeEnum[BravoLayoutExprTypeEnum["Expr"] = 1] = "Expr";
    BravoLayoutExprTypeEnum[BravoLayoutExprTypeEnum["ParameterValue"] = 2] = "ParameterValue";
})(BravoLayoutExprTypeEnum || (BravoLayoutExprTypeEnum = {}));
let BravoLayoutExprStruct = class BravoLayoutExprStruct {
    expr;
    type = BravoLayoutExprTypeEnum.Default;
};
__decorate([
    JsonProperty({ name: 'Expr', type: String }),
    __metadata("design:type", String)
], BravoLayoutExprStruct.prototype, "expr", void 0);
__decorate([
    JsonProperty({ name: 'Type', type: Number }),
    __metadata("design:type", Number)
], BravoLayoutExprStruct.prototype, "type", void 0);
BravoLayoutExprStruct = __decorate([
    JsonObject()
], BravoLayoutExprStruct);
const USE_LAYOUT = new InjectionToken('USE_LAYOUT');

/**
 * Generated bundle index. Do not edit.
 */

export { BravoCalloutData, BravoDataAccessModeEnum, BravoIsActiveEnum, BravoLayoutExprStruct, BravoLayoutExprTypeEnum, BravoLayoutTypeEnum, BravoLookupSettingParams, BravoNotificationDataParam, BravoNotificationMarkItem, ComparisonEnum, NotificationStatusFlagEnum, PagingModeEnum, USE_EVALUATOR, USE_LAYOUT, USE_LOOKUP_BINDING_MEMBER, USE_LOOKUP_FACTORY_CONTRACT, USE_NOTIFICATION_CONTRACT, USE_STREAM_FILE_CONTRACT };
//# sourceMappingURL=bravo-infra-core-contracts-tokens.mjs.map
