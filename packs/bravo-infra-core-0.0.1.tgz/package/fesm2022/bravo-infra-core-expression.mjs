import { BravoArgumentNullException, BravoEventArgs, BravoInvalidExpressionException, BravoNullReferenceException, BravoUsbTokenHelper } from '@bravo-infra/core/helper';
import { BravoCryptoExtension, BravoCryptography } from '@bravo-infra/core/utils/crypto';
import { BravoStringExtensions, BravoStringBuilder, BravoNumberExtensions, BravoBooleanExtensions, BravoEnumExtensions, tryCast, decodeHTMLEntities, escapeHtml, BravoConverterExtensions, escapeReplacement } from '@bravo-infra/core/utils/data-extensions';
import { BravoDataConvertUtil, TypeCodeEnum, BravoDataInterfaceNamingConstants, DataRowVersionEnum, DataRowStateEnum, DataViewRowStateEnum, toDataRelationName } from '@bravo-infra/core/data';
import { BravoDateExtensions, BravoMoment, BravoTimeSpan } from '@bravo-infra/core/utils/dates';
import { BravoLangEnum, BravoAppSettings } from '@bravo-infra/core/utils/global-settings';
import { Subject } from 'rxjs';

const Resources = {
    ArgumentNullError: "ArgumentNullException: Value cannot be null. Parameter name: '{0}'",
    CannotFindChildRow: 'Cannot find child row when evaluating row is null.',
    ColumnDoesNotExist: "Column '{0}' does not exist in table '{1}'.",
    CannotFindParentRow: 'Cannot find parent row when evaluating row is null.',
    NotSupportedError: "Not supported '{0}'.",
    IncorrectSyntaxError: "Incorrect syntax near '{0}'.",
    UnclosedQuotationError: "Unclosed quotation mark after the character '{0}'.",
    UnknownDatePart: "Unknown date part '{0}'.",
    RequiredFunctionArgument: 'The {0} function requires {1} argument(s).',
    SyntaxError: 'Syntax error',
    InvalidOperationError: "Invalid operation '{0}'.",
    UnknownLanguage: "Unknown language '{0}'.",
    RowDoesNotHaveParentRelation: 'The row does not have parent relation.',
    RowDoesNotHaveChildRelation: 'The row does not have child relation.',
    TableDoesNotExist: "Table '{0}' does not exist.",
    RelationKeyCannotNull: 'Relation key cannot be null.',
    ValueCanNotNull: 'Value cannot be null.',
    ParentTableCannotNull: 'Parent table cannot be null',
    PrimaryKeyCannotNull: "Primary key is required for table '{0}'.",
    ColumnValueDoesNotExist: "Could not find value '{0}' of column '{1}' of table '{2}'.",
    TableHasAlreadyExisted: "Table '{0}' already exists.",
    ParentTableNotExists: "Parent table '{0}' of table '{1}' does not exists.",
};

var DatePartEnum;
(function (DatePartEnum) {
    DatePartEnum[DatePartEnum["year"] = 0] = "year";
    DatePartEnum[DatePartEnum["yy"] = 1] = "yy";
    DatePartEnum[DatePartEnum["yyyy"] = 2] = "yyyy";
    DatePartEnum[DatePartEnum["quarter"] = 3] = "quarter";
    DatePartEnum[DatePartEnum["qq"] = 4] = "qq";
    DatePartEnum[DatePartEnum["q"] = 5] = "q";
    DatePartEnum[DatePartEnum["month"] = 6] = "month";
    DatePartEnum[DatePartEnum["mm"] = 7] = "mm";
    DatePartEnum[DatePartEnum["m"] = 8] = "m";
    DatePartEnum[DatePartEnum["dayofyear"] = 9] = "dayofyear";
    DatePartEnum[DatePartEnum["dy"] = 10] = "dy";
    DatePartEnum[DatePartEnum["y"] = 11] = "y";
    DatePartEnum[DatePartEnum["day"] = 12] = "day";
    DatePartEnum[DatePartEnum["dd"] = 13] = "dd";
    DatePartEnum[DatePartEnum["d"] = 14] = "d";
    DatePartEnum[DatePartEnum["week"] = 15] = "week";
    DatePartEnum[DatePartEnum["wk"] = 16] = "wk";
    DatePartEnum[DatePartEnum["ww"] = 17] = "ww";
    DatePartEnum[DatePartEnum["weekday"] = 18] = "weekday";
    DatePartEnum[DatePartEnum["dw"] = 19] = "dw";
    DatePartEnum[DatePartEnum["hour"] = 20] = "hour";
    DatePartEnum[DatePartEnum["hh"] = 21] = "hh";
    DatePartEnum[DatePartEnum["minute"] = 22] = "minute";
    DatePartEnum[DatePartEnum["mi"] = 23] = "mi";
    DatePartEnum[DatePartEnum["n"] = 24] = "n";
    DatePartEnum[DatePartEnum["second"] = 25] = "second";
    DatePartEnum[DatePartEnum["ss"] = 26] = "ss";
    DatePartEnum[DatePartEnum["s"] = 27] = "s";
    DatePartEnum[DatePartEnum["millisecond"] = 28] = "millisecond";
    DatePartEnum[DatePartEnum["ms"] = 29] = "ms";
    DatePartEnum[DatePartEnum["microsecond"] = 30] = "microsecond";
    DatePartEnum[DatePartEnum["mcs"] = 31] = "mcs";
    DatePartEnum[DatePartEnum["mid"] = 32] = "mid";
    //nanosecond, ns,
    //TZoffset, tz,
    //ISO_WEEK, isowk, isoww
})(DatePartEnum || (DatePartEnum = {}));

var OperatorEnum;
(function (OperatorEnum) {
    OperatorEnum[OperatorEnum["Unknown"] = 0] = "Unknown";
    OperatorEnum[OperatorEnum["UnknownFunction"] = 1] = "UnknownFunction";
    OperatorEnum[OperatorEnum["Declare"] = 2] = "Declare";
    OperatorEnum[OperatorEnum["Set"] = 3] = "Set";
    OperatorEnum[OperatorEnum["Value"] = 4] = "Value";
    // Binary
    OperatorEnum[OperatorEnum["Addition"] = 5] = "Addition";
    OperatorEnum[OperatorEnum["Subtraction"] = 6] = "Subtraction";
    OperatorEnum[OperatorEnum["Multiplication"] = 7] = "Multiplication";
    OperatorEnum[OperatorEnum["Division"] = 8] = "Division";
    OperatorEnum[OperatorEnum["Modulus"] = 9] = "Modulus";
    OperatorEnum[OperatorEnum["Eval"] = 10] = "Eval";
    OperatorEnum[OperatorEnum["Arguments"] = 11] = "Arguments";
    OperatorEnum[OperatorEnum["Parent"] = 12] = "Parent";
    OperatorEnum[OperatorEnum["Child"] = 13] = "Child";
    OperatorEnum[OperatorEnum["MemberAccess"] = 14] = "MemberAccess";
    OperatorEnum[OperatorEnum["GreaterThan"] = 15] = "GreaterThan";
    OperatorEnum[OperatorEnum["LessThan"] = 16] = "LessThan";
    OperatorEnum[OperatorEnum["Equal"] = 17] = "Equal";
    OperatorEnum[OperatorEnum["Notequal"] = 18] = "Notequal";
    OperatorEnum[OperatorEnum["Equality"] = 19] = "Equality";
    OperatorEnum[OperatorEnum["Inequality"] = 20] = "Inequality";
    OperatorEnum[OperatorEnum["GreaterThanOrEqual"] = 21] = "GreaterThanOrEqual";
    OperatorEnum[OperatorEnum["LessThanOrEqual"] = 22] = "LessThanOrEqual";
    OperatorEnum[OperatorEnum["And"] = 23] = "And";
    OperatorEnum[OperatorEnum["Or"] = 24] = "Or";
    OperatorEnum[OperatorEnum["Like"] = 25] = "Like";
    OperatorEnum[OperatorEnum["In"] = 26] = "In";
    OperatorEnum[OperatorEnum["Between"] = 27] = "Between";
    OperatorEnum[OperatorEnum["Is"] = 28] = "Is";
    // Unary
    OperatorEnum[OperatorEnum["UnaryPlus"] = 29] = "UnaryPlus";
    OperatorEnum[OperatorEnum["UnaryNegation"] = 30] = "UnaryNegation";
    OperatorEnum[OperatorEnum["LogicalNot"] = 31] = "LogicalNot";
    OperatorEnum[OperatorEnum["Not"] = 32] = "Not";
    OperatorEnum[OperatorEnum["Iif"] = 33] = "Iif";
    OperatorEnum[OperatorEnum["Case"] = 34] = "Case";
    OperatorEnum[OperatorEnum["IsNull"] = 35] = "IsNull";
    OperatorEnum[OperatorEnum["Coalesce"] = 36] = "Coalesce";
    OperatorEnum[OperatorEnum["Convert"] = 37] = "Convert";
    OperatorEnum[OperatorEnum["Empty"] = 38] = "Empty";
    OperatorEnum[OperatorEnum["IsInteger"] = 39] = "IsInteger";
    OperatorEnum[OperatorEnum["IsNumeric"] = 40] = "IsNumeric";
    OperatorEnum[OperatorEnum["IsDatetime"] = 41] = "IsDatetime";
    // Math
    OperatorEnum[OperatorEnum["Sqr"] = 42] = "Sqr";
    OperatorEnum[OperatorEnum["Abs"] = 43] = "Abs";
    OperatorEnum[OperatorEnum["Sin"] = 44] = "Sin";
    OperatorEnum[OperatorEnum["Cos"] = 45] = "Cos";
    OperatorEnum[OperatorEnum["Round"] = 46] = "Round";
    OperatorEnum[OperatorEnum["RoundUp"] = 47] = "RoundUp";
    OperatorEnum[OperatorEnum["RoundDown"] = 48] = "RoundDown";
    OperatorEnum[OperatorEnum["Ceiling"] = 49] = "Ceiling";
    OperatorEnum[OperatorEnum["Floor"] = 50] = "Floor";
    OperatorEnum[OperatorEnum["Pow"] = 51] = "Pow";
    OperatorEnum[OperatorEnum["MaxOf"] = 52] = "MaxOf";
    OperatorEnum[OperatorEnum["MinOf"] = 53] = "MinOf";
    // Aggregate
    OperatorEnum[OperatorEnum["Max"] = 54] = "Max";
    OperatorEnum[OperatorEnum["Min"] = 55] = "Min";
    OperatorEnum[OperatorEnum["Sum"] = 56] = "Sum";
    OperatorEnum[OperatorEnum["SumIf"] = 57] = "SumIf";
    OperatorEnum[OperatorEnum["Avg"] = 58] = "Avg";
    OperatorEnum[OperatorEnum["Concat"] = 59] = "Concat";
    OperatorEnum[OperatorEnum["Count"] = 60] = "Count";
    OperatorEnum[OperatorEnum["CountIf"] = 61] = "CountIf";
    OperatorEnum[OperatorEnum["Mode"] = 62] = "Mode";
    OperatorEnum[OperatorEnum["Vlookup"] = 63] = "Vlookup";
    OperatorEnum[OperatorEnum["Hlookup"] = 64] = "Hlookup";
    OperatorEnum[OperatorEnum["Exists"] = 65] = "Exists";
    // String
    OperatorEnum[OperatorEnum["Left"] = 66] = "Left";
    OperatorEnum[OperatorEnum["Right"] = 67] = "Right";
    OperatorEnum[OperatorEnum["PadL"] = 68] = "PadL";
    OperatorEnum[OperatorEnum["PadLeft"] = 69] = "PadLeft";
    OperatorEnum[OperatorEnum["PadR"] = 70] = "PadR";
    OperatorEnum[OperatorEnum["PadRight"] = 71] = "PadRight";
    OperatorEnum[OperatorEnum["SubStr"] = 72] = "SubStr";
    OperatorEnum[OperatorEnum["SubString"] = 73] = "SubString";
    OperatorEnum[OperatorEnum["CharIndex"] = 74] = "CharIndex";
    OperatorEnum[OperatorEnum["Replace"] = 75] = "Replace";
    OperatorEnum[OperatorEnum["Stuff"] = 76] = "Stuff";
    OperatorEnum[OperatorEnum["Len"] = 77] = "Len";
    OperatorEnum[OperatorEnum["Length"] = 78] = "Length";
    OperatorEnum[OperatorEnum["Trim"] = 79] = "Trim";
    OperatorEnum[OperatorEnum["Ltrim"] = 80] = "Ltrim";
    OperatorEnum[OperatorEnum["Rtrim"] = 81] = "Rtrim";
    OperatorEnum[OperatorEnum["Str"] = 82] = "Str";
    OperatorEnum[OperatorEnum["Upper"] = 83] = "Upper";
    OperatorEnum[OperatorEnum["Lower"] = 84] = "Lower";
    OperatorEnum[OperatorEnum["RemoveAccent"] = 85] = "RemoveAccent";
    OperatorEnum[OperatorEnum["SpellNumber"] = 86] = "SpellNumber";
    OperatorEnum[OperatorEnum["GeneratePassword"] = 87] = "GeneratePassword";
    OperatorEnum[OperatorEnum["RegexMatch"] = 88] = "RegexMatch";
    OperatorEnum[OperatorEnum["RegexReplace"] = 89] = "RegexReplace";
    OperatorEnum[OperatorEnum["RegexExtract"] = 90] = "RegexExtract";
    // Datetime
    OperatorEnum[OperatorEnum["DateAdd"] = 91] = "DateAdd";
    OperatorEnum[OperatorEnum["DateDiff"] = 92] = "DateDiff";
    OperatorEnum[OperatorEnum["DatePart"] = 93] = "DatePart";
    OperatorEnum[OperatorEnum["Hour"] = 94] = "Hour";
    OperatorEnum[OperatorEnum["Minute"] = 95] = "Minute";
    OperatorEnum[OperatorEnum["Second"] = 96] = "Second";
    OperatorEnum[OperatorEnum["Day"] = 97] = "Day";
    OperatorEnum[OperatorEnum["Month"] = 98] = "Month";
    OperatorEnum[OperatorEnum["Year"] = 99] = "Year";
    OperatorEnum[OperatorEnum["Quarter"] = 100] = "Quarter";
    OperatorEnum[OperatorEnum["GetDate"] = 101] = "GetDate";
    OperatorEnum[OperatorEnum["GetUtcDate"] = 102] = "GetUtcDate";
    OperatorEnum[OperatorEnum["GetDatetime"] = 103] = "GetDatetime";
    OperatorEnum[OperatorEnum["GetUtcDatetime"] = 104] = "GetUtcDatetime";
    OperatorEnum[OperatorEnum["Date"] = 105] = "Date";
    OperatorEnum[OperatorEnum["Time"] = 106] = "Time";
    OperatorEnum[OperatorEnum["StartDateOfYear"] = 107] = "StartDateOfYear";
    OperatorEnum[OperatorEnum["SOYear"] = 108] = "SOYear";
    OperatorEnum[OperatorEnum["EndDateOfYear"] = 109] = "EndDateOfYear";
    OperatorEnum[OperatorEnum["EOYear"] = 110] = "EOYear";
    OperatorEnum[OperatorEnum["StartDateOfMonth"] = 111] = "StartDateOfMonth";
    OperatorEnum[OperatorEnum["SOMonth"] = 112] = "SOMonth";
    OperatorEnum[OperatorEnum["EndDateOfMonth"] = 113] = "EndDateOfMonth";
    OperatorEnum[OperatorEnum["EOMonth"] = 114] = "EOMonth";
    OperatorEnum[OperatorEnum["StartDateOfQuarter"] = 115] = "StartDateOfQuarter";
    OperatorEnum[OperatorEnum["SOQuarter"] = 116] = "SOQuarter";
    OperatorEnum[OperatorEnum["EndDateOfQuarter"] = 117] = "EndDateOfQuarter";
    OperatorEnum[OperatorEnum["EOQuarter"] = 118] = "EOQuarter";
    OperatorEnum[OperatorEnum["IsFiscalDate"] = 119] = "IsFiscalDate";
    OperatorEnum[OperatorEnum["IsSpecialDate"] = 120] = "IsSpecialDate";
    // Display formatting
    OperatorEnum[OperatorEnum["Format"] = 121] = "Format";
    OperatorEnum[OperatorEnum["FormatCurrency"] = 122] = "FormatCurrency";
    OperatorEnum[OperatorEnum["FormatQuantity"] = 123] = "FormatQuantity";
    OperatorEnum[OperatorEnum["FormatDateRange"] = 124] = "FormatDateRange";
    // Current UI language
    OperatorEnum[OperatorEnum["LangId"] = 125] = "LangId";
    OperatorEnum[OperatorEnum["LangName"] = 126] = "LangName";
    // Return a name by current UI language
    OperatorEnum[OperatorEnum["NameByLang"] = 127] = "NameByLang";
    // Global system variables
    OperatorEnum[OperatorEnum["System"] = 128] = "System";
    // Config variables
    OperatorEnum[OperatorEnum["Config"] = 129] = "Config";
    // Currency info
    OperatorEnum[OperatorEnum["Currency"] = 130] = "Currency";
    // Current user info
    OperatorEnum[OperatorEnum["User"] = 131] = "User";
    // Current branch info
    OperatorEnum[OperatorEnum["Branch"] = 132] = "Branch";
    // Return filter expression of branch code
    OperatorEnum[OperatorEnum["BranchFilter"] = 133] = "BranchFilter";
    // Current fiscal year info
    OperatorEnum[OperatorEnum["FiscalYear"] = 134] = "FiscalYear";
    // Signature text
    OperatorEnum[OperatorEnum["SignatureText"] = 135] = "SignatureText";
    // Signature image
    OperatorEnum[OperatorEnum["SignatureImage"] = 136] = "SignatureImage";
    // Signature data
    OperatorEnum[OperatorEnum["SignatureData"] = 137] = "SignatureData";
    /// <summary>
    /// Return value of column at current row of binding source
    /// </summary>
    OperatorEnum[OperatorEnum["CurrentValue"] = 138] = "CurrentValue";
    OperatorEnum[OperatorEnum["TableChanged"] = 139] = "TableChanged";
    /// <summary>
    /// Return state of row
    /// </summary>
    OperatorEnum[OperatorEnum["RowState"] = 140] = "RowState";
    /// <summary>
    /// Return unchanged column value of row
    /// </summary>
    OperatorEnum[OperatorEnum["RowOldValue"] = 141] = "RowOldValue";
    /// <summary>
    /// Return error text of an indicated column of row
    /// </summary>
    OperatorEnum[OperatorEnum["RowError"] = 142] = "RowError";
    /// <summary>
    /// Current changing data column
    /// </summary>
    OperatorEnum[OperatorEnum["UpdatedColumn"] = 143] = "UpdatedColumn";
    /// <summary>
    /// Display text
    /// </summary>
    OperatorEnum[OperatorEnum["Text"] = 144] = "Text";
    /// <summary>
    /// Current selected grid column
    /// </summary>
    OperatorEnum[OperatorEnum["ColumnName"] = 145] = "ColumnName";
    /// <summary>
    /// Current selected grid table (or view)
    /// </summary>
    OperatorEnum[OperatorEnum["TableName"] = 146] = "TableName";
    /// <summary>
    /// Last application command has been executed
    /// </summary>
    OperatorEnum[OperatorEnum["LastCommand"] = 147] = "LastCommand";
    OperatorEnum[OperatorEnum["OsMachineName"] = 148] = "OsMachineName";
    OperatorEnum[OperatorEnum["OsDomainName"] = 149] = "OsDomainName";
    OperatorEnum[OperatorEnum["OsUserName"] = 150] = "OsUserName";
    OperatorEnum[OperatorEnum["ServerName"] = 151] = "ServerName";
    OperatorEnum[OperatorEnum["DatabaseName"] = 152] = "DatabaseName";
    OperatorEnum[OperatorEnum["FormCommandName"] = 153] = "FormCommandName";
    OperatorEnum[OperatorEnum["FormUserName"] = 154] = "FormUserName";
    OperatorEnum[OperatorEnum["LayoutName"] = 155] = "LayoutName";
    OperatorEnum[OperatorEnum["LayoutId"] = 156] = "LayoutId";
    OperatorEnum[OperatorEnum["VerifyChecksum"] = 157] = "VerifyChecksum";
    OperatorEnum[OperatorEnum["TokenRawData"] = 158] = "TokenRawData";
    OperatorEnum[OperatorEnum["TokenSignData"] = 159] = "TokenSignData";
    OperatorEnum[OperatorEnum["TokenSignXml"] = 160] = "TokenSignXml";
    OperatorEnum[OperatorEnum["TokenVerifyXml"] = 161] = "TokenVerifyXml";
    OperatorEnum[OperatorEnum["TokenSignDocument"] = 162] = "TokenSignDocument";
    OperatorEnum[OperatorEnum["Encrypt"] = 163] = "Encrypt";
    OperatorEnum[OperatorEnum["Decrypt"] = 164] = "Decrypt";
    OperatorEnum[OperatorEnum["HashValue"] = 165] = "HashValue";
    //HashPassword,
    OperatorEnum[OperatorEnum["ImageThumbnail"] = 166] = "ImageThumbnail";
    OperatorEnum[OperatorEnum["Platform"] = 167] = "Platform";
    OperatorEnum[OperatorEnum["NewId"] = 168] = "NewId";
    OperatorEnum[OperatorEnum["TokenSignString"] = 169] = "TokenSignString";
    OperatorEnum[OperatorEnum["TokenVerifyString"] = 170] = "TokenVerifyString";
    //GetEInvoiceUrl,
    OperatorEnum[OperatorEnum["GenerateToken"] = 171] = "GenerateToken";
    OperatorEnum[OperatorEnum["VerifyToken"] = 172] = "VerifyToken";
    OperatorEnum[OperatorEnum["Portal"] = 173] = "Portal";
    OperatorEnum[OperatorEnum["Logo"] = 174] = "Logo";
    // the functions used for t-sql expression
    OperatorEnum[OperatorEnum["Collate"] = 175] = "Collate";
    OperatorEnum[OperatorEnum["As"] = 176] = "As";
    // Nchar,
    OperatorEnum[OperatorEnum["Unicode"] = 177] = "Unicode";
    OperatorEnum[OperatorEnum["LayoutTableName"] = 178] = "LayoutTableName";
    OperatorEnum[OperatorEnum["DataFormat"] = 179] = "DataFormat";
    //GetData,
    OperatorEnum[OperatorEnum["GetXmlData"] = 180] = "GetXmlData";
    OperatorEnum[OperatorEnum["GetXmlSelectedData"] = 181] = "GetXmlSelectedData";
    OperatorEnum[OperatorEnum["GetJsonData"] = 182] = "GetJsonData";
    OperatorEnum[OperatorEnum["GetJsonSelectedData"] = 183] = "GetJsonSelectedData";
    OperatorEnum[OperatorEnum["EncodeHtml"] = 184] = "EncodeHtml";
    OperatorEnum[OperatorEnum["DecodeHtml"] = 185] = "DecodeHtml";
    OperatorEnum[OperatorEnum["Inlist"] = 186] = "Inlist";
    OperatorEnum[OperatorEnum["ResourceText"] = 187] = "ResourceText";
    OperatorEnum[OperatorEnum["PortalConfig"] = 188] = "PortalConfig";
})(OperatorEnum || (OperatorEnum = {}));

var OperatorLevelEnum;
(function (OperatorLevelEnum) {
    OperatorLevelEnum[OperatorLevelEnum["Operator"] = 0] = "Operator";
    OperatorLevelEnum[OperatorLevelEnum["Function"] = 1] = "Function";
})(OperatorLevelEnum || (OperatorLevelEnum = {}));

var OperatorTypeEnum;
(function (OperatorTypeEnum) {
    /// The operation with only one operand
    OperatorTypeEnum[OperatorTypeEnum["Unary"] = 0] = "Unary";
    /// The operation with two operands
    OperatorTypeEnum[OperatorTypeEnum["Binary"] = 1] = "Binary";
})(OperatorTypeEnum || (OperatorTypeEnum = {}));

var SqlDbTypeEnum;
(function (SqlDbTypeEnum) {
    //
    // Summary:
    //     System.Int64. A 64-bit signed integer.
    SqlDbTypeEnum[SqlDbTypeEnum["BigInt"] = 0] = "BigInt";
    //
    // Summary:
    //     System.Array of type System.Byte. A fixed-length stream of binary data ranging
    //     between 1 and 8,000 bytes.
    SqlDbTypeEnum[SqlDbTypeEnum["Binary"] = 1] = "Binary";
    //
    // Summary:
    //     System.Boolean. An unsigned numeric value that can be 0, 1, or null.
    SqlDbTypeEnum[SqlDbTypeEnum["Bit"] = 2] = "Bit";
    //
    // Summary:
    //     System.String. A fixed-length stream of non-Unicode characters ranging between
    //     1 and 8,000 characters.
    SqlDbTypeEnum[SqlDbTypeEnum["Char"] = 3] = "Char";
    //
    // Summary:
    //     System.DateTime. Date and time data ranging in value from January 1, 1753 to
    //     December 31, 9999 to an accuracy of 3.33 milliseconds.
    SqlDbTypeEnum[SqlDbTypeEnum["DateTime"] = 4] = "DateTime";
    //
    // Summary:
    //     System.Decimal. A fixed precision and scale numeric value between -10 38 -1 and
    //     10 38 -1.
    SqlDbTypeEnum[SqlDbTypeEnum["Decimal"] = 5] = "Decimal";
    //
    // Summary:
    //     System.Double. A floating point number within the range of -1.79E +308 through
    //     1.79E +308.
    SqlDbTypeEnum[SqlDbTypeEnum["Float"] = 6] = "Float";
    //
    // Summary:
    //     System.Array of type System.Byte. A variable-length stream of binary data ranging
    //     from 0 to 2 31 -1 (or 2,147,483,647) bytes.
    SqlDbTypeEnum[SqlDbTypeEnum["Image"] = 7] = "Image";
    //
    // Summary:
    //     System.Int32. A 32-bit signed integer.
    SqlDbTypeEnum[SqlDbTypeEnum["Int"] = 8] = "Int";
    //
    // Summary:
    //     System.Decimal. A currency value ranging from -2 63 (or -9,223,372,036,854,775,808)
    //     to 2 63 -1 (or +9,223,372,036,854,775,807) with an accuracy to a ten-thousandth
    //     of a currency unit.
    SqlDbTypeEnum[SqlDbTypeEnum["Money"] = 9] = "Money";
    //
    // Summary:
    //     System.String. A fixed-length stream of Unicode characters ranging between 1
    //     and 4,000 characters.
    SqlDbTypeEnum[SqlDbTypeEnum["NChar"] = 10] = "NChar";
    //
    // Summary:
    //     System.String. A variable-length stream of Unicode data with a maximum length
    //     of 2 30 - 1 (or 1,073,741,823) characters.
    SqlDbTypeEnum[SqlDbTypeEnum["NText"] = 11] = "NText";
    //
    // Summary:
    //     System.String. A variable-length stream of Unicode characters ranging between
    //     1 and 4,000 characters. Implicit conversion fails if the string is greater than
    //     4,000 characters. Explicitly set the object when working with strings longer
    //     than 4,000 characters. Use System.Data.SqlDbType.NVarChar when the database column
    //     is nvarchar(max).
    SqlDbTypeEnum[SqlDbTypeEnum["NVarChar"] = 12] = "NVarChar";
    //
    // Summary:
    //     System.Single. A floating point number within the range of -3.40E +38 through
    //     3.40E +38.
    SqlDbTypeEnum[SqlDbTypeEnum["Real"] = 13] = "Real";
    //
    // Summary:
    //     System.Guid. A globally unique identifier (or GUID).
    SqlDbTypeEnum[SqlDbTypeEnum["UniqueIdentifier"] = 14] = "UniqueIdentifier";
    //
    // Summary:
    //     System.DateTime. Date and time data ranging in value from January 1, 1900 to
    //     June 6, 2079 to an accuracy of one minute.
    SqlDbTypeEnum[SqlDbTypeEnum["SmallDateTime"] = 15] = "SmallDateTime";
    //
    // Summary:
    //     System.Int16. A 16-bit signed integer.
    SqlDbTypeEnum[SqlDbTypeEnum["SmallInt"] = 16] = "SmallInt";
    //
    // Summary:
    //     System.Decimal. A currency value ranging from -214,748.3648 to +214,748.3647
    //     with an accuracy to a ten-thousandth of a currency unit.
    SqlDbTypeEnum[SqlDbTypeEnum["SmallMoney"] = 17] = "SmallMoney";
    //
    // Summary:
    //     System.String. A variable-length stream of non-Unicode data with a maximum length
    //     of 2 31 -1 (or 2,147,483,647) characters.
    SqlDbTypeEnum[SqlDbTypeEnum["Text"] = 18] = "Text";
    //
    // Summary:
    //     System.Array of type System.Byte. Automatically generated binary numbers, which
    //     are guaranteed to be unique within a database. timestamp is used typically as
    //     a mechanism for version-stamping table rows. The storage size is 8 bytes.
    SqlDbTypeEnum[SqlDbTypeEnum["Timestamp"] = 19] = "Timestamp";
    //
    // Summary:
    //     System.Byte. An 8-bit unsigned integer.
    SqlDbTypeEnum[SqlDbTypeEnum["TinyInt"] = 20] = "TinyInt";
    //
    // Summary:
    //     System.Array of type System.Byte. A variable-length stream of binary data ranging
    //     between 1 and 8,000 bytes. Implicit conversion fails if the byte array is greater
    //     than 8,000 bytes. Explicitly set the object when working with byte arrays larger
    //     than 8,000 bytes.
    SqlDbTypeEnum[SqlDbTypeEnum["VarBinary"] = 21] = "VarBinary";
    //
    // Summary:
    //     System.String. A variable-length stream of non-Unicode characters ranging between
    //     1 and 8,000 characters. Use System.Data.SqlDbType.VarChar when the database column
    //     is varchar(max).
    SqlDbTypeEnum[SqlDbTypeEnum["VarChar"] = 22] = "VarChar";
    //
    // Summary:
    //     System.Object. A special data type that can contain numeric, string, binary,
    //     or date data as well as the SQL Server values Empty and Null, which is assumed
    //     if no other type is declared.
    SqlDbTypeEnum[SqlDbTypeEnum["Variant"] = 23] = "Variant";
    //
    // Summary:
    //     An XML value. Obtain the XML as a string using the System.Data.SqlClient.SqlDataReader.GetValue(System.Int32)
    //     method or System.Data.SqlTypes.SqlXml.Value property, or as an System.Xml.XmlReader
    //     by calling the System.Data.SqlTypes.SqlXml.CreateReader method.
    SqlDbTypeEnum[SqlDbTypeEnum["Xml"] = 25] = "Xml";
    //
    // Summary:
    //     A SQL Server user-defined type (UDT).
    SqlDbTypeEnum[SqlDbTypeEnum["Udt"] = 29] = "Udt";
    //
    // Summary:
    //     A special data type for specifying structured data contained in table-valued
    //     parameters.
    SqlDbTypeEnum[SqlDbTypeEnum["Structured"] = 30] = "Structured";
    //
    // Summary:
    //     Date data ranging in value from January 1,1 AD through December 31, 9999 AD.
    SqlDbTypeEnum[SqlDbTypeEnum["Date"] = 31] = "Date";
    //
    // Summary:
    //     Time data based on a 24-hour clock. Time value range is 00:00:00 through 23:59:59.9999999
    //     with an accuracy of 100 nanoseconds. Corresponds to a SQL Server time value.
    SqlDbTypeEnum[SqlDbTypeEnum["Time"] = 32] = "Time";
    //
    // Summary:
    //     Date and time data. Date value range is from January 1,1 AD through December
    //     31, 9999 AD. Time value range is 00:00:00 through 23:59:59.9999999 with an accuracy
    //     of 100 nanoseconds.
    SqlDbTypeEnum[SqlDbTypeEnum["DateTime2"] = 33] = "DateTime2";
    //
    // Summary:
    //     Date and time data with time zone awareness. Date value range is from January
    //     1,1 AD through December 31, 9999 AD. Time value range is 00:00:00 through 23:59:59.9999999
    //     with an accuracy of 100 nanoseconds. Time zone value range is -14:00 through
    //     +14:00.
    SqlDbTypeEnum[SqlDbTypeEnum["DateTimeOffset"] = 34] = "DateTimeOffset";
})(SqlDbTypeEnum || (SqlDbTypeEnum = {}));

var _a;
class BravoExpression {
    //#region static members
    // public static readonly Empty = new BravoExpression();
    static cachedExpressionCollection = new Map();
    static create(pExpression) {
        if (!pExpression)
            throw new Error(BravoStringExtensions.format(Resources.ArgumentNullError, 'expression'));
        const key = BravoCryptoExtension.computeSHA256(pExpression);
        if (this.cachedExpressionCollection.has(key))
            return this.cachedExpressionCollection.get(key) ?? [];
        const parse = new Parser();
        const exprs = parse.parseExpressions(pExpression);
        this.cachedExpressionCollection.set(key, exprs);
        return exprs;
    }
    static buildExpressionString(pExprs) {
        if (!pExprs || pExprs.length < 1)
            return;
        return pExprs[0].buildString();
    }
    static get Operators() {
        return [
            // Binary
            new OperatorDescriptor(OperatorEnum.Addition, '+', OperatorTypeEnum.Binary),
            new OperatorDescriptor(OperatorEnum.Subtraction, '-', OperatorTypeEnum.Binary),
            new OperatorDescriptor(OperatorEnum.Multiplication, '*', OperatorTypeEnum.Binary),
            new OperatorDescriptor(OperatorEnum.Division, '/', OperatorTypeEnum.Binary),
            new OperatorDescriptor(OperatorEnum.Modulus, '%', OperatorTypeEnum.Binary),
            new OperatorDescriptor(OperatorEnum.Arguments, ',', OperatorTypeEnum.Binary),
            new OperatorDescriptor(OperatorEnum.MemberAccess, '.', OperatorTypeEnum.Binary, OperatorLevelEnum.Operator),
            new OperatorDescriptor(OperatorEnum.GreaterThan, '>', OperatorTypeEnum.Binary),
            new OperatorDescriptor(OperatorEnum.LessThan, '<', OperatorTypeEnum.Binary),
            new OperatorDescriptor(OperatorEnum.Equal, '=', OperatorTypeEnum.Binary),
            new OperatorDescriptor(OperatorEnum.Notequal, '<>', OperatorTypeEnum.Binary),
            new OperatorDescriptor(OperatorEnum.Equality, '==', OperatorTypeEnum.Binary),
            new OperatorDescriptor(OperatorEnum.Inequality, '!=', OperatorTypeEnum.Binary),
            new OperatorDescriptor(OperatorEnum.GreaterThanOrEqual, '>=', OperatorTypeEnum.Binary),
            new OperatorDescriptor(OperatorEnum.LessThanOrEqual, '<=', OperatorTypeEnum.Binary),
            new OperatorDescriptor(OperatorEnum.And, 'and', OperatorTypeEnum.Binary),
            new OperatorDescriptor(OperatorEnum.Or, 'or', OperatorTypeEnum.Binary),
            new OperatorDescriptor(OperatorEnum.Like, 'like', OperatorTypeEnum.Binary),
            new OperatorDescriptor(OperatorEnum.In, 'in', OperatorTypeEnum.Binary),
            new OperatorDescriptor(OperatorEnum.Between, 'between', OperatorTypeEnum.Binary),
            new OperatorDescriptor(OperatorEnum.Is, 'is', OperatorTypeEnum.Binary),
            // Unary
            new OperatorDescriptor(OperatorEnum.UnaryPlus, '+', OperatorTypeEnum.Unary),
            new OperatorDescriptor(OperatorEnum.UnaryNegation, '-', OperatorTypeEnum.Unary),
            new OperatorDescriptor(OperatorEnum.LogicalNot, '!', OperatorTypeEnum.Unary),
            new OperatorDescriptor(OperatorEnum.Not, 'not', OperatorTypeEnum.Unary),
            new OperatorDescriptor(OperatorEnum.Iif, 'iif', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Case, 'case', OperatorTypeEnum.Unary, OperatorLevelEnum.Operator),
            new OperatorDescriptor(OperatorEnum.Eval, 'eval', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.IsNull, 'isnull', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Coalesce, 'coalesce', OperatorTypeEnum.Unary, OperatorLevelEnum.Operator),
            new OperatorDescriptor(OperatorEnum.Convert, 'convert', OperatorTypeEnum.Unary, OperatorLevelEnum.Operator),
            new OperatorDescriptor(OperatorEnum.Empty, 'empty', OperatorTypeEnum.Unary, OperatorLevelEnum.Operator),
            new OperatorDescriptor(OperatorEnum.IsInteger, 'isinteger', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.IsNumeric, 'isnumeric', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.IsDatetime, 'isdatetime', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Parent, 'parent', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Child, 'child', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Vlookup, 'vlookup', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Hlookup, 'hlookup', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Exists, 'exists', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Sqr, 'sqr', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Abs, 'abs', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Sin, 'sin', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Cos, 'cos', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Round, 'round', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.RoundUp, 'roundup', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.RoundDown, 'rounddown', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Ceiling, 'ceiling', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Floor, 'floor', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Pow, 'pow', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.MaxOf, 'maxof', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.MinOf, 'minof', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Max, 'max', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Min, 'min', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Sum, 'sum', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.SumIf, 'sumif', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Avg, 'avg', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Concat, 'concat', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Count, 'count', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.CountIf, 'countif', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Mode, 'mode', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Left, 'left', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Right, 'right', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.PadL, 'padl', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.PadLeft, 'padleft', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.PadR, 'padr', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.PadRight, 'padright', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.SubStr, 'substr', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.SubString, 'substring', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.CharIndex, 'charindex', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.DateAdd, 'dateadd', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.DateDiff, 'datediff', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.DatePart, 'datepart', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Replace, 'replace', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Stuff, 'stuff', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Len, 'len', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Length, 'length', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Trim, 'trim', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Ltrim, 'ltrim', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Rtrim, 'rtrim', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Str, 'str', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Upper, 'upper', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Lower, 'lower', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.RemoveAccent, 'removeaccent', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.SpellNumber, 'spellnumber', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.GeneratePassword, 'generatepassword', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.RegexMatch, 'regexmatch', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.RegexReplace, 'regexreplace', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.RegexExtract, 'regexextract', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Inlist, 'inlist', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Hour, 'hour', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Minute, 'minute', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Second, 'second', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Day, 'day', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Month, 'month', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Year, 'year', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Quarter, 'quarter', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.GetDate, 'getdate', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.GetUtcDate, 'getutcdate', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.GetDatetime, 'getdatetime', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.GetUtcDatetime, 'getutcdatetime', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Date, 'date', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Time, 'time', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.StartDateOfYear, 'startdateofyear', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.SOYear, 'soyear', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.EndDateOfYear, 'enddateofyear', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.EOYear, 'eoyear', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.StartDateOfMonth, 'startdateofmonth', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.SOMonth, 'somonth', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.EndDateOfMonth, 'enddateofmonth', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.EOMonth, 'eomonth', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.StartDateOfQuarter, 'startdateofquarter', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.SOQuarter, 'soquarter', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.EndDateOfQuarter, 'enddateofquarter', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.EOQuarter, 'eoquarter', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.IsFiscalDate, 'isfiscaldate', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.IsSpecialDate, 'isspecialdate', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Format, 'format', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.FormatCurrency, 'formatcurrency', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.FormatQuantity, 'formatquantity', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.FormatDateRange, 'formatdaterange', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.LangId, 'langid', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.LangName, 'langname', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.NameByLang, 'namebylang', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.ResourceText, 'resourcetext', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.System, 'system', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Config, 'config', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Currency, 'currency', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.User, 'user', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Branch, 'branch', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.BranchFilter, 'branchfilter', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.FiscalYear, 'fiscalyear', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.SignatureText, 'signaturetext', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.SignatureImage, 'signatureimage', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.SignatureData, 'signaturedata', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.CurrentValue, 'currentvalue', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.TableChanged, 'tablechanged', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.RowState, 'rowstate', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.RowOldValue, 'rowoldvalue', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.RowError, 'rowerror', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.UpdatedColumn, 'updatedcolumn', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Text, 'text', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.ColumnName, 'columnname', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.TableName, 'tablename', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.LastCommand, 'lastcommand', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.OsMachineName, 'osmachinename', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.OsDomainName, 'osdomainname', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.OsUserName, 'osusername', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.ServerName, 'servername', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.DatabaseName, 'databasename', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.FormCommandName, 'formcommandname', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.FormUserName, 'formusername', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.LayoutName, 'layoutname', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.LayoutId, 'layoutid', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.VerifyChecksum, 'verifychecksum', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.TokenRawData, 'tokenrawdata', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.TokenSignData, 'tokensigndata', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.TokenSignXml, 'tokensignxml', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.TokenVerifyXml, 'tokenverifyxml', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.TokenSignDocument, 'tokensigndocument', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Encrypt, 'encrypt', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Decrypt, 'decrypt', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.HashValue, 'hashvalue', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            //new OperatorDescriptor(OperatorEnum.HashPassword, "hashpassword", OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.ImageThumbnail, 'imagethumbnail', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Platform, 'platform', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.NewId, 'newid', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.TokenSignString, 'tokensignstring', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.TokenVerifyString, 'tokenverifystring', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.GenerateToken, 'generatetoken', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.VerifyToken, 'verifytoken', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Portal, 'portal', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Logo, 'logo', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Collate, 'collate', OperatorTypeEnum.Binary),
            new OperatorDescriptor(OperatorEnum.As, 'as', OperatorTypeEnum.Binary),
            // new OperatorDescriptor(OperatorEnum.Nchar, 'nchar', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.Unicode, 'unicode', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.LayoutTableName, 'layouttablename', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.DataFormat, 'dataformat', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            //new OperatorDescriptor(OperatorEnum.GetData, "getdata", OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.GetXmlData, 'getxmldata', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.GetXmlSelectedData, 'getxmlselecteddata', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.GetJsonData, 'getjsondata', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.GetJsonSelectedData, 'getjsonselecteddata', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.EncodeHtml, 'encodehtml', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.DecodeHtml, 'decodehtml', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
            new OperatorDescriptor(OperatorEnum.PortalConfig, 'portalconfig', OperatorTypeEnum.Unary, OperatorLevelEnum.Function),
        ];
    }
    /**
     * Return the operator descriptor
     */
    getOperator(pOperatorName) {
        for (const operator of _a.Operators) {
            if (BravoStringExtensions.compareStrings(operator.Name, pOperatorName))
                return operator;
        }
        return null;
    }
    /**
     * Return the operator name
     */
    getOperatorName(pOperator) {
        for (const op of _a.Operators) {
            if (op.Operator == pOperator)
                return op.Name;
        }
        throw new Error(BravoStringExtensions.format(Resources.NotSupportedError, pOperator));
    }
    /**
     * Return the operator type
     */
    static getOperatorType(pOperator) {
        for (const operator of _a.Operators) {
            if (operator.Operator == pOperator)
                return operator.Type;
        }
        throw new Error(BravoStringExtensions.format(Resources.NotSupportedError, pOperator));
    }
    static isAggregateFunction(pOperator) {
        return (pOperator == OperatorEnum.Max ||
            pOperator == OperatorEnum.Min ||
            pOperator == OperatorEnum.Sum ||
            pOperator == OperatorEnum.SumIf ||
            pOperator == OperatorEnum.Avg ||
            pOperator == OperatorEnum.Concat ||
            pOperator == OperatorEnum.Count ||
            pOperator == OperatorEnum.CountIf ||
            pOperator == OperatorEnum.Mode);
    }
    //#endregion static members
    _operator;
    _expressions;
    _value;
    constructor(pOperator, pExpressions, pValue) {
        this._operator = pOperator ?? OperatorEnum.Unknown;
        this._expressions = pExpressions ?? [];
        this._value = pValue;
        const str = typeof this._value == 'string' ? this._value : null;
        if (this._operator == OperatorEnum.Value && str && str.startsWith('@@'))
            throw new SyntaxError(BravoStringExtensions.format(Resources.IncorrectSyntaxError, this._value));
    }
    get Operator() {
        return this._operator;
    }
    get Expressions() {
        // if (this == BravoExpression.Empty) {
        //     throw new Error(StringsExtension.format(Resources.ArgumentNullError, "expression"));
        // }
        return this._expressions;
    }
    get Value() {
        // if (this == BravoExpression.Empty) {
        //     throw new Error(StringsExtension.format(Resources.ArgumentNullError, "expression"));
        // }
        return this._value;
    }
    attributes = new Array();
    ReplaceWith(pExpression) {
        if (!pExpression)
            throw new BravoArgumentNullException('pExpression');
        this._operator = pExpression.Operator;
        this._expressions = pExpression.Expressions;
        this._value = pExpression.Value;
    }
    buildString() {
        const attrs = new BravoStringBuilder();
        for (const a of this.attributes) {
            attrs.appendFormat(' {0}', a.buildString());
        }
        if (attrs.length > 0)
            return BravoStringExtensions.format('{0} {1}', this.#buildStringCore(), attrs.toString());
        return this.#buildStringCore();
    }
    #buildStringCore() {
        if (this.Operator == OperatorEnum.Unknown)
            return BravoStringExtensions.empty;
        if (this.Operator == OperatorEnum.Value)
            return BravoStringExtensions.format('{0}', this.Value);
        if (this.Operator == OperatorEnum.UnknownFunction)
            return BravoStringExtensions.format('{0}({1})', this.Value, this.Expressions[0].buildString());
        const descriptor = _a.Operators.find(pOperator => pOperator.Operator == this.Operator);
        if (!descriptor)
            return '#N/A';
        // the function
        if (descriptor.Level == OperatorLevelEnum.Function)
            return BravoStringExtensions.format('{0}({1})', descriptor.Name, this.Expressions[0].buildString());
        // the right unary operators
        if (descriptor.Type == OperatorTypeEnum.Unary) {
            // the [is not] operator is special case process
            if (descriptor.Operator == OperatorEnum.Not && this.Expressions[0].Operator == OperatorEnum.Is) {
                const isD = _a.Operators.find(pOperator => pOperator.Operator == this.Expressions[0].Operator);
                if (isD == null)
                    return '#N/A';
                const is0 = this.Expressions[0].Expressions[0].buildString();
                const is1 = this.Expressions[0].Expressions[1].buildString();
                return BravoStringExtensions.format('{0} {1} {2} {3}', is0, isD.Name, descriptor.Name, is1);
            }
            let format;
            switch (descriptor.Operator) {
                case OperatorEnum.Not:
                    format = '{0} ({1})';
                    break;
                default:
                    format = '{0}{1}';
                    break;
            }
            return BravoStringExtensions.format(format, descriptor.Name, this.Expressions[0].buildString());
        }
        if (descriptor.Type == OperatorTypeEnum.Binary) {
            const p = Parser.getOperatorPriority(descriptor.Name);
            let s0 = this.Expressions[0].buildString();
            let s1 = this.Expressions[1].buildString();
            // the between operator is special case process
            if (descriptor.Operator == OperatorEnum.Between)
                return BravoStringExtensions.format('{0} {1} {2}', s0, descriptor.Name, s1);
            const d0 = _a.Operators.find(pOperator => pOperator.Operator == this.Expressions[0].Operator);
            if (d0 != null && d0.Type == OperatorTypeEnum.Binary && Parser.getOperatorPriority(d0.Name) < p)
                s0 = '(' + s0 + ')';
            let isAddBrackets = false;
            const d1 = _a.Operators.find(pOperator => pOperator.Operator == this.Expressions[1].Operator);
            if (d1 != null && d1.Type == OperatorTypeEnum.Binary && Parser.getOperatorPriority(d1.Name) < p) {
                isAddBrackets = true;
                s1 = '(' + s1 + ')';
            }
            if (!isAddBrackets && descriptor.Operator == OperatorEnum.In)
                s1 = '(' + s1 + ')';
            if (!isAddBrackets &&
                d1 != null &&
                ((descriptor.Operator == OperatorEnum.And && d1.Operator == OperatorEnum.Or) ||
                    (descriptor.Operator == OperatorEnum.Or && d1.Operator == OperatorEnum.And)))
                s1 = '(' + s1 + ')';
            let format;
            switch (descriptor.Operator) {
                case OperatorEnum.Arguments:
                    format = '{1}{0} {2}';
                    break;
                case OperatorEnum.MemberAccess:
                case OperatorEnum.Addition:
                case OperatorEnum.Subtraction:
                case OperatorEnum.Multiplication:
                case OperatorEnum.Division:
                case OperatorEnum.Modulus:
                case OperatorEnum.GreaterThan:
                case OperatorEnum.LessThan:
                case OperatorEnum.Equal:
                case OperatorEnum.Notequal:
                case OperatorEnum.Equality:
                case OperatorEnum.Inequality:
                case OperatorEnum.GreaterThanOrEqual:
                case OperatorEnum.LessThanOrEqual:
                    format = '{1}{0}{2}';
                    break;
                default:
                    format = '{1} {0} {2}';
                    break;
            }
            return BravoStringExtensions.format(format, descriptor.Name, s0, s1);
        }
        return '#N/A';
    }
}
_a = BravoExpression;
const Empty = new BravoExpression();
class OperatorDescriptor {
    _name;
    _type;
    _operator;
    _level;
    _description;
    constructor(pOperator, pName, pType, pLevel = OperatorLevelEnum.Operator, pDescription) {
        this._operator = pOperator;
        this._name = pName;
        this._type = pType;
        this._level = pLevel;
        this._description = pDescription;
    }
    get Name() {
        return this._name;
    }
    get Type() {
        return this._type;
    }
    get Operator() {
        return this._operator;
    }
    get Level() {
        return this._level;
    }
    get Description() {
        return this._description;
    }
}
class Parser {
    static _isWhiteSpace(pChar) {
        return (pChar === ' ' || pChar === '\r' || pChar === '\t' || pChar === '\n' || pChar === '\v' || pChar === '\u00A0');
    }
    static _isDigit(pChar) {
        return '0' <= pChar && pChar <= '9';
    }
    static _isAlpha(pChar) {
        return 'A' <= pChar && pChar <= 'z';
    }
    /* private static isAlphaNumeric(ch): boolean {
        return ('0' <= ch && ch <= '9') || ('A' <= ch && ch <= 'z') || ch == '$' || ch == '@';
    } */
    static _isAlphaNumeric(pChar) {
        switch (pChar) {
            case '@':
            case '$':
            case '0':
            case '1':
            case '2':
            case '3':
            case '4':
            case '5':
            case '6':
            case '7':
            case '8':
            case '9':
            case 'A':
            case 'B':
            case 'C':
            case 'D':
            case 'E':
            case 'F':
            case 'G':
            case 'H':
            case 'I':
            case 'J':
            case 'K':
            case 'L':
            case 'M':
            case 'N':
            case 'O':
            case 'P':
            case 'Q':
            case 'R':
            case 'S':
            case 'T':
            case 'U':
            case 'V':
            case 'W':
            case 'X':
            case 'Y':
            case 'Z':
            case '_':
            case 'a':
            case 'b':
            case 'c':
            case 'd':
            case 'e':
            case 'f':
            case 'g':
            case 'h':
            case 'i':
            case 'j':
            case 'k':
            case 'l':
            case 'm':
            case 'n':
            case 'o':
            case 'p':
            case 'q':
            case 'r':
            case 's':
            case 't':
            case 'u':
            case 'v':
            case 'w':
            case 'x':
            case 'y':
            case 'z':
                return true;
        }
        return pChar > '\u007f';
    }
    static parseNumber(pValue) {
        if (!pValue)
            return pValue;
        let isDouble = false;
        const textNumber = [];
        for (let n = 0; n < pValue.length - 1; n++) {
            if (BravoNumberExtensions.isNumber(pValue[n]) || pValue[n] == '.') {
                textNumber.push(pValue[n]);
                if (BravoNumberExtensions.isNumber(pValue[n])) {
                    isDouble = true;
                }
            }
            else {
                return pValue;
            }
        }
        const ch = pValue[pValue.length - 1];
        let number;
        if (BravoNumberExtensions.isNumber(ch)) {
            textNumber.push(ch);
        }
        else {
            if (textNumber.length == 0) {
                return pValue;
            }
            number = textNumber.join('');
            switch (ch) {
                case 'f':
                    return parseFloat(number);
                default:
                    return number;
            }
        }
        number = textNumber.join('');
        if (isDouble)
            return parseFloat(number);
        return parseInt(number);
    }
    static _getUnaryOperator(pValue) {
        const operators = BravoExpression.Operators;
        for (let n = 0; n < operators.length; n++) {
            const op = operators[n];
            if (op.Type == OperatorTypeEnum.Unary &&
                pValue &&
                BravoStringExtensions.compareStrings(op.Name, pValue, true)) {
                return op.Operator;
            }
        }
        return OperatorEnum.UnknownFunction;
        // throw new Error(StringsExtension.format(Resources.NotSupportedError, value));
    }
    static _getBinaryOperator(pValue) {
        const operators = BravoExpression.Operators;
        for (let n = 0; n < operators.length; n++) {
            const op = operators[n];
            if (op.Type == OperatorTypeEnum.Binary &&
                pValue &&
                BravoStringExtensions.compareStrings(op.Name, pValue, true)) {
                return op.Operator;
            }
        }
        throw new Error(BravoStringExtensions.format(Resources.NotSupportedError, pValue));
    }
    static getOperatorPriority(pValue) {
        switch (pValue.toLowerCase()) {
            case '.':
                return 4;
            case '&':
                return 3;
            case '*':
            case '/':
            case '%':
                return -1;
            case '+':
            case '-':
                return -2;
            case '=':
            case '<':
            case '>':
            case '<>':
            case '==':
            case '!=':
            case '<=':
            case '>=':
                return -13;
            case 'is':
                return -14;
            case 'and':
                return -15;
            case 'or':
                return -16;
            case 'as':
                return -17;
            case ',':
                return -18;
            default:
                return 0;
        }
    }
    static _isExplicitUnary(pValue) {
        let isUnary = false;
        let isBinary = false;
        const operators = BravoExpression.Operators;
        for (let n = 0; n < operators.length; n++) {
            const op = operators[n];
            if (pValue && BravoStringExtensions.compareStrings(op.Name, pValue, true)) {
                if (op.Type == OperatorTypeEnum.Binary)
                    isBinary = true;
                else if (op.Type == OperatorTypeEnum.Unary)
                    isUnary = true;
            }
        }
        return isUnary && !isBinary;
    }
    static _isExplicitBinary(pValue) {
        let isUnary = false;
        let isBinary = false;
        const operators = BravoExpression.Operators;
        for (let n = 0; n < operators.length; n++) {
            const op = operators[n];
            if (pValue && BravoStringExtensions.compareStrings(op.Name, pValue, true)) {
                if (op.Type == OperatorTypeEnum.Binary)
                    isBinary = true;
                else if (op.Type == OperatorTypeEnum.Unary)
                    isUnary = true;
            }
        }
        return !isUnary && isBinary;
    }
    _expression;
    _length = 0;
    _pos = -1;
    get Opreators() {
        return BravoExpression.Operators;
    }
    _tokens;
    get tokens() {
        return this._tokens;
    }
    _getTokens() {
        this._tokens = new Array();
        let brackets = 0;
        this._pos = 0;
        let ch = this._expression[this._pos];
        while (this._pos < this._length) {
            let unicodeQuote = false;
            if (ch == 'N') {
                const p = this._pos + 1;
                if (p < this._length) {
                    const c = this._expression[p];
                    if (c == "'") {
                        ch = c;
                        this._pos = p;
                        unicodeQuote = true;
                    }
                }
            }
            if (unicodeQuote) {
                const sl = this._pos;
                const tk = 'N' + this._scanQuote();
                this._tokens.push(new Token(sl, this._pos, tk, TokenTypeEnum.UnicodeQuote));
            }
            else if (ch === "'") {
                const start = this._pos;
                const tk = this._scanQuote();
                this._tokens.push(new Token(start, this._pos, tk, TokenTypeEnum.Quote));
            }
            else if (Parser._isWhiteSpace(ch)) {
                const start = this._pos;
                const tk = this._scanWhiteSpace();
                this._tokens.push(new Token(start, this._pos, tk, TokenTypeEnum.WhiteSpace));
            }
            else if (Parser._isDigit(ch)) {
                const start = this._pos;
                const tk = this._scanNumeric();
                this._tokens.push(new Token(start, this._pos, tk, TokenTypeEnum.Numeric));
            }
            else if (ch === '+' ||
                ch === '-' ||
                ch === '*' ||
                ch === '/' ||
                ch === '%' ||
                ch === '(' ||
                ch === ')' ||
                ch === ',' ||
                ch === '.') {
                let isHandled = false;
                if (ch == '*') {
                    let isAllCols = true;
                    for (let i = this._tokens.length - 1; i >= 0; i--) {
                        if (this._tokens[i].Type == TokenTypeEnum.WhiteSpace)
                            continue;
                        if (this._tokens[i].Type == TokenTypeEnum.Operator &&
                            (this._tokens[i].Text == '.' || this._tokens[i].Text == '(' || this._tokens[i].Text == ',')) {
                            /* empty */
                        }
                        else {
                            isAllCols = false;
                        }
                        break;
                    }
                    if (isAllCols) {
                        this._tokens.push(new Token(this._pos, this._pos, ch, TokenTypeEnum.Word));
                        isHandled = true;
                    }
                }
                if (!isHandled)
                    this._tokens.push(new Token(this._pos, this._pos, ch, TokenTypeEnum.Operator));
                if (ch == '(') {
                    brackets++;
                }
                else if (ch == ')') {
                    brackets--;
                }
            }
            else if (ch === '=' || ch === '>' || ch === '<' || ch === '!') {
                if (this._pos < this._length &&
                    (this._expression[this._pos + 1] === '=' || (ch === '<' && this._expression[this._pos + 1] === '>'))) {
                    this._tokens.push(new Token(this._pos, this._pos + 1, ch.concat(this._expression[this._pos + 1]), TokenTypeEnum.Operator));
                    this._pos++;
                }
                else {
                    this._tokens.push(new Token(this._pos, this._pos, ch, TokenTypeEnum.Operator));
                }
            }
            else if (ch === ';') {
                this._tokens.push(new Token(this._pos, this._pos, ch, TokenTypeEnum.Terminator));
            }
            else if (ch === '[') {
                const start = this._pos;
                const tk = this._scanName();
                this._tokens.push(new Token(start, this._pos, tk, TokenTypeEnum.Name));
            }
            else if (Parser._isAlphaNumeric(ch)) {
                const start = this._pos;
                const tk = [];
                while (Parser._isAlphaNumeric(ch) && this._pos < this._length) {
                    tk.push(ch);
                    if (++this._pos < this._length) {
                        ch = this._expression[this._pos];
                    }
                }
                this._pos--;
                let type = TokenTypeEnum.Word;
                if (this._pos < this._length - 1 && this._nextWordChar() === '(')
                    type = TokenTypeEnum.Function;
                // Handle for t-sql user defined function
                if (type == TokenTypeEnum.Function &&
                    this._tokens.length > 1 &&
                    this._tokens[this._tokens.length - 1].Type == TokenTypeEnum.Operator &&
                    this._tokens[this._tokens.length - 1].Text == '.' &&
                    this._tokens[this._tokens.length - 2].Type == TokenTypeEnum.Word) {
                    // Remove "."
                    const dotToken = this._tokens[this._tokens.length - 1];
                    this._tokens.splice(this._tokens.length - 1, 1);
                    // Remove "schema"
                    const schemaToken = this._tokens[this._tokens.length - 1];
                    this._tokens.splice(this._tokens.length - 1, 1);
                    tk.splice(0, 0, dotToken.Text);
                    tk.splice(0, 0, schemaToken.Text);
                }
                this._tokens.push(new Token(start, this._pos, tk.join(''), type));
            }
            else {
                throw new SyntaxError(BravoStringExtensions.format(Resources.IncorrectSyntaxError, ch));
            }
            if (++this._pos < this._length) {
                ch = this._expression[this._pos];
            }
        }
        if (brackets > 0) {
            throw new SyntaxError(BravoStringExtensions.format(Resources.IncorrectSyntaxError, ch));
        }
    }
    _scanDeclare(pOutParams, pType) {
        let variable = BravoStringExtensions.empty;
        while (pOutParams.pos < this._tokens.length) {
            const token = this._tokens[pOutParams.pos++];
            if (token.Type == TokenTypeEnum.WhiteSpace) {
                continue;
            }
            if (variable) {
                variable = token.Text;
                continue;
            }
            if (token.Text != '=') {
                throw new SyntaxError(BravoStringExtensions.format(Resources.IncorrectSyntaxError, token.Text));
            }
            break;
        }
        return new BravoExpression(pType, [
            new BravoExpression(OperatorEnum.Value, undefined, variable),
            this._parseExpression(pOutParams),
        ]);
    }
    _parseExpression(pOutParams, pTerminal = false) {
        const operatorStack = new Stack();
        const operandStack = new Stack();
        let operator;
        let lhs, rhs;
        for (; pOutParams.pos < this._tokens.length; pOutParams.pos++) {
            const token = this._tokens[pOutParams.pos];
            if (token.Type === TokenTypeEnum.Terminator)
                break;
            if (token.Text === ')')
                break;
            if (token.Type === TokenTypeEnum.WhiteSpace)
                continue;
            const outParam = { keyword: BravoStringExtensions.empty, revert: 0 };
            if (ClauseExpression.match(this._tokens, pOutParams, outParam)) {
                if (pTerminal) {
                    break;
                }
            }
            if (ClauseExpression.isOption(token.Text, ClauseExpression.Over)) {
                pOutParams.pos += outParam.revert;
                const over = new ClauseExpression(ClauseExpression.Over);
                this._scanOverClause(over, pOutParams);
                pOutParams.pos--;
                let isAttribute = operandStack.size > 0;
                if (isAttribute)
                    isAttribute =
                        operatorStack.size < 1 ||
                            (operandStack.size > 1 &&
                                (operandStack.peek().Operator == OperatorEnum.UnknownFunction ||
                                    BravoExpression.isAggregateFunction(operandStack.peek().Operator) ||
                                    ClauseExpression.isFunction(BravoStringExtensions.format('{0}', operandStack.peek()?.Value))));
                // if (operandStack.size > 0 && operatorStack.size < 1)
                if (isAttribute)
                    operandStack.peek().attributes.push(over);
                else
                    operandStack.push(over);
                continue;
            }
            if (token.Type == TokenTypeEnum.Word && ClauseExpression.isOption(token.Text, ClauseExpression.Case)) {
                pOutParams.pos += outParam.revert;
                const clauseCase = new ClauseExpression(ClauseExpression.Case);
                this._scanCaseClause(clauseCase, pOutParams);
                pOutParams.pos--;
                if (operandStack.size > 0 && operatorStack.size < 1)
                    operandStack.peek().attributes.push(clauseCase);
                else
                    operandStack.push(clauseCase);
                continue;
            }
            // The operand that flow by attribute
            if (ClauseExpression.isOption(token.Text, ClauseExpression.AscendingOrder) ||
                ClauseExpression.isOption(token.Text, ClauseExpression.DescendingOrder)) {
                const order = new BravoExpression(OperatorEnum.Value, undefined, token.Text);
                if (operandStack.size > 0)
                    operandStack.peek().attributes.push(order);
                else
                    operandStack.push(order);
                continue;
            }
            if (token.Text === '(') {
                pOutParams.pos++;
                let expression = this._parseExpression(pOutParams);
                while (operatorStack.size > operandStack.size) {
                    if (Parser._isExplicitBinary(operatorStack.peek()))
                        break;
                    operator = operatorStack.pop();
                    const op = Parser._getUnaryOperator(operator);
                    if (op == OperatorEnum.UnknownFunction)
                        expression = new BravoExpression(op, [expression], operator);
                    else
                        expression = new BravoExpression(op, [expression], null);
                }
                operandStack.push(expression);
            }
            else if (this._isOperator(token)) {
                if (token.Text.toLowerCase() === 'and' &&
                    operatorStack.size > 0 &&
                    operatorStack.peek().toLowerCase() === 'between') {
                    operatorStack.push(token.Text);
                }
                else if (token.Text.toLowerCase() === 'not' &&
                    operatorStack.size > 0 &&
                    operatorStack.peek().toLowerCase() === 'is') {
                    operator = operatorStack.pop();
                    operatorStack.push(token.Text);
                    operatorStack.push(operator);
                }
                // Just handle for t-sql syntax such as: COUNT(*), SUM(*)...
                else if (token.Text.toLowerCase() == ClauseExpression.AllColumns && operandStack.size < 1) {
                    operandStack.push(new BravoExpression(OperatorEnum.Value, undefined, token.Text));
                }
                else {
                    while (operandStack.size >= 2 && operatorStack.size > 0) {
                        if (Parser.getOperatorPriority(operatorStack.peek()) < Parser.getOperatorPriority(token.Text))
                            break;
                        if (operatorStack.peek().toLowerCase() === 'not')
                            break;
                        operator = operatorStack.pop();
                        rhs = operandStack.pop();
                        lhs = operandStack.pop();
                        let expression = new BravoExpression(Parser._getBinaryOperator(operator), [lhs, rhs]);
                        if (operator.toLowerCase() === 'and' &&
                            operatorStack.size > 0 &&
                            operatorStack.peek().toLowerCase() === 'between') {
                            operator = operatorStack.pop();
                            lhs = operandStack.pop();
                            expression = new BravoExpression(Parser._getBinaryOperator(operator), [lhs, expression]);
                        }
                        if (Parser._isExplicitBinary(operator) &&
                            operatorStack.size > 0 &&
                            operatorStack.peek().toLowerCase() === 'not') {
                            operator = operatorStack.pop();
                            expression = new BravoExpression(OperatorEnum.Not, [expression]);
                        }
                        operandStack.push(expression);
                    }
                    operatorStack.push(token.Text);
                }
            }
            else {
                let value;
                if (token.Type == TokenTypeEnum.Quote || token.Type == TokenTypeEnum.UnicodeQuote) {
                    value = token.Text;
                }
                else if (BravoStringExtensions.compareStrings(token.Text, BravoBooleanExtensions.trueString, true)) {
                    value = true;
                }
                else if (BravoStringExtensions.compareStrings(token.Text, BravoBooleanExtensions.falseString, true)) {
                    value = false;
                }
                else {
                    value = Parser.parseNumber(token.Text);
                }
                let expression = new BravoExpression(OperatorEnum.Value, undefined, value);
                while (operatorStack.size > operandStack.size) {
                    if (Parser._isExplicitBinary(operatorStack.peek()))
                        break;
                    if (operatorStack.peek().toLowerCase() === 'not')
                        break;
                    operator = operatorStack.pop();
                    expression = new BravoExpression(Parser._getUnaryOperator(operator), [expression]);
                }
                operandStack.push(expression);
            }
        }
        while (operandStack.size >= 2 && operatorStack.size > 0) {
            operator = operatorStack.pop();
            rhs = operandStack.pop();
            lhs = operandStack.pop();
            let expression = new BravoExpression(Parser._getBinaryOperator(operator), [lhs, rhs]);
            if (Parser._isExplicitBinary(operator) &&
                operatorStack.size > 0 &&
                operatorStack.peek().toLowerCase() === 'not') {
                operator = operatorStack.pop();
                expression = new BravoExpression(OperatorEnum.Not, [expression]);
            }
            operandStack.push(expression);
        }
        if (operandStack.size == 0)
            return Empty;
        if (operandStack.size >= 2)
            throw new SyntaxError(BravoStringExtensions.format(Resources.IncorrectSyntaxError, operandStack.peek().Value));
        if (operatorStack.size >= 1)
            throw new SyntaxError(BravoStringExtensions.format(Resources.IncorrectSyntaxError, operatorStack.peek()));
        return operandStack.peek();
    }
    parseExpressions(pExpression) {
        if (!pExpression)
            throw new BravoArgumentNullException('pExpression');
        this._expression = pExpression;
        this._length = pExpression.length;
        this._pos = 0;
        this._getTokens();
        const batch = new Array();
        const outPos = { pos: 0 };
        // this._posTk = 0;
        for (; outPos.pos < this._tokens.length; outPos.pos++) {
            const token = this._tokens[outPos.pos];
            if (token.Type == TokenTypeEnum.WhiteSpace) {
                continue;
            }
            switch (token.Text.toLowerCase()) {
                case 'declare':
                    outPos.pos++;
                    batch.push(this._scanDeclare(outPos, OperatorEnum.Declare));
                    break;
                case 'set':
                    outPos.pos++;
                    batch.push(this._scanDeclare(outPos, OperatorEnum.Set));
                    break;
                default:
                    batch.push(this._parseExpression(outPos));
                    break;
            }
        }
        return batch;
    }
    _scanQuote() {
        const quote = [];
        let state = 0;
        let ch = this._expression[this._pos];
        while (this._pos < this._length) {
            if (ch == "'") {
                quote.push(ch);
                if (state == 0) {
                    state = 1;
                }
                else {
                    let escape = false;
                    if (this._pos < this._length - 1) {
                        const nch = this._expression[this._pos + 1];
                        if (nch == "'") {
                            this._pos++;
                            escape = true;
                        }
                    }
                    if (!escape) {
                        return quote.join('');
                    }
                }
            }
            else {
                quote.push(ch);
            }
            if (++this._pos < this._length) {
                ch = this._expression[this._pos];
            }
        }
        throw new Error(BravoStringExtensions.format(Resources.UnclosedQuotationError, ch));
    }
    _scanName() {
        const name = [];
        let ch = this._expression[this._pos];
        while (this._pos < this._length) {
            name.push(ch);
            if (ch == ']') {
                return name.join('');
            }
            if (++this._pos < this._length) {
                ch = this._expression[this._pos];
            }
        }
        throw new Error(BravoStringExtensions.format(Resources.UnclosedQuotationError, ch));
    }
    _scanWhiteSpace() {
        const white = [];
        let ch = this._expression[this._pos];
        while (Parser._isWhiteSpace(ch) && this._pos < this._length) {
            white.push(ch);
            if (++this._pos < this._length) {
                ch = this._expression[this._pos];
            }
        }
        this._pos--;
        return white.join('');
    }
    _scanNumeric() {
        const num = [];
        let ch = this._expression[this._pos];
        const isHexNumber = this._pos + 2 < this._length &&
            Boolean([ch, this._expression[this._pos + 1], this._expression[this._pos + 2]]
                .join('')
                .match(/^(0x|0X)?[a-fA-F0-9]{1}$/i));
        if (isHexNumber) {
            num.push(ch);
            num.push(this._expression[++this._pos]);
            if (this._pos + 1 < this._length)
                ch = this._expression[++this._pos];
        }
        let validChars = BravoStringExtensions.empty;
        if (isHexNumber)
            validChars = '[a-fA-F0-9]';
        else
            validChars = '[0-9.fd]';
        // while ((Parser.isDigit(ch) || ch == '.' || ch == 'f' || ch == 'd') && this._pos < this._length) {
        const regex = new RegExp(validChars, 'i');
        while (regex.test(ch) && this._pos < this._length) {
            num.push(ch);
            if (!isHexNumber && (ch == 'f' || ch == 'd')) {
                this._pos++;
                break;
            }
            if (++this._pos < this._length) {
                ch = this._expression[this._pos];
            }
        }
        this._pos--;
        return num.join('');
    }
    _nextWordChar() {
        let pos = this._pos + 1;
        while (pos < this._length && Parser._isWhiteSpace(this._expression[pos++]))
            ;
        return this._expression[--pos];
    }
    _isOperator(pValue) {
        if (pValue.Text == '*' && pValue.Type == TokenTypeEnum.Word)
            return false;
        const outArgs = { resultValue: null };
        if (BravoEnumExtensions.isEnumType(OperatorEnum, pValue.Text, outArgs) &&
            this.Opreators.find(pOperator => pOperator.Operator == outArgs.resultValue && pOperator.Type == OperatorTypeEnum.Binary) &&
            this._tokens.length < 3)
            return false;
        for (let n = 0; n < this.Opreators.length; n++) {
            const op = this.Opreators[n];
            if (pValue && BravoStringExtensions.compareStrings(op.Name, pValue.Text, true)) {
                if (op.Level == OperatorLevelEnum.Operator)
                    return true;
                if (op.Level == OperatorLevelEnum.Function && pValue.Type == TokenTypeEnum.Function)
                    return true;
            }
        }
        if (pValue.Type == TokenTypeEnum.Function && ClauseExpression.isFunction(pValue.Text))
            return true;
        return false;
    }
    _scanOverClause(pClause, pRefPos) {
        while (pRefPos.pos < this._tokens.length) {
            const token = this._tokens[pRefPos.pos++];
            if (token.Type == TokenTypeEnum.WhiteSpace)
                continue;
            if (token.Text == '(')
                break;
            throw new Error(BravoStringExtensions.format(Resources.IncorrectSyntaxError, token.Text));
        }
        while (true) {
            const outParam = { keyword: BravoStringExtensions.empty, revert: 0 };
            if (ClauseExpression.match(this._tokens, pRefPos, outParam)) {
                if (ClauseExpression.isOption(outParam.keyword, ClauseExpression.PartitionBy)) {
                    pRefPos.pos += outParam.revert;
                    pClause.addOption(ClauseExpression.PartitionBy, this._parseExpression(pRefPos, true));
                    if (this._tokens[pRefPos.pos].Text == ')')
                        break;
                }
                else if (ClauseExpression.isOption(outParam.keyword, ClauseExpression.OrderBy)) {
                    pRefPos.pos += outParam.revert;
                    pClause.addOption(ClauseExpression.OrderBy, this._parseExpression(pRefPos, true));
                    if (this._tokens[pRefPos.pos].Text == ')')
                        break;
                }
                else {
                    break;
                }
            }
            else {
                break;
            }
        }
        pRefPos.pos++;
    }
    _scanCaseClause(pClause, pRefPos) {
        while (pRefPos.pos < this._tokens.length) {
            const token = this._tokens[pRefPos.pos++];
            if (token.Type == TokenTypeEnum.WhiteSpace)
                continue;
            if (token.Text.toLowerCase() == ClauseExpression.When) {
                pRefPos.pos--;
                break;
            }
            throw new Error(BravoStringExtensions.format(Resources.IncorrectSyntaxError, token.Text));
        }
        while (true) {
            const outParam = { keyword: BravoStringExtensions.empty, revert: 0 };
            if (ClauseExpression.match(this._tokens, pRefPos, outParam)) {
                if (ClauseExpression.isOption(outParam.keyword, ClauseExpression.When) ||
                    ClauseExpression.isOption(outParam.keyword, ClauseExpression.Then) ||
                    ClauseExpression.isOption(outParam.keyword, ClauseExpression.Else)) {
                    pRefPos.pos += outParam.revert;
                    pClause.addOption(outParam.keyword, this._parseExpression(pRefPos, true));
                }
                else if (ClauseExpression.isOption(outParam.keyword, ClauseExpression.End)) {
                    pRefPos.pos += outParam.revert;
                    pClause.addOption(ClauseExpression.End);
                    break;
                }
                else {
                    break;
                }
            }
            else {
                break;
            }
        }
        pRefPos.pos++;
    }
}
class Token {
    _type;
    _text;
    _startLocation;
    _endLocation;
    constructor(pStartLocation, pEndLocation, pText, pType) {
        this._startLocation = pStartLocation;
        this._endLocation = pEndLocation;
        this._text = pText;
        this._type = pType;
    }
    get Type() {
        return this._type;
    }
    get Text() {
        return this._text;
    }
    get StartLocation() {
        return this._startLocation;
    }
    get EndLocation() {
        return this._endLocation;
    }
}
class ClauseExpression extends BravoExpression {
    static Select = 'select';
    static All = 'all';
    static Distinct = 'distinct';
    static Top = 'top';
    static Percent = 'percent';
    static SelectList = 'select_list';
    static AllColumns = '*';
    static From = 'from';
    static TableSource = 'table_source';
    static Join = 'join';
    static Join_Inner = 'inner join';
    static LeftJoin = 'left join';
    static LeftJoin_Outer = 'left outer join';
    static RightJoin = 'right join';
    static RightJoin_Outer = 'right outer join';
    static On = 'on';
    static GroupBy = 'group by';
    static ColumnExpression = 'column-expression';
    static Where = 'where';
    static SearchCondition = 'search_condition';
    static OrderBy = 'order by';
    static OrderByExpression = 'order_by_expression';
    static RowNumber = 'row_number';
    static AscendingOrder = 'asc';
    static DescendingOrder = 'desc';
    static Over = 'over';
    static PartitionBy = 'partition by';
    static Case = 'case';
    static When = 'when';
    static Then = 'then';
    static Else = 'else';
    static End = 'end';
    static clauseTokens = [
        ClauseExpression.Select,
        ClauseExpression.All,
        ClauseExpression.Distinct,
        ClauseExpression.Top,
        ClauseExpression.Percent,
        ClauseExpression.SelectList,
        ClauseExpression.AllColumns,
        ClauseExpression.From,
        ClauseExpression.TableSource,
        ClauseExpression.Join,
        ClauseExpression.Join_Inner,
        ClauseExpression.LeftJoin,
        ClauseExpression.LeftJoin_Outer,
        ClauseExpression.RightJoin,
        ClauseExpression.RightJoin_Outer,
        ClauseExpression.On,
        ClauseExpression.GroupBy,
        ClauseExpression.ColumnExpression,
        ClauseExpression.Where,
        ClauseExpression.SearchCondition,
        ClauseExpression.OrderBy,
        ClauseExpression.OrderByExpression,
        ClauseExpression.AscendingOrder,
        ClauseExpression.DescendingOrder,
        ClauseExpression.Over,
        ClauseExpression.PartitionBy,
        ClauseExpression.Case,
        ClauseExpression.When,
        ClauseExpression.Then,
        ClauseExpression.Else,
        ClauseExpression.End,
        ClauseExpression.RowNumber,
    ];
    static _keywords = [
        ClauseExpression.Select,
        ClauseExpression.All,
        ClauseExpression.Distinct,
        ClauseExpression.Top,
        ClauseExpression.Percent,
        ClauseExpression.From,
        ClauseExpression.Join,
        ClauseExpression.Join_Inner,
        ClauseExpression.LeftJoin,
        ClauseExpression.LeftJoin_Outer,
        ClauseExpression.RightJoin,
        ClauseExpression.RightJoin_Outer,
        ClauseExpression.On,
        ClauseExpression.Where,
        ClauseExpression.GroupBy,
        ClauseExpression.OrderBy,
        ClauseExpression.PartitionBy,
        ClauseExpression.When,
        ClauseExpression.Then,
        ClauseExpression.Else,
        ClauseExpression.End,
    ];
    static isFunction(pFunc) {
        if (pFunc.toLowerCase() == 'cast' ||
            pFunc.toLowerCase() == 'numeric' ||
            pFunc.toLowerCase() == 'BrSafeAny' ||
            pFunc.toLowerCase() == 'all' ||
            pFunc.toLowerCase() == 'some' ||
            pFunc.toLowerCase() == 'row_number' ||
            pFunc.toLowerCase() == 'rank' ||
            pFunc.toLowerCase() == 'string_agg' ||
            pFunc.toLowerCase() == '$')
            return true;
        if (BravoEnumExtensions.isEnumType(SqlDbTypeEnum, pFunc))
            return true;
        const matches = pFunc.match(/(?:)ufn_\w+(?:)/g);
        if (matches && matches.length > 0)
            return true;
        switch (pFunc.toLowerCase()) {
            case 'host_id':
            case 'host_name':
            case 'db_id':
            case 'db_name':
                return false;
        }
        return true;
    }
    static isJoin(pJoin) {
        return (BravoStringExtensions.compareStrings(pJoin, this.Join, true) ||
            BravoStringExtensions.compareStrings(pJoin, this.Join_Inner, true) ||
            BravoStringExtensions.compareStrings(pJoin, this.LeftJoin, true) ||
            BravoStringExtensions.compareStrings(pJoin, this.LeftJoin_Outer, true) ||
            BravoStringExtensions.compareStrings(pJoin, this.RightJoin, true) ||
            BravoStringExtensions.compareStrings(pJoin, this.RightJoin_Outer, true));
    }
    static isOption(pStr, pK) {
        return BravoStringExtensions.compareStrings(pStr, pK, true);
    }
    static match(pTokens, pRefPos, pOutParams) {
        if (pRefPos.pos >= pTokens.length) {
            pOutParams.revert = 0;
            pOutParams.keyword = BravoStringExtensions.empty;
            return false;
        }
        pOutParams.revert = 1;
        let s = pTokens[pRefPos.pos++].Text;
        pOutParams.keyword =
            this._keywords.find(pKeyword => pKeyword.toLowerCase().startsWith(s.toLowerCase())) ??
                BravoStringExtensions.empty;
        if (pOutParams.keyword == null) {
            pRefPos.pos -= pOutParams.revert;
            return false;
        }
        if (BravoStringExtensions.compareStrings(s, pOutParams.keyword, true)) {
            pRefPos.pos -= pOutParams.revert;
            return true;
        }
        const b = new BravoStringBuilder();
        b.append(s);
        const at = pRefPos.pos;
        while (pRefPos.pos < pTokens.length) {
            const token = pTokens[pRefPos.pos++];
            pOutParams.revert = pRefPos.pos - at + 1;
            if (token.Type == TokenTypeEnum.WhiteSpace)
                continue;
            b.append(' ');
            b.append(token.Text);
            s = b.toString();
            pOutParams.keyword =
                this._keywords.find(pKeyword => pKeyword.toLowerCase().startsWith(s.toLowerCase())) ??
                    BravoStringExtensions.empty;
            if (pOutParams.keyword == null) {
                pRefPos.pos -= pOutParams.revert;
                return false;
            }
            if (BravoStringExtensions.compareStrings(s, pOutParams.keyword, true)) {
                pRefPos.pos -= pOutParams.revert;
                return true;
            }
        }
        pRefPos.pos -= pOutParams.revert;
        return false;
    }
    _options;
    zName;
    constructor(pName, pExpression) {
        super(OperatorEnum.Unknown, pExpression ? [pExpression] : []);
        this.zName = pName;
        this._options = new Array();
    }
    addOption(pArg, pExpression) {
        if (pArg instanceof ClauseExpression)
            this._options.push(pArg);
        else
            this._options.push(new ClauseExpression(pArg, pExpression));
    }
    buildString() {
        const b = new BravoStringBuilder();
        switch (true) {
            case BravoStringExtensions.compareStrings(this.zName, ClauseExpression.Select): {
                this._buildSelect(b);
                break;
            }
            case BravoStringExtensions.compareStrings(this.zName, ClauseExpression.From): {
                this._buildFromClause(b);
                break;
            }
            case BravoStringExtensions.compareStrings(this.zName, ClauseExpression.GroupBy):
                {
                    const clause = this.getOption(ClauseExpression.ColumnExpression);
                    b.appendFormat('{0} {1}', this.zName, clause?.buildString());
                }
                break;
            case BravoStringExtensions.compareStrings(this.zName, ClauseExpression.Where):
                {
                    const clause = this.getOption(ClauseExpression.SearchCondition);
                    b.appendFormat('{0} {1}', this.zName, clause?.buildString());
                }
                break;
            case BravoStringExtensions.compareStrings(this.zName, ClauseExpression.OrderBy):
                {
                    const clause = this.getOption(ClauseExpression.OrderByExpression);
                    b.appendFormat('{0} {1}', this.zName.toUpperCase(), clause?.buildString());
                }
                break;
            case BravoStringExtensions.compareStrings(this.zName, ClauseExpression.RowNumber):
                {
                    b.appendFormat('{0}()', this.zName.toUpperCase());
                    if (this.containsOption(ClauseExpression.Over))
                        b.appendFormat(' {0}', this.getOption(ClauseExpression.Over)?.buildString());
                }
                break;
            case BravoStringExtensions.compareStrings(this.zName, ClauseExpression.Over):
                {
                    b.appendFormat('{0} (', this.zName.toUpperCase());
                    if (this.containsOption(ClauseExpression.PartitionBy))
                        b.appendFormat(' {0} {1}', ClauseExpression.PartitionBy, this.getOption(ClauseExpression.PartitionBy)?.buildString());
                    if (this.containsOption(ClauseExpression.OrderByExpression))
                        b.appendFormat(' {0} {1}', ClauseExpression.OrderBy, this.getOption(ClauseExpression.OrderByExpression)?.buildString());
                    b.append(')');
                }
                break;
            case BravoStringExtensions.compareStrings(this.zName, ClauseExpression.Case): {
                b.appendFormat('({0}', this.zName);
                b.appendLine();
                for (let i = 0; i < this._options.length; i++) {
                    const isThenClause = BravoStringExtensions.compareStrings(this._options[i].zName, ClauseExpression.Then, true);
                    if (BravoStringExtensions.compareStrings(this._options[i].zName, ClauseExpression.When, true) ||
                        isThenClause) {
                        if (isThenClause)
                            b.append(' ');
                        b.appendFormat('{0} {1}', this._options[i].zName, this._options[i].buildString());
                        if (isThenClause)
                            b.appendLine();
                    }
                    else {
                        break;
                    }
                }
                if (this.containsOption(ClauseExpression.Else)) {
                    b.appendFormat('{0} {1}', ClauseExpression.Else, this.getOption(ClauseExpression.Else)?.buildString());
                    b.appendLine();
                }
                if (this.containsOption(ClauseExpression.End))
                    b.appendFormat('{0}', ClauseExpression.End);
                b.appendLine(')');
                break;
            }
            case BravoStringExtensions.compareStrings(this.zName, ClauseExpression.Join_Inner):
                {
                    b.appendFormat('{0}', this.zName);
                    if (this.containsOption(ClauseExpression.TableSource))
                        b.appendFormat(' {0}', this.getOption(ClauseExpression.TableSource)?.buildString());
                    if (this.containsOption(ClauseExpression.On)) {
                        b.appendLine();
                        b.appendFormat('{0} {1}', ClauseExpression.On, this.getOption(ClauseExpression.On)?.buildString());
                    }
                }
                break;
            default: {
                if (this.Expressions != null)
                    b.append(this.Expressions[0].buildString());
                break;
            }
        }
        return b.toString();
    }
    _buildFromClause(pSb) {
        pSb.appendFormat('{0}', this.zName);
        if (this.containsOption(ClauseExpression.TableSource))
            pSb.appendFormat(' {0}', this.getOption(ClauseExpression.TableSource)?.buildString());
        for (const clause of this.getJoinOptions()) {
            const tableSource = clause.getOption(ClauseExpression.TableSource)?.buildString();
            const on = clause.getOption(ClauseExpression.On)?.buildString();
            pSb.appendLine().appendFormat('{0} {1} on {2}', clause.zName, tableSource, on);
        }
    }
    _buildSelect(pSb) {
        pSb.appendFormat('({0}', this.zName);
        if (this.containsOption(ClauseExpression.All))
            pSb.appendFormat(' {0}', ClauseExpression.All);
        if (this.containsOption(ClauseExpression.Distinct))
            pSb.appendFormat(' {0}', ClauseExpression.Distinct);
        if (this.containsOption(ClauseExpression.Top))
            pSb.appendFormat(' {0} ({1})', ClauseExpression.Top, this.getOption(ClauseExpression.Top)?.buildString());
        if (this.containsOption(ClauseExpression.Percent))
            pSb.appendFormat(' {0}', ClauseExpression.Percent);
        if (this.containsOption(ClauseExpression.SelectList))
            pSb.appendFormat(' {0}', this.getOption(ClauseExpression.SelectList)?.buildString());
        if (this.containsOption(ClauseExpression.From))
            pSb.appendLine().appendFormat('{0}', this.getOption(ClauseExpression.From)?.buildString());
        if (this.containsOption(ClauseExpression.Where))
            pSb.appendLine().appendFormat('{0}', this.getOption(ClauseExpression.Where)?.buildString());
        if (this.containsOption(ClauseExpression.GroupBy))
            pSb.appendLine().appendFormat('{0}', this.getOption(ClauseExpression.GroupBy)?.buildString());
        if (this.containsOption(ClauseExpression.OrderBy))
            pSb.appendLine().appendFormat('{0}', this.getOption(ClauseExpression.OrderBy)?.buildString());
        pSb.append(')');
    }
    containsOption(pKey) {
        return this._options.findIndex(pOption => BravoStringExtensions.compareStrings(pOption.zName, pKey)) >= 0;
    }
    getOption(pKey) {
        return this._options.find(pOption => BravoStringExtensions.compareStrings(pOption.zName, pKey));
    }
    getOptions(pKey) {
        if (!pKey) {
            if (!this._options)
                return new Array();
            return this._options;
        }
        return this._options.filter(pOption => BravoStringExtensions.compareStrings(pOption.zName, pKey));
    }
    getJoinOptions() {
        return this._options.filter(pOption => ClauseExpression.isJoin(pOption.zName));
    }
    removeOptions(pKey) {
        const clauses = this.getOptions(pKey);
        for (const clause of clauses) {
            this._options.splice(this._options.indexOf(clause), 1);
        }
    }
}
class Stack {
    _stack;
    _count;
    constructor() {
        this._stack = {};
        this._count = 0;
    }
    get isEmpty() {
        return this.size === 0;
    }
    get size() {
        return this._count;
    }
    push(pValue) {
        this._stack[this._count] = pValue;
        this._count++;
    }
    pop() {
        this._count--;
        const value = this._stack[this._count];
        delete this._stack[this._count];
        return value;
    }
    peek() {
        return this._stack[this._count - 1];
    }
    clear() {
        this._stack = {};
        this._count = 0;
    }
    print() {
        if (this.isEmpty) {
            return '';
        }
        const values = [];
        for (let i = 0; i < this._count; i++) {
            values.unshift(BravoStringExtensions.format('{0}', this._stack[i]));
        }
        return values.join(' -> ');
    }
}
var TokenTypeEnum;
(function (TokenTypeEnum) {
    /// <summary>
    /// Token is white space
    /// </summary>
    TokenTypeEnum[TokenTypeEnum["WhiteSpace"] = 0] = "WhiteSpace";
    /// <summary>
    /// Token is word
    /// </summary>
    TokenTypeEnum[TokenTypeEnum["Word"] = 1] = "Word";
    /// <summary>
    /// Token is quote
    /// </summary>
    TokenTypeEnum[TokenTypeEnum["Quote"] = 2] = "Quote";
    /// <summary>
    /// Token is unicode quote
    /// </summary>
    TokenTypeEnum[TokenTypeEnum["UnicodeQuote"] = 3] = "UnicodeQuote";
    /// <summary>
    /// Token is operator, this not mean same as OperatorEnum
    /// </summary>
    TokenTypeEnum[TokenTypeEnum["Operator"] = 4] = "Operator";
    /// <summary>
    /// Token is function
    /// </summary>
    TokenTypeEnum[TokenTypeEnum["Function"] = 5] = "Function";
    /// <summary>
    /// Token is numeric
    /// </summary>
    TokenTypeEnum[TokenTypeEnum["Numeric"] = 6] = "Numeric";
    /// <summary>
    /// Token is name [Name]
    /// </summary>
    TokenTypeEnum[TokenTypeEnum["Name"] = 7] = "Name";
    /// <summary>
    /// Token is terminator (;)
    /// </summary>
    TokenTypeEnum[TokenTypeEnum["Terminator"] = 8] = "Terminator";
})(TokenTypeEnum || (TokenTypeEnum = {}));

class ColumnValueEventArgs extends BravoEventArgs {
    columnName;
    dataRow;
    value;
    constructor(pDataRow, pColumnName) {
        super();
        this.dataRow = pDataRow;
        this.columnName = pColumnName;
        this.value = pDataRow.table.columns.contains(pColumnName) ? pDataRow.getValue(pColumnName) : null;
    }
}

class ParameterValueEventArgs extends BravoEventArgs {
    name;
    value;
    constructor(pName) {
        super();
        this.name = pName;
    }
}

class PropertyValueEventArgs extends BravoEventArgs {
    propertyName;
    propertyOwner;
    value;
    constructor(pPropertyOwner, pzPropertyName) {
        super();
        this.propertyOwner = pPropertyOwner;
        this.propertyName = pzPropertyName;
        this.value = null;
    }
}

class ValueEventArgs extends BravoEventArgs {
    Operator;
    arguments;
    value;
    constructor(pOperator, pArguments) {
        super();
        this.Operator = pOperator;
        this.arguments = pArguments ?? [];
    }
}

class ExpressionUtil {
    static compareObject(pValue0, pValue1) {
        return isFinite(pValue0) && isFinite(pValue1)
            ? (pValue0 > pValue1) - (pValue0 < pValue1)
            : NaN;
    }
}

class BravoDebug {
    constructor() { }
    static _debugExpressionCollection;
    static isDebugExpression(pzExpression) {
        if (!this._debugExpressionCollection)
            return false;
        for (const str of this._debugExpressionCollection) {
            if (pzExpression.includes(str) || BravoStringExtensions.compareStrings(pzExpression, str))
                return true;
        }
        return false;
    }
    static startDebugExpression(pzExpression) {
        if (!this._debugExpressionCollection)
            this._debugExpressionCollection = new Array();
        if (!this._debugExpressionCollection.includes(pzExpression))
            this._debugExpressionCollection.push(pzExpression);
    }
    static stopDebugExpression(pzExpression) {
        if (this._debugExpressionCollection) {
            const index = this._debugExpressionCollection.indexOf(pzExpression);
            this._debugExpressionCollection.splice(index, 1);
        }
    }
}

//#region constants
const ExprPattern = /(?:{=)([^}]+)(?:})/g;
const RtfExprPattern = /(?:\\?{=)([^}]+)(?:})/g;
const ExprGroupPattern = `(?:{=)(?<expr>[^}]+)(?:})`;
const QuoteExprPattern = `(?:{=)(?<='{=)(?<quote_expr>[^}]+)(?:})`;
const TableSourceKey = 'Source';
const TableAliasKey = 'Alias';
const TableExpressionCollection = 'Expressions';
// Parent qualifier
const PARENT_QUALIFIER = 'PARENT';
// Child qualifier
const CHILD_QUALIFIER = 'CHILD';
// The null value
const NULL_VALUE = 'NULL';
// The variable prefix
const VARIABLE_PREFIX = '$';
const PARAMETER_PREFIX = '@';
const msecPerMinute = 1000 * 60;
const msecPerHour = msecPerMinute * 60;
const msecPerDay = msecPerHour * 24;
/**
 * The expression keywords. The keyword is ignore in evaluate.
 */
const Keywords = ['true', 'false'];
const EmptyDate = new Date(1900, 1, 1);
const INVALID_VALUE = '#VALUE';
//#endregion constants
class BravoExpressionEvaluator {
    //#region static members
    static _valueRequired$ = new Subject();
    /**
     * Static event occurs when a global system value is required
     */
    static get valueRequired$() {
        return BravoExpressionEvaluator._valueRequired$.asObservable();
    }
    static containsExpression(pzText) {
        const regex = new RegExp(ExprPattern);
        return regex.test(pzText);
    }
    static escapeRtfUnicode(pzText) {
        if (BravoStringExtensions.isNullOrEmpty(pzText))
            return BravoStringExtensions.empty;
        let sb = '';
        for (let i = 0; i < pzText.length; i++) {
            const code = pzText.charCodeAt(i);
            if (code > 127) {
                sb += `\\u`;
                sb += code;
                sb += '?';
            }
            else {
                sb += pzText.charAt(i);
            }
        }
        return sb;
    }
    /**
     * Print the expression diagram
     */
    static print(pExpression) {
        if (pExpression instanceof Array) {
            const sb = new BravoStringBuilder();
            for (const e of pExpression) {
                if (sb.length > 0) {
                    sb.append(';');
                    sb.appendLine();
                }
                sb.append(BravoExpressionEvaluator.print(e));
            }
            return sb.toString();
        }
        if (pExpression == Empty)
            return BravoStringExtensions.empty;
        if (pExpression.Operator == OperatorEnum.Value)
            return `${pExpression.Value}`;
        const sb = new BravoStringBuilder();
        for (const childExpression of pExpression.Expressions) {
            if (sb.length > 0)
                sb.append(',');
            sb.append(BravoExpressionEvaluator.print(childExpression));
        }
        return BravoStringExtensions.format('{0}({1})', OperatorEnum[pExpression.Operator], sb.toString());
    }
    static quoteExpression(pzExpression) {
        if (pzExpression && !pzExpression.includes('{='))
            return '{=' + pzExpression + '}';
        return pzExpression;
    }
    static unquoteExpression(pzExpression) {
        if (pzExpression && pzExpression.startsWith('{=') && pzExpression.endsWith('}'))
            return pzExpression.substring(2, pzExpression.length - 3);
        return pzExpression;
    }
    static useAliasName(pTable) {
        if (!pTable)
            throw new Error(BravoStringExtensions.format(Resources.ArgumentNullError, 'pTable'));
        return pTable.extendedProperties.has(TableAliasKey);
    }
    static getAliasName(pTable) {
        if (!pTable)
            throw new Error(BravoStringExtensions.format(Resources.ArgumentNullError, 'pTable'));
        if (pTable.extendedProperties.has(TableAliasKey))
            return BravoStringExtensions.asString(pTable.extendedProperties.get(TableAliasKey));
        return pTable.name;
    }
    /**
     * Return table name from alias if available
     */
    static getTableName(pzAlias, pDataSet) {
        if (!pzAlias)
            throw new Error(BravoStringExtensions.format(Resources.ArgumentNullError, 'pzAlias'));
        if (!pDataSet)
            throw new Error(BravoStringExtensions.format(Resources.ArgumentNullError, 'pDataSet'));
        for (const table of pDataSet.tables) {
            if (table &&
                ((table.extendedProperties.has(TableAliasKey) &&
                    BravoStringExtensions.compareStrings(table.extendedProperties.get(TableAliasKey), pzAlias, true)) ||
                    (table.extendedProperties.has(TableAliasKey) &&
                        BravoStringExtensions.compareStrings(table.extendedProperties.get(TableSourceKey), pzAlias, true))))
                return table.name;
        }
        return pzAlias;
    }
    static getSourceName(pTableOrAlias, pDataSet) {
        if (!pTableOrAlias && !pDataSet)
            return BravoStringExtensions.empty;
        if (typeof pTableOrAlias == 'string') {
            if (!pDataSet)
                return BravoStringExtensions.empty;
            for (const table of pDataSet.tables)
                if ((table.extendedProperties.has(TableAliasKey) &&
                    BravoStringExtensions.compareStrings(table.extendedProperties.get(TableAliasKey), pTableOrAlias, true)) ||
                    (table.extendedProperties.has(TableSourceKey) &&
                        BravoStringExtensions.compareStrings(table.extendedProperties.get(TableSourceKey), pTableOrAlias, true)))
                    return this.getSourceName(table);
            return pTableOrAlias;
        }
        if (!pTableOrAlias)
            throw new Error(BravoStringExtensions.format(Resources.ArgumentNullError, 'pTable'));
        if (pTableOrAlias.extendedProperties.has(TableSourceKey))
            return pTableOrAlias.extendedProperties.get(TableSourceKey);
        return pTableOrAlias.name;
    }
    static getDbColumnExpression(pColumn, pIncludeAlias = false) {
        if (pColumn == null)
            throw new BravoArgumentNullException('pColumn');
        if (pColumn.extendedProperties.has('Expression')) {
            const field = BravoStringExtensions.splitText(BravoStringExtensions.format('{0}', pColumn.extendedProperties.get('Expression')), '|', true);
            return pIncludeAlias ? field[field.length - 1] : field[0];
        }
        return pColumn.columnName;
    }
    /**
     * Return the value is expression keyword
     */
    static _isKeyword(pValue) {
        for (const kw of Keywords)
            if (BravoStringExtensions.compareStrings(kw, pValue, true))
                return true;
        return false;
    }
    /**
     * The generic version
     */
    static _convert(pValue, pType) {
        return BravoDataConvertUtil.convertValue(pValue, pType);
    }
    /**
     * Compare object
     */
    static compare(pLhs, pRhs) {
        const lhsnull = pLhs == null || pLhs == undefined;
        const rhsnull = pRhs == null || pRhs == undefined;
        if (lhsnull || rhsnull)
            return 0;
        const output = { lhsConvert: pLhs, rhsConvert: pRhs };
        const type = this._getPriorityType(pLhs, pRhs, output);
        if (type == TypeCodeEnum.String)
            return output.lhsConvert.localeCompare(output.rhsConvert);
        return ExpressionUtil.compareObject(output.lhsConvert, output.rhsConvert);
    }
    static _getPriorityType(pLhs, pRhs, pOutput) {
        let type = TypeCodeEnum.String;
        const lhsType = typeof pLhs;
        const rhsType = typeof pRhs;
        if (lhsType === rhsType) {
            if (pLhs instanceof Date)
                type = TypeCodeEnum.DateTime;
            else if (typeof pLhs == 'string')
                type = TypeCodeEnum.String;
            else if (typeof pLhs == 'number')
                type = TypeCodeEnum.Decimal;
            else if (typeof pLhs == 'boolean')
                type = TypeCodeEnum.Boolean;
            else
                type = TypeCodeEnum.Object;
            pOutput.lhsConvert = pLhs;
            pOutput.rhsConvert = pRhs;
        }
        else if (pLhs instanceof Date && typeof pRhs == 'string') {
            type = TypeCodeEnum.DateTime;
            pOutput.lhsConvert = pLhs;
            pOutput.rhsConvert = BravoStringExtensions.isNullOrEmpty(pRhs)
                ? EmptyDate
                : BravoDataConvertUtil.convertValue(pRhs, TypeCodeEnum.DateTime);
        }
        else if (typeof pLhs == 'string' && pRhs instanceof Date) {
            type = TypeCodeEnum.DateTime;
            pOutput.lhsConvert = BravoStringExtensions.isNullOrEmpty(pLhs)
                ? EmptyDate
                : BravoDataConvertUtil.convertValue(pRhs, TypeCodeEnum.DateTime);
            pOutput.rhsConvert = pRhs;
        }
        else {
            if (typeof pLhs == 'boolean' || typeof pRhs == 'boolean')
                type = TypeCodeEnum.Boolean;
            else if (typeof pLhs == 'number' || typeof pRhs == 'number')
                type = TypeCodeEnum.Decimal;
            pOutput.lhsConvert = BravoDataConvertUtil.convertValue(pLhs, type);
            pOutput.rhsConvert = BravoDataConvertUtil.convertValue(pRhs, type);
        }
        return type;
    }
    static _isTrueValue(pValue) {
        if (pValue == null || pValue == undefined)
            return false;
        return BravoDataConvertUtil.convertValue(pValue, TypeCodeEnum.Boolean) === true;
    }
    /**
     * Return result of like function
     * @param pPattern
     * @param pValue
     */
    static _like(pPattern, pValue, pEscape = '\0') {
        if (pValue == null || pPattern == null)
            return false;
        if (pPattern.length == 0)
            return BravoStringExtensions.isNullOrEmpty(pValue.trim());
        const tokens = this._getLikeToken(pPattern, pEscape);
        const paramOut = { pos: 0, lastMultipleCharacterTokenPosition: -1 };
        const rs = this.#like(tokens, pValue, paramOut);
        if (rs != null)
            return rs;
        if (paramOut.lastMultipleCharacterTokenPosition >= 0 && paramOut.pos < pValue.length) {
            const result = this.#like(tokens, pValue, paramOut);
            if (result != null)
                return result;
        }
        return paramOut.pos >= pValue.length;
    }
    static #like(pTokens, pValue, pParamOut) {
        let lastCharacterPositionAtMultipleCharacterTokenPosition = -1;
        for (let i = 0; i < pTokens.length; i++) {
            const token = pTokens[i];
            if (token.type == LikeTokenTypeEnum.MultipleCharacter) {
                // value was ended but token not yet, next token will know the result
                if (pParamOut.pos >= pValue.length)
                    continue;
                const nextPos = i + 1;
                if (nextPos >= pTokens.length)
                    return true;
                // check to next token match
                // if false return like false
                // if true process next token
                const next = pTokens[nextPos];
                let match = false;
                for (; pParamOut.pos < pValue.length; pParamOut.pos++) {
                    if (next.isMatch(pValue[pParamOut.pos])) {
                        match = true;
                        break;
                    }
                }
                if (!match)
                    return false;
                // mark the match potion with '%' token processing
                // ex: 'abc1123z' like '%123_', now pos is 3
                // next token will process with value is '1123z' and token is '123_', read below to continue
                pParamOut.lastMultipleCharacterTokenPosition = i;
                lastCharacterPositionAtMultipleCharacterTokenPosition = pParamOut.pos;
            }
            else {
                if (pParamOut.pos >= pValue.length)
                    return i >= pTokens.length;
                if (!token.isMatch(pValue[pParamOut.pos])) {
                    // we seek next one character, will process value is '123z' and token is '123_'
                    if (pParamOut.lastMultipleCharacterTokenPosition >= 0) {
                        i = pParamOut.lastMultipleCharacterTokenPosition;
                        pParamOut.pos = lastCharacterPositionAtMultipleCharacterTokenPosition;
                        // seek next one
                        lastCharacterPositionAtMultipleCharacterTokenPosition++;
                    }
                    else {
                        return false;
                    }
                }
                pParamOut.pos++;
            }
        }
        return false;
    }
    static _getLikeToken(pValue, pEscape = '\0') {
        const tokens = new Array();
        let pos = 0;
        for (; pos < pValue.length; pos++) {
            let c = pValue[pos];
            if (c == pEscape) {
                pos++;
                if (pos < pValue.length)
                    tokens.push(new LikeToken(LikeTokenTypeEnum.Character, pValue[pos]));
            }
            else if (c == '[') {
                pos++;
                const token = new BravoStringBuilder();
                let type = LikeTokenTypeEnum.PositiveCharacters;
                if (pValue[pos] == '^') {
                    type = LikeTokenTypeEnum.NegativeCharacters;
                    pos++;
                }
                while (pos < pValue.length) {
                    c = pValue[pos];
                    let next = pos + 1;
                    if (next < pValue.length && pValue[next] == '-') {
                        next++;
                        if (next < pValue.length && pValue[next] != ']') {
                            const n = pValue[next];
                            for (let ci = c; ci <= n; ci = String.fromCharCode(ci.charCodeAt(0) + 1))
                                token.append(ci);
                        }
                        pos = next + 1;
                    }
                    else if (c == ']') {
                        break;
                    }
                    else {
                        token.append(c);
                        pos++;
                    }
                }
                tokens.push(new LikeToken(type, token.toString()));
            }
            else if (c == '%') {
                if (tokens.length == 0 || tokens[tokens.length - 1].type != LikeTokenTypeEnum.MultipleCharacter)
                    tokens.push(new LikeToken(LikeTokenTypeEnum.MultipleCharacter, c));
            }
            else if (c == '_') {
                if (tokens.length == 0 || tokens[tokens.length - 1].type != LikeTokenTypeEnum.MultipleCharacter)
                    tokens.push(new LikeToken(LikeTokenTypeEnum.SingleCharacter, c));
            }
            else {
                tokens.push(new LikeToken(LikeTokenTypeEnum.Character, c));
            }
        }
        return tokens;
    }
    /**
     * Addition (+) operator
     * @param pLhs
     * @param pRhs
     */
    static addition(pLhs, pRhs) {
        if (pLhs == null || pLhs == undefined || pRhs == null || pRhs == undefined)
            return null;
        const args = { lhsConvert: 0, rhsConvert: 0 };
        const type = this._getPriorityType(pLhs, pRhs, args);
        if (BravoDataConvertUtil.isNumericType(type)) {
            const num = BravoNumberExtensions.asNumber(args.lhsConvert) + BravoNumberExtensions.asNumber(args.rhsConvert);
            return BravoNumberExtensions.round(num, 10);
        }
        if (type == TypeCodeEnum.String)
            return args.lhsConvert + args.rhsConvert;
        return null;
    }
    /**
     * Subtraction (-) operator
     * @param pLhs
     * @param pRhs
     */
    static subtraction(pLhs, pRhs) {
        if (pLhs == null || pLhs == undefined || pRhs == null || pRhs == undefined)
            return null;
        if (!BravoNumberExtensions.isNumber(pLhs) || !BravoNumberExtensions.isNumber(pRhs))
            throw new Error('Aggurent is not number');
        const num = BravoNumberExtensions.asNumber(pLhs) - BravoNumberExtensions.asNumber(pRhs);
        return BravoNumberExtensions.round(num, 10);
    }
    /**
     * Multiplication (*) operator
     * @param pLhs
     * @param pRhs
     */
    static multiplication(pLhs, pRhs) {
        if (pLhs == null || pLhs == undefined || pRhs == null || pLhs == undefined)
            return 0;
        if (!BravoNumberExtensions.isNumber(pLhs) || !BravoNumberExtensions.isNumber(pRhs))
            throw new Error('Aggurent is not number');
        return BravoNumberExtensions.asNumber(pLhs) * BravoNumberExtensions.asNumber(pRhs);
    }
    /**
     * Division (/) operator
     * @param pLhs
     * @param pRhs
     */
    static division(pLhs, pRhs) {
        if (pLhs == null || pLhs == undefined || pRhs == null || pLhs == undefined)
            return 0;
        if (!BravoNumberExtensions.isNumber(pLhs) || !BravoNumberExtensions.isNumber(pRhs))
            throw new Error('Aggurent is not number');
        return pRhs == 0 ? 0 : BravoNumberExtensions.asNumber(pLhs) / BravoNumberExtensions.asNumber(pRhs);
    }
    /**
     * Modulus (%) operator
     * @param pLhs
     * @param pRhs
     */
    static modulus(pLhs, pRhs) {
        if (pLhs == null || pLhs == undefined || pRhs == null || pLhs == undefined)
            return 0;
        if (!BravoNumberExtensions.isNumber(pLhs) || !BravoNumberExtensions.isNumber(pRhs))
            throw new Error('Aggurent is not number');
        return BravoNumberExtensions.asNumber(pLhs) % BravoNumberExtensions.asNumber(pRhs);
    }
    /**
     * Abs operator
     * @param pValue
     */
    static abs(pValue) {
        if (pValue == null || pValue == undefined)
            return pValue;
        if (!BravoNumberExtensions.isNumber(pValue))
            throw new Error('Aggurent is not number');
        return Math.abs(BravoNumberExtensions.asNumber(pValue));
    }
    static fix(pNum) {
        if (pNum > 0)
            return Math.floor(pNum);
        return -Math.floor(-pNum);
    }
    static datePart(pDatePart, pDate) {
        const date = BravoDataConvertUtil.convertValue(pDate, TypeCodeEnum.DateTime);
        switch (pDatePart) {
            case DatePartEnum.year:
            case DatePartEnum.yy:
            case DatePartEnum.yyyy:
                return BravoDateExtensions.year(date);
            case DatePartEnum.quarter:
            case DatePartEnum.qq:
            case DatePartEnum.q:
                return Math.ceil(BravoDateExtensions.month(date) / 3);
            case DatePartEnum.month:
            case DatePartEnum.mm:
            case DatePartEnum.m:
                return BravoDateExtensions.month(date);
            case DatePartEnum.dayofyear:
            case DatePartEnum.dy:
            case DatePartEnum.y:
                return BravoDateExtensions.dayOfYear(date);
            case DatePartEnum.day:
            case DatePartEnum.dd:
            case DatePartEnum.d:
                return BravoDateExtensions.day(date);
            case DatePartEnum.weekday:
            case DatePartEnum.dw:
                return date.getDay() + 1;
            case DatePartEnum.week:
            case DatePartEnum.wk:
            case DatePartEnum.ww:
                return 0;
            case DatePartEnum.hour:
            case DatePartEnum.hh:
                return date.getHours();
            case DatePartEnum.minute:
            case DatePartEnum.mi:
            case DatePartEnum.n:
                return date.getMinutes();
            case DatePartEnum.second:
            case DatePartEnum.ss:
            case DatePartEnum.s:
                return date.getSeconds();
            case DatePartEnum.millisecond:
            case DatePartEnum.ms:
                return date.getMilliseconds();
        }
        throw new Error(BravoStringExtensions.format('Not support datepart: ', pDatePart));
    }
    static _dateAdd(pDatePart, pNumber, pDate) {
        const toDate = (pDate) => (pDate instanceof Date ? pDate : new Date(pDate));
        let date = this._convertDate(pDate);
        date = new Date(toDate(pDate).getTime());
        switch (pDatePart) {
            case DatePartEnum.year:
            case DatePartEnum.yy:
            case DatePartEnum.yyyy: {
                date.setFullYear(date.getFullYear() + pNumber);
                break;
            }
            case DatePartEnum.quarter:
            case DatePartEnum.qq:
            case DatePartEnum.q: {
                date.setMonth(date.getMonth() + pNumber * 3);
                break;
            }
            case DatePartEnum.month:
            case DatePartEnum.mm:
            case DatePartEnum.m: {
                date.setMonth(date.getMonth() + pNumber);
                break;
            }
            case DatePartEnum.dayofyear:
            case DatePartEnum.dy:
            case DatePartEnum.d:
            case DatePartEnum.weekday:
            case DatePartEnum.dw:
            case DatePartEnum.day:
            case DatePartEnum.dd: {
                date.setDate(date.getDate() + pNumber);
                break;
            }
            case DatePartEnum.week:
            case DatePartEnum.wk:
            case DatePartEnum.ww: {
                date.setDate(date.getDate() + pNumber * 7);
                break;
            }
            case DatePartEnum.hour:
            case DatePartEnum.hh: {
                date.setHours(date.getHours() + pNumber);
                break;
            }
            case DatePartEnum.minute:
            case DatePartEnum.mi:
            case DatePartEnum.n: {
                date.setMinutes(date.getMinutes() + pNumber);
                break;
            }
            case DatePartEnum.second:
            case DatePartEnum.ss:
            case DatePartEnum.s: {
                date.setSeconds(date.getSeconds() + pNumber);
                break;
            }
            case DatePartEnum.millisecond:
            case DatePartEnum.ms: {
                date.setMilliseconds(date.getMilliseconds() + pNumber);
                break;
            }
        }
        if (date instanceof Date)
            return date;
        throw new Error(BravoStringExtensions.format(Resources.UnknownDatePart, pDatePart));
    }
    static _dateDiff(pDatePart, pStartDate, pEndDate) {
        let startDate = this._convertDate(pStartDate), endDate = this._convertDate(pEndDate);
        const toDate = (pDate) => (pDate instanceof Date ? pDate : new Date(pDate));
        startDate = toDate(pStartDate);
        endDate = toDate(pEndDate);
        switch (pDatePart) {
            case DatePartEnum.year:
            case DatePartEnum.yy:
            case DatePartEnum.yyyy: {
                return endDate.getUTCFullYear() - startDate.getUTCFullYear();
            }
            case DatePartEnum.quarter:
            case DatePartEnum.qq:
            case DatePartEnum.q: {
                const startQuarter = Math.floor(startDate.getUTCMonth() / 3);
                const endQuarter = Math.floor(endDate.getUTCMonth() / 3);
                return (endDate.getUTCFullYear() - startDate.getUTCFullYear()) * 4 + (endQuarter - startQuarter);
            }
            case DatePartEnum.month:
            case DatePartEnum.mm:
            case DatePartEnum.m: {
                return ((endDate.getUTCFullYear() - startDate.getUTCFullYear()) * 12 +
                    (endDate.getUTCMonth() - startDate.getUTCMonth()));
            }
            case DatePartEnum.dayofyear:
            case DatePartEnum.dy:
            case DatePartEnum.d:
            case DatePartEnum.weekday:
            case DatePartEnum.dw:
            case DatePartEnum.day:
            case DatePartEnum.dd: {
                return Math.floor((endDate.getTime() - startDate.getTime()) / msecPerDay);
            }
            case DatePartEnum.week:
            case DatePartEnum.wk:
            case DatePartEnum.ww: {
                return Math.floor((endDate.getTime() - startDate.getTime()) / (msecPerDay * 7));
            }
            case DatePartEnum.hour:
            case DatePartEnum.hh: {
                return Math.floor((endDate.getTime() - startDate.getTime()) / msecPerHour);
            }
            case DatePartEnum.minute:
            case DatePartEnum.mi:
            case DatePartEnum.n: {
                return Math.floor((endDate.getTime() - startDate.getTime()) / msecPerMinute);
            }
            case DatePartEnum.second:
            case DatePartEnum.ss:
            case DatePartEnum.s: {
                return Math.floor((endDate.getTime() - startDate.getTime()) / 1000);
            }
            case DatePartEnum.millisecond:
            case DatePartEnum.ms: {
                return endDate.getTime() - startDate.getTime();
            }
        }
        throw new Error(BravoStringExtensions.format(Resources.UnknownDatePart, pDatePart));
    }
    static _convertDate(pDate) {
        let date = null;
        try {
            date = BravoDateExtensions.asDate(pDate);
        }
        catch {
            /* empty */
        }
        try {
            if (!date)
                date = BravoDataConvertUtil.convertValue(pDate, TypeCodeEnum.DateTime);
        }
        catch {
            if (BravoStringExtensions.isString(pDate) && BravoStringExtensions.isNullOrEmpty(pDate))
                pDate = 0;
            date = BravoDateExtensions.minValue;
            date.setUTCFullYear(pDate);
        }
        return date;
    }
    static spellAmountUnit(pnNumber, pLanguage) {
        if (pLanguage == BravoLangEnum.Vietnamese)
            return this._spellNumberVi(pnNumber, 0, undefined, undefined, true);
        else if (pLanguage == BravoLangEnum.English)
            return this._numberToWords(pnNumber, true);
        else
            return BravoStringExtensions.format('***Not-supported-language: {0}***', BravoLangEnum[pLanguage]);
    }
    static spellNumber(pnNumber, pLanguage, pnDecimals = 0, pzBasicCurrencyUnit, pzFractionalCurrencyUnit) {
        if (pLanguage == BravoLangEnum.Vietnamese)
            return this._spellNumberVi(pnNumber, pnDecimals, pzBasicCurrencyUnit, pzFractionalCurrencyUnit);
        else if (pLanguage == BravoLangEnum.English)
            return this._spellNumberEn(pnNumber, pnDecimals, pzBasicCurrencyUnit, pzFractionalCurrencyUnit);
        else
            return BravoStringExtensions.format('***Not-supported-language: {0}***', BravoLangEnum[pLanguage]);
    }
    static _numberToWords(pNumber, pIsAmountUnit = false) {
        if (pNumber == 0)
            return 'Zero';
        if (pNumber < 0)
            return 'Minus ' + this._numberToWords(BravoExpressionEvaluator.abs(pNumber), pIsAmountUnit);
        const sb = new BravoStringBuilder();
        let n = Math.trunc(pNumber / 1000000000000000);
        if (n > 0) {
            sb.append(this._numberToWords(n, pIsAmountUnit));
            sb.append(' Quadrillion ');
            pNumber %= 1000000000000000;
        }
        n = Math.trunc(pNumber / 1000000000000);
        if (n > 0) {
            sb.append(this._numberToWords(n, pIsAmountUnit));
            sb.append(' Trillion ');
            pNumber %= 1000000000000;
        }
        n = Math.trunc(pNumber / 1000000000);
        if (n > 0) {
            sb.append(this._numberToWords(n, pIsAmountUnit));
            sb.append(' Billion ');
            pNumber %= 1000000000;
        }
        n = Math.trunc(pNumber / 1000000);
        if (n > 0) {
            sb.append(this._numberToWords(n, pIsAmountUnit));
            sb.append(' Million ');
            pNumber %= 1000000;
        }
        n = Math.trunc(pNumber / 1000);
        if (n > 0) {
            sb.append(this._numberToWords(n, pIsAmountUnit));
            sb.append(' Thousand ');
            pNumber %= 1000;
        }
        n = Math.trunc(pNumber / 100);
        if (n > 0) {
            sb.append(this._numberToWords(n, pIsAmountUnit));
            sb.append(' Hundred ');
            pNumber %= 100;
        }
        if (pNumber > 0) {
            const unitsMap = [
                'Zero',
                pIsAmountUnit ? '' : 'One',
                'Two',
                'Three',
                'Four',
                'Five',
                'Six',
                'Seven',
                'Eight',
                'Nine',
                'Ten',
                'Eleven',
                'Twelve',
                'Thirteen',
                'Fourteen',
                'Fifteen',
                'Sixteen',
                'Seventeen',
                'Eighteen',
                'Nineteen',
            ];
            const tensMap = [
                'Zero',
                'Ten',
                'Twenty',
                'Thirty',
                'Forty',
                'Fifty',
                'Sixty',
                'Seventy',
                'Eighty',
                'Ninety',
            ];
            if (pNumber < 20) {
                sb.append(unitsMap[pNumber]);
            }
            else {
                sb.append(tensMap[Math.floor(pNumber / 10)]);
                if (pNumber % 10 > 0) {
                    sb.append('-');
                    sb.append(unitsMap[Math.floor(pNumber % 10)]);
                }
            }
        }
        return sb.toString().replace(/\s+/gi, ' ');
    }
    static _spellNumberEn(pNumber, pDecimals = 0, pDong, pXu) {
        let decimalStr = BravoStringExtensions.empty;
        const strCollection = BravoStringExtensions.format('{0}', BravoExpressionEvaluator.abs(pNumber)).split('.');
        if (pDecimals > 0 && strCollection && strCollection.length > 1) {
            const decimalMap = [
                '',
                'Tenth',
                'Hundredth',
                'Thousandth',
                'Ten-Thousandth',
                'Hundred-Thousandth',
                'Millionth',
                'Ten-Millionth',
                'Hundred-Millionth',
                'Billionth',
                'Ten-Billionth',
                'Hundred-Billionth',
                'Trillionth',
                'Ten-Trillionth',
                'Hundred-Trillionth',
                'Quadrillionth',
                'Ten-Quadrillionth',
                'Hundred-Quadrillionth',
            ];
            if (pDong && pXu && pDecimals > 2)
                pDecimals = 2;
            let zd = strCollection[1].substring(0, Math.min(decimalMap.length, Math.min(strCollection[1].length, pDecimals)));
            const decLen = BravoStringExtensions.trimEndChar(zd, '0').length;
            if (pDong && pXu && zd.length < 2)
                zd = zd.padEnd(2, '0');
            const decimal = BravoNumberExtensions.asNumber(zd);
            if (decimal > 0) {
                if (decimal >= 2 && pXu) {
                    if (BravoStringExtensions.compareStrings(pXu, 'penny', true))
                        pXu = 'pence';
                    else if (BravoStringExtensions.compareStrings(pXu, 'cent', true))
                        pXu += 's';
                }
                decimalStr = this._numberToWords(decimal);
                if (decimalStr && !pXu) {
                    decimalStr += ' ' + decimalMap[decLen];
                    if (decimal > 1)
                        decimalStr += 's';
                }
            }
        }
        const integer = strCollection ? BravoNumberExtensions.asNumber(strCollection[0]) : 0;
        const sb = new BravoStringBuilder();
        sb.append(this._numberToWords(integer));
        if (pDong) {
            if (sb.get(sb.length - 1) != ' ')
                sb.append(' ');
            sb.append(pDong);
            if (integer >= 2) {
                if (BravoStringExtensions.compareStrings(pDong, 'dollar', true) ||
                    BravoStringExtensions.compareStrings(pDong, 'pound', true))
                    sb.append('s');
            }
            if (!decimalStr)
                sb.append(' only');
        }
        if (decimalStr) {
            if (sb.get(sb.length - 1) != ' ')
                sb.append(' ');
            sb.append(' and ');
            sb.append(decimalStr);
            if (pXu) {
                if (sb.get(sb.length - 1) != ' ')
                    sb.append(' ');
                sb.append(pXu);
            }
        }
        return sb.toString();
    }
    static _spellNumberVi(pNumber, pDecimals = 0, pDong, pXu, pAmountUnit = false) {
        let decimalStr = BravoStringExtensions.empty;
        const isNegative = Math.sign(pNumber) < 0;
        const strCollection = BravoStringExtensions.format('{0}', BravoExpressionEvaluator.abs(pNumber)).split('.');
        if (pDecimals > 0 && strCollection && strCollection.length > 1) {
            if (pDong && pXu && pDecimals > 2)
                pDecimals = 2;
            let zd = strCollection[1].substr(0, Math.min(strCollection[1].length, pDecimals));
            if (pDong && pXu && zd.length < 2)
                zd = zd.padEnd(2, '0');
            const decimal = BravoNumberExtensions.asNumber(zd);
            if (decimal > 0)
                decimalStr = this._spellNumberVi(decimal, 0);
        }
        const DON_VI = ['không', pAmountUnit ? '' : 'một', 'hai', 'ba', 'bốn', 'năm', 'sáu', 'bảy', 'tám', 'chín'];
        const HANG = ['', 'nghìn', 'triệu', 'tỷ'];
        const sb = new BravoStringBuilder();
        if (BravoNumberExtensions.asNumber(strCollection[0]) == 0) {
            sb.append(DON_VI[0]);
        }
        else {
            let i = strCollection[0].length;
            if (i == 0) {
                sb.insert(0, DON_VI[0]);
            }
            else {
                let j = 0;
                while (i > 0) {
                    const donvi = parseInt(strCollection[0].substr(i - 1, 1));
                    i--;
                    let chuc = -1;
                    if (i > 0)
                        chuc = parseInt(strCollection[0].substr(i - 1, 1));
                    i--;
                    let tram = -1;
                    if (i > 0)
                        tram = parseInt(strCollection[0].substr(i - 1, 1));
                    i--;
                    if (donvi > 0 || chuc > 0 || tram > 0 || j == 3)
                        sb.insert(0, HANG[j]);
                    j++;
                    if (j > 3)
                        j = 1; //Tránh lỗi, nếu dưới 13 số thì không có vấn đề.
                    //Hàm này chỉ dùng để đọc đến 9 số nên không phải bận tâm
                    if (donvi == 1 && chuc > 1) {
                        sb.insert(0, 'mốt ');
                    }
                    else {
                        if (donvi == 5 && chuc > 0)
                            sb.insert(0, 'lăm ');
                        else if (donvi > 0)
                            sb.insert(0, DON_VI[donvi] + ' ');
                    }
                    if (chuc < 0) {
                        break; //Hết số
                    }
                    else {
                        if (chuc == 0 && donvi > 0)
                            sb.insert(0, 'linh ');
                        if (chuc == 1)
                            sb.insert(0, 'mười ');
                        if (chuc > 1)
                            sb.insert(0, DON_VI[chuc] + ' mươi ');
                    }
                    if (tram < 0) {
                        break; //Hết số
                    }
                    else {
                        if (tram > 0 || chuc > 0 || donvi > 0)
                            sb.insert(0, DON_VI[tram] + ' trăm ');
                    }
                    sb.insert(0, ' ');
                }
            }
        }
        if (isNegative) {
            sb.insert(0, 'âm ');
        }
        const z = sb
            .toString()
            .trim()
            .replace(/\s+/gi, ' ')
            .replace('linh bốn', 'linh tư')
            .replace('mươi bốn', 'mươi tư');
        sb.clear();
        sb.append(z);
        if (pDong) {
            if (sb.get(sb.length - 1) != ' ')
                sb.append(' ');
            sb.append(pDong[0].toLowerCase());
            sb.append(pDong.substring(1));
            if (!decimalStr) {
                if (sb.get(sb.length - 1) != ' ')
                    sb.append(' ');
                sb.append('chẵn');
            }
        }
        if (decimalStr) {
            if (sb.get(sb.length - 1) != ' ')
                sb.append(' ');
            if (!pDong && !pXu)
                sb.append('phẩy ');
            sb.append(decimalStr.toLowerCase());
            if (pXu) {
                if (sb.get(sb.length - 1) != ' ')
                    sb.append(' ');
                sb.append(pXu[0].toLowerCase());
                sb.append(pXu.substring(1));
            }
        }
        if (sb.strings[0])
            sb.strings[0] = BravoStringExtensions.capitalizeFirstLetter(sb.strings[0]);
        return sb.toString();
    }
    /**
     * Get unevaluate argument expression
     * @param pExpression
     */
    static getArgumentExpressions(pExpression) {
        const list = new Array();
        if (pExpression.Operator == OperatorEnum.Arguments)
            this._loadArgumentExpression(pExpression, list);
        else if (pExpression != Empty)
            list.push(pExpression);
        return list;
    }
    /**
     * Get unevaluate argument expression
     * @param pExpression
     * @param pList
     */
    static _loadArgumentExpression(pExpression, pList) {
        if (pExpression.Operator != OperatorEnum.Arguments)
            throw new Error('expression');
        if (pExpression.Expressions[0].Operator != OperatorEnum.Arguments) {
            pList.push(pExpression.Expressions[0]);
        }
        else if (pExpression != Empty) {
            this._loadArgumentExpression(pExpression.Expressions[0], pList);
        }
        if (pExpression.Expressions[1].Operator != OperatorEnum.Arguments) {
            pList.push(pExpression.Expressions[1]);
        }
        else {
            this._loadArgumentExpression(pExpression.Expressions[1], pList);
        }
    }
    static _getMemberAccessExpressions(pExpression) {
        const list = new Array();
        if (pExpression.Operator == OperatorEnum.MemberAccess)
            this._loadMemberAccessExpression(pExpression, list);
        else if (pExpression != Empty)
            list.push(pExpression);
        return list;
    }
    static _loadMemberAccessExpression(pExpression, pList) {
        if (pExpression.Operator != OperatorEnum.MemberAccess)
            throw new Error('InvalidOperationException');
        if (pExpression.Expressions[0].Operator != OperatorEnum.MemberAccess)
            pList.push(pExpression.Expressions[0]);
        else if (pExpression != Empty)
            this._loadMemberAccessExpression(pExpression.Expressions[0], pList);
        pList.push(pExpression.Expressions[1]);
    }
    //#endregion static members
    _dataRowRequired$ = new Subject();
    get dataRowRequired$() {
        return this._dataRowRequired$.asObservable();
    }
    #onDataRowRequired(pEventArgs) {
        this._dataRowRequired$.next(pEventArgs);
    }
    _localValueRequired$ = new Subject();
    get localValueRequired$() {
        return this._localValueRequired$.asObservable();
    }
    _defaultValueRequired$ = new Subject();
    get defaultValueRequired$() {
        return this._defaultValueRequired$.asObservable();
    }
    _aggregateSourceRequired$ = new Subject();
    get aggregateSourceRequired$() {
        return this._aggregateSourceRequired$.asObservable();
    }
    #raiseOnAggregateSourceRequired(pzName) {
        if (!this._aggregateSourceRequired$.observed)
            return null;
        const e = new ParameterValueEventArgs(pzName);
        this._aggregateSourceRequired$.next(e);
        if (e.value == null)
            return null;
        return e.value;
    }
    _columnValueRequired$ = new Subject();
    get columnValueRequired$() {
        return this._columnValueRequired$.asObservable();
    }
    _propertyValueRequired$ = new Subject();
    get propertyValueRequired$() {
        return this._propertyValueRequired$.asObservable();
    }
    _evaluatingObject = {};
    _evaluatingDataRow;
    _aggregateCalculating = false;
    dispose() {
        if (this._variables) {
            this._variables.clear();
            this._variables = undefined;
        }
    }
    /**
     * Enable tracing values while evaluating expression.
     */
    bEnableTracing = false;
    _tracer;
    /**
     * Return tracing values while evaluating expression.
     */
    get tracer() {
        if (this._tracer == null)
            this._tracer = BravoStringExtensions.empty;
        return this._tracer;
    }
    _variables;
    /**
     * Declare variables.
     */
    get variables() {
        if (!this._variables)
            this._variables = new Map();
        return this._variables;
    }
    isTrue(pzExpression, pDataItem) {
        const evalValue = this.evaluate(pzExpression, pDataItem);
        return true === evalValue;
    }
    /**
     * Evaluate BrSafeAny expression in format {=expr} existing in an indicated string
     * @param pzText
     * @param pDataItem object || DataRow
     */
    evaluateText(pzText, pDataItem = null, pCulture = null) {
        return this._internalEvaluateText(pzText, pDataItem, pCulture, true, false);
    }
    /**
     * Evaluate BrSafeAny expression in format {=expr} existing in an indicated string
     * @param pzText
     * @param pDataItem object || DataRow
     */
    evaluateRtfText(pzText, pDataItem = null, pCulture = null) {
        return this._internalEvaluateText(pzText, pDataItem, pCulture, true, true);
    }
    zEvaluateTextErrorValue;
    defaultCulture = null;
    /**
     * Evaluate BrSafeAny expression in format {=expr} existing in an indicated string
     * @param pzText
     * @param pDataItem
     * @param pbClearTracing
     * @param pbRtfFormat
     */
    _internalEvaluateText(pzText, pDataItem, pCulture, pbClearTracing, pbRtfFormat = false) {
        if (pbClearTracing) {
            if (this.tracer.length > 0)
                this._tracer = BravoStringExtensions.empty;
        }
        if (!BravoStringExtensions.isString(pzText))
            pzText = BravoStringExtensions.format('{0}', pzText);
        if (!pzText)
            return BravoStringExtensions.empty;
        pzText = pzText.trim();
        if (!pzText.includes('{=') && !pzText.includes('}'))
            return pzText;
        let isDebug = false;
        if (pbClearTracing && BravoDebug.isDebugExpression(pzText)) {
            isDebug = true;
            if (!this.bEnableTracing)
                this.bEnableTracing = true;
        }
        try {
            const result = pzText.replace(pbRtfFormat ? RtfExprPattern : ExprPattern, (pMatch, pExpr) => {
                if (pbRtfFormat && pExpr[pExpr.length - 1] == '\\')
                    pExpr = pExpr.substring(0, pExpr.length - 1);
                const lastValue = this.zEvaluateTextErrorValue;
                const lastCulture = this.defaultCulture;
                this.defaultCulture = pCulture;
                try {
                    const exprs = BravoExpression.create(pExpr);
                    const returnValue = this._evaluateCollection(exprs, pDataItem);
                    if (returnValue == null || returnValue == undefined)
                        throw new BravoArgumentNullException(pExpr);
                    if (pbRtfFormat) {
                        if (pMatch && pMatch.startsWith('\\'))
                            return BravoExpressionEvaluator.escapeRtfUnicode(BravoStringExtensions.format('\\*{0}', returnValue));
                        else
                            return BravoExpressionEvaluator.escapeRtfUnicode(BravoStringExtensions.format('{0}', returnValue));
                    }
                    if (BravoMoment.isDate(returnValue))
                        return BravoMoment.format(returnValue, 'dd MMM yyyy hh:mm:ss aaa');
                    return `${returnValue}`;
                }
                catch (ex) {
                    if (lastValue != null)
                        return lastValue;
                    throw new BravoInvalidExpressionException(pExpr, ex);
                }
                finally {
                    this.zEvaluateTextErrorValue = lastValue;
                    this.defaultCulture = lastCulture;
                }
            });
            return result;
        }
        finally {
            if (this._variables)
                this._variables.clear();
            if (isDebug)
                console.log(BravoStringExtensions.format('<<<DEBUG EXPRESSION>>> {0}\n{1}', pzText, this.tracer));
        }
    }
    evaluate(pzExpression, pDataItem) {
        if (this.tracer.length > 0)
            this._tracer = BravoStringExtensions.empty;
        if (!pzExpression)
            return null;
        if (BravoStringExtensions.compareStrings(pzExpression, BravoBooleanExtensions.trueString, true))
            return true;
        else if (BravoStringExtensions.compareStrings(pzExpression, BravoBooleanExtensions.falseString, true))
            return false;
        let isDebug = false;
        if (BravoDebug.isDebugExpression(pzExpression)) {
            isDebug = true;
            if (!this.bEnableTracing)
                this.bEnableTracing = true;
        }
        try {
            pzExpression = this._internalEvaluateText(pzExpression, pDataItem, null, false);
            if (pzExpression.startsWith('{=') && pzExpression.endsWith('}'))
                pzExpression = pzExpression.substring(2, pzExpression.length - 3);
            if (BravoStringExtensions.compareStrings(pzExpression, BravoBooleanExtensions.trueString, true))
                return true;
            else if (BravoStringExtensions.compareStrings(pzExpression, BravoBooleanExtensions.falseString, true))
                return false;
            return this._evaluateCollection(BravoExpression.create(pzExpression), pDataItem);
        }
        catch (ex) {
            throw new BravoInvalidExpressionException(pzExpression, ex);
        }
        finally {
            if (isDebug)
                console.log(BravoStringExtensions.format('<<<DEBUG EXPRESSION>>> {0}\n{1}', pzExpression, this.tracer));
        }
    }
    _evaluateCollection(pExpressions, pDataItem = null) {
        const lastObject = this._evaluatingObject;
        const lastDataRow = this._evaluatingDataRow;
        this._evaluatingDataRow = tryCast(pDataItem, BravoDataInterfaceNamingConstants.IDataRow);
        if (!this._evaluatingDataRow) {
            const drv = tryCast(pDataItem, BravoDataInterfaceNamingConstants.IDataRowView);
            if (drv)
                this._evaluatingDataRow = drv.row;
        }
        if (!this._evaluatingDataRow && !pDataItem && this._dataRowRequired$ != null) {
            const eventArgs = new ParameterValueEventArgs(BravoStringExtensions.empty);
            this.#onDataRowRequired(eventArgs);
            this._evaluatingDataRow = eventArgs.value;
        }
        if (!this._evaluatingDataRow && pDataItem)
            this._evaluatingObject = pDataItem;
        else
            this._evaluatingObject = null;
        let returnValue = null;
        try {
            for (const expr of pExpressions) {
                returnValue = this.evaluateExpression(expr);
            }
            return returnValue;
        }
        finally {
            if (this._variables != null)
                this._variables.clear();
            this._evaluatingObject = lastObject;
            this._evaluatingDataRow = lastDataRow;
        }
    }
    /**
     * Evaluate the expression
     * @param pExpression
     */
    evaluateExpression(pExpression) {
        if (pExpression == Empty)
            return BravoStringExtensions.empty;
        if (pExpression.Operator == OperatorEnum.Unknown)
            return BravoStringExtensions.empty;
        // Aggregate expression
        if (BravoExpression.isAggregateFunction(pExpression.Operator)) {
            if (this._aggregateCalculating)
                throw new Error('Cannot recursive perform aggregate functions.');
            return this._evaluateAggregateExpression(pExpression);
        }
        switch (pExpression.Operator) {
            case OperatorEnum.Declare: {
                const variable = BravoStringExtensions.format('{0}', pExpression.Expressions[0].Value);
                const val = pExpression.Expressions[1];
                if (this.variables.has(variable))
                    throw new Error(BravoStringExtensions.format("The variable name '{0}' has been already declared.", variable));
                this.variables.set(variable, this.evaluateExpression(val));
                return this.variables.get(variable);
            }
            case OperatorEnum.Set: {
                const variable = BravoStringExtensions.format('{0}', pExpression.Expressions[0].Value);
                const val = pExpression.Expressions[1];
                if (!this.variables.has(variable))
                    throw new Error(BravoStringExtensions.format("Must declare the local variable '{0}'.", variable));
                this.variables.set(variable, val);
                return this.variables.get(variable);
            }
            case OperatorEnum.Value: {
                return this._evaluateValueExpression(pExpression);
            }
            case OperatorEnum.Vlookup: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (args.length < 2 || args.length > 3)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 2));
                if (!this._evaluatingDataRow) {
                    const valueArgs = new ValueEventArgs(pExpression.Operator, args);
                    this._defaultValueRequired$.next(valueArgs);
                    return valueArgs.value;
                }
                const options = { pzSourceDataName: '' };
                const obj = this._evaluateSourceDataExpression(args[0], options);
                const rows = BravoExpressionEvaluator._getAggregateSource(obj);
                for (const row of rows) {
                    if (args.length < 3)
                        return this._evaluateCollection([args[1]], row);
                    if (BravoExpressionEvaluator._isTrueValue(this._evaluateCollection([args[2]], row)))
                        return this._evaluateCollection([args[1]], row);
                }
                return null;
            }
            case OperatorEnum.Exists: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (args.length < 1 || args.length > 2)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 1));
                if (args.length == 1 &&
                    (BravoStringExtensions.compareStrings(`${args[0].Value}`, BravoBooleanExtensions.trueString, true) ||
                        BravoStringExtensions.compareStrings(`${args[0].Value}`, '1', true) ||
                        BravoStringExtensions.compareStrings(`${args[0].Value}`, BravoBooleanExtensions.falseString, true) ||
                        BravoStringExtensions.compareStrings(`${args[0].Value}`, '0', true))) {
                    return (BravoStringExtensions.compareStrings(`${args[0].Value}`, BravoBooleanExtensions.trueString, true) || BravoStringExtensions.compareStrings(`${args[0].Value}`, '1', true));
                }
                const options = { pzSourceDataName: '' };
                const obj = this._evaluateSourceDataExpression(args[0], options);
                const rows = BravoExpressionEvaluator._getAggregateSource(obj) || [];
                if (args.length < 2)
                    return rows.length > 0;
                for (const row of rows) {
                    if (BravoExpressionEvaluator._isTrueValue(this._evaluateCollection([args[1]], row)))
                        return true;
                }
                return false;
            }
            case OperatorEnum.MemberAccess: {
                const member = BravoExpressionEvaluator._convert(pExpression.Expressions[1].Value, TypeCodeEnum.String);
                const options = { pzSourceDataName: '' };
                const obj = this._evaluateSourceDataExpression(pExpression.Expressions[0], options);
                let row = tryCast(obj, BravoDataInterfaceNamingConstants.IDataRow);
                if (row == null && obj instanceof Array && obj.length > 0)
                    row = obj[0];
                if (row)
                    return this._evaluateDataRow(row, member);
                // if (_obj instanceof Object)
                //     return this.evaluateObject(_obj, _member);
                if (!obj)
                    throw new Error('Value cannot be null');
                break;
            }
            case OperatorEnum.Between: {
                const bwLhs = this.evaluateExpression(pExpression.Expressions[0]);
                const bwRhs = pExpression.Expressions[1];
                if (bwRhs.Operator != OperatorEnum.And)
                    throw new BravoInvalidExpressionException(BravoStringExtensions.format("{0} '{1}'.", Resources.SyntaxError, bwRhs.Value));
                const bwFrom = this.evaluateExpression(bwRhs.Expressions[0]);
                if (BravoExpressionEvaluator.compare(bwLhs, bwFrom) < 0)
                    return false;
                const bwTo = this.evaluateExpression(bwRhs.Expressions[1]);
                return BravoExpressionEvaluator.compare(bwLhs, bwTo) <= 0;
            }
            case OperatorEnum.Is: {
                const isLhs = this.evaluateExpression(pExpression.Expressions[0]);
                const isRhs = pExpression.Expressions[1];
                if (isRhs.Operator == OperatorEnum.Value) {
                    if (!BravoStringExtensions.compareStrings(isRhs.Value, 'null', true))
                        throw new BravoInvalidExpressionException(BravoStringExtensions.format("{0} '{1}'.", Resources.SyntaxError, isRhs.Value));
                    return isLhs == null || isLhs == undefined ? true : false;
                }
                else {
                    throw new BravoInvalidExpressionException(BravoStringExtensions.format("{0} '{1}'.", Resources.SyntaxError, isRhs.Value));
                }
            }
            case OperatorEnum.RowState: {
                return this._evaluatingDataRow ? DataRowStateEnum[this._evaluatingDataRow.rowState] : null;
            }
            case OperatorEnum.RowError:
            case OperatorEnum.RowOldValue: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if ((pExpression.Operator == OperatorEnum.RowOldValue && args.length != 1) ||
                    (pExpression.Operator == OperatorEnum.RowError && args.length > 1))
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 1));
                if (this._evaluatingDataRow == null)
                    return null;
                if (args.length == 0 && pExpression.Operator == OperatorEnum.RowError)
                    return this._evaluatingDataRow.hasErrors;
                const colName = BravoStringExtensions.format('{0}', this.evaluateExpression(args[0]));
                if (BravoStringExtensions.isNullOrEmpty(colName) ||
                    !this._evaluatingDataRow.table.columns.contains(colName))
                    throw new BravoNullReferenceException(BravoStringExtensions.format(Resources.ColumnDoesNotExist, colName, this._evaluatingDataRow.table.name));
                if (pExpression.Operator == OperatorEnum.RowError)
                    return !BravoStringExtensions.isNullOrEmpty(this._evaluatingDataRow.getColumnError(colName));
                if (this._evaluatingDataRow.hasVersion(DataRowVersionEnum.Original))
                    return this._evaluatingDataRow.getValue(colName, DataRowVersionEnum.Original);
                return null;
            }
            case OperatorEnum.TableChanged:
            case OperatorEnum.CurrentValue:
            case OperatorEnum.UpdatedColumn:
            case OperatorEnum.ColumnName:
            case OperatorEnum.TableName:
            case OperatorEnum.Text:
            case OperatorEnum.LastCommand:
            case OperatorEnum.LayoutName:
            case OperatorEnum.LayoutId:
            case OperatorEnum.FormCommandName:
            case OperatorEnum.FormUserName: {
                if (!this._localValueRequired$.observed)
                    throw new Error(BravoStringExtensions.format(Resources.InvalidOperationError, OperatorEnum[pExpression.Operator].toUpperCase()));
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                let maxArg = 0;
                if (pExpression.Operator == OperatorEnum.Text || pExpression.Operator == OperatorEnum.TableChanged)
                    maxArg = 1;
                else if (pExpression.Operator == OperatorEnum.CurrentValue)
                    maxArg = 2;
                else if (pExpression.Operator == OperatorEnum.FormCommandName)
                    maxArg = 1;
                if (args.length > maxArg)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), maxArg));
                const arr = new Array();
                for (const expr of args) {
                    arr.push(this.evaluateExpression(expr));
                }
                const e = new ValueEventArgs(pExpression.Operator, arr);
                this._localValueRequired$.next(e);
                return e.value;
            }
            case OperatorEnum.LayoutTableName: {
                if (this._evaluatingDataRow == null)
                    throw new BravoNullReferenceException();
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                return args != null && args.length > 0
                    ? BravoExpressionEvaluator.getSourceName(BravoStringExtensions.format('{0}', this.evaluateExpression(args[0])), this._evaluatingDataRow.table.dataSet)
                    : BravoExpressionEvaluator.getSourceName(this._evaluatingDataRow.table);
            }
            case OperatorEnum.Platform:
                return 'WEB';
            case OperatorEnum.NewId:
                return BravoStringExtensions.guid();
            case OperatorEnum.OsMachineName: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (args.length > 0)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 0));
                return BravoAppSettings.settings.browserIdentifier;
            }
            case OperatorEnum.OsDomainName: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (args.length > 0)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 0));
                return '<NOT SUPPORT>';
            }
            case OperatorEnum.OsUserName: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (args.length > 0)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 0));
                return '<NOT SUPPORT>';
            }
            case OperatorEnum.LangId: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (args && args.length > 1)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 1));
                if (args.length < 1)
                    return BravoAppSettings.settings.currentLangId;
                const langKey = BravoStringExtensions.format('{0}', this.evaluateExpression(args[0]));
                if (!BravoLangEnum[langKey])
                    throw new Error(BravoStringExtensions.format("Unknown language '{0}'.", langKey));
                const cultureCollection = BravoAppSettings.settings.getLangCollection();
                if (!cultureCollection)
                    return -1;
                return cultureCollection.indexOf(parseInt(langKey));
            }
            case OperatorEnum.LangName: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (args.length > 1)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 1));
                if (args.length < 1)
                    return BravoLangEnum.Vietnamese;
                const langCollection = BravoAppSettings.settings.getLangCollection();
                const langId = BravoNumberExtensions.asNumber(this.evaluateExpression(args[0]));
                if (langId < 0 || langId >= langCollection.length)
                    throw new Error(BravoStringExtensions.format(Resources.UnknownLanguage, langId));
                return langCollection[langId].toString();
            }
            case OperatorEnum.System:
            case OperatorEnum.Config:
            case OperatorEnum.Currency:
            case OperatorEnum.User:
            case OperatorEnum.Branch:
            case OperatorEnum.BranchFilter:
            case OperatorEnum.FiscalYear:
            case OperatorEnum.SignatureText:
            case OperatorEnum.SignatureImage:
            case OperatorEnum.SignatureData:
            case OperatorEnum.FormatCurrency:
            case OperatorEnum.FormatQuantity:
            case OperatorEnum.FormatDateRange:
            case OperatorEnum.ServerName:
            case OperatorEnum.DatabaseName:
            case OperatorEnum.VerifyChecksum:
            case OperatorEnum.IsFiscalDate:
            case OperatorEnum.IsSpecialDate:
            case OperatorEnum.StartDateOfYear:
            case OperatorEnum.SOYear:
            case OperatorEnum.EndDateOfYear:
            case OperatorEnum.EOYear:
            case OperatorEnum.StartDateOfQuarter:
            case OperatorEnum.SOQuarter:
            case OperatorEnum.EndDateOfQuarter:
            case OperatorEnum.EOQuarter:
            case OperatorEnum.NameByLang:
            case OperatorEnum.Portal:
            case OperatorEnum.Logo:
            case OperatorEnum.ResourceText:
            case OperatorEnum.DataFormat: {
                if (!BravoExpressionEvaluator._valueRequired$.observed)
                    throw new Error(BravoStringExtensions.format(Resources.InvalidOperationError, OperatorEnum[pExpression.Operator].toUpperCase()));
                let minArg = 1;
                switch (pExpression.Operator) {
                    case OperatorEnum.User:
                    case OperatorEnum.Branch:
                    case OperatorEnum.FiscalYear:
                    case OperatorEnum.ServerName:
                    case OperatorEnum.DatabaseName:
                    case OperatorEnum.FormatCurrency:
                    case OperatorEnum.FormatQuantity:
                    case OperatorEnum.Currency:
                    case OperatorEnum.Portal:
                    case OperatorEnum.Logo: {
                        minArg = 0;
                        break;
                    }
                    case OperatorEnum.FormatDateRange:
                    case OperatorEnum.SignatureData: {
                        minArg = 2;
                        break;
                    }
                }
                let maxArg = 1;
                switch (pExpression.Operator) {
                    case OperatorEnum.Logo:
                        maxArg = 0;
                        break;
                    case OperatorEnum.SignatureImage:
                    case OperatorEnum.SignatureText:
                    case OperatorEnum.FormatCurrency:
                    case OperatorEnum.Currency:
                    case OperatorEnum.ResourceText:
                        maxArg = 2;
                        break;
                    case OperatorEnum.SignatureData:
                        maxArg = 3;
                        break;
                    case OperatorEnum.FormatDateRange:
                        maxArg = 4;
                        break;
                    case OperatorEnum.DataFormat:
                        maxArg = Number.MAX_VALUE;
                        break;
                }
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (args.length < minArg || args.length > maxArg)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), minArg));
                const arr = new Array();
                for (const expr of args) {
                    arr.push(this.evaluateExpression(expr));
                }
                const e = new ValueEventArgs(pExpression.Operator, arr);
                if (this._localValueRequired$ && this._localValueRequired$.observed) {
                    this._localValueRequired$.next(e);
                    if (e.value != null)
                        return e.value;
                }
                BravoExpressionEvaluator._valueRequired$.next(e);
                return e.value;
            }
            case OperatorEnum.TokenRawData: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (args.length < 1 || args.length > 2)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 1));
                const property = args.length > 1 ? BravoStringExtensions.format('{0}', this.evaluateExpression(args[1])) : undefined;
                return BravoUsbTokenHelper.readRawData(BravoStringExtensions.format('{0}', this.evaluateExpression(args[0])), property);
            }
            case OperatorEnum.TokenSignData: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (args.length < 3 || args.length > 5)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 3));
                if (args.length == 3)
                    return BravoUsbTokenHelper.signData(BravoStringExtensions.format('{0}', this.evaluateExpression(args[0])), BravoStringExtensions.format('{0}', this.evaluateExpression(args[1])), BravoStringExtensions.format('{0}', this.evaluateExpression(args[2])));
                if (args.length == 4)
                    return BravoUsbTokenHelper.signData(BravoStringExtensions.format('{0}', this.evaluateExpression(args[0])), BravoStringExtensions.format('{0}', this.evaluateExpression(args[1])), BravoStringExtensions.format('{0}', this.evaluateExpression(args[2])), {
                        hashValueTagName: BravoStringExtensions.format('{0}', this.evaluateExpression(args[3])),
                    });
                if (args.length == 5)
                    return BravoUsbTokenHelper.signData(BravoStringExtensions.format('{0}', this.evaluateExpression(args[0])), BravoStringExtensions.format('{0}', this.evaluateExpression(args[1])), BravoStringExtensions.format('{0}', this.evaluateExpression(args[2])), {
                        hashValueTagName: BravoStringExtensions.format('{0}', this.evaluateExpression(args[3])),
                        signValueTagName: BravoStringExtensions.format('{0}', this.evaluateExpression(args[4])),
                    });
                break;
            }
            case OperatorEnum.TokenSignXml: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (args.length < 2 || args.length > 5)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 2));
                let isIncludeKeyInfo = false;
                let signatureId = '', referUri = '';
                if (args.length >= 3)
                    isIncludeKeyInfo = Object.is(true, this.evaluateExpression(args[2]));
                if (args.length >= 4)
                    signatureId = BravoStringExtensions.format('{0}', this.evaluateExpression(args[3]));
                if (args.length >= 5)
                    referUri = BravoStringExtensions.format('{0}', this.evaluateExpression(args[4]));
                return BravoUsbTokenHelper.signXml(BravoStringExtensions.format('{0}', this.evaluateExpression(args[0])), BravoStringExtensions.format('{0}', this.evaluateExpression(args[1])), {
                    isIncludeKeyInfo: isIncludeKeyInfo,
                    signatureId: signatureId,
                    referenceUri: referUri,
                });
            }
            case OperatorEnum.TokenVerifyXml: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (args.length != 2)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 2));
                const val = this.evaluateExpression(args[0]);
                let buff = val instanceof Uint8Array ? val : null;
                if (buff == null || buff.length < 1) {
                    try {
                        if (val != null &&
                            BravoStringExtensions.isString(val) &&
                            val.length > 0 &&
                            `${val}`.length % 4 == 0)
                            buff = BravoConverterExtensions.fromBase64String(val);
                        if (buff == null || buff.length < 1)
                            return false;
                    }
                    catch {
                        return false;
                    }
                }
                return BravoUsbTokenHelper.verifySignXml(buff, BravoStringExtensions.format('{0}', this.evaluateExpression(args[1])));
            }
            case OperatorEnum.TokenSignDocument: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (args.length < 2 || args.length > 8)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 2));
                let isVisible = true;
                let reason, contact, location, xOffset = BravoStringExtensions.empty, yOffset = BravoStringExtensions.empty;
                if (args.length >= 3)
                    reason = BravoStringExtensions.format('{0}', this.evaluateExpression(args[2]));
                if (args.length >= 4)
                    contact = BravoStringExtensions.format('{0}', this.evaluateExpression(args[3]));
                if (args.length >= 5)
                    location = BravoStringExtensions.format('{0}', this.evaluateExpression(args[4]));
                if (args.length >= 6)
                    xOffset = BravoStringExtensions.format('{0}', this.evaluateExpression(args[5]));
                if (args.length >= 7)
                    yOffset = BravoStringExtensions.format('{0}', this.evaluateExpression(args[6]));
                if (args.length == 8)
                    isVisible = BravoBooleanExtensions.asBoolean(BravoStringExtensions.format('{0}', this.evaluateExpression(args[7])));
                return BravoUsbTokenHelper.signDocument(BravoStringExtensions.format('{0}', this.evaluateExpression(args[0])), BravoStringExtensions.format('{0}', this.evaluateExpression(args[1])), {
                    reason: reason,
                    contact: contact,
                    location: location,
                    xOffset: xOffset,
                    yOffset: yOffset,
                    isShow: isVisible,
                });
            }
            case OperatorEnum.HashValue: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (args.length < 1 || args.length > 2)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 2));
                let prefix;
                if (args.length > 1)
                    prefix = BravoStringExtensions.format('{0}', this.evaluateExpression(args[1]));
                const input = this.evaluateExpression(args[0]);
                const buff = input instanceof Uint8Array ? input : null;
                if (buff)
                    return BravoCryptography.hashBytes(buff);
                return BravoCryptography.hashString(input, prefix);
            }
            case OperatorEnum.TokenSignString: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (args.length != 2)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 2));
                return BravoUsbTokenHelper.signDataString(BravoStringExtensions.format('{0}', this.evaluateExpression(args[0])), BravoStringExtensions.format('{0}', this.evaluateExpression(args[1])));
            }
            case OperatorEnum.TokenVerifyString: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (args.length != 3)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 3));
                const val = this.evaluateExpression(args[0]);
                if (val instanceof Uint8Array)
                    return BravoUsbTokenHelper.verifySignDataString(val, BravoStringExtensions.format('{0}', this.evaluateExpression(args[1])), BravoStringExtensions.format('{0}', this.evaluateExpression(args[2])));
                return BravoUsbTokenHelper.verifySignDataString(BravoStringExtensions.format('{0}', val), BravoStringExtensions.format('{0}', this.evaluateExpression(args[1])), BravoStringExtensions.format('{0}', this.evaluateExpression(args[2])));
            }
            case OperatorEnum.Encrypt:
            case OperatorEnum.Decrypt: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (args.length == 1 && BravoExpressionEvaluator._valueRequired$.observed) {
                    const eventArgs = new ValueEventArgs(pExpression.Operator, [this.evaluateExpression(args[0])]);
                    BravoExpressionEvaluator._valueRequired$.next(eventArgs);
                    if (eventArgs.value != null)
                        return eventArgs.value;
                }
                if (args.length != 2)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 2));
                const key = BravoStringExtensions.format('{0:G}', this.evaluateExpression(args[1]));
                if (BravoStringExtensions.isNullOrEmpty(key))
                    throw new Error('Password is required.');
                const input = this.evaluateExpression(args[0]);
                if (input instanceof Uint8Array) {
                    if (pExpression.Operator == OperatorEnum.Encrypt) {
                        const plainBytes = BravoCryptography.decryptBytes(input, key);
                        if (BravoDataConvertUtil.compareValue(input, plainBytes, TypeCodeEnum.ByteArray))
                            return BravoCryptography.encryptBytes(input, key);
                        return plainBytes;
                    }
                    else {
                        return BravoCryptography.decryptBytes(input, key);
                    }
                }
                else {
                    const str = BravoStringExtensions.format('{0}', input);
                    if (pExpression.Operator == OperatorEnum.Encrypt) {
                        const plainStr = BravoCryptography.decryptString(input, key);
                        if (BravoStringExtensions.compareStrings(plainStr, str))
                            return BravoCryptography.encryptString(str, key);
                        return plainStr;
                    }
                    else {
                        return BravoCryptography.decryptString(str, key);
                    }
                }
            }
            case OperatorEnum.DatePart: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (args == null || args.length != 2)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 2));
                const datePart = `${args[0].Value}`;
                const datePartEnum = DatePartEnum[datePart];
                if (datePartEnum == null || datePartEnum == undefined)
                    throw new Error(BravoStringExtensions.format(Resources.UnknownDatePart, datePart));
                if (BravoExpressionEvaluator._valueRequired$.observed &&
                    (datePartEnum == DatePartEnum.q ||
                        datePartEnum == DatePartEnum.qq ||
                        datePartEnum == DatePartEnum.quarter)) {
                    const date = (BravoDataConvertUtil.convertValue(this.evaluateExpression(args[1]), TypeCodeEnum.DateTime));
                    const e = new ValueEventArgs(OperatorEnum.Quarter, [date]);
                    BravoExpressionEvaluator._valueRequired$.next(e);
                    if (e.value)
                        return e.value;
                }
                return BravoExpressionEvaluator.datePart(datePartEnum, this.evaluateExpression(args[1]));
            }
            case OperatorEnum.StartDateOfMonth:
            case OperatorEnum.SOMonth:
            case OperatorEnum.EndDateOfMonth:
            case OperatorEnum.EOMonth: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (!args || args.length != 1)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 3));
                const val = this.evaluateExpression(args[0]);
                const outArgs = { datetime: null };
                let month = 0, year = 0;
                if (BravoDataConvertUtil.isDateTimeValue(`${val}`, outArgs) && outArgs.datetime) {
                    month = BravoDateExtensions.month(outArgs.datetime);
                    year = BravoDateExtensions.year(outArgs.datetime);
                }
                else {
                    month =
                        BravoExpressionEvaluator._convert(this.evaluateExpression(args[0]), TypeCodeEnum.Int32) ?? 0;
                    year = BravoDateExtensions.year(this._getCurrentDateTime(OperatorEnum.GetDate));
                }
                if (pExpression.Operator == OperatorEnum.EndDateOfMonth ||
                    pExpression.Operator == OperatorEnum.EOMonth) {
                    if (month == 12) {
                        month = 1;
                        year += 1;
                    }
                    else {
                        month++;
                    }
                }
                const date = new Date(Date.UTC(year, month - 1, 1));
                if (pExpression.Operator == OperatorEnum.EndDateOfMonth || pExpression.Operator == OperatorEnum.EOMonth)
                    date.setDate(date.getDate() - 1);
                return BravoDateExtensions.date(date);
            }
            case OperatorEnum.DateAdd: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (!args || args.length != 3)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 3));
                const datePart = BravoStringExtensions.asString(args[0].Value);
                const dp = DatePartEnum[datePart];
                if (dp == null || dp == undefined)
                    throw new Error(BravoStringExtensions.format(Resources.UnknownDatePart, datePart));
                return BravoExpressionEvaluator._dateAdd(dp, BravoExpressionEvaluator._convert(this.evaluateExpression(args[1]), TypeCodeEnum.Int32) ??
                    0, this.evaluateExpression(args[2]));
            }
            case OperatorEnum.DateDiff: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (!args || args.length != 3)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 3));
                const datePart = BravoStringExtensions.asString(args[0].Value);
                const dp = DatePartEnum[datePart];
                if (dp == null || dp == undefined)
                    throw new Error(BravoStringExtensions.format(Resources.UnknownDatePart, datePart));
                return BravoExpressionEvaluator._dateDiff(dp, this.evaluateExpression(args[1]), this.evaluateExpression(args[2]));
            }
            case OperatorEnum.Format: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (args == null || args.length < 1 || args.length > 3)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 3));
                let format = BravoStringExtensions.empty;
                if (args.length >= 2)
                    format = this.getFormat(BravoStringExtensions.format('{0}', this.evaluateExpression(args[1])));
                const val = this.evaluateExpression(args[0]);
                if (BravoStringExtensions.isNullOrEmpty(format)) {
                    if (BravoDateExtensions.isDate(val)) {
                        format = BravoStringExtensions.format('{0}', this.evaluate("CONFIG('M_DefaultDateFormat')"));
                        if (!format)
                            format = 'd';
                    }
                    else if (BravoNumberExtensions.isNumber(val)) {
                        format = BravoStringExtensions.format('{0}', this.evaluate("CONFIG('M_DefaultNumberFormat')"));
                        if (!format)
                            format = 'G';
                    }
                }
                if (BravoStringExtensions.isString(val))
                    return val;
                if (BravoDateExtensions.isDate(val))
                    return BravoMoment.format(val, format);
                if (BravoNumberExtensions.isNumber(val)) {
                    // TODO wait support config global number
                    return BravoNumberExtensions.format(val, format); //this.defaultCulture);
                }
                return val ? val.toString() : BravoStringExtensions.empty;
            }
            case OperatorEnum.Iif: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (!args || args.length != 3)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 3));
                const val0 = this.evaluateExpression(args[0]);
                if (BravoExpressionEvaluator._isTrueValue(val0))
                    return this.evaluateExpression(args[1]);
                return this.evaluateExpression(args[2]);
            }
            case OperatorEnum.Case: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (!args || args.length < 3)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 3));
                let caseClause = 0;
                const val0 = this.evaluateExpression(args[0]);
                if (val0 != null && val0 != undefined)
                    caseClause = BravoExpressionEvaluator._convert(val0, TypeCodeEnum.Int32);
                caseClause += 1;
                if (caseClause < 1 || caseClause >= args.length)
                    throw new Error('ArgumentOutOfRangeException: ' + OperatorEnum[pExpression.Operator]);
                return this.evaluateExpression(args[caseClause]);
            }
            case OperatorEnum.IsNull: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (!args || args.length != 2)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 2));
                const val = this.evaluateExpression(args[0]);
                if (val != null && val != undefined)
                    return val;
                return this.evaluateExpression(args[1]);
            }
            case OperatorEnum.Coalesce: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (!args || args.length < 2)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 2));
                for (const arg of args) {
                    const value = this.evaluateExpression(arg);
                    if (value == null || value == undefined)
                        continue;
                    if (BravoNumberExtensions.isNumber(value) && value == 0)
                        continue;
                    if (BravoDateExtensions.isDate(value) && BravoDateExtensions.isEqual(value, EmptyDate))
                        continue;
                    if (BravoStringExtensions.isString(value) && !BravoStringExtensions.asString(value))
                        continue;
                    return value;
                }
                return null;
            }
            case OperatorEnum.IsInteger: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (!args || args.length != 1)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 1));
                const val = this.evaluateExpression(args[0]);
                return val != null && val != undefined && Number.isInteger(Number(val));
            }
            case OperatorEnum.IsNumeric: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (!args || args.length != 1)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 1));
                const val = this.evaluateExpression(args[0]);
                return val != null && val != undefined && BravoNumberExtensions.isNumber(val);
            }
            case OperatorEnum.IsDatetime: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (!args || args.length != 1)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 1));
                const val = this.evaluateExpression(args[0]);
                return BravoDateExtensions.isDate(val);
            }
            case OperatorEnum.GenerateToken:
            case OperatorEnum.VerifyToken: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                const argsNum = pExpression.Operator == OperatorEnum.GenerateToken ? 0 : 1;
                if (args.length != argsNum)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), argsNum));
                if (pExpression.Operator == OperatorEnum.GenerateToken) {
                    let serverDate = BravoDateExtensions.minValue;
                    if (BravoExpressionEvaluator._valueRequired$.observed) {
                        const e = new ValueEventArgs(OperatorEnum.GetUtcDatetime);
                        BravoExpressionEvaluator._valueRequired$.next(e);
                        serverDate = BravoDataConvertUtil.convertValue(e.value, TypeCodeEnum.DateTime);
                    }
                    if (BravoDateExtensions.isEqual(serverDate, BravoDateExtensions.minValue))
                        throw new Error('Could not obtain server date time.');
                    return 'abcdefgdsdsfds';
                }
                return false;
            }
            case OperatorEnum.RemoveAccent: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (args.length != 1)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 1));
                return BravoStringExtensions.removeAccent(BravoStringExtensions.format('{0}', this.evaluateExpression(args[0])));
            }
            case OperatorEnum.SpellNumber: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (args.length < 1 || args.length > 4)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 4));
                let val = this.evaluateExpression(args[0]);
                if (BravoStringExtensions.isNullOrEmpty(BravoStringExtensions.format('{0}', val).trim()))
                    return BravoStringExtensions.empty;
                const num = BravoNumberExtensions.asNumber(val);
                let decimals = 0;
                if (args.length > 3) {
                    val = this.evaluateExpression(args[3]);
                    if (val != null)
                        decimals = BravoNumberExtensions.asNumber(val);
                }
                let lang = BravoAppSettings.settings.currentLang;
                if (args.length > 2) {
                    const strLang = BravoStringExtensions.format('{0}', this.evaluateExpression(args[2]));
                    const outLang = { resultValue: BravoLangEnum.Vietnamese };
                    if (!BravoEnumExtensions.isEnumType(BravoLangEnum, strLang, outLang))
                        throw new Error(BravoStringExtensions.format(Resources.UnknownLanguage, strLang));
                    lang = outLang.resultValue;
                }
                if (args.length > 1) {
                    const currency = BravoStringExtensions.format('{0}', this.evaluateExpression(args[1]));
                    if (currency) {
                        if (!BravoExpressionEvaluator._valueRequired$.observed)
                            throw new Error('InvalidOperationException' + OperatorEnum[pExpression.Operator]);
                        const argument = new Array();
                        argument.push(num, currency, lang);
                        if (args.length > 3)
                            argument.push(decimals);
                        const e = new ValueEventArgs(pExpression.Operator, argument);
                        BravoExpressionEvaluator._valueRequired$.next(e);
                        if (e.value == null)
                            return '';
                        return e.value;
                    }
                }
                return BravoExpressionEvaluator.spellNumber(num, lang, decimals);
            }
            case OperatorEnum.Inlist: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (args.length < 2 || args.length > 3)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 3));
                const searchedVal = this.evaluateExpression(args[0]);
                if (searchedVal == null)
                    return false;
                let sep = ',';
                if (args.length > 2) {
                    sep = BravoExpressionEvaluator._convert(this.evaluateExpression(args[2]), TypeCodeEnum.String);
                    if (BravoStringExtensions.isNullOrEmpty(sep))
                        sep = ',';
                }
                const searchedText = BravoStringExtensions.format('{0:G}', BravoExpressionEvaluator._convert(searchedVal, TypeCodeEnum.String)).trim();
                const strArr = BravoStringExtensions.splitText(BravoStringExtensions.format('{0:G}', BravoExpressionEvaluator._convert(this.evaluateExpression(args[1]), TypeCodeEnum.String)), sep, true);
                for (const s of strArr) {
                    if (BravoStringExtensions.compareStrings(searchedText, s.trim(), true)) {
                        return true;
                    }
                }
                return false;
            }
            case OperatorEnum.RegexMatch: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (args.length != 2)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 2));
                const text = BravoStringExtensions.asString(this.evaluateExpression(args[0]));
                if (!text)
                    return text;
                const regex = new RegExp(this.evaluateExpression(args[1]));
                return regex.test(BravoStringExtensions.asString(args[0]));
            }
            case OperatorEnum.RegexReplace: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (args.length != 3)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 3));
                const text = BravoStringExtensions.asString(this.evaluateExpression(args[0]));
                if (!text)
                    return text;
                return text.replace(new RegExp(this.evaluateExpression(args[1])), BravoStringExtensions.asString(this.evaluateExpression(args[2])));
            }
            case OperatorEnum.RegexExtract: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (args.length != 2)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 2));
                const text = BravoStringExtensions.asString(this.evaluateExpression(args[0]));
                if (!text)
                    return text;
                return text.match(new RegExp(this.evaluateExpression(args[1])))?.values.toString();
            }
            case OperatorEnum.GetDate:
            case OperatorEnum.GetUtcDate:
            case OperatorEnum.GetDatetime:
            case OperatorEnum.GetUtcDatetime: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (args.length == 0)
                    return this._getCurrentDateTime(pExpression.Operator);
                if (args.length > 1)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 1));
                const val = this.evaluateExpression(args[0]);
                if (val == null)
                    return val;
                let dateParam = BravoDateExtensions.asDate(val);
                dateParam =
                    pExpression.Operator == OperatorEnum.GetDate || pExpression.Operator == OperatorEnum.GetDatetime
                        ? dateParam
                        : BravoDateExtensions.toUniversalTime(dateParam);
                return pExpression.Operator == OperatorEnum.GetDate || pExpression.Operator == OperatorEnum.GetUtcDate
                    ? BravoDateExtensions.date(dateParam)
                    : dateParam;
            }
            case OperatorEnum.MaxOf:
            case OperatorEnum.MinOf: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (args.length < 2)
                    throw new BravoArgumentNullException(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 2));
                let retValue;
                for (const arg of args) {
                    const val = this.evaluateExpression(arg);
                    if (val == null) {
                        if (pExpression.Operator == OperatorEnum.MinOf)
                            return val;
                        continue;
                    }
                    if (retValue == null) {
                        retValue = val;
                        continue;
                    }
                    const compareVal = BravoExpressionEvaluator.compare(val, retValue);
                    if (pExpression.Operator == OperatorEnum.MinOf) {
                        if (compareVal < 0)
                            retValue = val;
                    }
                    else {
                        if (compareVal > 0)
                            retValue = val;
                    }
                }
                return retValue;
            }
            case OperatorEnum.Eval: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (args.length != 1)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 1));
                const expr = BravoStringExtensions.format('{0}', this.evaluateExpression(args[0]));
                if (BravoStringExtensions.isNullOrEmpty(expr))
                    return expr;
                return this._evaluateCollection(BravoExpression.create(expr), this._evaluatingDataRow);
            }
            case OperatorEnum.Empty: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (args.length != 1)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 1));
                const val = this.evaluateExpression(args[0]);
                if (val == null)
                    return true;
                if (typeof val == 'number')
                    return BravoDataConvertUtil.compareValue(0, BravoExpressionEvaluator._convert(val, TypeCodeEnum.Decimal), TypeCodeEnum.Decimal);
                if (BravoDateExtensions.isDate(val))
                    return BravoDateExtensions.isEqual(BravoExpressionEvaluator._convert(val, TypeCodeEnum.DateTime), EmptyDate);
                if (BravoStringExtensions.isString(val))
                    return BravoStringExtensions.isNullOrEmpty(BravoExpressionEvaluator._convert(val, TypeCodeEnum.String));
                if (BravoBooleanExtensions.isBoolean(val))
                    return false === BravoExpressionEvaluator._convert(val, TypeCodeEnum.Boolean);
                return false;
            }
            case OperatorEnum.Sqr:
            case OperatorEnum.Abs:
            case OperatorEnum.Sin:
            case OperatorEnum.Cos:
            case OperatorEnum.Ceiling:
            case OperatorEnum.Floor: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (args.length != 1)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 1));
                const val = this.evaluateExpression(args[0]);
                if (val == null)
                    return val;
                if (pExpression.Operator == OperatorEnum.Sqr)
                    return Math.sqrt(BravoExpressionEvaluator._convert(val, TypeCodeEnum.Double));
                else if (pExpression.Operator == OperatorEnum.Abs)
                    return BravoExpressionEvaluator.abs(val);
                else if (pExpression.Operator == OperatorEnum.Sin)
                    return Math.sin(BravoExpressionEvaluator._convert(val, TypeCodeEnum.Double));
                else if (pExpression.Operator == OperatorEnum.Cos)
                    return Math.cos(BravoExpressionEvaluator._convert(val, TypeCodeEnum.Double));
                else if (pExpression.Operator == OperatorEnum.Ceiling)
                    return Math.ceil(BravoExpressionEvaluator._convert(val, TypeCodeEnum.Double));
                else
                    return Math.floor(BravoExpressionEvaluator._convert(val, TypeCodeEnum.Double));
            }
            case OperatorEnum.Round:
            case OperatorEnum.RoundUp:
            case OperatorEnum.RoundDown:
            case OperatorEnum.Pow: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (args.length != 2)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 2));
                const val1 = this.evaluateExpression(args[0]);
                if (val1 == null)
                    return val1;
                const val2 = this.evaluateExpression(args[1]);
                if (val2 == null)
                    return val2;
                if (pExpression.Operator == OperatorEnum.Pow)
                    return Math.pow(BravoExpressionEvaluator._convert(val1, TypeCodeEnum.Double), BravoExpressionEvaluator._convert(val2, TypeCodeEnum.Double));
                const decimals = BravoExpressionEvaluator._convert(val2, TypeCodeEnum.Double);
                if (pExpression.Operator == OperatorEnum.RoundUp)
                    return Math.ceil((BravoNumberExtensions.asNumber(val1) *
                        Math.pow(10, BravoNumberExtensions.asNumber(decimals))) /
                        Math.pow(10, BravoNumberExtensions.asNumber(decimals)));
                else if (pExpression.Operator == OperatorEnum.RoundDown)
                    return Math.floor((BravoNumberExtensions.asNumber(val1) *
                        Math.pow(10, BravoNumberExtensions.asNumber(decimals))) /
                        Math.pow(10, BravoNumberExtensions.asNumber(decimals)));
                // if(expression.Operator == OperatorEnum.Round)
                else
                    return BravoNumberExtensions.round(BravoNumberExtensions.asNumber(val1), BravoNumberExtensions.asNumber(decimals));
            }
            case OperatorEnum.Convert: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (args.length < 1 || args.length > 2)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 2));
                const val1 = this.evaluateExpression(args[0]);
                if (val1 == null)
                    return val1;
                let typeCode = BravoExpressionEvaluator._convert(this.evaluateExpression(args[1]), TypeCodeEnum.String);
                if (typeCode.startsWith('System.'))
                    typeCode = typeCode.substring('System.'.length);
                const typeCodeEnum = TypeCodeEnum[typeCode];
                if (val1 instanceof Uint8Array && typeCodeEnum == TypeCodeEnum.String)
                    return BravoConverterExtensions.toBase64String(val1);
                if (BravoStringExtensions.isString(val1) && typeCodeEnum == TypeCodeEnum.ByteArray)
                    return BravoConverterExtensions.fromBase64String(val1);
                return BravoDataConvertUtil.convertValue(val1, typeCodeEnum);
            }
            case OperatorEnum.Left:
            case OperatorEnum.Right: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (!args || args.length != 2)
                    throw new BravoArgumentNullException(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 2));
                const val1 = this.evaluateExpression(args[0]);
                if (val1 == null)
                    return val1;
                const val2 = this.evaluateExpression(args[1]);
                if (val2 == null)
                    return val2;
                const str = BravoExpressionEvaluator._convert(val1, TypeCodeEnum.String), p = Math.min(str.length, BravoExpressionEvaluator._convert(val2, TypeCodeEnum.Int32));
                if (pExpression.Operator == OperatorEnum.Left)
                    return str.substring(0, p);
                return str.substring(str.length - p, str.length);
            }
            case OperatorEnum.PadL:
            case OperatorEnum.PadLeft:
            case OperatorEnum.PadR:
            case OperatorEnum.PadRight:
            case OperatorEnum.SubStr:
            case OperatorEnum.SubString: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (args.length < 2 || args.length > 3)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 3));
                const val1 = this.evaluateExpression(args[0]);
                if (val1 == null)
                    return val1;
                const val2 = this.evaluateExpression(args[1]);
                if (val2 == null)
                    return val2;
                const str = BravoStringExtensions.asString(val1);
                const len = BravoNumberExtensions.asNumber(val2);
                const start = len;
                if (args.length > 2) {
                    if (pExpression.Operator == OperatorEnum.SubStr || pExpression.Operator == OperatorEnum.SubString) {
                        if (start < 0 || start >= str.length)
                            return BravoStringExtensions.empty;
                        const subLen = BravoExpressionEvaluator._convert(this.evaluateExpression(args[2]), TypeCodeEnum.Int32);
                        if (subLen == null || subLen < 1)
                            return BravoStringExtensions.empty;
                        if (start + subLen <= str.length)
                            return str.substr(start, subLen);
                    }
                    else {
                        const pc = BravoStringExtensions.format('{0}', this.evaluateExpression(args[2]));
                        if (!BravoStringExtensions.isNullOrEmpty(pc) && pc.length > 0)
                            return pExpression.Operator == OperatorEnum.PadL ||
                                pExpression.Operator == OperatorEnum.PadLeft
                                ? str.padStart(len, pc[0])
                                : str.padEnd(len, pc[0]);
                    }
                }
                if (pExpression.Operator == OperatorEnum.SubStr || pExpression.Operator == OperatorEnum.SubString)
                    return str.substring(start);
                return pExpression.Operator == OperatorEnum.PadL || pExpression.Operator == OperatorEnum.PadLeft
                    ? str.padStart(len)
                    : str.padEnd(len);
            }
            case OperatorEnum.CharIndex: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (args.length < 2 || args.length > 3)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 3));
                const val1 = this.evaluateExpression(args[0]);
                if (val1 == null)
                    return val1;
                const val2 = this.evaluateExpression(args[1]);
                if (val2 == null)
                    return val2;
                if (args.length > 2) {
                    const val3 = this.evaluateExpression(args[2]);
                    if (val3 == null)
                        return val3;
                    return BravoExpressionEvaluator._convert(val2, TypeCodeEnum.String).indexOf(BravoExpressionEvaluator._convert(val1, TypeCodeEnum.String), BravoExpressionEvaluator._convert(val3, TypeCodeEnum.Int32));
                }
                return BravoExpressionEvaluator._convert(val2, TypeCodeEnum.String).indexOf(BravoExpressionEvaluator._convert(val1, TypeCodeEnum.String));
            }
            case OperatorEnum.Replace: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (args.length < 2 || args.length > 3)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 3));
                const val1 = this.evaluateExpression(args[0]);
                if (val1 == null)
                    return val1;
                const val2 = this.evaluateExpression(args[1]);
                if (val2 == null)
                    return val2;
                let strReplace = BravoStringExtensions.empty;
                if (args.length > 2) {
                    const val3 = this.evaluateExpression(args[2]);
                    if (val3 == null)
                        return val3;
                    strReplace = BravoStringExtensions.asString(val3);
                }
                return BravoStringExtensions.asString(val1).replace(new RegExp(escapeReplacement(val2), 'g'), strReplace);
            }
            case OperatorEnum.Stuff: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (args.length != 4)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 4));
                const val1 = this.evaluateExpression(args[0]);
                if (val1 == null)
                    return val1;
                const val2 = this.evaluateExpression(args[1]);
                if (val2 == null)
                    return val2;
                const val3 = this.evaluateExpression(args[2]);
                if (val3 == null)
                    return val3;
                const val4 = this.evaluateExpression(args[3]);
                if (val4 == null)
                    return val4;
                if (args[0] == null || args[0] == undefined)
                    return args[0];
                return BravoStringExtensions.stuff(BravoStringExtensions.asString(val1), val2, val3, val4);
            }
            case OperatorEnum.Len:
            case OperatorEnum.Length:
            case OperatorEnum.Trim:
            case OperatorEnum.Ltrim:
            case OperatorEnum.Rtrim:
            case OperatorEnum.Upper:
            case OperatorEnum.Lower: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (args.length != 1)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 1));
                const val1 = this.evaluateExpression(args[0]);
                if (val1 == null)
                    return val1;
                if (pExpression.Operator == OperatorEnum.Trim)
                    return BravoExpressionEvaluator._convert(val1, TypeCodeEnum.String).trim();
                else if (pExpression.Operator == OperatorEnum.Ltrim)
                    return BravoExpressionEvaluator._convert(val1, TypeCodeEnum.String).trimStart();
                else if (pExpression.Operator == OperatorEnum.Rtrim)
                    return BravoExpressionEvaluator._convert(val1, TypeCodeEnum.String).trimEnd();
                else if (pExpression.Operator == OperatorEnum.Upper)
                    return BravoExpressionEvaluator._convert(val1, TypeCodeEnum.String).toUpperCase();
                else if (pExpression.Operator == OperatorEnum.Lower)
                    return BravoExpressionEvaluator._convert(val1, TypeCodeEnum.String).toLowerCase();
                else {
                    const bytes = val1 instanceof Uint8Array ? val1 : null;
                    if (bytes != null)
                        return bytes.length;
                    return BravoExpressionEvaluator._convert(val1, TypeCodeEnum.String).length;
                }
            }
            case OperatorEnum.Str: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (args.length < 1 || args.length > 3)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 1));
                const val1 = this.evaluateExpression(args[0]);
                if (val1 == null)
                    return val1;
                const bytes = val1 instanceof Uint8Array || val1 instanceof ArrayBuffer ? val1 : null;
                if (bytes) {
                    try {
                        return BravoConverterExtensions.toBase64String(bytes);
                    }
                    catch {
                        return bytes.toString();
                    }
                }
                let len = 10, decimals = 0;
                if (args.length > 1) {
                    const val2 = this.evaluateExpression(args[1]);
                    if (val2 == null)
                        return val2;
                    len = BravoExpressionEvaluator._convert(val2, TypeCodeEnum.Int32);
                }
                if (args.length > 2) {
                    const val3 = this.evaluateExpression(args[2]);
                    if (val3 != null)
                        decimals = BravoExpressionEvaluator._convert(val3, TypeCodeEnum.Int32);
                }
                const num = BravoExpressionEvaluator._convert(val1, TypeCodeEnum.Decimal);
                return BravoNumberExtensions.str(num, len, decimals);
            }
            case OperatorEnum.Day:
            case OperatorEnum.Month:
            case OperatorEnum.Year:
            case OperatorEnum.Hour:
            case OperatorEnum.Minute:
            case OperatorEnum.Second:
            case OperatorEnum.Quarter:
            case OperatorEnum.Date:
            case OperatorEnum.Time: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (args.length != 1)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 1));
                const val1 = this.evaluateExpression(args[0]);
                if (val1 == null)
                    return val1;
                const date = BravoExpressionEvaluator._convertDate(val1);
                if (pExpression.Operator == OperatorEnum.Quarter) {
                    if (BravoExpressionEvaluator._valueRequired$.observed) {
                        const eventArgs = new ValueEventArgs(pExpression.Operator, [date]);
                        BravoExpressionEvaluator._valueRequired$.next(eventArgs);
                        return eventArgs.value;
                    }
                    return Math.ceil(date.getMonth()) + 1 / 3;
                }
                else {
                    if (pExpression.Operator == OperatorEnum.Day)
                        return BravoDateExtensions.date(date);
                    else if (pExpression.Operator == OperatorEnum.Month)
                        return BravoDateExtensions.month(date);
                    else if (pExpression.Operator == OperatorEnum.Year)
                        return BravoDateExtensions.year(date);
                    else if (pExpression.Operator == OperatorEnum.Hour)
                        return date.getHours();
                    else if (pExpression.Operator == OperatorEnum.Minute)
                        return date.getMinutes();
                    else if (pExpression.Operator == OperatorEnum.Second)
                        return date.getSeconds();
                    else if (pExpression.Operator == OperatorEnum.Time) {
                        // return DateTime.newDate(_nowDt.year(), _nowDt.getMonth(), _nowDt.day(), _dt.getHours(), _dt.getMinutes(), _dt.getSeconds()).getTime();
                        return BravoTimeSpan.fromTime(date.getHours(), date.getMinutes(), date.getSeconds())
                            .totalSeconds;
                    } // if (expression.Operator == OperatorEnum.Date)
                    else
                        return BravoDateExtensions.date(date);
                }
            }
            case OperatorEnum.Unicode: {
                break;
            }
            case OperatorEnum.GetXmlData:
            case OperatorEnum.GetXmlSelectedData:
            case OperatorEnum.GetJsonData:
            case OperatorEnum.GetJsonSelectedData: {
                if (this._localValueRequired$ == null)
                    throw new BravoNullReferenceException(BravoStringExtensions.format("Event '{0}' is required for operator '{1}'.", 'onLocalValueRequired', OperatorEnum[pExpression.Operator] ?? pExpression.Operator));
                const maxArg = pExpression.Operator == OperatorEnum.GetXmlData ||
                    pExpression.Operator == OperatorEnum.GetXmlSelectedData
                    ? 5
                    : 4;
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (args.length > maxArg)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), maxArg));
                const argArr = [];
                for (const expr of args) {
                    argArr.push(this.evaluateExpression(expr));
                }
                const eventArgs = new ValueEventArgs(pExpression.Operator, argArr);
                this._localValueRequired$.next(eventArgs);
                return eventArgs.value;
            }
            case OperatorEnum.PortalConfig: {
                if (this._localValueRequired$ == null)
                    throw new BravoNullReferenceException(BravoStringExtensions.format("Event '{0}' is required for operator '{1}'.", 'onLocalValueRequired', OperatorEnum[pExpression.Operator] ?? pExpression.Operator));
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (args.length != 1)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 1));
                const argArr = [];
                for (const expr of args) {
                    argArr.push(this.evaluateExpression(expr));
                }
                const eventArgs = new ValueEventArgs(pExpression.Operator, argArr);
                this._localValueRequired$.next(eventArgs);
                return eventArgs.value;
            }
            case OperatorEnum.EncodeHtml: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (!args || args.length != 1)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 1));
                const val = this.evaluateExpression(args[0]);
                return escapeHtml(val);
            }
            case OperatorEnum.DecodeHtml: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
                if (!args || args.length != 1)
                    throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 1));
                const val = this.evaluateExpression(args[0]);
                return decodeHTMLEntities(val);
            }
        }
        let lhs = null, rhs = null;
        lhs = this.evaluateExpression(pExpression.Expressions[0]);
        switch (pExpression.Operator) {
            case OperatorEnum.And: {
                if (!BravoExpressionEvaluator._isTrueValue(lhs))
                    return false;
                rhs = this.evaluateExpression(pExpression.Expressions[1]);
                return BravoExpressionEvaluator._isTrueValue(rhs);
            }
            case OperatorEnum.Or: {
                if (BravoExpressionEvaluator._isTrueValue(lhs))
                    return true;
                rhs = this.evaluateExpression(pExpression.Expressions[1]);
                return BravoExpressionEvaluator._isTrueValue(rhs);
            }
            case OperatorEnum.In: {
                const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[1]);
                for (const arg of args) {
                    const val = this.evaluateExpression(arg);
                    if (BravoExpressionEvaluator.compare(lhs, val) == 0)
                        return true;
                }
                return false;
            }
        }
        const type = BravoExpression.getOperatorType(pExpression.Operator);
        if (type == OperatorTypeEnum.Binary)
            rhs = this.evaluateExpression(pExpression.Expressions[1]);
        switch (pExpression.Operator) {
            case OperatorEnum.Addition: {
                return BravoExpressionEvaluator.addition(lhs, rhs);
            }
            case OperatorEnum.Subtraction: {
                return BravoExpressionEvaluator.subtraction(lhs, rhs);
            }
            case OperatorEnum.Multiplication: {
                return BravoExpressionEvaluator.multiplication(lhs, rhs);
            }
            case OperatorEnum.Division: {
                return BravoExpressionEvaluator.division(lhs, rhs);
            }
            case OperatorEnum.Arguments: {
                const argCollection = [];
                let args = lhs instanceof Array ? lhs : null;
                if (args)
                    argCollection.push(...args);
                else
                    argCollection.push(lhs);
                args = rhs instanceof Array ? rhs : null;
                if (args)
                    argCollection.push(...args);
                else
                    argCollection.push(rhs);
                return argCollection;
            }
            case OperatorEnum.Modulus: {
                return BravoExpressionEvaluator.modulus(lhs, rhs);
            }
            case OperatorEnum.GreaterThan: {
                return BravoExpressionEvaluator.compare(lhs, rhs) > 0;
            }
            case OperatorEnum.LessThan: {
                return BravoExpressionEvaluator.compare(lhs, rhs) < 0;
            }
            case OperatorEnum.Equal:
            case OperatorEnum.Equality: {
                return BravoExpressionEvaluator.compare(lhs, rhs) == 0;
            }
            case OperatorEnum.Notequal:
            case OperatorEnum.Inequality: {
                return BravoExpressionEvaluator.compare(lhs, rhs) > 0 || BravoExpressionEvaluator.compare(lhs, rhs) < 0;
            }
            case OperatorEnum.GreaterThanOrEqual: {
                return BravoExpressionEvaluator.compare(lhs, rhs) >= 0;
            }
            case OperatorEnum.LessThanOrEqual: {
                return BravoExpressionEvaluator.compare(lhs, rhs) <= 0;
            }
            case OperatorEnum.Like: {
                const args = rhs instanceof Array ? rhs : null;
                if (args != null && args.length >= 2)
                    return BravoExpressionEvaluator._like(args[0], lhs, args[1][0]);
                return BravoExpressionEvaluator._like(rhs, lhs);
            }
            case OperatorEnum.UnaryPlus: {
                return lhs;
            }
            case OperatorEnum.UnaryNegation: {
                return BravoExpressionEvaluator.multiplication(-1, lhs);
            }
            case OperatorEnum.LogicalNot:
            case OperatorEnum.Not: {
                return !BravoExpressionEvaluator._isTrueValue(lhs);
            }
        }
        throw new Error(BravoStringExtensions.format(Resources.NotSupportedError, pExpression.Operator.toString()));
    }
    _getCurrentDateTime(pOperator) {
        if (BravoExpressionEvaluator._valueRequired$.observed) {
            const eventArgs = new ValueEventArgs(pOperator);
            BravoExpressionEvaluator._valueRequired$.next(eventArgs);
            return BravoDateExtensions.asDate(eventArgs.value);
        }
        const dtResult = pOperator == OperatorEnum.GetDate || pOperator == OperatorEnum.GetDatetime
            ? BravoDateExtensions.now
            : BravoDateExtensions.utcNow;
        return pOperator == OperatorEnum.GetDate || pOperator == OperatorEnum.GetUtcDate
            ? BravoDateExtensions.date(dtResult)
            : dtResult;
    }
    _evaluateSourceDataExpression(pExpression, pOptions) {
        if (pExpression.Operator == OperatorEnum.Value) {
            const name = BravoExpressionEvaluator._convert(pExpression.Value, TypeCodeEnum.String);
            pOptions.pzSourceDataName = name;
            switch (name.toUpperCase()) {
                case PARENT_QUALIFIER: {
                    if (this._evaluatingDataRow == null) {
                        const parentRow = this._raiseOnParentRowRequired();
                        if (!parentRow)
                            throw new Error(Resources.CannotFindParentRow);
                        pOptions.pzSourceDataName = parentRow.table.name;
                        return parentRow;
                    }
                    else {
                        let parentRow = null;
                        if (this._evaluatingDataRow.table.parentRelations.length < 1) {
                            parentRow = this._raiseOnParentRowRequired();
                        }
                        else if (this._evaluatingDataRow) {
                            pOptions.pzSourceDataName =
                                this._evaluatingDataRow.table.parentRelations[0]?.parentTable?.name ??
                                    BravoStringExtensions.empty;
                            parentRow = this._evaluatingDataRow.getParentRow(this._evaluatingDataRow.table.parentRelations[0]);
                            if (!parentRow)
                                parentRow = this._raiseOnParentRowRequired();
                        }
                        if (!parentRow)
                            throw new Error(Resources.RowDoesNotHaveParentRelation);
                        pOptions.pzSourceDataName = parentRow.table.name;
                        return parentRow;
                    }
                }
                case CHILD_QUALIFIER: {
                    if (!this._evaluatingDataRow)
                        throw new Error(Resources.CannotFindChildRow);
                    if (this._evaluatingDataRow.table.childRelations.length < 1)
                        throw new Error(Resources.RowDoesNotHaveChildRelation);
                    pOptions.pzSourceDataName = this._evaluatingDataRow.table.name;
                    const childRows = this._evaluatingDataRow.getChildRows(this._evaluatingDataRow.table.childRelations[0]);
                    if (childRows == null)
                        throw new Error(Resources.RowDoesNotHaveChildRelation);
                    if (childRows.length > 0)
                        pOptions.pzSourceDataName = childRows[0].table.name;
                    return childRows;
                }
                default: {
                    let tableName = null;
                    if (this._evaluatingDataRow) {
                        tableName = BravoExpressionEvaluator.getTableName(name, this._evaluatingDataRow.table.dataSet);
                        pOptions.pzSourceDataName = tableName;
                        if (this._evaluatingDataRow.table.dataSet.tables.contains(tableName)) {
                            const dataRows = this._evaluatingDataRow.table.dataSet.tables
                                .get(tableName)
                                ?.select(null, null, DataViewRowStateEnum.CurrentRows) ?? [];
                            if (dataRows.length == 0 && this._defaultValueRequired$.observed) {
                                const valueArgs = new ValueEventArgs(OperatorEnum.MemberAccess, [name]);
                                this._defaultValueRequired$.next(valueArgs);
                                return valueArgs.value;
                            }
                            return dataRows;
                        }
                    }
                    if ( /* !this._evaluatingDataRow && */this._defaultValueRequired$) {
                        const valueArgs = new ValueEventArgs(OperatorEnum.MemberAccess, [name]);
                        this._defaultValueRequired$.next(valueArgs);
                        return valueArgs.value;
                    }
                    if (BravoStringExtensions.isNullOrEmpty(tableName))
                        throw new BravoInvalidExpressionException(name);
                    else
                        throw new BravoNullReferenceException(BravoStringExtensions.format(Resources.TableDoesNotExist, tableName));
                }
            }
        }
        else {
            switch (pExpression.Operator) {
                case OperatorEnum.Parent: {
                    const args = BravoExpressionEvaluator._convert(pExpression.Expressions[0].Value, TypeCodeEnum.String);
                    pOptions.pzSourceDataName = args;
                    if (!this._evaluatingDataRow) {
                        const parentRow = this._raiseOnParentRowRequired();
                        if (parentRow == null)
                            throw new Error(Resources.CannotFindParentRow);
                        pOptions.pzSourceDataName = parentRow.table.name;
                        return parentRow;
                    }
                    else {
                        const tableName = BravoExpressionEvaluator.getTableName(args, this._evaluatingDataRow.table.dataSet);
                        pOptions.pzSourceDataName = tableName;
                        let parentRow = null;
                        const relationName = toDataRelationName(tableName);
                        const relation = this._evaluatingDataRow.table.parentRelations.get(relationName);
                        if (!relation) {
                            parentRow = this._raiseOnParentRowRequired();
                            if (parentRow == null)
                                throw new Error(BravoStringExtensions.format(Resources.TableDoesNotExist, tableName));
                        }
                        else {
                            parentRow = this._evaluatingDataRow.getParentRow(relation);
                            if (parentRow == null)
                                parentRow = this._raiseOnParentRowRequired();
                            if (parentRow == null)
                                throw new Error(Resources.RowDoesNotHaveParentRelation);
                        }
                        pOptions.pzSourceDataName = parentRow.table.name;
                        return parentRow;
                    }
                }
                case OperatorEnum.Child: {
                    const args = BravoExpressionEvaluator._convert(pExpression.Expressions[0].Value, TypeCodeEnum.String);
                    pOptions.pzSourceDataName = args;
                    if (!this._evaluatingDataRow)
                        throw new Error(Resources.CannotFindChildRow);
                    const tableName = BravoExpressionEvaluator.getTableName(args, this._evaluatingDataRow.table.dataSet);
                    pOptions.pzSourceDataName = tableName;
                    const relationName = toDataRelationName(tableName);
                    const relation = this._evaluatingDataRow.table.childRelations.get(relationName);
                    if (!relation)
                        throw new Error(BravoStringExtensions.format(Resources.TableDoesNotExist, tableName));
                    const childRows = this._evaluatingDataRow.getChildRows(relation);
                    if (childRows == null)
                        throw new Error(Resources.RowDoesNotHaveChildRelation);
                    if (childRows.length > 0)
                        pOptions.pzSourceDataName = childRows[0].table.name;
                    return childRows;
                }
                default: {
                    pOptions.pzSourceDataName = BravoStringExtensions.empty;
                    return this.evaluateExpression(pExpression);
                }
            }
        }
    }
    _evaluateValueExpression(pExpression) {
        if (pExpression.Value == null && pExpression.Value == undefined)
            throw new Error(Resources.ValueCanNotNull);
        if (BravoStringExtensions.isString(pExpression.Value)) {
            const stringValue = pExpression.Value;
            // The NULL value
            if (BravoStringExtensions.compareStrings(stringValue, NULL_VALUE, true))
                return null;
            // The keyword
            if (BravoExpressionEvaluator._isKeyword(stringValue))
                return stringValue;
            // The quote
            if (stringValue.startsWith("'") || stringValue.startsWith("N'")) {
                let start;
                if (stringValue.startsWith("N'"))
                    start = 2;
                else
                    start = 1;
                let len = stringValue.length;
                if (stringValue.endsWith("'"))
                    len -= 1;
                return stringValue.substring(start, len);
            }
            // The local variable
            if (stringValue.startsWith(VARIABLE_PREFIX)) {
                if (!this.variables.has(stringValue))
                    throw new Error(BravoStringExtensions.format("Must declare the local variable '{0}'.", stringValue));
                return this.variables.get(stringValue);
            }
            // The form parameter
            if (stringValue.startsWith(PARAMETER_PREFIX))
                return this._raiseOnParameterValueRequired(stringValue);
            if (this._evaluatingDataRow)
                return this._evaluateDataRow(this._evaluatingDataRow, stringValue);
            if (this._evaluatingObject)
                return this._evaluateObject(this._evaluatingObject, stringValue);
            if (this._defaultValueRequired$.observed) {
                const valueArgs = new ValueEventArgs(pExpression.Operator, [pExpression.Value]);
                this._defaultValueRequired$.next(valueArgs);
                return valueArgs.value;
            }
            throw new BravoInvalidExpressionException(stringValue);
        }
        return pExpression.Value;
    }
    _evaluateObject(pDataItem, pMember) {
        if (!pDataItem)
            throw new Error(BravoStringExtensions.format(Resources.ArgumentNullError, 'dataItem'));
        if (!pMember)
            throw new Error(BravoStringExtensions.format(Resources.ArgumentNullError, 'member'));
        let val = null;
        if (this._propertyValueRequired$.observed) {
            const e = new PropertyValueEventArgs(pDataItem, pMember);
            this._propertyValueRequired$.next(e);
            val = e.value;
        }
        else {
            if (Object.prototype.hasOwnProperty.call(pDataItem, pMember))
                val = pDataItem[pMember];
            if (pDataItem.grid) {
                const g = pDataItem.grid;
                if (g.columns.indexOf(pMember) != -1) {
                    const colIndex = g.columns.indexOf(pMember);
                    const rowIndex = pDataItem.index;
                    if (rowIndex >= 0 && rowIndex < g.rows.length)
                        val = g.getCellData(rowIndex, colIndex, false);
                }
            }
        }
        if (this.bEnableTracing) {
            if (val == null)
                this._tracer += BravoStringExtensions.format('{0}.{1}: <null>', pDataItem, pMember);
            else if (val == undefined)
                this._tracer += BravoStringExtensions.format('{0}.{1}: <NULL>', pDataItem, pMember);
            else
                this._tracer += BravoStringExtensions.format('{0}.{1}: {2:G} ({3})', pDataItem, pMember, val, typeof val);
        }
        return val;
    }
    _evaluateDataRow(pDataRow, pMember) {
        if (!pDataRow)
            throw new Error('dataRow argument null');
        if (!pMember)
            throw new Error('member argument null');
        const isTracing = this.bEnableTracing && !this._aggregateCalculating;
        if (isTracing)
            this._tracer += BravoStringExtensions.format('{0}.{1}: ', pDataRow.table.name, pMember);
        if (pDataRow.table.extendedProperties.has(TableExpressionCollection)) {
            const exprs = tryCast(pDataRow.table.extendedProperties.get(TableExpressionCollection), Map);
            if (exprs != null && exprs.has(pMember)) {
                try {
                    const evalExpr = new BravoExpressionEvaluator();
                    evalExpr.bEnableTracing = this.bEnableTracing;
                    evalExpr._localValueRequired$.subscribe(pEventArgs => {
                        const eventArgs = new ValueEventArgs(pEventArgs.Operator, pEventArgs.arguments);
                        this._localValueRequired$.next(eventArgs);
                        pEventArgs.value = eventArgs.value;
                    });
                    if (this._parentRowRequired$ != null)
                        evalExpr._parentRowRequired$.subscribe((pEventArgs) => {
                            pEventArgs.value = this._raiseOnParentRowRequired(evalExpr);
                        });
                    if (this._parameterValueRequired$ != null)
                        evalExpr._parameterValueRequired$.subscribe((pEventArgs) => {
                            pEventArgs.value = this._raiseOnParameterValueRequired(pEventArgs.name, evalExpr);
                        });
                    const val = evalExpr.evaluate(exprs.get(pMember), pDataRow);
                    if (isTracing) {
                        this._tracer += '\n';
                        if (evalExpr.tracer.length > 0)
                            this._tracer += evalExpr.tracer;
                    }
                    return val;
                }
                catch (_ex) {
                    throw new BravoInvalidExpressionException(exprs.get(pMember), _ex);
                }
            }
        }
        if (!pDataRow.table.columns.contains(pMember) && !this._columnValueRequired$.observed)
            throw new Error(BravoStringExtensions.format("Column '{0}' does not exists in table '{1}'", pMember, pDataRow.table.name));
        if (isTracing) {
            const dataType = pDataRow.table.columns.get(pMember)?.dataType;
            this._tracer += BravoStringExtensions.format('{0:G} ({1})', pDataRow.isNull(pMember) ? '<NULL>' : pDataRow.getValue(pMember), TypeCodeEnum[dataType]);
            this._tracer += '\n';
        }
        if (this._columnValueRequired$.observed) {
            const eventArgs = new ColumnValueEventArgs(pDataRow, pMember);
            this._columnValueRequired$.next(eventArgs);
            return eventArgs.value;
        }
        return pDataRow.getValue(pMember);
    }
    static _getAggregateSource(pItem) {
        const dataRow = tryCast(pItem, BravoDataInterfaceNamingConstants.IDataRow);
        if (dataRow) {
            return [dataRow];
        }
        else if (pItem instanceof Array) {
            return pItem;
        }
        return [];
    }
    _evaluateAggregateExpression(pExpression) {
        let aggregate, aggregateSource = null, aggregateExpression = null, condition = null, aggregateSourceName = BravoStringExtensions.empty;
        const args = BravoExpressionEvaluator.getArgumentExpressions(pExpression.Expressions[0]);
        if (pExpression.Operator == OperatorEnum.Sum ||
            pExpression.Operator == OperatorEnum.Min ||
            pExpression.Operator == OperatorEnum.Max ||
            pExpression.Operator == OperatorEnum.Avg ||
            pExpression.Operator == OperatorEnum.Count ||
            pExpression.Operator == OperatorEnum.Mode) {
            if (args.length > 2)
                throw new Error(`The ${OperatorEnum[pExpression.Operator]} function requires 2 argument(s).`);
            if (args.length == 2) {
                const out = { pzSourceDataName: aggregateSourceName };
                const obj = this._evaluateSourceDataExpression(args[0], out);
                aggregateSource =
                    this.#raiseOnAggregateSourceRequired(out.pzSourceDataName) ??
                        BravoExpressionEvaluator._getAggregateSource(obj);
                aggregateExpression = args[1];
            }
            else if (args.length == 1) {
                if (args[0].Operator == OperatorEnum.MemberAccess) {
                    const out = { pzSourceDataName: aggregateSourceName };
                    const obj = this._evaluateSourceDataExpression(args[0].Expressions[0], out);
                    aggregateSource =
                        this.#raiseOnAggregateSourceRequired(out.pzSourceDataName) ??
                            BravoExpressionEvaluator._getAggregateSource(obj);
                    aggregateExpression = args[0].Expressions[1];
                }
                else if (pExpression.Operator == OperatorEnum.Count) {
                    const out = { pzSourceDataName: aggregateSourceName };
                    const obj = this._evaluateSourceDataExpression(args[0], out);
                    aggregateSource =
                        this.#raiseOnAggregateSourceRequired(out.pzSourceDataName) ??
                            BravoExpressionEvaluator._getAggregateSource(obj);
                    aggregateExpression = null;
                }
                else {
                    aggregateSourceName = this._evaluatingDataRow?.table.name ?? BravoStringExtensions.empty;
                    aggregateSource =
                        this.#raiseOnAggregateSourceRequired(aggregateSourceName) ??
                            this._evaluatingDataRow?.table.select(null, null, DataViewRowStateEnum.CurrentRows) ??
                            null;
                    aggregateExpression = args[0];
                }
            }
            else {
                aggregateSourceName = this._evaluatingDataRow?.table.name ?? BravoStringExtensions.empty;
                aggregateSource =
                    this.#raiseOnAggregateSourceRequired(aggregateSourceName) ??
                        this._evaluatingDataRow?.table.select(null, null, DataViewRowStateEnum.CurrentRows) ??
                        null;
                aggregateExpression = null;
            }
            switch (pExpression.Operator) {
                case OperatorEnum.Sum:
                    aggregate = new SumAggregate();
                    break;
                case OperatorEnum.Min:
                    aggregate = new MinAggregate();
                    break;
                case OperatorEnum.Max:
                    aggregate = new MaxAggregate();
                    break;
                case OperatorEnum.Avg:
                    aggregate = new AvgAggregate();
                    break;
                case OperatorEnum.Count:
                    aggregate = new CountAggregate();
                    break;
                case OperatorEnum.Mode:
                    aggregate = new ModeAggregate();
                    break;
            }
        }
        else if (pExpression.Operator == OperatorEnum.Concat) {
            if (args.length < 1 || args.length > 3)
                throw new Error(`The ${OperatorEnum[pExpression.Operator]} function requires 2 argument(s).`);
            if (args.length == 3) {
                const out = { pzSourceDataName: aggregateSourceName };
                const obj = this._evaluateSourceDataExpression(args[0], out);
                aggregateSource =
                    this.#raiseOnAggregateSourceRequired(out.pzSourceDataName) ||
                        BravoExpressionEvaluator._getAggregateSource(obj);
                aggregateExpression = args[1];
                const separator = this.evaluateExpression(args[2]);
                aggregate = new ConcatAggregate(separator);
            }
            else if (args.length == 2) {
                if (args[0].Operator == OperatorEnum.MemberAccess) {
                    const out = { pzSourceDataName: aggregateSourceName };
                    const obj = this._evaluateSourceDataExpression(args[0].Expressions[0], out);
                    aggregateSource =
                        this.#raiseOnAggregateSourceRequired(out.pzSourceDataName) ||
                            BravoExpressionEvaluator._getAggregateSource(obj);
                    aggregateExpression = args[0].Expressions[1];
                }
                else {
                    aggregateSourceName = this._evaluatingDataRow?.table.name ?? BravoStringExtensions.empty;
                    aggregateSource =
                        (this.#raiseOnAggregateSourceRequired(aggregateSourceName) ||
                            this._evaluatingDataRow?.table.select(null, null, DataViewRowStateEnum.CurrentRows)) ??
                            null;
                    aggregateExpression = args[0];
                }
                const separator = this.evaluateExpression(args[1]);
                aggregate = new ConcatAggregate(separator);
            }
            else {
                if (args[0].Operator == OperatorEnum.MemberAccess) {
                    const out = { pzSourceDataName: aggregateSourceName };
                    const obj = this._evaluateSourceDataExpression(args[0].Expressions[0], out);
                    aggregateSource =
                        this.#raiseOnAggregateSourceRequired(out.pzSourceDataName) ||
                            BravoExpressionEvaluator._getAggregateSource(obj);
                    aggregateExpression = args[0].Expressions[1];
                }
                else {
                    aggregateSourceName = this._evaluatingDataRow?.table.name ?? BravoStringExtensions.empty;
                    aggregateSource =
                        (this.#raiseOnAggregateSourceRequired(aggregateSourceName) ||
                            this._evaluatingDataRow?.table.select(null, null, DataViewRowStateEnum.CurrentRows)) ??
                            null;
                    aggregateExpression = args[0];
                }
                aggregate = new ConcatAggregate(BravoStringExtensions.empty);
            }
        }
        else if (pExpression.Operator == OperatorEnum.SumIf || pExpression.Operator == OperatorEnum.CountIf) {
            if (args.length < 1 || args.length > 3)
                throw new Error(BravoStringExtensions.format(Resources.RequiredFunctionArgument, OperatorEnum[pExpression.Operator].toUpperCase(), 3));
            if (args.length == 3) {
                const out = { pzSourceDataName: aggregateSourceName };
                const obj = this._evaluateSourceDataExpression(args[0], out);
                aggregateSource =
                    this.#raiseOnAggregateSourceRequired(out.pzSourceDataName) ||
                        BravoExpressionEvaluator._getAggregateSource(obj);
                aggregateExpression = args[1];
                condition = args[2];
            }
            else if (args.length == 2) {
                if (args[0].Operator == OperatorEnum.MemberAccess) {
                    const out = { pzSourceDataName: aggregateSourceName };
                    const obj = this._evaluateSourceDataExpression(args[0].Expressions[0], out);
                    aggregateSource =
                        this.#raiseOnAggregateSourceRequired(out.pzSourceDataName) ||
                            BravoExpressionEvaluator._getAggregateSource(obj);
                    aggregateExpression = args[0].Expressions[1];
                }
                else {
                    aggregateSourceName = this._evaluatingDataRow?.table.name ?? BravoStringExtensions.empty;
                    aggregateSource =
                        (this.#raiseOnAggregateSourceRequired(aggregateSourceName) ||
                            this._evaluatingDataRow?.table.select(null, null, DataViewRowStateEnum.CurrentRows)) ??
                            null;
                    aggregateExpression = args[0];
                }
                condition = args[1];
            }
            else {
                if (args[0].Operator == OperatorEnum.MemberAccess) {
                    const out = { pzSourceDataName: aggregateSourceName };
                    const obj = this._evaluateSourceDataExpression(args[0].Expressions[0], out);
                    aggregateSource =
                        this.#raiseOnAggregateSourceRequired(out.pzSourceDataName) ||
                            BravoExpressionEvaluator._getAggregateSource(obj);
                    aggregateExpression = args[0].Expressions[1];
                }
                else {
                    aggregateSourceName = this._evaluatingDataRow?.table.name ?? BravoStringExtensions.empty;
                    aggregateSource =
                        (this.#raiseOnAggregateSourceRequired(aggregateSourceName) ||
                            this._evaluatingDataRow?.table.select(null, null, DataViewRowStateEnum.CurrentRows)) ??
                            null;
                    aggregateExpression = args[0];
                }
            }
            switch (pExpression.Operator) {
                case OperatorEnum.SumIf:
                    aggregate = new SumAggregate();
                    break;
                case OperatorEnum.CountIf:
                    aggregate = new CountAggregate();
                    break;
            }
        }
        else {
            throw new Error(`Not support operator ${OperatorEnum[pExpression.Operator]}`);
        }
        this._aggregateCalculating = true;
        try {
            const isTracing = this.bEnableTracing;
            if (isTracing)
                this._tracer += BravoStringExtensions.format('{0}=>{1}=>{2}: ', pExpression.Operator, aggregateSourceName, aggregateExpression ? aggregateExpression.Value : '<empty>');
            aggregate.init();
            for (let i = 0; aggregateSource && i < aggregateSource.length; i++) {
                const row = aggregateSource[i];
                if (condition && !BravoExpressionEvaluator._isTrueValue(this._evaluateCollection([condition], row)))
                    continue;
                if (aggregateExpression)
                    aggregate.accumulate(this._evaluateCollection([aggregateExpression], row));
                else
                    aggregate.accumulate(0);
            }
            const val = aggregate.terminate();
            if (isTracing) {
                if (val == null)
                    this._tracer += '<null>';
                else if (val == undefined)
                    this._tracer += '<NULL>';
                else
                    this._tracer += BravoStringExtensions.format('{0} ({1})', val, typeof val);
                this._tracer += '\n';
            }
            return val;
        }
        finally {
            this._aggregateCalculating = false;
        }
    }
    _parentRowRequired$ = new Subject();
    get parentRowRequired$() {
        return this._parentRowRequired$.asObservable();
    }
    _raiseOnParentRowRequired(pEval = null) {
        const evalExpr = pEval ?? this;
        if (!evalExpr._parentRowRequired$.observed)
            return null;
        const eventArgs = new ParameterValueEventArgs(BravoStringExtensions.empty);
        evalExpr._parentRowRequired$.next(eventArgs);
        return eventArgs.value;
    }
    _parameterValueRequired$ = new Subject();
    get parameterValueRequired$() {
        return this._parameterValueRequired$.asObservable();
    }
    _raiseOnParameterValueRequired(pzName, pEval = null) {
        const evalExpr = pEval ?? this;
        if (!evalExpr._parameterValueRequired$.observed)
            return null;
        const eventArgs = new ParameterValueEventArgs(pzName);
        evalExpr._parameterValueRequired$.next(eventArgs);
        return eventArgs.value;
    }
    getFormat(pzFormat) {
        if (pzFormat && BravoStringExtensions.compareStrings(pzFormat, 'C'))
            return BravoStringExtensions.format('{0}', this.evaluate('FORMATCURRENCY()'));
        if (pzFormat && BravoStringExtensions.compareStrings(pzFormat, 'Q'))
            return BravoStringExtensions.format('{0}', this.evaluate('FORMATQUANTITY()'));
        if (!BravoStringExtensions.isNullOrEmpty(pzFormat) && BravoExpressionEvaluator._valueRequired$.observed) {
            const args = new ValueEventArgs(OperatorEnum.DataFormat, [
                pzFormat,
                BravoAppSettings.settings.currentLangString,
            ]);
            BravoExpressionEvaluator._valueRequired$.next(args);
            if (args.value != null)
                return args.value.toString();
            return pzFormat;
        }
        return pzFormat;
    }
    static isTableExpression(pExpr) {
        const expr = pExpr;
        if (expr.Operator == OperatorEnum.Value &&
            expr.Value != null &&
            BravoStringExtensions.isString(expr.Value) &&
            !expr.Value.startsWith('@') &&
            !expr.Value.startsWith("'"))
            return true;
        if (expr != Empty && expr.Expressions != null && expr.Expressions.length > 0) {
            let isDateArg = false;
            for (const e of expr.Expressions) {
                if (e != Empty &&
                    (expr.Operator == OperatorEnum.DatePart ||
                        expr.Operator == OperatorEnum.DateAdd ||
                        expr.Operator == OperatorEnum.DateDiff)) {
                    isDateArg = true;
                    continue;
                }
                if (isDateArg && e.Operator == OperatorEnum.Value) {
                    isDateArg = false;
                    continue;
                }
                if (isDateArg)
                    continue;
                if (this.isTableExpression(e))
                    return true;
            }
        }
        return false;
    }
}
class SumAggregate {
    _value;
    init() {
        /*empty*/
    }
    accumulate(pValue) {
        if (pValue == null)
            return;
        if (this._value == null) {
            this._value = pValue;
            return;
        }
        this._value = BravoExpressionEvaluator.addition(this._value, pValue);
    }
    terminate() {
        return this._value;
    }
}
class ConcatAggregate {
    _value;
    _separator;
    get separator() {
        return this._separator;
    }
    constructor(pSeparator) {
        this._separator = pSeparator;
    }
    init() {
        this._value = new BravoStringBuilder();
    }
    accumulate(pValue) {
        if (pValue == null)
            return;
        if (BravoDateExtensions.isDate(pValue))
            this._value.append(BravoMoment.format(pValue, 'dd/MM/yy hh:mm:ss tt'));
        else
            this._value.append(pValue);
        this._value.append(this._separator);
    }
    terminate() {
        let output = BravoStringExtensions.empty;
        if (this._value.length > 0)
            output = this._value.toString().substring(0, this._value.length - this._separator.length);
        return output;
    }
}
class MaxAggregate {
    _value;
    init() {
        /*empty*/
    }
    accumulate(pValue) {
        if (pValue == null)
            return;
        if (this._value == null) {
            this._value = pValue;
            return;
        }
        if (BravoExpressionEvaluator.compare(this._value, pValue) < 0)
            this._value = pValue;
    }
    terminate() {
        return this._value;
    }
}
class MinAggregate {
    _value;
    init() {
        /*empty*/
    }
    accumulate(pValue) {
        if (pValue == null)
            return;
        if (this._value == null) {
            this._value = pValue;
            return;
        }
        if (BravoExpressionEvaluator.compare(this._value, pValue) > 0)
            this._value = pValue;
    }
    terminate() {
        return this._value;
    }
}
class AvgAggregate {
    _value;
    _count = 0;
    init() {
        /*empty*/
    }
    accumulate(pValue) {
        if (pValue == null)
            return;
        if (this._value == null) {
            this._value = pValue;
            this._count = 1;
            return;
        }
        this._value = BravoExpressionEvaluator.addition(this._value, pValue);
        this._count++;
    }
    terminate() {
        if (this._count <= 0)
            return this._value;
        return BravoExpressionEvaluator.division(this._value, this._count);
    }
}
class CountAggregate {
    _count;
    init() {
        this._count = 0;
    }
    accumulate(pValue) {
        if (pValue == null)
            return;
        this._count++;
    }
    terminate() {
        return this._count;
    }
}
class ModeAggregate {
    _dic;
    init() {
        this._dic = new Map();
    }
    accumulate(pValue) {
        if (pValue == null)
            return;
        let val = this._dic.get(pValue);
        if (val) {
            val++;
            this._dic.set(pValue, val);
        }
        else {
            this._dic.set(pValue, 1);
        }
    }
    terminate() {
        if (this._dic.size == 0)
            return null;
        let cnt = 0, value = null;
        this._dic.forEach((pVal, pKey) => {
            if (pVal > cnt) {
                cnt = pVal;
                value = pKey;
            }
        });
        return value;
    }
}
class LikeToken {
    type;
    value;
    constructor(pType, pValue) {
        this.type = pType;
        this.value = pValue;
    }
    isMatch(pStr) {
        switch (this.type) {
            case LikeTokenTypeEnum.Character:
            case LikeTokenTypeEnum.PositiveCharacters:
                return (this.value.indexOf(pStr) >= 0 ||
                    this.value.indexOf(pStr.toLowerCase()) >= 0 ||
                    this.value.indexOf(pStr.toUpperCase()) >= 0);
            case LikeTokenTypeEnum.NegativeCharacters:
                return (this.value.indexOf(pStr) < 0 ||
                    this.value.indexOf(pStr.toLowerCase()) < 0 ||
                    this.value.indexOf(pStr.toUpperCase()) < 0);
            default:
                return true;
        }
    }
    toString() {
        return BravoStringExtensions.format("Type: {0}, Value: '{1}'", LikeTokenTypeEnum[this.type], this.value);
    }
}
//#endregion helper classes
var LikeTokenTypeEnum;
(function (LikeTokenTypeEnum) {
    LikeTokenTypeEnum[LikeTokenTypeEnum["Character"] = 0] = "Character";
    LikeTokenTypeEnum[LikeTokenTypeEnum["MultipleCharacter"] = 1] = "MultipleCharacter";
    LikeTokenTypeEnum[LikeTokenTypeEnum["SingleCharacter"] = 2] = "SingleCharacter";
    LikeTokenTypeEnum[LikeTokenTypeEnum["PositiveCharacters"] = 3] = "PositiveCharacters";
    LikeTokenTypeEnum[LikeTokenTypeEnum["NegativeCharacters"] = 4] = "NegativeCharacters";
})(LikeTokenTypeEnum || (LikeTokenTypeEnum = {}));

/**
 * Generated bundle index. Do not edit.
 */

export { BravoExpression, BravoExpressionEvaluator, ClauseExpression, ColumnValueEventArgs, DatePartEnum, Empty, ExprGroupPattern, ExprPattern, INVALID_VALUE, OperatorDescriptor, OperatorEnum, OperatorLevelEnum, OperatorTypeEnum, ParameterValueEventArgs, PropertyValueEventArgs, QuoteExprPattern, RtfExprPattern, SqlDbTypeEnum, Stack, TableAliasKey, TableExpressionCollection, TableSourceKey, Token, ValueEventArgs };
//# sourceMappingURL=bravo-infra-core-expression.mjs.map
