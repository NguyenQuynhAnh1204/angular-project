import { isSignal, numberAttribute } from '@angular/core';
import { Subject } from 'rxjs';
import { BravoAppSettings } from '@bravo-infra/core/utils/global-settings';
import { BravoMoment } from '@bravo-infra/core/utils/dates';
import 'reflect-metadata';

function isKeyOf(pKey) {
    const typeofK = typeof pKey;
    return pKey !== null && pKey !== undefined && ['string', 'symbol', 'number'].includes(typeofK);
}
function isObjectGuard(pObj) {
    return pObj !== null && pObj !== undefined && typeof pObj === 'object' && !Array.isArray(pObj);
}
function isDefined(pVal) {
    return pVal !== null && pVal !== undefined;
}
function assert(pCondition, pMsg) {
    if (!pCondition) {
        pMsg = '** Assertion failed in Bravo: ' + pMsg;
        console.error(pMsg);
        throw pMsg;
    }
}
/**
 * Checks whether a value is null or undefined.
 *
 * @param pValue The value to check.
 * @returns True if the value is null or undefined; otherwise, false.
 *
 * @example
 * isNullish(null); // true
 * isNullish(undefined); // true
 * isNullish(''); // false
 */
const isNullish = (pValue) => [null, undefined].includes(pValue);
/**
 * Checks whether a value is neither null nor undefined.
 *
 * @param pValue The value to check.
 * @returns True if the value is not null or undefined; otherwise, false.
 *
 * @example
 * isNotNil('hello'); // true
 * isNotNil(undefined); // false
 * isNotNil(null); // false
 */
function isNotNil(pValue) {
    return typeof pValue !== 'undefined' && pValue !== null;
}
/**
 * Checks whether a value is a Map instance.
 *
 * @param pValue The value to check.
 * @returns True if the value is a Map; otherwise, false.
 *
 * @example
 * isMap(new Map()); // true
 * isMap({}); // false
 */
const isMap = (pValue) => pValue instanceof Map;
/**
 * Checks whether a value is a Set instance.
 *
 * @param pValue The value to check.
 * @returns True if the value is a Set; otherwise, false.
 *
 * @example
 * isSet(new Set()); // true
 * isSet([]); // false
 */
const isSet = (pValue) => pValue instanceof Set;
/**
 * Determines whether an object is a primitive type (string, number, Boolean, or Date).
 *
 * @param pValue Value to test.
 */
function isPrimitive(pValue) {
    return (typeof pValue === 'string' ||
        typeof pValue === 'number' ||
        typeof pValue === 'boolean' ||
        pValue instanceof Date);
}
/**
 * Determines whether an object is a function.
 *
 * @param value Value to test.
 */
function isFunction(pValue) {
    return typeof pValue == 'function';
}
/**
 * Asserts that a value is a function.
 *
 * @param pValue Value supposed to be a function.
 * @param pIsNullOK Whether null values are acceptable.
 * @return The function passed in.
 */
function asFunction(pValue, pIsNullOK = true) {
    assert((pIsNullOK && pValue == null) || isFunction(pValue), 'Function expected.');
    return pValue;
}
/**
 * Determines whether an object is undefined.
 *
 * @param value Value to test.
 */
function isUndefined(pValue) {
    return typeof pValue == 'undefined';
}
/**
 * Determines whether the given object is a Promise.
 *
 * @param pObj The object to test.
 * @returns True if the object is a Promise; otherwise, false.
 *
 * @example
 * isPromise(Promise.resolve(123)); // true
 * isPromise(123); // false
 */
function isPromise(pObj) {
    return !!pObj && typeof pObj.then === 'function' && typeof pObj.catch === 'function';
}
function isWritableSignal(pValue) {
    if (!isSignal(pValue))
        return false;
    if (pValue['set'] && pValue['update'])
        return true;
    return false;
}
/**
 * Asserts that a value is an instance of a given type.
 *
 * @param pValue Value to be checked.
 * @param pType Type of value expected.
 * @param pIsNullOK Whether null values are acceptable.
 * @return The value passed in.
 */
function asType(pValue, pType, pIsNullOK = false) {
    pValue = tryCast(pValue, pType);
    assert(pIsNullOK || pValue != null, pType + ' expected.');
    return pValue;
}
/**
 * Casts a value to a type if possible.
 *
 * @param pValue Value to cast.
 * @param pType Type or interface name to cast to.
 * @return The value passed in if the cast was successful, null otherwise.
 */
function tryCast(pValue, pType) {
    // null doesn't implement anything
    if (pValue == null) {
        return null;
    }
    // test for interface implementation (IQueryInterface)
    if (isString(pType)) {
        return isFunction(pValue.implementsInterface) && pValue.implementsInterface(pType) ? pValue : null;
    }
    // regular type test
    return pValue instanceof pType ? pValue : null;
}
/**
 * Determines whether an object is a string.
 *
 * @param pValue Value to test.
 */
function isString(pValue) {
    return typeof pValue == 'string';
}
/**
 * Asserts that a value is a number.
 *
 * @param pValue Value supposed to be numeric.
 * @param pNullOK Whether null values are acceptable.
 * @param positive Whether to accept only positive numeric values.
 * @return The number passed in.
 */
function asNumber(pValue, pNullOK = false, positive = false) {
    assert((pNullOK && pValue == null) || isNumber(pValue), 'Number expected.');
    if (typeof pValue == 'number')
        return pValue;
    if (typeof pValue == 'string') {
        const val = parseFloat(pValue);
        if (!isNaN(val))
            return val;
    }
    if (positive && pValue && pValue < 0)
        throw 'Positive number expected.';
    return Number(pValue);
}
/**
 * Determines whether an object is a number.
 *
 * @param pValue Value to test.
 */
function isNumber(pValue) {
    return !isNaN(parseFloat(pValue)) && isFinite(pValue);
}
/**
 * @description
 * Escapes all special RegExp characters in a string by prefixing them with a backslash (`\`).
 * This ensures the string can be safely used inside a regular expression pattern.
 *
 * @example
 * ```ts
 * escapeReplacement("a+b*c"); // returns "a\+b\*c"
 * escapeReplacement("[path]/test$"); // returns "\[path\]\/test\$"
 * ```
 *
 * @remarks
 * The function escapes the following characters:
 * `- [ ] / { } ( ) * + ? . \ ^ $ |`
 */
function escapeReplacement(pStr) {
    // Matches any RegExp special character
    const regex = /[\\^$.*+?()[\]{}|/-]/g;
    // Replace each special character with its escaped version (e.g. '+' -> '\+')
    return pStr.replace(regex, '\\$&');
}
/**
 * Escapes a string by replacing HTML characters as text entities.
 *
 * Strings entered by uses should always be escaped before they are displayed
 * in HTML pages. This ensures page integrity and prevents HTML/javascript
 * injection attacks.
 *
 * @param pText Text to escape.
 * @return An HTML-escaped version of the original string.
 */
const ENTITY_MAP = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;',
    '/': '&#x2F;',
};
function escapeHtml(pText) {
    if (isString(pText)) {
        // remove the unnecessary escape before '/'
        return pText.replace(/[&<>"'/]/g, pStr => ENTITY_MAP[pStr]);
    }
    return pText;
}
/**
 * @description
 * Decodes HTML entities and strips out any HTML or script tags.
 *
 * @example
 * decodeHTMLEntities('&lt;b&gt;Hi&lt;/b&gt;'); // "Hi"
 *
 * @param pStr - The encoded HTML string.
 * @returns The decoded plain text.
 */
function decodeHTMLEntities(pStr) {
    const element = document.createElement('div');
    if (pStr && typeof pStr === 'string') {
        // strip script/html tags
        pStr = pStr.replace(/<script[^>]*>([\S\s]*?)<\/script>/gim, '');
        pStr = pStr.replace(/<\/?\w(?:[^"'>]|"[^"]*"|'[^']*')*>/gim, '');
        element.innerHTML = pStr;
        pStr = element.textContent;
        element.textContent = '';
    }
    return pStr;
}
const tryParse = (pValue) => {
    try {
        const parsed = JSON.parse(pValue);
        return typeof parsed === 'object' ? parsed : pValue;
    }
    catch {
        return pValue;
    }
};

class BravoArrayExtensions {
    /**
     * Removes the first occurrence of pItem from pArray, if it exists.
     *
     * @param pArray The array to remove the item from.
     * @param pItem The item to remove.
     * @returns True if an item was removed, false otherwise.
     *
     * @example
     * const arr = [1, 2, 3];
     * ArrayExtension.removeItem(arr, 2); // arr is now [1, 3]
     */
    static removeItem(pArray, pItem) {
        const idx = pArray.indexOf(pItem);
        if (idx > -1) {
            pArray.splice(idx, 1);
            return true;
        }
        return false;
    }
    static isArraysEqual(pArray1, pArray2) {
        if (!pArray1 || !pArray2 || pArray1.length !== pArray2.length)
            return false;
        const len = pArray1.length;
        for (let i = 0; i < len; i++) {
            if (pArray1[i] !== pArray2[i])
                return false;
        }
        return true;
    }
    /**
     * Returns a new array containing the elements that are present in both the source and target arrays.
     *
     * @param pSourceArray - The array to filter for intersection.
     * @param pTargeArray - The array whose elements are used to determine the intersection.
     * @returns An array containing the elements found in both `pSourceArray` and `pTargeArray`.
     */
    static intersect(pSourceArray, pTargeArray) {
        return pSourceArray.filter(Set.prototype.has, new Set([...pTargeArray]));
    }
    /**
     * Returns a new array containing elements from the `source` array that are not present in the `compareTo` array.
     *
     * @typeParam T - The type of elements in the arrays.
     * @param pSource - The array to filter.
     * @param pCompareTo - The array containing elements to exclude from the result.
     * @returns A new array with elements from `source` that are not found in `compareTo`.
     */
    static expect(pSource, pCompareTo) {
        return pSource.filter(pItem => !pCompareTo.includes(pItem));
    }
    /**
     * @description
     * Accepts an array of objects of type T and single key or array of keys (K extends keyof T).
     * The `exctract` method is pure and immutable, thus not touching the input values and returning a shallow
     * copy of the extracted source.
     *
     * @example
     *
     * const cats = [{id: 1, type: 'cat', name: 'Fluffy'}, {id: 2, type: 'cat', name: 'Emma'}];
     *
     * const catsWithoutTypes = extract(cats, ['name', 'id']);
     *
     * // catsWithoutTypes will be:
     * // [{id: 1, name: 'Fluffy'}, {id: 2, name: 'Emma'}];
     *
     * @returns T
     *
     * @docsPage slice
     * @docsCategory transformation-helpers
     */
    static extract(pArray, pKeys) {
        const arrayIsArray = isDefined(pArray) && Array.isArray(pArray);
        if (!arrayIsArray) {
            console.warn(`extract: original value (${pArray}) is not an array.`);
            return undefined;
        }
        const sanitizedKeys = (Array.isArray(pKeys) ? pKeys : [pKeys]).filter(pItem => isKeyOf(pItem) && pArray.some(pItem2 => pItem in pItem2));
        const length = sanitizedKeys.length;
        if (!sanitizedKeys.length) {
            console.warn(`extract: provided keys not found`);
            return undefined;
        }
        return pArray.map(pItem => {
            let i = 0;
            const result = {};
            for (i; i < length; i++) {
                result[sanitizedKeys[i]] = pItem[sanitizedKeys[i]];
            }
            return result;
        });
    }
    /**
     * @description
     * Inserts one or multiple items to an array T[].
     * Returns a shallow copy of the updated array T[], and does not mutate the original one.
     *
     * @example
     * // Inserting single value
     *
     * const creatures = [{id: 1, type: 'cat'}, {id: 2, type: 'dog'}];
     *
     * const updatedCreatures = insert(creatures, {id: 3, type: 'parrot'});
     *
     * // updatedCreatures will be:
     * //  [{id: 1, type: 'cat'}, {id: 2, type: 'dog}, {id: 3, type: 'parrot}];
     *
     * @example
     * // Inserting multiple values
     *
     * const creatures = [{id: 1, type: 'cat'}, {id: 2, type: 'dog'}];
     *
     * const updatedCreatures = insert(creatures, [{id: 3, type: 'parrot'}, {id: 4, type: 'hamster'}]);
     *
     * // updatedCreatures will be:
     * // [{id: 1, type: 'cat'}, {id: 2, type: 'dog'}, {id: 3, type: 'parrot'}, {id: 4, type: 'hamster'}];
     *
     * @returns T[]
     *
     * @docsPage insert
     * @docsCategory transformation-helpers
     */
    static insert(pSource, pUpdates) {
        const updatesDefined = isDefined(pUpdates);
        const sourceIsNotArray = !Array.isArray(pSource);
        const invalidInput = sourceIsNotArray && !updatesDefined;
        if (sourceIsNotArray && isDefined(pSource)) {
            console.warn(`Insert: Original value (${pSource}) is not an array.`);
        }
        if (invalidInput) {
            return pSource;
        }
        return (sourceIsNotArray ? [] : pSource).concat(updatesDefined ? (Array.isArray(pUpdates) ? pUpdates : [pUpdates]) : []);
    }
    /**
     * @description
     * Converts an array of objects to a dictionary {[key: string]: T}.
     * Accepts array T[] and key of type string, number or symbol as inputs.
     *
     *
     * @example
     *
     * const creatures = [{id: 1, type: 'cat'}, {id: 2, type: 'dog'}, {id: 3, type: 'parrot'}];
     *
     * const creaturesDictionary = toDictionary(creatures, 'id');
     *
     * // creaturesDictionary will be:
     * // {
     * //  1: {id: 1, type: 'cat'},
     * //  2: {id: 2, type: 'dog'},
     * //  3: {id: 3, type: 'parrot'}
     * // };
     *    // Imperative implementation
     *    convertToDictionary(): void {
     *        this.state.set({ creaturesDictionary: toDictionary(this.state.get().creatures, 'id'});
     *    }
     * }
     *
     * @see {@link OnlyKeysOfSpecificType}
     * @param {OnlyKeysOfSpecificType<T, S>} pKey
     * @returns { [key: string]: T[] }
     * @docsPage toDictionary
     * @docsCategory transformation-helpers
     */
    static toDictionary(pSource, pKey) {
        if (!isDefined(pSource)) {
            return pSource;
        }
        const sourceEmpty = !pSource.length;
        if (!Array.isArray(pSource) || sourceEmpty || !isKeyOf(pSource[0][pKey])) {
            if (!sourceEmpty) {
                console.warn('ToDictionary: unexpected input params.');
            }
            return {};
        }
        const dictionary = {};
        const length = pSource.length;
        let i = 0;
        for (i; i < length; i++) {
            dictionary[`${pSource[i][pKey]}`] = Object.assign({}, pSource[i]);
        }
        return dictionary;
    }
    /**
     * @description
     * Removes one or multiple items from an array T[].
     * For comparison you can provide a key, an array of keys or a custom comparison function that should return true if items match.
     * If no comparison data is provided, an equality check is used by default.
     * Returns a shallow copy of the updated array T[], and does not mutate the original one.
     *
     * @example
     * // Removing value without comparison data
     *
     * const items = [1,2,3,4,5];
     *
     * const updatedItems = remove(items, [1,2,3]);
     *
     * // updatedItems will be: [4,5];
     *
     * @example
     * // Removing values with comparison function
     *
     * const creatures = [{id: 1, type: 'cat'}, {id: 2, type: 'unicorn'}, {id: 3, type: 'kobold'}];
     *
     * const nonExistingCreatures = [{id: 2, type: 'unicorn'}, {id: 3, type: 'kobold'}];
     *
     * const realCreatures = remove(creatures, nonExistingCreatures, (a, b) => a.id === b.id);
     *
     * // realCreatures will be: [{id: 1, type: 'cat'}];
     *
     * @example
     * // Removing values with key
     *
     * const creatures = [{id: 1, type: 'cat'}, {id: 2, type: 'unicorn'}, {id: 3, type: 'kobold'}];
     *
     * const nonExistingCreatures = [{id: 2, type: 'unicorn'}, {id: 3, type: 'kobold'}];
     *
     * const realCreatures = remove(creatures, nonExistingCreatures, 'id');
     *
     * // realCreatures will be: [{id: 1, type: 'cat'}];
     *
     * @example
     * // Removing values with array of keys
     *
     * const creatures = [{id: 1, type: 'cat'}, {id: 2, type: 'unicorn'}, {id: 3, type: 'kobold'}];
     *
     * const nonExistingCreatures = [{id: 2, type: 'unicorn'}, {id: 3, type: 'kobold'}];
     *
     * const realCreatures = remove(creatures, nonExistingCreatures, ['id', 'type']);
     *
     * // realCreatures will be: [{id: 1, type: 'cat'}];
     * @returns T[]
     *
     * @docsPage remove
     * @docsCategory transformation-helpers
     */
    static remove(pSource, pScrap, pCompare) {
        const scrapAsArray = isDefined(pScrap) ? (Array.isArray(pScrap) ? pScrap : [pScrap]) : [];
        const invalidInput = !Array.isArray(pSource);
        if (invalidInput) {
            console.warn(`Remove: original value (${pSource}) is not an array`);
            return pSource;
        }
        return pSource.filter(pExistingItem => {
            return !scrapAsArray.some(pItem => valuesComparer(pItem, pExistingItem, pCompare));
        });
    }
    /**
     * @description
     * Updates one or multiple items in an array T[].
     * For comparison you can provide key, array of keys or a custom comparison function that should return true if items match.
     * If no comparison is provided, an equality check is used by default.
     * Returns a shallow copy of the array T[] and updated items, does not mutate the original array.
     *
     * @example
     * // Update with comparison function
     *
     * const creatures = [{id: 1, type: 'cat'}, {id: 2, type: 'dog'}];
     *
     * const newCat = {id: 1, type: 'lion'};
     *
     * const updatedCreatures = update(creatures, newCat, (a, b) => a.id === b.id);
     *
     * // updatedCreatures will be:
     * // [{id: 1, type: 'lion'}, {id: 2, type: 'dog'}];
     *
     * @example
     * // Update with key
     *
     * const creatures = [{id: 1, type: 'cat'}, {id: 2, type: 'dog'}];
     *
     * const newCat = {id: 1, type: 'lion'};
     *
     * const updatedCreatures = update(creatures, newCat, 'id');
     *
     * // updatedCreatures will be:
     * // [{id: 1, type: 'lion'}, {id: 2, type: 'dog'}];
     *
     * @example
     * // Update with array of keys
     *
     * const creatures = [{id: 1, type: 'cat', name: 'Bella'}, {id: 2, type: 'dog', name: 'Sparky'}];
     *
     * const newCat = {id: 1, type: 'lion', name: 'Bella'};
     *
     * const updatedCreatures = update(creatures, newCat, ['id', 'name']);
     *
     * // updatedCreatures will be:
     * // [{id: 1, type: 'lion', name: 'Bella'}, {id: 2, type: 'dog', name: 'Sparky'}];
     *
     * @returns T[]
     *
     * @docsPage update
     * @docsCategory transformation-helpers
     */
    static update(pSource, pUpdates, pCompare) {
        const updatesDefined = pUpdates != null;
        const updatesAsArray = updatesDefined ? (Array.isArray(pUpdates) ? pUpdates : [pUpdates]) : [];
        const sourceDefined = pSource != null;
        const sourceIsNotArray = !Array.isArray(pSource);
        const invalidInput = sourceIsNotArray || pSource.length === 0 || updatesAsArray.length === 0;
        if (sourceDefined && sourceIsNotArray) {
            console.warn(`Update: Original value (${pSource}) is not an array.`);
        }
        if (invalidInput) {
            return pSource;
        }
        const x = [];
        for (const existingItem of pSource) {
            const match = customFind(updatesAsArray, pItem => valuesComparer(pItem, existingItem, pCompare));
            x.push(match ? { ...existingItem, ...match } : existingItem);
        }
        return x;
    }
    /**
     * @description
     * Updates or inserts (if does not exist) one or multiple items in an array T[].
     * For comparison you can provide a key, an array of keys or a custom comparison function that should return true if
     * items match.
     * If no comparison is provided, an equality check is used by default.
     * upsert is `pure` and `immutable`, your inputs won't be changed
     *
     *
     * @example
     * // Upsert (update) with key
     *
     * const creatures = [{id: 1, type: 'cat'}, {id: 2, type: 'dog'}];
     *
     * const newCat = {id: 1, type: 'lion'};
     *
     * const updatedCreatures = upsert(creatures, newCat, 'id');
     *
     * // updatedCreatures will be:
     * // [{id: 1, type: 'lion'}, {id: 2, type: 'dog'}];
     *
     * @example
     * // Upsert (insert) with key
     *
     * const creatures = [{id: 1, type: 'cat'}, {id: 2, type: 'dog'}];
     *
     * const newCat = {id: 3, type: 'lion'};
     *
     * const updatedCreatures = upsert(creatures, newCat, 'id');
     *
     * // updatedCreatures will be:
     * // [{id: 1, type: 'cat'}, {id: 2, type: 'dog'}, {id: 3, type: 'lion'}];
     *
     * @example
     * // Upsert (update) with array of keys
     *
     * const creatures = [{id: 1, type: 'cat', name: 'Bella'}, {id: 2, type: 'dog', name: 'Sparky'}];
     *
     * const newCat = {id: 1, type: 'lion', name: 'Bella'};
     *
     * const updatedCreatures = upsert(creatures, newCat, ['id', 'name']);
     *
     * // updatedCreatures will be:
     * // [{id: 1, type: 'lion', name: 'Bella'}, {id: 2, type: 'dog', name: 'Sparky'}];
     *
     * @example
     * // Update (insert) with comparison function
     *
     * const creatures = [{id: 1, type: 'cat'}, {id: 2, type: 'dog'}];
     *
     * const newCat = {id: 3, type: 'lion'};
     *
     * const updatedCreatures = upsert(creatures, newCat, (a, b) => a.id === b.id);
     *
     * // updatedCreatures will be:
     * // [{id: 1, type: 'cat'}, {id: 2, type: 'dog'}, {id: 3, type: 'lion'}];
     *
     * @returns T[]
     *
     * @docsPage upsert
     * @docsCategory transformation-helpers
     */
    static upsert(pSource, pUpdate, pCompare) {
        // check inputs for validity
        const updatesAsArray = pUpdate != null ? (Array.isArray(pUpdate) ? pUpdate : [pUpdate]) : [];
        // check inputs for validity
        const sourceIsNotArray = !Array.isArray(pSource);
        const invalidInput = sourceIsNotArray && updatesAsArray.length === 0;
        // if the source value is not an Array or the input is not defined return the original source
        // this is the case for any edge case:
        // '', null, undefined, CustomObjectOfDoomAndDarkness, ...
        if (invalidInput) {
            return pSource;
        }
        // if source is empty array or not an array, but the updates are valid:
        // return a shallow copy of the updates as result
        if (updatesAsArray.length > 0 && (sourceIsNotArray || pSource.length === 0)) {
            return [...updatesAsArray];
        }
        const inserts = [];
        const updates = {};
        // process updates/inserts
        for (const item of updatesAsArray) {
            const match = pSource.findIndex(pSourceItem => valuesComparer(item, pSourceItem, pCompare));
            // if item already exists, save it as update
            if (match !== -1) {
                updates[match] = item;
            }
            else {
                // otherwise consider this as insert
                if (isObjectGuard(item)) {
                    // create a shallow copy if item is an object
                    inserts.push({ ...item });
                }
                else {
                    // otherwise just push it
                    inserts.push(item);
                }
            }
        }
        const updated = pSource.map((pItem, pIndex) => {
            const updatedItem = updates[pIndex];
            // process the updated
            if (updatedItem !== null && updatedItem !== undefined) {
                if (isObjectGuard(pItem)) {
                    return { ...pItem, ...updatedItem };
                }
                else {
                    return updatedItem;
                }
            }
            return pItem;
        });
        // return the combination of the updated source & the inserts as new array
        return updated.concat(inserts);
    }
    /**
     * Moves an element inside the given array from one index to another.
     * This function mutates the original array.
     *
     * @template T
     * @param {T[]} pArray - The array to modify.
     * @param {number} pFrom - The index of the element to move.
     * @param {number} pTo - The target index to move the element to.
     * @returns {T[]} The same array instance with the element moved.
     * @throws {RangeError} If the `from` index is out of bounds.
     *
     * @example
     * const arr = [10, 20, 30, 40];
     * Utils.moveMutable(arr, 0, 2);
     * console.log(arr); // [20, 30, 10, 40]
     */
    static moveMutable(pArray, pFrom, pTo) {
        if (pFrom < 0 || pFrom >= pArray.length) {
            throw new RangeError("Index 'from' is out of array bounds");
        }
        if (pTo < 0)
            pTo = 0;
        if (pTo >= pArray.length)
            pTo = pArray.length - 1;
        const element = pArray.splice(pFrom, 1)[0];
        pArray.splice(pTo, 0, element);
        return pArray;
    }
    /**
     * Removes all items from the array that match the given predicate.
     *
     * @template T
     * @param {T[]} pArray - The array to process.
     * @param {(value: T, index: number) => boolean} predicate - Function used to test each element.
     * If it returns `true`, the element will be removed.
     * @param {boolean} [pReturnNew=false] - If `true`, a new filtered array is returned and the original is unchanged.
     * If `false` (default), the array is modified in place.
     * @returns {T[] | void} - Returns a new array if `returnNew` is `true`, otherwise `void`.
     *
     * @example
     * // Mutates original array
     * let numbers = [1, 2, 3, 4, 5];
     * ArrayExtension.removeIf(numbers, n => n % 2 === 0);
     * console.log(numbers); // [1, 3, 5]
     *
     * @example
     * // Returns new array without modifying the original
     * let numbers2 = [1, 2, 3, 4, 5];
     * let oddNumbers = ArrayExtension.removeIf(numbers2, n => n % 2 === 0, true);
     * console.log(numbers2); // [1, 2, 3, 4, 5]
     * console.log(oddNumbers); // [1, 3, 5]
     */
    static removeIf(pArray, predicate, pReturnNew = false) {
        if (pReturnNew) {
            return pArray.filter((pItem, pIndex) => !predicate(pItem, pIndex));
        }
        let i = pArray.length;
        while (i--) {
            if (predicate(pArray[i], i)) {
                pArray.splice(i, 1);
            }
        }
        return pArray;
    }
    /**
     * Returns the last element of the provided array or `null` when the array is empty or not defined.
     * This is a safe utility that avoids accessing an out-of-bounds index on empty arrays.
     *
     * @typeParam T - Element type of the array.
     * @param pArray - The array to inspect.
     * @returns The last element of the array or `null` if the array is empty or falsy.
     *
     * @example
     * const nums = [1, 2, 3];
     * const last = ArrayExtension.peek(nums); // 3
     *
     * @example
     * const empty: number[] = [];
     * const nothing = ArrayExtension.peek(empty); // null
     */
    static peek(pArray) {
        if (!Array.isArray(pArray) || pArray.length === 0)
            return null;
        const peekIndex = pArray.length - 1;
        return pArray[peekIndex] ?? null;
    }
    /**
     * Returns the next item in the given array in a circular manner.
     *
     * - If the current item is found in the array, the function returns the next item.
     * - If the current item is the last element, it wraps around and returns the first element.
     * - If the current item does not exist in the array, it returns the first element.
     *
     * @template T - The type of elements in the array.
     * @param {T[]} pArray - The array to navigate through.
     * @param {T} pCurrentItem - The current item whose next item should be returned.
     * @returns {T} The next item in the array, or the first element if the current item is not found.
     */
    static nextItem(pArray, pCurrentItem) {
        const index = pArray.indexOf(pCurrentItem);
        if (index === -1) {
            return pArray[0];
        }
        const nextIndex = (index + 1) % pArray.length;
        return pArray[nextIndex];
    }
    /**
     * Returns the previous item in the given array in a circular manner.
     *
     * - If the current item is found in the array, the function returns the previous item.
     * - If the current item is the first element, it wraps around and returns the last element.
     * - If the current item does not exist in the array, it returns the last element.
     *
     * @template T - The type of elements in the array.
     * @param {T[]} pArray - The array to navigate through.
     * @param {T} pCurrentItem - The current item whose previous item should be returned.
     * @returns {T} The previous item in the array, or the last element if the current item is not found.
     */
    static previousItem(pArray, pCurrentItem) {
        const index = pArray.indexOf(pCurrentItem);
        if (index === -1)
            return pArray[pArray.length - 1];
        const prevIndex = (index - 1 + pArray.length) % pArray.length;
        return pArray[prevIndex];
    }
    /**
     * Asserts that a value is an array.
     *
     * @param pValue Value supposed to be an array.
     * @param pIsNullOK Whether null values are acceptable.
     * @return The array passed in.
     */
    static asArray(pValue, pIsNullOK = true) {
        assert((pIsNullOK && pValue == null) || BravoArrayExtensions.isArray(pValue), 'Array expected.');
        return pValue;
    }
    /**
     * Determines whether an object is an Array.
     *
     * @param pValue Value to test.
     */
    static isArray(pValue) {
        return (pValue instanceof Array || // doesn't work on different windows
            Array.isArray(pValue) || // doesn't work on derived classes
            Object.prototype.toString.call(pValue) === '[object Array]'); // always works
        // for a detailed discussion see
        // http://perfectionkills.com/instanceof-considered-harmful-or-how-to-write-a-robust-isarray/
    }
    /**
     * Returns the elements that are present in the first array but not in the second.
     *
     * @param {Array<string>} pArr1 - The array to compare from.
     * @param {Array<string>} pArr2 - The array to compare against.
     * @returns {Array<string>} A new array containing elements from `pArr1` that are not found in `pArr2`.
     *
     * @example
     * // Basic usage
     * BravoArrayExtensions.differenceArray(["apple", "banana", "cherry"], ["banana", "grape"]);
     * // → ["apple", "cherry"]
     *
     * @example
     * // When all elements overlap
     * BravoArrayExtensions.differenceArray(["a", "b"], ["a", "b"]);
     * // → []
     *
     * @example
     * // When there are no common elements
     * BravoArrayExtensions.differenceArray(["x", "y"], ["a", "b"]);
     * // → ["x", "y"]
     */
    static differenceArray = (pArr1, pArr2) => pArr1.filter(pElement1 => !pArr2.some(pElement2 => pElement1 === pElement2));
    /**
     * Compares two arrays and checks if all corresponding elements are equal.
     *
     * @template T - The type of elements in the arrays.
     * @param {T[]} pArr1 - The first array to compare.
     * @param {T[]} pArr2 - The second array to compare.
     * @param {(a: T, b: T) => boolean} [pCompareFn=(pA, pB) => pA === pB]
     *        A comparison callback that defines how two values are compared.
     *        Defaults to strict equality (`===`) comparison.
     *
     * @returns {boolean} Returns `true` if both arrays have the same length and
     *          every element pair satisfies the comparison function; otherwise `false`.
     *
     * @example
     * compareArray([1, 2, 3], [1, 2, 3]) // true
     * compareArray([1, 2], [1, 2, 3])    // false
     * compareArray([{id:1}], [{id:1}], (a,b) => a.id === b.id) // true
     */
    static compareArray(pArr1, pArr2, pCompareFn = (pA, pB) => pA === pB) {
        if (pArr1.length !== pArr2.length)
            return false;
        for (let i = 0; i < pArr1.length; i++) {
            if (!pCompareFn(pArr1[i], pArr2[i]))
                return false;
        }
        return true;
    }
}
const defaultCompareFn = (pItem1, pItem2) => pItem1 === pItem2;
function customFind(pArray, pFn) {
    for (const item of pArray) {
        const x = pFn(item);
        if (x) {
            return item;
        }
    }
    return undefined;
}
function valuesComparer(pOriginal, pIncoming, pCompare) {
    if (isKeyOf(pCompare)) {
        return pOriginal[pCompare] === pIncoming[pCompare];
    }
    if (Array.isArray(pCompare)) {
        const sanitizedKeys = pCompare.filter(pItem => isKeyOf(pItem));
        return sanitizedKeys.length > 0
            ? sanitizedKeys.every(pItem => pOriginal[pItem] === pIncoming[pItem])
            : defaultCompareFn(pOriginal, pIncoming);
    }
    return (pCompare || defaultCompareFn)(pOriginal, pIncoming);
}

/* eslint-disable @typescript-eslint/explicit-member-accessibility */
/**
 * A `Map`-like collection that uses a custom key comparator function.
 *
 * Useful when keys are complex objects (e.g., arrays or objects) that
 * require deep comparison or specialized equality checks.
 *
 * @template K The type of the keys.
 * @template V The type of the values.
 *
 * @example
 * const comparator = (a: { id: number }, b: { id: number }) => a.id === b.id;
 * const map = new BravoComparableMap(comparator);
 * map.set({ id: 1 }, "Apple");
 * map.set({ id: 2 }, "Banana");
 *
 * console.log(map.get({ id: 1 })); // "Apple"
 * console.log(map.size); // 2
 */
class BravoComparableMap {
    #entriesList = [];
    #comparator;
    /**
     * Creates a new instance of `BravoComparableMap`.
     *
     * @param {KeyComparator<K>} pComparator - A function to compare keys.
     * @param {Iterable<[K, V]>} [pInitial] - Optional initial entries to populate the map.
     *
     * @example
     * const map = new BravoComparableMap<number, string>((a, b) => a === b, [[1, "one"], [2, "two"]]);
     * console.log(map.get(1)); // "one"
     */
    constructor(pComparator, pInitial) {
        this.#comparator = pComparator;
        if (pInitial) {
            for (const [key, value] of pInitial) {
                this.set(key, value);
            }
        }
    }
    #findIndex(pKey) {
        return this.#entriesList.findIndex(pEntry => this.#comparator(pEntry.key, pKey));
    }
    /**
     * Adds or updates an entry in the map.
     *
     * @param {K} pKey - The key to set.
     * @param {V} pValue - The value to associate with the key.
     * @returns {this} The map instance (for chaining).
     *
     * @example
     * map.set({ id: 1 }, "Updated Apple").set({ id: 3 }, "Cherry");
     */
    set(pKey, pValue) {
        const index = this.#findIndex(pKey);
        if (index !== -1) {
            this.#entriesList[index].value = pValue;
        }
        else {
            this.#entriesList.push({ key: pKey, value: pValue });
        }
        return this;
    }
    /**
     * Retrieves the value associated with the given key.
     *
     * @param {K} pKey - The key to look up.
     * @returns {V | undefined} The associated value, or `undefined` if not found.
     *
     * @example
     * map.get({ id: 2 }); // "Banana"
     * map.get({ id: 99 }); // undefined
     */
    get(pKey) {
        const entry = this.#entriesList.find(pItem => this.#comparator(pItem.key, pKey));
        return entry?.value;
    }
    /**
     * Checks if the map contains the specified key.
     *
     * @param {K} pKey - The key to check.
     * @returns {boolean} `true` if the key exists, otherwise `false`.
     *
     * @example
     * map.has({ id: 1 }); // true
     * map.has({ id: 99 }); // false
     */
    has(pKey) {
        return this.#findIndex(pKey) !== -1;
    }
    /**
     * Removes an entry from the map by key.
     *
     * @param {K} pKey - The key to remove.
     * @returns {boolean} `true` if the entry was removed, otherwise `false`.
     *
     * @example
     * map.delete({ id: 2 }); // true
     * map.delete({ id: 99 }); // false
     */
    delete(pKey) {
        const index = this.#findIndex(pKey);
        if (index !== -1) {
            this.#entriesList.splice(index, 1);
            return true;
        }
        return false;
    }
    /**
     * Removes all entries from the map.
     *
     * @example
     * map.clear();
     * console.log(map.size); // 0
     */
    clear() {
        this.#entriesList = [];
    }
    /**
     * The number of entries in the map.
     *
     * @type {number}
     *
     * @example
     * console.log(map.size); // e.g., 2
     */
    get size() {
        return this.#entriesList.length;
    }
    /**
     * Returns an iterator over the map's keys.
     *
     * @returns {IterableIterator<K>} An iterator of keys.
     *
     * @example
     * for (const key of map.keys()) console.log(key);
     */
    keys() {
        return this.#entriesList.map(pItem => pItem.key)[Symbol.iterator]();
    }
    /**
     * Returns an iterator over the map's values.
     *
     * @returns {IterableIterator<V>} An iterator of values.
     *
     * @example
     * for (const value of map.values()) console.log(value);
     */
    values() {
        return this.#entriesList.map(pItem => pItem.value)[Symbol.iterator]();
    }
    /**
     * Returns an iterator over the map's `[key, value]` pairs.
     *
     * @returns {IterableIterator<[K, V]>} An iterator of entries.
     *
     * @example
     * for (const [key, value] of map.entries()) {
     *   console.log(key, value);
     * }
     */
    entries() {
        return this.#entriesList.map(pItem => [pItem.key, pItem.value])[Symbol.iterator]();
    }
    /**
     * Executes a provided function once per each key/value pair in the map.
     *
     * @param {(pValue: V, pKey: K, pMap: BravoComparableMap<K, V>) => void} pCallback - Function to execute for each entry.
     *
     * @example
     * map.forEach((value, key) => {
     *   console.log(key, value);
     * });
     */
    forEach(pCallback) {
        for (const { key, value } of this.#entriesList) {
            pCallback(value, key, this);
        }
    }
    /**
     * Returns a default iterator for the map, equivalent to `entries()`.
     *
     * @returns {IterableIterator<[K, V]>} An iterator of `[key, value]` pairs.
     *
     * @example
     * for (const [key, value] of map) {
     *   console.log(key, value);
     * }
     */
    [Symbol.iterator]() {
        return this.entries();
    }
}

/**
 * Describes the action that caused the @see:INotifyCollectionChanged.collectionChanged
 * event to fire.
 */
var NotifyCollectionChangedActionEnum;
(function (NotifyCollectionChangedActionEnum) {
    /** An item was added to the collection. */
    NotifyCollectionChangedActionEnum[NotifyCollectionChangedActionEnum["Add"] = 0] = "Add";
    /** An item was removed from the collection. */
    NotifyCollectionChangedActionEnum[NotifyCollectionChangedActionEnum["Remove"] = 1] = "Remove";
    /** An item was changed or replaced. */
    NotifyCollectionChangedActionEnum[NotifyCollectionChangedActionEnum["Change"] = 2] = "Change";
    /**
     * Several items changed simultaneously
     * (for example, the collection was sorted, filtered, or grouped).
     */
    NotifyCollectionChangedActionEnum[NotifyCollectionChangedActionEnum["Reset"] = 3] = "Reset";
})(NotifyCollectionChangedActionEnum || (NotifyCollectionChangedActionEnum = {}));

/**
 * Provides data for the @see:INotifyCollectionChanged.collectionChanged event.
 */
class NotifyCollectionChangedEventArgs {
    /**
     * Provides a value to use with events that do not have event data.
     */
    static empty = new NotifyCollectionChangedEventArgs();
    /**
     * Provides a reset notification.
     */
    static reset = new NotifyCollectionChangedEventArgs(NotifyCollectionChangedActionEnum.Reset);
    /**
     * Gets the action that caused the event to fire.
     */
    action;
    /**
     * Gets the item that was added, removed, or changed.
     */
    item;
    /**
     * Gets the index at which the change occurred.
     */
    index;
    /**
     * Initializes a new instance of the @see:NotifyCollectionChangedEventArgs class.
     *
     * @param pAction Type of action that caused the event to fire.
     * @param pItem Item that was added or changed.
     * @param pIndex Index of the item.
     */
    constructor(pAction = NotifyCollectionChangedActionEnum.Reset, pItem, pIndex = -1) {
        this.action = pAction;
        this.item = pItem;
        this.index = pIndex;
    }
}

/* eslint-disable @typescript-eslint/no-unsafe-function-type */
/**
 * Base class for Array classes with notifications.
 */
class ArrayBase extends Array {
    /**
     * Initializes a new instance of the @see:ArrayBase class.
     */
    constructor() {
        if (!canChangePrototype) {
            super();
        }
    }
}
let canChangePrototype = true;
try {
    ArrayBase.prototype = Array.prototype;
    canChangePrototype = ArrayBase.prototype === Array.prototype; // check in case where assignment was just ignored
}
catch (pExe) {
    canChangePrototype = false;
}
// In ES6 without this Symbol.species property, the methods returning an array will return instance
// of the derived class instead of a native Array.
const symbol = window['Symbol'];
if (!canChangePrototype && symbol && symbol.species) {
    Object.defineProperty(ArrayBase, symbol.species, {
        get: function () {
            return Array;
        },
        enumerable: false,
        configurable: false,
    });
}
/**
 * Array that sends notifications on changes.
 *
 * The class raises the @see:collectionChanged event when changes are made with
 * the push, pop, splice, insert, or remove methods.
 *
 * Warning: Changes made by assigning values directly to array members or to the
 * length of the array do not raise the @see:collectionChanged event.
 */
class ObservableArray extends ArrayBase {
    #updating = 0;
    /**
     * Initializes a new instance of the @see:ObservableArray class.
     *
     * @param pData Array containing items used to populate the @see:ObservableArray.
     */
    constructor(pData) {
        super();
        // initialize the array
        if (pData) {
            pData = BravoArrayExtensions.asArray(pData);
            this.#updating++;
            for (let i = 0; i < pData.length; i++) {
                this.push(pData[i]);
            }
            this.#updating--;
        }
    }
    /**
     * Adds one or more items to the end of the array.
     *
     * @param ...item One or more items to add to the array.
     * @return The new length of the array.
     */
    push(...item) {
        let length = this.length;
        for (let i = 0; item && i < item.length; i++) {
            length = super.push(item[i]);
            if (!this.#updating) {
                this.#raiseCollectionChanged(NotifyCollectionChangedActionEnum.Add, item[i], length - 1);
            }
        }
        return length;
    }
    /*
     * Removes the last item from the array.
     *
     * @return The item that was removed from the array.
     */
    pop() {
        const item = super.pop();
        this.#raiseCollectionChanged(NotifyCollectionChangedActionEnum.Remove, item, this.length);
        return item;
    }
    /**
     * Removes and/or adds items to the array.
     *
     * @param index Position where items will be added or removed.
     * @param count Number of items to remove from the array.
     * @param item Item to add to the array.
     * @return An array containing the removed elements.
     */
    splice(index, count, item) {
        let rv;
        const action = NotifyCollectionChangedActionEnum;
        if (count && item) {
            // add and remove items (argh)
            rv = super.splice(index, count, item);
            if (count == 1) {
                this.#raiseCollectionChanged(action.Change, item, index);
            }
            else {
                this.#raiseCollectionChanged();
            }
            return rv;
        }
        else if (item) {
            // add a value to the array
            rv = super.splice(index, 0, item);
            this.#raiseCollectionChanged(action.Add, item, index);
            return rv;
        }
        else {
            // remove one or more items from the array
            rv = super.splice(index, count);
            if (count == 1) {
                this.#raiseCollectionChanged(action.Remove, rv[0], index);
            }
            else {
                this.#raiseCollectionChanged();
            }
            return rv;
        }
    }
    /**
     * Creates a shallow copy of a portion of an array.
     *
     * @param pBegin Position where the copy starts.
     * @param pEnd Position where the copy ends.
     * @return A shallow copy of a portion of an array.
     */
    slice(pBegin, pEnd) {
        return super.slice(pBegin, pEnd);
    }
    /**
     * Searches for an item in the array.
     *
     * @param pSearchElement Element to locate in the array.
     * @param pFromIndex The index where the search should start.
     * @return The index of the item in the array, or -1 if the item was not found.
     */
    indexOf(pSearchElement, pFromIndex) {
        return super.indexOf(pSearchElement, pFromIndex);
    }
    /**
     * Sorts the elements of the array in place.
     *
     * @param pCompareFn Specifies a function that defines the sort order.
     * If specified, the function should take two arguments and should return
     * -1, +1, or 0 to indicate the first argument is smaller, greater than,
     * or equal to the second argument.
     * If omitted, the array is sorted in dictionary order according to the
     * string conversion of each element.
     * @return A copy of the sorted array.
     */
    sort(pCompareFn) {
        const rv = super.sort(pCompareFn);
        this.#raiseCollectionChanged();
        return rv;
    }
    /**
     * Inserts an item at a specific position in the array.
     *
     * @param pIndex Position where the item will be added.
     * @param pItem Item to add to the array.
     */
    insert(pIndex, pItem) {
        this.splice(pIndex, 0, pItem);
    }
    /**
     * Removes an item from the array.
     *
     * @param pItem Item to remove.
     * @return True if the item was removed, false if it wasn't found in the array.
     */
    remove(pItem) {
        const index = this.indexOf(pItem);
        if (index > -1) {
            this.removeAt(index);
            return true;
        }
        return false;
    }
    /**
     * Removes an item at a specific position in the array.
     *
     * @param pIndex Position of the item to remove.
     */
    removeAt(pIndex) {
        this.splice(pIndex, 1);
    }
    /**
     * Assigns an item at a specific position in the array.
     *
     * @param pIndex Position where the item will be assigned.
     * @param pItem Item to assign to the array.
     */
    setAt(pIndex, pItem) {
        // make sure we have enough elements to set at the right index!
        if (pIndex > this.length) {
            this.length = pIndex;
        }
        // go ahead and splice now
        this.splice(pIndex, 1, pItem);
    }
    /**
     * Removes all items from the array.
     */
    clear() {
        if (this.length) {
            this.splice(0, this.length); // safer than setting length = 0
            //this.length = 0; // fastest way to clear an array
            //this._raiseCollectionChanged(); // no need, splice handled it TFS 317728
        }
    }
    /**
     * Suspends notifications until the next call to @see:endUpdate.
     */
    beginUpdate() {
        this.#updating++;
    }
    /**
     * Resumes notifications suspended by a call to @see:beginUpdate.
     */
    endUpdate() {
        if (this.#updating > 0) {
            this.#updating--;
            if (this.#updating == 0) {
                this.#raiseCollectionChanged();
            }
        }
    }
    /**
     * Gets a value that indicates whether notifications are currently suspended
     * (see @see:beginUpdate and @see:endUpdate).
     */
    get isUpdating() {
        return this.#updating > 0;
    }
    /**
     * Executes a function within a @see:beginUpdate/@see:endUpdate block.
     *
     * The collection will not be refreshed until the function finishes.
     * This method ensures @see:endUpdate is called even if the function throws
     * an exception.
     *
     * @param pCallback Function to be executed without updates.
     */
    deferUpdate(pCallback) {
        try {
            this.beginUpdate();
            pCallback();
        }
        finally {
            this.endUpdate();
        }
    }
    // ** IQueryInterface
    // ** INotifyCollectionChanged
    _collectionChanged$ = new Subject();
    /**
     * Occurs when the collection changes.
     */
    get collectionChanged$() {
        return this._collectionChanged$.asObservable();
    }
    /**
     * Raises the @see:collectionChanged event.
     *
     * @param e Contains a description of the change.
     */
    onCollectionChanged(e) {
        if (!this.isUpdating) {
            this._collectionChanged$.next(e);
        }
    }
    // creates event args and calls onCollectionChanged
    #raiseCollectionChanged(action = NotifyCollectionChangedActionEnum.Reset, item, index) {
        if (!this.isUpdating) {
            const e = new NotifyCollectionChangedEventArgs(action, item, index);
            this.onCollectionChanged(e);
        }
    }
    dispose() {
        this._collectionChanged$.complete();
        this._collectionChanged$.unsubscribe();
    }
}

class ObservableMap extends Map {
    #updating = 0;
    /**
     * Initializes a new instance of the ObservableMap class.
     *
     * @param pEntries Optional array of key-value pairs to initialize the map.
     */
    constructor(pEntries) {
        super(pEntries);
    }
    /**
     * Sets a key-value pair in the map.
     *
     * @param pKey The key of the element to add or update.
     * @param pValue The value of the element to add or update.
     */
    set(pKey, pValue) {
        const action = this.has(pKey)
            ? NotifyCollectionChangedActionEnum.Change
            : NotifyCollectionChangedActionEnum.Add;
        super.set(pKey, pValue);
        if (!this.#updating) {
            this.#raiseCollectionChanged(action, { key: pKey, value: pValue });
        }
        return this;
    }
    /**
     * Removes a key-value pair from the map by key.
     *
     * @param pKey The key of the element to remove.
     * @returns True if the element existed and was removed; otherwise, false.
     */
    delete(pKey) {
        if (this.has(pKey)) {
            const value = this.get(pKey);
            super.delete(pKey);
            if (!this.#updating && value) {
                this.#raiseCollectionChanged(NotifyCollectionChangedActionEnum.Remove, { key: pKey, value });
            }
            return true;
        }
        return false;
    }
    /**
     * Clears all key-value pairs from the map.
     */
    clear() {
        if (this.size > 0) {
            if (!this.#updating) {
                this.forEach((pVal, pKey) => {
                    this.delete(pKey);
                });
                this.#raiseCollectionChanged(NotifyCollectionChangedActionEnum.Reset);
            }
        }
    }
    /**
     * Suspends notifications until the next call to endUpdate.
     */
    beginUpdate() {
        this.#updating++;
    }
    /**
     * Resumes notifications suspended by a call to beginUpdate.
     */
    endUpdate() {
        if (this.#updating > 0) {
            this.#updating--;
            if (this.#updating === 0) {
                this.#raiseCollectionChanged(NotifyCollectionChangedActionEnum.Reset);
            }
        }
    }
    /**
     * Gets a value indicating whether notifications are currently suspended.
     */
    get isUpdating() {
        return this.#updating > 0;
    }
    /**
     * Executes a function within a beginUpdate/endUpdate block.
     *
     * @param pCallback Function to execute.
     */
    deferUpdate(pCallback) {
        try {
            this.beginUpdate();
            pCallback();
        }
        finally {
            this.endUpdate();
        }
    }
    get lastItem() {
        const toArray = Array.from(this.values());
        return toArray[toArray.length - 1] || null;
    }
    // ** INotifyCollectionChanged
    /**
     * Occurs when the collection changes.
     */
    _collectionChanged$ = new Subject();
    /**
     * Occurs when the collection changes.
     */
    get collectionChanged$() {
        return this._collectionChanged$.asObservable();
    }
    /**
     * Raises the collectionChanged event.
     *
     * @param pAction The action that caused the event.
     * @param pItem The item involved in the action (if applicable).
     */
    #raiseCollectionChanged(pAction, pItem) {
        if (!this.isUpdating) {
            const e = new NotifyCollectionChangedEventArgs(pAction, pItem);
            this._collectionChanged$.next(e);
        }
    }
    dispose() {
        this._collectionChanged$.complete();
        this._collectionChanged$.unsubscribe();
    }
}

/**
 * Utility class for handling and converting values to booleans or numeric equivalents.
 */
class BravoBooleanExtensions {
    /**
     * The lowercase string representation of `true`.
     * @type {string}
     */
    static trueString = 'true';
    /**
     * The lowercase string representation of `false`.
     * @type {string}
     */
    static falseString = 'false';
    /**
     * Converts a given value to a boolean.
     *
     * Recognized truthy values:
     * - `true`
     * - `'True'` (case-insensitive)
     * - `'true'`
     * - `1`
     * - `'1'`
     *
     * All other values are considered `false`.
     *
     * @param {any} pValue - The value to convert.
     * @returns {boolean} The boolean representation of the input.
     *
     * @example
     * BooleanExtension.asBoolean(true);       // true
     * BooleanExtension.asBoolean('True');     // true
     * BooleanExtension.asBoolean('true');     // true
     * BooleanExtension.asBoolean(1);          // true
     * BooleanExtension.asBoolean('1');        // true
     * BooleanExtension.asBoolean('false');    // false
     * BooleanExtension.asBoolean(0);          // false
     * BooleanExtension.asBoolean(null);       // false
     */
    static asBoolean(pValue) {
        if (pValue === true ||
            pValue === 'True' ||
            `${pValue}`.toLowerCase() === BravoBooleanExtensions.trueString ||
            pValue === 1 ||
            pValue === '1') {
            return true;
        }
        return false;
    }
    /**
     * Checks whether a given value can be interpreted as a boolean.
     *
     * Recognized boolean-like values:
     * - `true`, `false`
     * - `'True'`, `'False'`
     * - `'true'`, `'false'`
     *
     * @param {any} pValue - The value to check.
     * @returns {boolean} `true` if the value represents a boolean, otherwise `false`.
     *
     * @example
     * BooleanExtension.isBoolean(true);       // true
     * BooleanExtension.isBoolean('False');    // true
     * BooleanExtension.isBoolean('true');     // true
     * BooleanExtension.isBoolean('yes');      // false
     * BooleanExtension.isBoolean(1);          // false
     */
    static isBoolean(pValue) {
        if (typeof pValue === 'boolean' ||
            pValue === 'True' ||
            pValue === 'False' ||
            `${pValue}`.toLowerCase() === BravoBooleanExtensions.trueString ||
            `${pValue}`.toLowerCase() === BravoBooleanExtensions.falseString) {
            return true;
        }
        return false;
    }
    /**
     * Converts a value to a number based on its boolean interpretation.
     *
     * - Returns `1` if the value is considered `true` (per {@link asBoolean} rules)
     * - Returns `0` otherwise.
     *
     * @param {any} pValue - The value to convert.
     * @returns {number} `1` for truthy values, `0` otherwise.
     *
     * @example
     * BooleanExtension.asNumber(true);      // 1
     * BooleanExtension.asNumber('True');    // 1
     * BooleanExtension.asNumber('false');   // 0
     * BooleanExtension.asNumber(0);         // 0
     * BooleanExtension.asNumber('yes');     // 0
     */
    static asNumber(pValue) {
        return this.asBoolean(pValue) ? 1 : 0;
    }
    static toBoolean(pValue) {
        if (pValue == true || pValue == 'True' || `${pValue}`.toLowerCase() == 'true' || pValue == 1 || pValue == '1')
            return true;
        return false;
    }
}

/**
 * Utility class for encoding, decoding, and converting binary data.
 */
class BravoConverterExtensions {
    /**
     * Base64 character set used for encoding/decoding.
     */
    static #chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
    /**
     * Converts a byte array (`Uint8Array` or `ArrayBuffer`) to a Base64-encoded string.
     *
     * @param pBuff - Input data as `Uint8Array` or `ArrayBuffer`.
     * @returns Base64-encoded string.
     *
     * @example
     * const bytes = new Uint8Array([72, 101, 108, 108, 111]); // "Hello"
     * const base64 = Convert.toBase64String(bytes);
     * console.log(base64); // "SGVsbG8="
     */
    static toBase64String(pBuff) {
        const bytes = pBuff instanceof ArrayBuffer ? new Uint8Array(pBuff) : pBuff;
        const len = bytes?.length;
        let i, base64 = '';
        for (i = 0; i < len; i += 3) {
            base64 += this.#chars[bytes[i] >> 2];
            base64 += this.#chars[((bytes[i] & 3) << 4) | (bytes[i + 1] >> 4)];
            base64 += this.#chars[((bytes[i + 1] & 15) << 2) | (bytes[i + 2] >> 6)];
            base64 += this.#chars[bytes[i + 2] & 63];
        }
        if (len % 3 === 2) {
            base64 = base64.substring(0, base64.length - 1) + '=';
        }
        else if (len % 3 === 1) {
            base64 = base64.substring(0, base64.length - 2) + '==';
        }
        return base64;
    }
    /**
     * Decodes a Base64-encoded string into a `Uint8Array`.
     *
     * @param pBase64 - Base64 string to decode.
     * @returns Decoded data as a `Uint8Array`.
     *
     * @example
     * const base64 = "SGVsbG8=";
     * const bytes = Convert.fromBase64String(base64);
     * console.log(new TextDecoder().decode(bytes)); // "Hello"
     */
    static fromBase64String(pBase64) {
        // Use a lookup table to find the index.
        const lookup = new Uint8Array(256);
        for (let i = 0; i < this.#chars.length; i++) {
            lookup[this.#chars.charCodeAt(i)] = i;
        }
        const len = pBase64.length;
        let bufferLength = pBase64.length * 0.75, i, p = 0, encoded1, encoded2, encoded3, encoded4;
        if (pBase64[pBase64.length - 1] === '=') {
            bufferLength--;
            if (pBase64[pBase64.length - 2] === '=') {
                bufferLength--;
            }
        }
        const arraybuffer = new ArrayBuffer(bufferLength), bytes = new Uint8Array(arraybuffer);
        for (i = 0; i < len; i += 4) {
            encoded1 = lookup[pBase64.charCodeAt(i)];
            encoded2 = lookup[pBase64.charCodeAt(i + 1)];
            encoded3 = lookup[pBase64.charCodeAt(i + 2)];
            encoded4 = lookup[pBase64.charCodeAt(i + 3)];
            bytes[p++] = (encoded1 << 2) | (encoded2 >> 4);
            bytes[p++] = ((encoded2 & 15) << 4) | (encoded3 >> 2);
            bytes[p++] = ((encoded3 & 3) << 6) | (encoded4 & 63);
        }
        return bytes;
    }
    /**
     * Wraps an `ArrayBuffer` into a `Blob`.
     *
     * @param pBuffer - The ArrayBuffer to convert.
     * @returns A `Blob` containing the ArrayBuffer data.
     *
     * @example
     * const buffer = new TextEncoder().encode("Hello").buffer;
     * const blob = Convert.arrBufferToBlob(buffer);
     * console.log(blob instanceof Blob); // true
     */
    static arrBufferToBlob(pBuffer) {
        return new Blob([pBuffer]);
    }
    /**
     * Wraps a `Uint8Array` into a `Blob` with MIME type `octet/stream`.
     *
     * @param pUnit8Array - The Uint8Array to convert.
     * @returns A `Blob` containing the Uint8Array data.
     *
     * @example
     * const bytes = new Uint8Array([72, 101, 108, 108, 111]);
     * const blob = Convert.unit8ArrToBlob(bytes);
     * console.log(blob instanceof Blob); // true
     */
    static unit8ArrToBlob(pUnit8Array) {
        return new Blob([pUnit8Array], { type: 'octet/stream' });
    }
    /**
     * Convert Base64 DataURL to Blob
     * @param pBase64Data -  base64 (DataURL), exam: "data:image/png;base64,iVBORw0KGgo..."
     */
    static base64ToBlob(pBase64Data) {
        const parts = pBase64Data.split(',');
        const mime = parts[0].match(/:(.*?);/)?.[1] || 'application/octet-stream';
        const byteString = atob(parts[1]);
        const ab = new ArrayBuffer(byteString.length);
        const ia = new Uint8Array(ab);
        for (let i = 0; i < byteString.length; i++) {
            ia[i] = byteString.charCodeAt(i);
        }
        return new Blob([ab], { type: mime });
    }
    /**
     * @function isBase64
     * @description Checks whether a given string is a valid Base64-encoded string.
     * @param {string} pStr - The string to check.
     * @returns {boolean} - Returns `true` if the string is a valid Base64-encoded string, otherwise returns `false`.
     *
     * @example
     * console.log(FileUtil.isBase64("SGVsbG8gd29ybGQ=")); // ✅ true
     * console.log(FileUtil.isBase64("NotBase64@"));       // ❌ false
     */
    static isBase64(pStr) {
        try {
            return btoa(atob(pStr)) === pStr;
        }
        catch (_) {
            return false;
        }
    }
    /**
     * Converts a Blob object to a Uint8Array.
     *
     * @param {Blob} pBlob - The Blob object to be converted.
     * @returns {Promise<Uint8Array>} A promise that resolves with the Uint8Array representation of the Blob.
     *
     * @example
     * const blob = new Blob([new Uint8Array([1, 2, 3])]);
     * BlobUtils.blobToUint8Array(blob).then(uint8Array => {
     *     console.log(uint8Array); // Uint8Array [1, 2, 3]
     * });
     */
    static blobToUint8Array(pBlob) {
        return new Promise((pResolve, pReject) => {
            const reader = new FileReader();
            reader.onload = () => pResolve(new Uint8Array(reader.result));
            reader.onerror = pReject;
            reader.readAsArrayBuffer(pBlob);
        });
    }
}

class BravoNumberExtensions {
    /**
     * Checks whether a given value is a valid number.
     *
     * @param {any} pValue - The value to check.
     * @returns {pValue is number} `true` if the value is a number or a numeric string, otherwise `false`.
     *
     * @example
     * BravoNumberExtensions.isNumber(123); // true
     * BravoNumberExtensions.isNumber("123.45"); // true
     * BravoNumberExtensions.isNumber("abc"); // false
     */
    static isNumber(pValue) {
        return isNumber(pValue);
    }
    /**
     * Converts a given value to a number if possible.
     *
     * @param {any} pValue - The value to convert.
     * @returns {number} The numeric value if conversion succeeds, otherwise `NaN`.
     *
     * @example
     * BravoNumberExtensions.asNumber("12.34"); // 12.34
     * BravoNumberExtensions.asNumber(42); // 42
     * BravoNumberExtensions.asNumber("abc"); // NaN
     */
    static asNumber(pValue, pNullOK = false, positive = false) {
        return asNumber(pValue, pNullOK, positive);
    }
    /**
     * Asserts that a value is an integer.
     *
     * @param pValue Value supposed to be an integer.
     * @param pIsNullOK Whether null values are acceptable.
     * @param pIsPositive Whether to accept only positive integers.
     * @return The number passed in.
     */
    static asInt(pValue, pIsNullOK = false, pIsPositive = false) {
        assert((pIsNullOK && pValue == null) || BravoNumberExtensions.isInt(pValue), 'Integer expected.');
        if (pIsPositive && pValue && pValue < 0)
            throw 'Positive integer expected.';
        return pValue;
    }
    static isInt(pValue) {
        return BravoNumberExtensions.isNumber(pValue) && pValue == Math.round(pValue);
    }
    /**
     * Rounds a number to the specified number of decimal digits.
     *
     * @param {number} pValue - The number to round.
     * @param {number} pDigits - The number of digits after the decimal point.
     * @returns {number} The rounded number.
     *
     * @example
     * BravoNumberExtensions.round(3.14159, 2); // 3.14
     * BravoNumberExtensions.round(1.005, 2); // 1.01
     */
    static round(pValue, pDigits) {
        if (pDigits >= 0) {
            return Number(pValue.toFixed(pDigits));
        }
        pDigits = Math.abs(pDigits);
        let temp = pValue / Math.pow(10, pDigits);
        temp = Number(temp.toFixed(0));
        return temp * Math.pow(10, pDigits);
    }
    /**
     * Formats a number as a string with padding and fixed decimal precision.
     *
     * @param {number} pValue - The number to format.
     * @param {number} pLength - The total length of the formatted string (including decimals).
     * @param {number} pScale - The number of digits after the decimal point.
     * @returns {string} The formatted string.
     *
     * @example
     * BravoNumberExtensions.str(123.456, 8, 2); // "   123.46"
     * BravoNumberExtensions.str(5, 6, 0); // "     5"
     */
    static str(pValue, pLength, pScale) {
        let number = pValue;
        if (pScale > 0) {
            number = this.round(pValue, pScale);
        }
        const text = number.toString();
        const arr = text.split('.');
        let intText;
        if (pScale > 0) {
            const intLen = pLength - pScale - 1;
            intText = arr[0].substring(Math.max(0, arr[0].length - intLen));
            if (arr.length > 1) {
                const decText = arr.length > 0 ? arr[1].substring(0, Math.min(pScale, arr[1].length)) : '';
                return intText.padStart(intLen, ' ') + '.' + decText.padEnd(pScale, '0');
            }
            else {
                return intText.padStart(intLen, ' ') + '.' + ''.padEnd(pScale, '0');
            }
        }
        intText = arr[0].substring(Math.max(0, arr[0].length - pLength));
        return intText.padStart(pLength, ' ');
    }
    /**
     * Converts a value to a number, returning 0 if the conversion fails.
     *
     * @param {unknown} pValue - The value to convert.
     * @returns {number} The numeric value, or 0 if invalid.
     *
     * @example
     * BravoNumberExtensions.numberWithZeroFallback("123"); // 123
     * BravoNumberExtensions.numberWithZeroFallback("abc"); // 0
     */
    static numberWithZeroFallback(pValue) {
        return numberAttribute(pValue, 0);
    }
    static toNumber(pValue, pFallbackValue = 0) {
        if (BravoNumberExtensions.isNumber(pValue))
            return Number(pValue);
        return arguments.length === 2 ? pFallbackValue : 0;
    }
    /**
     * Checks if the given value is a finite number (not Infinity or NaN).
     *
     * @param pValue The value to check.
     * @returns True if the value is a finite number, otherwise false.
     *
     * @example
     * NumberExtension.isNumberFinite(5); // true
     * NumberExtension.isNumberFinite(Infinity); // false
     * NumberExtension.isNumberFinite('5'); // false
     */
    static isNumberFinite(pValue) {
        return typeof pValue === 'number' && isFinite(pValue);
    }
    /**
     * Rounds a number to a specified number of decimal places.
     *
     * @param pValue The number to round.
     * @param pDecimal The number of decimal places.
     * @returns The rounded number.
     *
     * @example
     * NumberExtension.toDecimal(3.14159, 2); // 3.14
     */
    static toDecimal(pValue, pDecimal) {
        return Math.round(pValue * Math.pow(10, pDecimal)) / Math.pow(10, pDecimal);
    }
    /**
     * Calculates the sum of an array of numbers, starting from an optional initial value.
     *
     * @param pInput The array of numbers to sum.
     * @param pInitial The initial value to start the sum (default is 0).
     * @returns The sum of the numbers.
     *
     * @example
     * NumberExtension.sum([1, 2, 3]); // 6
     * NumberExtension.sum([1, 2, 3], 10); // 16
     */
    static sum(pInput, pInitial = 0) {
        return pInput.reduce((pPRevious, pCurrent) => pPRevious + pCurrent, pInitial);
    }
    /**
     * Formats a number using the current culture.
     *
     * The @see:formatNumber method accepts most .NET-style
     * <a href="http://msdn.microsoft.com/en-us/library/dwhawy9k(v=vs.110).aspx">
     * Standard Numeric Format Strings</a>, except for the 'e' and 'x' formats
     * (scientific notation and hexadecimal) which are not supported.
     *
     * Numeric format strings take the form <i>Axxsscc</i>, where:
     * <ul>
     * <li>
     *  <i>A</i> is a single case-insensitive alphabetic character called the
     *  format specifier.</li>
     * <li>
     *  <i>xx</i> is an optional integer called the precision specifier.
     *  The precision specifier affects the number of digits in the result.</li>
     * <li>
     *  <i>ss</i> is an optional string used to scale the number. If provided,
     *  it must consist of commas. The number is divided by 1000 for each comma
     *  specified.</li>
     * <li>
     *  <i>cc</i> is an optional string used to override the currency symbol
     *  when formatting currency values. This is useful when formatting
     *  currency values for cultures different than the current default
     *  (for example, when formatting Euro or Yen values in applications
     *  that use the English culture).</li>
     * </ul>
     *
     * The following table describes the standard numeric format specifiers and
     * displays sample output produced by each format specifier for the default
     * culture.
     *
     * <b>n</b> Number: <code>formatNumber(1234.5, 'n2') => '1,234.50'</code><br/>
     * <b>f</b> Fixed-point: <code>formatNumber(1234.5, 'f2') => '1234.50'</code><br/>
     * <b>g</b> General (no trailing zeros): <code>formatNumber(1234.5, 'g2') => '1234.5'</code><br/>
     * <b>d</b> Decimal (integers): <code>formatNumber(-1234, 'd6') => '-001234'</code><br/>
     * <b>x</b> Hexadecimal (integers): <code>formatNumber(1234, 'x6') => '0004d2'</code><br/>
     * <b>c</b> Currency: <code>formatNumber(1234, 'c') => '$ 1,234.00'</code><br/>
     * <b>p</b> Percent: <code>formatNumber(0.1234, 'p2') => '12.34 %'</code>
     *
     * The scaling specifier is especially useful when charting large values. For
     * example, the markup below creates a chart that plots population versus GDP.
     * The raw data expresses the population is units and the GDP in millions.
     * The scaling specified in the axes formats causes the chart to show population
     * in millions and GDP in trillions:
     *
     * <pre>&lt;wj-flex-chart
     *   items-source="countriesGDP" binding-x="pop" chart-type="Scatter"&gt;
     *   &lt;wj-flex-chart-series
     *     name="GDP" binding="gdp"&gt;&lt;/wj-flex-chart-series&gt;
     *   &lt;wj-flex-chart-axis
     *     wj-property="axisX" title="Population (millions)"
     *     format="n0,,"&gt;
     *   &lt;/wj-flex-chart-axis&gt;
     *   &lt;wj-flex-chart-axis
     *     wj-property="axisY" title="GDP (US$ trillions)"
     *     format="c0,,"&gt;
     *   &lt;/wj-flex-chart-axis&gt;
     * &lt;/wj-flex-chart&gt;</pre>
     *
     * @param pValue Number to format.
     * @param pFormat .NET-style standard numeric format string (e.g. 'n2', 'c4', 'p0', 'g2', 'd2').
     * @param pIsTrim Whether to remove trailing zeros from the result.
     * @param pIsTruncate Whether to truncate the value rather than round it.
     * @return A string representation of the given number.
     */
    static format(pValue, pFormat, pIsTrim, pIsTruncate = false) {
        if (!pFormat)
            return pValue.toString();
        pValue = BravoNumberExtensions.asNumber(pValue);
        const nf = BravoAppSettings.settings.numberFormat, m = pFormat ? pFormat.match(/([a-z])(\d*)(,*)(.*)/i) : null, f1 = m ? m[1].toLowerCase() : 'n', prec = m && m[2] ? parseInt(m[2]) : f1 == 'c' ? nf.currency.decimals : pValue == Math.round(pValue) ? 0 : 2, scale = m && m[3] ? 3 * m[3].length : 0, dp = nf['.'] || '.', ts = nf[','] || ',', neg = nf['-'] || '-';
        let result;
        // scale (,:thousands ,,:millions ,,,:billions)
        if (scale) {
            pValue /= Math.pow(10, scale);
        }
        // d, x: integers/hexadecimal
        if (f1 == 'd' || f1 == 'x') {
            result = Math.round(Math.abs(pValue)).toString(f1 == 'd' ? 10 : 16);
            while (result.length < prec) {
                result = '0' + result;
            }
            if (pValue < 0) {
                result = neg + result;
            }
            if (pFormat && pFormat[0] == 'X') {
                result = result.toUpperCase();
            }
            return result;
        }
        // p: percentage
        if (f1 == 'p') {
            pValue = BravoNumberExtensions.#mul100(pValue); // TFS 210383
            pValue = BravoNumberExtensions.toFixed(pValue, prec, pIsTruncate); // TFS 227998
        }
        // truncate value
        if (pIsTruncate && f1 != 'p') {
            pValue = BravoNumberExtensions.toFixed(pValue, prec, true);
        }
        // get result
        result = BravoNumberExtensions.#toFixedStr(f1 == 'c' || f1 == 'p' ? Math.abs(pValue) : pValue, prec);
        // g: remove trailing zeros
        if ((pIsTrim || f1 == 'g') && result.indexOf('.') > -1) {
            result = result.replace(/(\.[0-9]*?)0+$/g, '$1');
            result = result.replace(/\.$/, '');
        }
        // replace decimal point
        if (dp != '.') {
            result = result.replace('.', dp);
        }
        // replace negative character
        if (neg != '-') {
            result = result.replace('-', neg);
        }
        // n, c, p: insert thousand separators (before decimal/neg replacements)
        if (ts && (f1 == 'n' || f1 == 'c' || f1 == 'p')) {
            const idx = result.indexOf(dp), rx = /\B(?=(\d\d\d)+(?!\d))/g;
            result = idx > -1 ? result.substr(0, idx).replace(rx, ts) + result.substr(idx) : result.replace(rx, ts);
        }
        // c: currency pattern
        if (f1 == 'c') {
            const pat = nf.currency.pattern[pValue < 0 ? 0 : 1];
            let curr = m && m[4] ? m[4] : nf.currency.symbol;
            if (curr == '\u200B') {
                // invisible space: TFS 295426
                curr = '';
            }
            result = pat.replace('n', result).replace('$', curr);
        }
        // p: percentage pattern
        if (f1 == 'p') {
            const pat = nf.percent.pattern[pValue < 0 ? 0 : 1], pct = nf['%'] || '%';
            result = pat.replace('n', result);
            if (pct != '%')
                result = result.replace('%', pct);
            if (neg != '-' && pValue < 0)
                result = result.replace('-', neg);
        }
        // done
        return result;
    }
    /**
     * Parses a string into an integer.
     *
     * @param pValue String to convert to an integer.
     * @param pFormat Format to use when parsing the number.
     * @return The integer represented by the given string,
     * or <b>NaN</b> if the string cannot be parsed into an integer.
     */
    static parseInt(pValue, pFormat) {
        return Math.round(BravoNumberExtensions.parseFloat(pValue, pFormat));
    }
    /**
     * Parses a string into a floating point number.
     *
     * @param pValue String to convert to a number.
     * @param pFormat Format to use when parsing the number.
     * @return The floating point number represented by the given string,
     * or <b>NaN</b> if the string cannot be parsed into a floating point number.
     */
    static parseFloat(pValue, pFormat = BravoAppSettings.settings.numericFormat) {
        if (!pFormat)
            return parseFloat(pValue);
        const formatConfig = BravoNumberExtensions.parseNumericFormat(pFormat), prefix = formatConfig.prefix;
        prefix && 0 == pValue.indexOf(prefix) && (pValue = pValue.substring(prefix.length));
        const suffix = formatConfig.suffix;
        if (suffix) {
            const suffixIndex = pValue.lastIndexOf(suffix);
            suffixIndex > -1 &&
                suffixIndex == pValue.length - suffix.length &&
                (pValue = pValue.substring(0, pValue.length - suffix.length));
        }
        const numberFormatConfig = BravoAppSettings.settings.numberFormat, decimalSeparator = numberFormatConfig['.'] || '.', thousandSeparator = numberFormatConfig[','] || ',', negativeSign = numberFormatConfig['-'] || '-', percentSign = numberFormatConfig['%'] || '%', currencySymbol = formatConfig.curr || numberFormatConfig.currency.symbol || '$', isPercent = pValue.indexOf(percentSign) > -1;
        let isNegativeParenthesized = pValue.indexOf('(') > -1 && pValue.indexOf(')') > -1, parsedNumber = 0;
        if ('x' == formatConfig.spec)
            parsedNumber = parseInt(pValue, 16);
        else {
            [currencySymbol, percentSign, '(', ')'].forEach(pChar => {
                pValue = pValue.replace(pChar, '');
            });
            /\s/.test(thousandSeparator) && (pValue = pValue.replace(/\s+/g, ''));
            const processedLength = (pValue = pValue
                .replace(new RegExp('\\' + thousandSeparator, 'g'), '')
                .replace(new RegExp('\\' + negativeSign, 'g'), '-')
                .replace(/(\+|\\-)\s+/g, '$1')
                .replace(decimalSeparator, '.')
                .trim()).length;
            if (!isNegativeParenthesized && processedLength && '-' == pValue[processedLength - 1]) {
                isNegativeParenthesized = true;
                pValue = pValue.substring(0, processedLength - 1);
            }
            parsedNumber = /^\s*([+\\-])?\d*(\.\d*)?(\s*E[+\\-]?\d+)?\s*$/i.test(pValue)
                ? parseFloat(pValue)
                : Number.NaN;
        }
        if (!isNaN(parsedNumber)) {
            isNegativeParenthesized = isNegativeParenthesized || parsedNumber < 0;
            parsedNumber = Math.abs(parsedNumber);
            isPercent && (parsedNumber = BravoNumberExtensions.shiftDecimalPoint(parsedNumber, -2));
            isNegativeParenthesized && (parsedNumber = -parsedNumber);
            formatConfig.scale && (parsedNumber *= Math.pow(10, formatConfig.scale));
        }
        return parsedNumber;
    }
    /**
     * Parses a numeric format string into its individual parts.
     *
     * The format string is expected to be of the following form:
     *   ["prefix"]type["scale"]","precision["suffix"]["currency"]
     *   where:
     *     prefix: a string that is prefixed to the number
     *     type: a single character indicating the type of number (n, c, p, x)
     *     scale: a string of comma characters indicating the power of 10 to shift the number
     *     precision: the number of digits to display after the decimal point
     *     suffix: a string that is suffixed to the number
     *     currency: a currency symbol to display with the number
     *
     * Returns an object with the following properties:
     *   prefix: the prefix
     *   spec: the type of number
     *   specRaw: the original type of number (before being lower-cased)
     *   prec: the precision
     *   scale: the scale
     *   suffix: the suffix
     *   curr: the currency symbol
     */
    static parseNumericFormat(pFormat) {
        let formatConfig = BravoAppSettings.settings.numberFormatCache[pFormat];
        if (!formatConfig) {
            let matchResult = (pFormat && pFormat.match(/(\\"(.*?)\\"\s*)?([a-z]+)\s*(\d*)\s*(,*)(\s*\\"(.*?)\\"\s*)?(.*)/i)) ||
                [], formatType = matchResult[3] ? matchResult[3] : 'n';
            if (formatType.length > 1) {
                matchResult = [];
                formatType = 'n';
            }
            formatConfig = {
                prefix: matchResult[2] || '',
                spec: formatType.toLowerCase(),
                specRaw: formatType,
                prec: matchResult[4] ? parseInt(matchResult[4]) : null,
                scale: matchResult[5] ? 3 * matchResult[5].length : 0,
                suffix: matchResult[7] || '',
                curr: matchResult[8] || null,
            };
            BravoAppSettings.settings.numberFormatCache[pFormat] = formatConfig;
        }
        return formatConfig;
    }
    static ensureFormat(pFormat) {
        //!TODO
        return pFormat;
    }
    /**
     * Shifts the decimal point of a number by the specified number of positions.
     * If the number is in exponential notation, it is converted to a string and the decimal point is shifted accordingly.
     * If the number is not in exponential notation, it is converted to a string and the decimal point is shifted by padding with zeros.
     * The number of positions to shift can be positive (to the right) or negative (to the left).
     * If a precision is specified, the result is rounded to that precision.
     * @param {number} pNumber the number to shift the decimal point of
     * @param {number} pShiftPositions the number of positions to shift the decimal point
     * @param {number} [pPrecision] the number of decimal places to round to
     * @returns {number} the shifted number
     */
    static shiftDecimalPoint(pNumber, pShiftPositions, pPrecision) {
        if (0 == pShiftPositions || isNaN(pNumber))
            return pNumber;
        let numberString = pNumber.toString();
        if (numberString.indexOf('e') > -1) {
            let resultNumber = pNumber * Math.pow(10, pShiftPositions);
            pPrecision != null && (resultNumber = parseFloat(resultNumber.toFixed(pPrecision)));
            return resultNumber;
        }
        const zeroPadding = Array(Math.abs(pShiftPositions) + 1).join('0');
        pShiftPositions < 0 && (numberString = zeroPadding + numberString);
        let decimalPosition = numberString.indexOf('.');
        decimalPosition < 0 && (decimalPosition = (numberString += '.').indexOf('.'));
        pShiftPositions > 0 && (numberString += zeroPadding);
        decimalPosition += pShiftPositions;
        const removedDotString = numberString.replace('.', '');
        numberString = removedDotString.substr(0, decimalPosition) + '.' + removedDotString.substr(decimalPosition);
        return parseFloat(numberString);
    }
    static getNumberDecimalSeparator() {
        const ndc = BravoAppSettings.settings.numberFormat['.'];
        return ndc ? ndc : '.';
    }
    // ** implementation
    // similar to JavaScript's toFixed, but smarter about appending
    // zeros when that's all that's needed (TFS 286926)
    static #toFixedStr(pNum, pDigits) {
        const str = pNum.toString(), decPos = str.indexOf('.'), xZeros = pDigits - (str.length - decPos) + 1;
        return str.indexOf('e') < 0 && decPos > -1 && xZeros >= 0
            ? str + Array(xZeros + 1).join('0')
            : pNum.toFixed(pDigits);
    }
    // multiply a number by 100 without round-off errors (sigh: TFS 210383)
    static #mul100(pNumber) {
        let str = pNumber.toString(), pos = str.indexOf('.');
        // we don't do scientific notation
        if (str.indexOf('e') > -1) {
            return pNumber * 100;
        }
        // multiply string by 100
        if (pos < 0) {
            str += '00';
        }
        else {
            pos += 2;
            str = str.replace('.', '') + '00';
            str = str.substr(0, pos) + '.' + str.substr(pos);
        }
        // parse string
        return parseFloat(str);
    }
    /**
     * Rounds or truncates a number to a specified precision.
     *
     * @param pValue Value to round or truncate.
     * @param pPrec Number of decimal digits for the result.
     * @param pIsTruncate Whether to truncate or round the original value.
     */
    static toFixed(pValue, pPrec, pIsTruncate) {
        if (pIsTruncate) {
            let str = pValue.toString();
            const decPos = str.indexOf('.');
            if (str.indexOf('e') < 0 && decPos > -1) {
                str = str.substr(0, decPos + 1 + pPrec);
                pValue = parseFloat(str);
            }
        }
        else {
            const str = pValue.toFixed(pPrec);
            pValue = parseFloat(str);
        }
        return pValue;
    }
    /**
     * Clamps a value between a minimum and a maximum.
     *
     * @param pValue Original value.
     * @param pMin Minimum allowed value.
     * @param pMax Maximum allowed value.
     */
    static clamp(pValue, pMin, pMax) {
        if (pValue != null) {
            if (pMax != null && pValue > pMax)
                pValue = pMax;
            if (pMin != null && pValue < pMin)
                pValue = pMin;
        }
        return pValue;
    }
    /**
     * Returns a random integer between two bounds (inclusive).
     *
     * The provided bounds are normalized to integers: `pMin` is rounded up
     * using `Math.ceil`, and `pMax` is rounded down using `Math.floor`.
     * The returned value is a uniformly-distributed integer N such that
     * ceil(pMin) <= N <= floor(pMax).
     *
     * Note: callers should ensure that after rounding the lower bound is
     * less than or equal to the upper bound. If ceil(pMin) > floor(pMax)
     * the result is implementation-dependent (the expression will still
     * evaluate but will not produce a meaningful range).
     *
     * @param {number} pMin - Lower bound (inclusive). Will be rounded up to an integer.
     * @param {number} pMax - Upper bound (inclusive). Will be rounded down to an integer.
     * @returns {number} A random integer between the normalized bounds (inclusive).
     *
     * @example
     * // returns an integer between 1 and 5 (inclusive)
     * BravoNumberExtensions.random(1, 5);
     *
     * @example
     * // fractional bounds are normalized: ceil(1.2)=2, floor(5.8)=5 -> returns integer between 2 and 5
     * BravoNumberExtensions.random(1.2, 5.8);
     */
    static random(pMin, pMax) {
        pMin = Math.ceil(pMin); // ensure min is integer
        pMax = Math.floor(pMax); // ensure max is integer
        return Math.floor(Math.random() * (pMax - pMin + 1)) + pMin;
    }
    /**
     * Determines whether a value is a numeric value (can be parsed as a finite number).
     *
     * @param pValue The value to test.
     * @returns True if the value is numeric and finite; otherwise, false.
     *
     * @example
     * isNumericValue('123.45'); // true
     * isNumericValue('abc'); // false
     * isNumericValue(Infinity); // false
     */
    static isNumericValue(pValue) {
        return !isNaN(parseFloat(pValue)) && isFinite(pValue);
    }
    /**
     * Determines whether a value is an integer (can be parsed as a finite integer).
     *
     * @param pValue The value to test.
     * @returns True if the value is an integer and finite; otherwise, false.
     *
     * @example
     * isIntegerType('42'); // true
     * isIntegerType('42.5'); // true (because parseInt('42.5') is 42)
     * isIntegerType('abc'); // false
     */
    static isIntegerType(pValue) {
        return !isNaN(parseInt(pValue)) && isFinite(pValue);
    }
}

/**
 * BravoUTF8 class for encoding and decoding UTF-8 strings.
 */
class BravoUTF8 {
    /**
     * Converts a UTF-8 string into a Uint8Array.
     *
     * @param {string} pText - The input string to encode.
     * @returns {Uint8Array} - The encoded UTF-8 byte array.
     */
    static getBytes(pText) {
        if (typeof TextEncoder !== 'undefined') {
            const encoder = new TextEncoder();
            return encoder.encode(pText);
        }
        const octets = [];
        const length = pText.length;
        let index = 0;
        while (index < length) {
            const codePoint = pText.codePointAt(index) || 0;
            let c = 0;
            let bits = 0;
            if (codePoint <= 0x7f) {
                // 1-byte sequence
                c = 0;
                bits = 0x00;
            }
            else if (codePoint <= 0x7ff) {
                // 2-byte sequence
                c = 6;
                bits = 0xc0;
            }
            else if (codePoint <= 0xffff) {
                // 3-byte sequence
                c = 12;
                bits = 0xe0;
            }
            else if (codePoint <= 0x1fffff) {
                // 4-byte sequence
                c = 18;
                bits = 0xf0;
            }
            octets.push(bits | (codePoint >> c));
            c -= 6;
            while (c >= 0) {
                octets.push(0x80 | ((codePoint >> c) & 0x3f));
                c -= 6;
            }
            // Move index by 2 if surrogate pair (4-byte character)
            index += codePoint >= 0x10000 ? 2 : 1;
        }
        return new Uint8Array(octets);
    }
    /**
     * Decodes a Uint8Array into a UTF-8 string.
     *
     * @param {Uint8Array} pBytes - The byte array to decode.
     * @returns {string} - The decoded string.
     */
    static getString(pBytes) {
        if (typeof TextDecoder !== 'undefined') {
            const decoder = new TextDecoder();
            return decoder.decode(pBytes);
        }
        let string = '';
        let index = 0;
        while (index < pBytes.length) {
            let octet = pBytes[index];
            let bytesNeeded = 0;
            let codePoint = 0;
            if (octet <= 0x7f) {
                // 1-byte sequence
                bytesNeeded = 0;
                codePoint = octet & 0xff;
            }
            else if (octet <= 0xdf) {
                // 2-byte sequence
                bytesNeeded = 1;
                codePoint = octet & 0x1f;
            }
            else if (octet <= 0xef) {
                // 3-byte sequence
                bytesNeeded = 2;
                codePoint = octet & 0x0f;
            }
            else if (octet <= 0xf4) {
                // 4-byte sequence
                bytesNeeded = 3;
                codePoint = octet & 0x07;
            }
            if (pBytes.length - index - bytesNeeded > 0) {
                let k = 0;
                while (k < bytesNeeded) {
                    octet = pBytes[index + k + 1];
                    codePoint = (codePoint << 6) | (octet & 0x3f);
                    k += 1;
                }
            }
            else {
                codePoint = 0xfffd; // Replacement character for incomplete sequences
                bytesNeeded = pBytes.length - index;
            }
            string += String.fromCodePoint(codePoint);
            index += bytesNeeded + 1;
        }
        return string;
    }
}
/**
 * Unicode class for encoding and decoding UTF-16 (Little Endian).
 */
class BravoUnicode {
    /**
     * Converts a Unicode string to a Uint8Array (UTF-16 Little Endian).
     *
     * @param {string} pText - The input string to encode.
     * @returns {Uint8Array} - The encoded UTF-16 byte array.
     */
    static getBytes(pText) {
        const buf = new ArrayBuffer(pText.length * 2); // 2 bytes per character
        const bufView = new Uint16Array(buf);
        for (let i = 0, strLen = pText.length; i < strLen; i++) {
            bufView[i] = pText.charCodeAt(i);
        }
        return new Uint8Array(buf);
    }
    /**
     * Decodes a Uint8Array or Uint16Array into a Unicode string.
     *
     * @param {Uint8Array | Uint16Array} pBytes - The byte array to decode.
     * @returns {string} - The decoded string.
     */
    static getString(pBytes) {
        let buff = null;
        if (pBytes instanceof Uint8Array) {
            buff = pBytes.buffer;
        }
        else if (pBytes instanceof Uint16Array) {
            buff = pBytes.buffer;
        }
        if (buff instanceof ArrayBuffer) {
            return String.fromCharCode.apply(null, Array.from(new Uint16Array(buff)));
        }
        return '';
    }
}

class BravoStringExtensions {
    static get empty() {
        return '';
    }
    /**
     * Formats a template string by replacing placeholders with the provided arguments.
     *
     * Placeholders follow the syntax `{index[:format]}`:
     * - `index`: The zero-based index of the value in the `args` list.
     * - `format` (optional): A format specifier applied to dates or numbers.
     *
     * This method supports:
     * - Date formatting via `BravoGlobalize.formatDate(value, format)`
     * - Number formatting via `BravoGlobalize.formatNumber(value, format)`
     *
     * @param pTemplate - The template string containing placeholders (e.g., "Today is {0:yyyy-MM-dd}").
     * @param pArgs - A list of values to be substituted into the template.
     * @returns A formatted string with all placeholders replaced with corresponding values.
     *
     * @example
     * StringExtension.format('Today is {0:yyyy-MM-dd}', new Date());
     * StringExtension.format('Amount: {0:#,##0.00}', 123456.789);
     */
    static format(pTemplate, ...pArgs) {
        const params = pArgs;
        // eslint-disable-next-line no-useless-escape
        return pTemplate.replace(/\{(\d+)(?:\:([^}]+))?\}/g, (pMatch, pIndexStr, pFormat) => {
            const index = parseInt(pIndexStr, 10);
            const value = params[index];
            if (value == null)
                return '';
            if (!pFormat)
                return String(value);
            if (value instanceof Date) {
                return BravoMoment.format(value, pFormat);
            }
            if (typeof value === 'number') {
                return BravoNumberExtensions.format(value, pFormat);
            }
            return String(value);
        });
    }
    static insert(pText, pIndex, pVal) {
        if (pIndex > 0)
            return pText.substring(0, pIndex) + pVal + pText.substring(pIndex, this.length);
        else
            return pVal + pText;
    }
    static isNonEmptyString(pVal) {
        return typeof pVal === 'string' && pVal !== '';
    }
    /**
     * Removes accents and diacritical marks from the input string.
     *
     * This function normalizes the string using Unicode Normalization Form KD (NFKD),
     * optionally replaces Vietnamese-specific characters 'đ' and 'Đ' with 'd' and 'D',
     * applies any custom replacements provided, and removes all combining diacritical marks.
     *
     * @param pText - The input string potentially containing accented characters.
     * @param pOptions - Optional configuration to customize the behavior.
     * @param options.replaceVietnameseD - Whether to replace 'đ' and 'Đ' characters. Defaults to `true`.
     * @param options.customReplacements - An object mapping regex patterns (as strings) to replacement strings for custom substitutions.
     * @returns The processed string with accents and diacritics removed as specified.
     *
     * @example
     * ```ts
     * // Basic usage
     * BravoStringExtensions.removeAccent('Điện thoại'); // returns 'Dien thoai'
     *
     * // Disable Vietnamese 'đ' replacement
     * BravoStringExtensions.removeAccent('Điện thoại', { replaceVietnameseD: false }); // returns 'Điện thoại'
     *
     * // Custom replacements example
     * BravoStringExtensions.removeAccent('Çàfé', {
     *   customReplacements: { 'Ç': 'C' }
     * }); // returns 'Cafe'
     * ```
     */
    static removeAccent(pText, pOptions = { replaceVietnameseD: true }) {
        if (typeof pText !== 'string')
            return '';
        let result = pText.normalize('NFKD');
        if (pOptions.replaceVietnameseD ?? true) {
            result = result.replace(/đ/g, 'd').replace(/Đ/g, 'D');
        }
        if (pOptions.customReplacements) {
            for (const [key, val] of Object.entries(pOptions.customReplacements)) {
                result = result.replace(new RegExp(key, 'g'), val);
            }
        }
        return result.replace(/[\u0300-\u036f]/g, '');
    }
    /**
     * Splits a string by the given separator, trims each segment,
     * and optionally removes empty entries.
     *
     * @param pText - The input string to split.
     * @param pSeparator - The separator used to split the string.
     * @param pRemoveEmpty - Whether to remove empty strings after trimming. Defaults to `false`.
     * @returns An array of trimmed strings, with optional removal of empty entries.
     *
     * @example
     * ```ts
     * // Basic usage without removing empty strings
     * BravoStringExtensions.splitText('apple, banana, , orange', ',', false);
     * // Returns: ['apple', 'banana', '', 'orange']
     *
     * // Remove empty strings after splitting
     * BravoStringExtensions.splitText('apple, banana, , orange', ',', true);
     * // Returns: ['apple', 'banana', 'orange']
     * ```
     */
    static splitText(pText, pSeparator, pRemoveEmpty = false) {
        const parts = pText.split(pSeparator).map(part => part.trim());
        return pRemoveEmpty ? parts.filter(part => part !== '') : parts;
    }
    /**
     * Capitalizes the first letter of the given string.
     *
     * @param pText - The input string to transform.
     * @returns A new string with the first character converted to uppercase.
     *          If the input is an empty string, returns an empty string.
     *
     * @example
     * ```ts
     * BravoStringExtensions.capitalizeFirstLetter('hello world'); // Returns: 'Hello world'
     * BravoStringExtensions.capitalizeFirstLetter('javaScript');  // Returns: 'JavaScript'
     * BravoStringExtensions.capitalizeFirstLetter('');            // Returns: ''
     * ```
     */
    static capitalizeFirstLetter(pText) {
        return pText.charAt(0).toUpperCase() + pText.slice(1);
    }
    /**
     * Converts the first character of a string to lowercase.
     *
     * @param pStr - The input string to process.
     * @returns A new string with the first character in lowercase.
     *
     * @example
     * firstLowerCase("Hello World") // "hello World"
     * firstLowerCase("TypeScript")  // "typeScript"
     */
    static firstLowerCase(pStr) {
        if (!pStr)
            return pStr;
        return pStr.charAt(0).toLowerCase() + pStr.slice(1);
    }
    /**
     * Returns the input string with the first character in uppercase.
     * @param pStr The input string.
     * @returns The string with the first character in uppercase.
     */
    static firstUpperCase(pStr) {
        return pStr.substring(0, 1).toUpperCase() + pStr.substring(1);
    }
    /**
     * Checks whether the input value is null, undefined, or an empty string.
     *
     * @param pText - The value to check.
     * @returns `true` if the value is `null`, `undefined`, or an empty string (`''`); otherwise, `false`.
     *
     * @example
     * ```ts
     * BravoStringExtensions.isNullOrEmpty(null);      // true
     * BravoStringExtensions.isNullOrEmpty(undefined); // true
     * BravoStringExtensions.isNullOrEmpty('');        // true
     * BravoStringExtensions.isNullOrEmpty('hello');   // false
     * BravoStringExtensions.isNullOrEmpty(' ');       // false (not empty string)
     * ```
     */
    static isNullOrEmpty(pText) {
        return pText == null || pText === '' || pText === void 0;
    }
    /**
     * Compares two strings for equality with options to ignore case and use locale-based case conversion.
     *
     * @param pString1 - The first string to compare.
     * @param pString2 - The second string to compare.
     * @param pIsIgnoreCase - If `true`, comparison ignores case differences. Defaults to `false`.
     * @param pisUseLocale - If `true` and `ignoreCase` is `true`, uses locale-aware case conversion. Defaults to `false`.
     * @returns `true` if both strings are equal based on the specified options; otherwise, `false`.
     *
     * @example
     * ```ts
     * BravoStringExtensions.compareStrings('hello', 'HELLO');              // false
     * BravoStringExtensions.compareStrings('hello', 'HELLO', true);        // true
     * BravoStringExtensions.compareStrings('straße', 'STRASSE', true);     // false (locale matters)
     * BravoStringExtensions.compareStrings('straße', 'STRASSE', true, true); // true (locale-aware)
     * BravoStringExtensions.compareStrings(null, null);                     // true
     * BravoStringExtensions.compareStrings(null, '');                       // false
     * ```
     */
    static compareStrings(pString1, pString2, pIsIgnoreCase = false, pisUseLocale = false) {
        if (!pString1 && !pString2)
            return true;
        if (pString1 && pString2) {
            if (pIsIgnoreCase) {
                pString1 = pisUseLocale ? pString1.toString().toLocaleLowerCase() : pString1.toString().toLowerCase();
                pString2 = pisUseLocale ? pString2.toString().toLocaleLowerCase() : pString2.toString().toLowerCase();
            }
            return pString1 === pString2;
        }
        return false;
    }
    /**
     * Determines whether the given string starts with the specified search string.
     *
     * @param pString - The string to be searched.
     * @param pSearchString - The substring to search for at the start of `pString`.
     * @param pIsIgnoreCase - Optional. If `true`, performs a case-insensitive comparison. Defaults to `true`.
     * @returns `true` if `pString` starts with `searchString`; otherwise, `false`.
     */
    static startsWith(pString, pSearchString, pIsIgnoreCase = true) {
        if (pIsIgnoreCase)
            return pString.toLowerCase().startsWith(pSearchString.toLowerCase());
        return pString.startsWith(pSearchString);
    }
    /**
     * Asserts that a value is a string.
     *
     * @param pValue Value supposed to be a string.
     * @param pIsNullOK Whether null values are acceptable.
     * @return The string passed in.
     */
    static asString(pValue, pIsNullOK = true) {
        assert((pIsNullOK && pValue == null) || this.isString(pValue), 'String expected.');
        return pValue;
    }
    /**
     * Determines whether an object is a string.
     *
     * @param pValue Value to test.
     */
    static isString(pValue) {
        return isString(pValue);
    }
    /**
     * Determines whether the given string contains only ASCII characters.
     *
     * @param pValue - The string to be tested.
     * @returns `true` if the string consists solely of ASCII characters (character codes 0–127); otherwise, `false`.
     */
    static isASCII(pValue) {
        // eslint-disable-next-line no-control-regex
        return /^[\x00-\x7F]*$/.test(pValue);
    }
    static indexOfAny(pValue, pChars, pStartIndex = 0, pCount) {
        const end = pCount !== undefined ? Math.min(pStartIndex + pCount, pValue.length) : pValue.length;
        for (let i = pStartIndex; i < end; i++) {
            if (pChars.includes(pValue[i])) {
                return i;
            }
        }
        return -1;
    }
    /**
     * Replaces a substring within a string, starting at a specified position,
     * with a replacement string, removing a given number of characters.
     *
     * This function behaves similarly to SQL's STUFF function.
     *
     * @param pStr - The original string.
     * @param pStart - The 1-based position to start replacing characters.
     * @param pLength - The number of characters to remove from the start position.
     * @param pReplacement - The string to insert in place of the removed characters.
     * @returns A new string with the specified section replaced.
     *
     * @example
     * ```ts
     * BravoStringExtensions.stuff('Hello World', 7, 5, 'Universe'); // Returns 'Hello Universe'
     * BravoStringExtensions.stuff('abcdef', 2, 3, 'XYZ');           // Returns 'aXYZf'
     * ```
     */
    static stuff(pStr, pStart, pLength, pReplacement) {
        return pStr.substring(0, pStart - 1) + pReplacement + pStr.substring(pStart - 1 + pLength);
    }
    /**
     * Trims specified characters from the start and end of a string.
     * @param pText The input string.
     * @param pChars The characters to trim.
     * @returns A new string with the specified characters removed from both ends.
     *
     * @example
     * StringUtils.trimChars('--hello--', '-') // "hello"
     * StringUtils.trimChars('***hello***', '*', '-') // "hello"
     */
    static trimChars(pText, ...pChars) {
        if (!pText || pChars.length === 0)
            return pText;
        let result = pText;
        for (const ch of pChars) {
            const escapedChar = ch.replace(/[-/\\^$*+?.()|[\]{}]/g, '\\$&'); // escape regex special characters
            const re = new RegExp(`^[${escapedChar}]+|[${escapedChar}]+$`, 'g');
            result = result.replace(re, '');
        }
        return result;
    }
    /**
     * Removes all trailing occurrences of a specific character from the end of a string.
     * @param pStr - The original string.
     * @param pChar - The character to remove from the end of the string.
     * @returns The trimmed string with specified characters removed from the end.
     */
    static trimEndChar(pStr, pChar) {
        // Escape special regex characters in the input character
        const escapedChar = pChar.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        // Create a regular expression to match one or more of the character at the end
        const regex = new RegExp(`${escapedChar}+$`);
        // Replace matched characters at the end with an empty string
        return pStr.replace(regex, '');
    }
    /**
     * Removes all leading occurrences of a specific character from the start of a string.
     *
     * @param pStr - The original string.
     * @param pChar - The character to remove from the start of the string.
     * @returns The trimmed string with specified characters removed from the start.
     *
     * @example
     * StringExtension.trimStartChar('---hello---', '-') // Returns: 'hello---'
     * StringExtension.trimStartChar('***test***', '*')  // Returns: 'test***'
     */
    static trimStartChar(pStr, pChar) {
        // Escape special regex characters in the input character
        const escapedChar = pChar.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        // Create a regular expression to match one or more of the character at the start
        const regex = new RegExp(`^${escapedChar}+`);
        // Replace matched characters at the start with an empty string
        return pStr.replace(regex, '');
    }
    /**
     * Trim special spaces (\\s and \\u00A0) from a string.
     * @param pStr The input string.
     * @param pPosition The position at which to trim special spaces. Defaults to 'both'.
     * @returns The trimmed string with special spaces removed.
     *
     * @example
     * BravoStringExtensions.trimSpecialSpaces('   hello   ', 'start'); // "hello   "
     * BravoStringExtensions.trimSpecialSpaces('   hello   ', 'end'); // "   hello"
     * BravoStringExtensions.trimSpecialSpaces('   hello   ', 'both'); // "hello"
     */
    static trimSpecialSpaces(pStr, pPosition = 'both') {
        if (pStr == null)
            return '';
        const start = /^[\s\u00A0]+/;
        const end = /[\s\u00A0]+$/;
        const both = /^[\s\u00A0]+|[\s\u00A0]+$/g;
        switch (pPosition) {
            case 'start':
                return pStr.replace(start, '');
            case 'end':
                return pStr.replace(end, '');
            case 'both':
            default:
                return pStr.replace(both, '');
        }
    }
    /**
     * Removes a substring from the specified string, starting at the given index and spanning the specified length.
     *
     * @param pStr - The original string from which to remove characters.
     * @param pStartIndex - The zero-based index at which to start removing characters.
     * @param pLength - The number of characters to remove from the string.
     * @returns A new string with the specified substring removed.
     */
    static remove(pStr, pStartIndex, pLength) {
        return pStr.substring(0, pStartIndex) + pStr.substring(pStartIndex + pLength);
    }
    /**
     * Converts a camelCase string to kebab-case.
     *
     * @param pStr - The camelCase string to convert.
     * @returns The converted kebab-case string.
     *
     * @example
     * ```typescript
     * StringExtension.camelToKebab('myCamelCaseString'); // 'my-camel-case-string'
     * ```
     */
    static camelToKebab(pStr) {
        return pStr.replace(/([a-z])([A-Z])/g, '$1-$2').toLowerCase();
    }
    /**
     * Checks whether a string starts with the given substring,
     * ignoring case sensitivity.
     *
     * @param pInput - The source string.
     * @param pSearch - The substring to match at the beginning.
     * @returns True if the input starts with the substring (case-insensitive), otherwise false.
     */
    static isStartsWithIgnoreCase(pInput, pSearch) {
        if (typeof pInput !== 'string' || typeof pSearch !== 'string') {
            return false;
        }
        return pInput.toLowerCase().startsWith(pSearch.toLowerCase());
    }
    /**
     * Generates a hotkey prefix from a numeric index using either a compact
     * single-character mode or an Excel-like column mode.
     *
     * Modes:
     * - 'short': returns a single character. Indices 0-9 map to '0'-'9',
     *   indices 10-35 map to 'a'-'z'. If the computed character is not a
     *   valid ASCII letter when expected the function returns an empty string.
     * - 'excel': returns Excel-style column labels: 0 -> 'a', 1 -> 'b', ..., 25 -> 'z',
     *   26 -> 'aa', 27 -> 'ab', etc.
     *
     * @param pnHotKeyNumberingValue - Zero-based index used to build the hotkey.
     * @param pMode - 'short' (compact single char) or 'excel' (Excel-style labels).
     * @returns A hotkey string (single char or multi-char excel-style) or an empty string when
     *          the short-mode computation yields an invalid character.
     *
     * @example
     * // short mode examples
     * BravoStringExtensions.addHotKeyPrefix(0);   // '0'
     * BravoStringExtensions.addHotKeyPrefix(9);   // '9'
     * BravoStringExtensions.addHotKeyPrefix(10);  // 'a'
     * BravoStringExtensions.addHotKeyPrefix(35);  // 'z'
     *
     * @example
     * // excel mode examples
     * BravoStringExtensions.addHotKeyPrefix(0, 'excel');   // 'a'
     * BravoStringExtensions.addHotKeyPrefix(25, 'excel');  // 'z'
     * BravoStringExtensions.addHotKeyPrefix(26, 'excel');  // 'aa'
     */
    static addHotKeyPrefix(pnHotKeyNumberingValue, pMode = 'short') {
        let hotKey = '';
        // 🔹 1. MODE "SHORT": 0–9, a–z (chỉ 1 ký tự)
        if (pMode === 'short') {
            if (pnHotKeyNumberingValue < 10) {
                hotKey = `${pnHotKeyNumberingValue}`;
            }
            else {
                hotKey = String.fromCharCode(pnHotKeyNumberingValue - 10 + 97); // a–z
                if (hotKey.length > 1 || !BravoStringExtensions.isLetter(hotKey[0]))
                    return '';
            }
            return hotKey;
        }
        // 🔹 2. MODE "EXCEL": a, b, ..., z, aa, ab, ...
        if (pMode === 'excel') {
            pnHotKeyNumberingValue++; // Excel-style bắt đầu từ 1
            while (pnHotKeyNumberingValue > 0) {
                const remainder = (pnHotKeyNumberingValue - 1) % 26;
                hotKey = String.fromCharCode(97 + remainder) + hotKey;
                pnHotKeyNumberingValue = Math.floor((pnHotKeyNumberingValue - 1) / 26);
            }
            return hotKey;
        }
        return '';
    }
    /**
     * Returns true if the first character of the given string is an ASCII letter
     * (A-Z or a-z).
     *
     * @param pStr - Input string (should contain at least one character).
     * @returns True when the first character is an ASCII letter; otherwise false.
     *
     * @example
     * BravoStringExtensions.isLetter('A'); // true
     * BravoStringExtensions.isLetter('z'); // true
     * BravoStringExtensions.isLetter('1'); // false
     */
    static isLetter(pStr) {
        return ((pStr.charCodeAt(0) >= 65 && pStr.charCodeAt(0) <= 90) ||
            (pStr.charCodeAt(0) >= 97 && pStr.charCodeAt(0) <= 122));
    }
    /**
     * Returns true for ASCII alphanumeric characters plus a few allowed symbols
     * (@, $, _). For characters outside the basic ASCII range this method
     * returns true if the character code is greater than U+007F (i.e. non-ASCII
     * letters are considered valid).
     *
     * @param pCharacter - Single character to test.
     * @returns True when character is allowed (alphanumeric, @, $, _, or non-ASCII).
     *
     * @example
     * BravoStringExtensions.isAlphaNumeric('a'); // true
     * BravoStringExtensions.isAlphaNumeric('Z'); // true
     * BravoStringExtensions.isAlphaNumeric('@'); // true
     * BravoStringExtensions.isAlphaNumeric('é'); // true (non-ASCII)
     */
    static isAlphaNumeric(pCharacter) {
        switch (pCharacter) {
            case '@':
            case '$':
            case '0':
            case '1':
            case '2':
            case '3':
            case '4':
            case '5':
            case '6':
            case '7':
            case '8':
            case '9':
            case 'A':
            case 'B':
            case 'C':
            case 'D':
            case 'E':
            case 'F':
            case 'G':
            case 'H':
            case 'I':
            case 'J':
            case 'K':
            case 'L':
            case 'M':
            case 'N':
            case 'O':
            case 'P':
            case 'Q':
            case 'R':
            case 'S':
            case 'T':
            case 'U':
            case 'V':
            case 'W':
            case 'X':
            case 'Y':
            case 'Z':
            case '_':
            case 'a':
            case 'b':
            case 'c':
            case 'd':
            case 'e':
            case 'f':
            case 'g':
            case 'h':
            case 'i':
            case 'j':
            case 'k':
            case 'l':
            case 'm':
            case 'n':
            case 'o':
            case 'p':
            case 'q':
            case 'r':
            case 's':
            case 't':
            case 'u':
            case 'v':
            case 'w':
            case 'x':
            case 'y':
            case 'z':
                return true;
        }
        return pCharacter > '\u007f';
    }
    /**
     * Checks whether a given string contains Unicode characters outside the ASCII range.
     *
     * @param pInput - Input string to check.
     * @returns True if the string contains Unicode characters (code points > 255);
     *   otherwise, false.
     *
     * @example
     * BravoStringExtensions.isUnicode('A');  // false
     * BravoStringExtensions.isUnicode('●');  // true
     * BravoStringExtensions.isUnicode('😀'); // true
     * BravoStringExtensions.isUnicode('');   // false
     */
    static isUnicode(pInput) {
        for (let i = 0, n = pInput.length; i < n; i++) {
            if (pInput.charCodeAt(i) > 255) {
                return true;
            }
        }
        return false;
    }
    /**
     * Converts a string to its Unicode escape sequence.
     *
     * @param pInput - Input string to convert.
     * @returns The Unicode escape sequence of the input string.
     *
     * @example
     * BravoStringExtensions.toUnicode('A'); // "\\u0041"
     * BravoStringExtensions.toUnicode(''); // "\\u20BB"
     * BravoStringExtensions.toUnicode(''); // "\\u1F600"
     */
    static toUnicode(pInput) {
        const result = [];
        for (let i = 0; i < this.length;) {
            const cp = pInput.codePointAt(i);
            if (cp > 0xffff) {
                result.push(`\\u{${cp.toString(16)}}`);
                i += 2; // surrogate pair
            }
            else {
                result.push(`\\u${cp.toString(16).padStart(4, '0')}`);
                i += 1;
            }
        }
        return result.join('');
    }
    /**
     * Compares two hotkey strings and returns a signed number indicating their
     * relative ordering.
     *
     * Ordering rules:
     * - Single-character compact hotkeys are ordered using the sequence
     *   '0'..'9','a'..'z'.
     * - Multi-character keys are treated as Excel-style sequences (base-26 a=1..z=26)
     *   and are always considered greater than compact single-character keys
     *   (an offset of +100 is applied to their numeric value internally).
     * - Invalid multi-character keys (containing non a-z letters) are mapped to a
     *   very large value so they compare after valid keys.
     *
     * @param pKey1 - First hotkey string.
     * @param pKey2 - Second hotkey string.
     * @returns Negative if pKey1 < pKey2, zero if equal, positive if pKey1 > pKey2.
     *
     * @example
     * BravoStringExtensions.compareHotKey('1', '2');   // < 0
     * BravoStringExtensions.compareHotKey('9', 'a');   // < 0 (9 before a)
     * BravoStringExtensions.compareHotKey('a', 'aa');  // < 0 (single char before excel labels)
     * BravoStringExtensions.compareHotKey('aa', 'ab'); // < 0
     */
    static compareHotKey(pKey1, pKey2) {
        // handle empty / null
        if (!pKey1 && !pKey2)
            return 0;
        if (!pKey1)
            return 1;
        if (!pKey2)
            return -1;
        const order = '0123456789abcdefghijklmnopqrstuvwxyz';
        const normalize = (pKey) => {
            pKey = pKey.toLowerCase();
            // single character (short mode)
            if (pKey.length === 1) {
                return order.indexOf(pKey);
            }
            // excel-style multi-character: convert to base-26 (a=1..z=26)
            let value = 0;
            for (let i = 0; i < pKey.length; i++) {
                const charCode = pKey.charCodeAt(i) - 96; // a=1
                if (charCode < 1 || charCode > 26)
                    return Number.MAX_SAFE_INTEGER; // invalid
                value = value * 26 + charCode;
            }
            // add offset so excel-mode values are ordered after short-mode
            return 100 + value;
        };
        const valA = normalize(pKey1);
        const valB = normalize(pKey2);
        return valA - valB;
    }
    /**
     * Detects whether an array of hotkey strings is sorted in ascending order,
     * descending order, or is unsorted. Uses `compareHotKey` to determine the
     * ordering between consecutive elements.
     *
     * @param pHotkeys - Array of hotkey strings to inspect.
     * @returns 'asc' if ascending, 'desc' if descending, otherwise 'unsorted'.
     *
     * @example
     * BravoStringExtensions.detectHotKeySortOrder(['0','1','2']); // 'asc'
     * BravoStringExtensions.detectHotKeySortOrder(['b','a']);     // 'desc'
     * BravoStringExtensions.detectHotKeySortOrder(['a','1','b']); // 'unsorted'
     */
    static detectHotKeySortOrder(pHotkeys) {
        let ascending = true;
        let descending = true;
        for (let i = 1; i < pHotkeys.length; i++) {
            const cmp = BravoStringExtensions.compareHotKey(pHotkeys[i - 1], pHotkeys[i]);
            if (cmp > 0)
                ascending = false;
            if (cmp < 0)
                descending = false;
        }
        if (ascending)
            return 'asc';
        if (descending)
            return 'desc';
        return 'unsorted';
    }
    /**
     * Determines whether a string is null, empty, or whitespace only.
     *
     * @param pValue Value to test.
     */
    static isNullOrWhiteSpace(pValue) {
        return pValue == null ? true : pValue.replace(/\s/g, '').length < 1;
    }
    /**
     * @description: Generates a globally unique identifier (GUID).
     * The format follows the structure of "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx", where x is a hexadecimal digit.
     * @example:
     * const id = Unique.guid();
     * console.log(id); // e.g., "3f2504e0-4f89-41d3-9a0c-0305e82c3301"
     */
    static guid() {
        function s4() {
            return Math.floor((1 + Math.random()) * 0x10000)
                .toString(16)
                .substring(1);
        }
        return s4() + s4() + '-' + s4() + '-' + s4() + '-' + s4() + '-' + s4() + s4() + s4();
    }
    /**
     * @description: Generates a unique name prefixed with an underscore ("_").
     * The unique part is derived from a random base-36 string.
     *
     * @example:
     * const name = Unique.guName();
     * console.log(name); // e.g., "_5g1k2s"
     */
    static guName() {
        return `_${Math.random().toString(36).substring(7)}`;
    }
    /**
     * @description: Generates a random column name, optionally prefixed and/or suffixed.
     * The generated name uses a unique base and removes potentially unsafe characters.
     * @param pPrefix Optional string to prefix the column name.
     * @param pSuffix Optional string to suffix the column name.
     * @returns A sanitized, unique column name string.
     * @example
     * const colName = Unique.generateRandomColName('pre_', '_suf');
     * console.log(colName); // e.g., "pre__5g1k2s_suf"
     */
    static generateRandomColName(pPrefix, pSuffix) {
        const colName = `${pPrefix}${this.guName()}${pSuffix ?? ''}`;
        return colName.replace(/ |,|--|\*|xp_|exec|\[|%|;|\//gi, '');
    }
}

class BravoStringBuilder {
    #strings;
    get strings() {
        return this.#strings;
    }
    set strings(pVal) {
        this.#strings = pVal;
    }
    get length() {
        return this._internalStrings.length;
    }
    #split = '';
    get split() {
        return this.#split;
    }
    constructor(pCollection, pSplit = '') {
        this.#split = pSplit;
        if (pCollection instanceof Array)
            this.#strings = new ObservableArray(pCollection);
        else
            this.#strings = new ObservableArray();
    }
    get _internalStrings() {
        return this.#strings ? this.strings.join(this.#split) : '';
    }
    get(pos) {
        if (pos < 0 || pos >= this.length)
            return null;
        return this._internalStrings[pos];
    }
    clone() {
        const strings = new ObservableArray([...this.#strings]);
        return new BravoStringBuilder(strings);
    }
    append(pVal) {
        if (pVal instanceof BravoStringBuilder) {
            this.strings.push(...pVal.strings);
            return;
        }
        if (pVal)
            this.strings.push(pVal);
    }
    appendLine(pVal) {
        if (pVal) {
            this.strings.push(`${pVal}\n\t`);
        }
        else {
            this.strings.push('\n\t');
        }
        return this;
    }
    appendFormat(pFormat, ...pArgs) {
        this.strings.push(BravoStringExtensions.format(pFormat, ...pArgs));
    }
    insert(pIndex, pVal) {
        this.strings.insert(pIndex, pVal);
    }
    clear() {
        this.strings.length = 0;
    }
    toString() {
        return this._internalStrings;
    }
}

const BravoStringComparer = {
    ordinalIgnoreCase: (pTxt1, pTxt2) => pTxt1?.toLowerCase() === pTxt2?.toLowerCase(),
    ordinal: (pTxt1, pTxt2) => pTxt1 === pTxt2,
};

class BravoObjectExtensions {
    static values(pObj) {
        return Object.keys(pObj).map(pKey => {
            return pObj[pKey];
        });
    }
    /**
     * Assigns values from a literal object to an instance of a class.
     * @param pTarget The class instance to update.
     * @param pSource The class instance containing the values to assign.
     * @param pIgnoreNullish if nullish not assign.
     * @param pIncludeProps include props map to assign (optional).
     * @returns The updated class instance.
     */
    static mapProperties(pTarget, pSource, pIgnoreNullish = true, pIncludeProps) {
        const keys = (pIncludeProps ?? Object.keys(pSource));
        for (const key of keys) {
            const outProp = {};
            let propName = key;
            if (!this.hasProperty(pSource, propName, outProp))
                continue;
            propName = outProp.name;
            if (!propName)
                continue;
            const value = pSource[propName];
            if (isNullish(value) && pIgnoreNullish)
                continue;
            this.setValue(pTarget, value, propName, false);
        }
        return pTarget;
    }
    /**
     * Safely assigns a value to a property of an object.
     *
     * - Validates that the owner object is not null or undefined
     * - Checks whether the property exists (including aliases, if supported)
     * - Automatically coerces boolean / number values when applicable
     * - Supports WritableSignal (uses `.set()` if the target is a signal)
     *
     * @param pValue - The value to assign
     * @param pOwner - The object that owns the property
     * @param pPropName - The property name (string or alias)
     *
     * @returns `true` if the value was successfully assigned, `false` otherwise
     *
     * @throws Error if `pOwner` is null or undefined
     */
    static setValue(pOwner, pValue, pPropName, pCheckHasProperty = true) {
        if (isNullish(pOwner))
            throw new Error('Owner must not be null or undefined');
        if (isNullish(pValue))
            return false;
        let propName = pPropName;
        if (pCheckHasProperty) {
            const outProp = {};
            this.hasProperty(pOwner, pPropName, outProp);
            propName = outProp.name;
        }
        if (!propName)
            return false;
        if (BravoBooleanExtensions.isBoolean(pValue))
            pValue = BravoBooleanExtensions.asBoolean(pValue);
        else if (BravoNumberExtensions.isNumber(pValue))
            pValue = BravoNumberExtensions.asNumber(pValue);
        const owner = pOwner;
        const target = owner[propName];
        if (isWritableSignal(target))
            target.set(pValue);
        else
            owner[propName] = pValue;
        return true;
    }
    /**
     * @description
     * Accepts an object of type T and key of type K extends keyof T.
     * Removes property from an object and returns a shallow copy of the updated object without specified property.
     * If property not found returns copy of the original object.
     * Not mutating original object.
     *
     * @example
     *
     * const cat = {id: 1, type: 'cat', name: 'Fluffy'};
     *
     * const anonymusCat = deleteProp(cat, 'name');
     *
     * // anonymusCat will be:
     * // {id: 1, type: 'cat'};
     *
     *
     * @returns Omit<T, K>
     *
     * @docsPage deleteProp
     * @docsCategory transformation-helpers
     */
    static deleteProp(pObject, pKey) {
        if (!isDefined(pObject) || !isObjectGuard(pObject)) {
            console.warn(`DeleteProp: original value ${pObject} is not an object.`);
            return pObject;
        }
        if (!isKeyOf(pKey)) {
            console.warn(`DeleteProp: provided key is not a string, number or symbol.`);
            return { ...pObject };
        }
        const copy = { ...pObject };
        delete copy[pKey];
        return copy;
    }
    /**
     * @description
     * Converts a dictionary of type {[key: string]: T} to array T[].
     *
     * @example
     *
     * const creaturesDictionary = {
     *   '1': {id: 1, type: 'cat'},
     *   '2': {id: 2, type: 'dog'},
     *   '3': {id: 3, type: 'parrot'}
     * };
     *
     * const creaturesArray = dictionaryToArray(creaturesDictionary);
     *
     * // creaturesArray will be:
     * // [{id: 1, type: 'cat'}, {id: 2, type: 'dog'}, {id: 3, type: 'parrot'}];
     *
     *
     * @returns T[];
     *
     * @docsPage dictionaryToArray
     * @docsCategory transformation-helpers
     */
    static dictionaryToArray(pDictionary) {
        if (!isDefined(pDictionary)) {
            return pDictionary;
        }
        if (!isObjectGuard(pDictionary)) {
            console.warn(`DictionaryToArray: unexpected input.`);
            return [];
        }
        return Object.values(pDictionary);
    }
    /**
   * @description
   * Merges an object of type T with updates of type Partial<T>.
   * Returns a new object where updates override original values while not mutating the original one.

  * @example
  * interface Creature {
  *  id: number,
  *  type: string,
  *  name: string
  * }
  *
  * const cat = {id: 1, type: 'cat'};
  *
  * const catWithname = patch(cat, {name: 'Fluffy'});
  *
  * // catWithname will be:
  * // {id: 1, type: 'cat', name: 'Fluffy'};
  *
  *
  * @returns T
  *
  * @docsPage patch
  * @docsCategory transformation-helpers
  */
    static patch(pObject, pUpd) {
        const update = isObjectGuard(pUpd) ? pUpd : {};
        if (!isObjectGuard(pObject) && isObjectGuard(pUpd)) {
            console.warn(`Patch: original value ${pObject} is not an object.`);
            return { ...update };
        }
        if (!isObjectGuard(pObject) && !isObjectGuard(pUpd)) {
            console.warn(`Patch: original value ${pObject} and updates ${pUpd} are not objects.`);
            return pObject;
        }
        return { ...pObject, ...update };
    }
    /**
     * @description
     * Accepts an object of type T, key of type K extends keyof T, and value of type T[K].
     * Sets the property and returns a newly updated shallow copy of an object while not mutating the original one.
     *
     * @example
     *
     * const cat = {id: 1, type: 'cat', name: 'Fluffy'};
     *
     * const renamedCat = setProp(cat, 'name', 'Bella');
     *
     * // renamedCat will be:
     * // {id: 1, type: 'cat', name: 'Bella'};
     *
     *
     * @returns T
     *
     * @docsPage setProp
     * @docsCategory transformation-helpers
     */
    static setProp(pObject, pKey, pValue) {
        const objectIsObject = isObjectGuard(pObject);
        const keyIsValid = isKeyOf(pKey);
        const initialObject = objectIsObject ? pObject : {};
        if (!objectIsObject) {
            console.warn(`SetProp: original value (${pObject}) is not an object.`);
        }
        if (!keyIsValid) {
            console.warn(`SetProp: key argument (${pKey}) is invalid.`);
        }
        if (!isDefined(pObject) && !keyIsValid) {
            return pObject;
        }
        if (keyIsValid) {
            return {
                ...initialObject,
                [pKey]: pValue,
            };
        }
        return { ...initialObject };
    }
    /**
     * @description
     * Accepts an object of type T and single key or array of keys (K extends keyof T).
     * Constructs new object based on provided keys.
     *
     * @example
     *
     * const cat = {id: 1, type: 'cat', name: 'Fluffy'};
     *
     * const catWithoutType = slice(cat, ['name', 'id']);
     *
     * // catWithoutType will be:
     * // {id: 1, name: 'Fluffy'};
     *
     *
     * @returns T
     *
     * @docsPage slice
     * @docsCategory transformation-helpers
     */
    static slice(pObject, pKeys) {
        const objectIsObject = isDefined(pObject) && isObjectGuard(pObject);
        if (!objectIsObject) {
            console.warn(`slice: original value (${pObject}) is not an object.`);
            return undefined;
        }
        const sanitizedKeys = (Array.isArray(pKeys) ? pKeys : [pKeys]).filter(pKey => isKeyOf(pKey) && pKey in pObject);
        if (!sanitizedKeys.length) {
            console.warn(`slice: provided keys not found`);
            return undefined;
        }
        return sanitizedKeys.reduce((pAcc, pKey) => ({ ...pAcc, [pKey]: pObject[pKey] }), {});
    }
    /**
     * @description
     * Toggles a boolean property in the object.
     * Accepts object of type T and key value of which is boolean.
     * Toggles the property and returns a shallow copy of an object, while not mutating the original one.
     *
     * @example
     *
     * const state = {items: [1,2,3], loading: true};
     *
     * const updatedState = toggle(state, 'loading');
     *
     * // updatedState will be:
     * // {items: [1,2,3], loading: false};
     *
     *
     * @returns T
     *
     * @docsPage toggle
     * @docsCategory transformation-helpers
     */
    static toggle(pObject, pKey) {
        const objectIsObject = isObjectGuard(pObject);
        const keyIsValid = isKeyOf(pKey);
        const initialObject = objectIsObject ? pObject : {};
        if (!objectIsObject) {
            console.warn(`Toggle: original value (${pObject}) is not an object.`);
        }
        if (!keyIsValid) {
            console.warn(`Toggle: key argument (${pKey}) is invalid.`);
        }
        if (keyIsValid && typeof initialObject[pKey] !== 'boolean') {
            console.warn(`Toggle: value of the key (${String(pKey)}) is not a boolean.`);
        }
        if (!isDefined(pObject) && !keyIsValid) {
            return pObject;
        }
        // eslint-disable-next-line no-prototype-builtins
        if (keyIsValid && (typeof initialObject[pKey] === 'boolean' || !initialObject.hasOwnProperty(pKey))) {
            return { ...initialObject, [pKey]: !initialObject[pKey] };
        }
        return { ...initialObject };
    }
    /**
     * Groups an array of objects by multiple keys.
     *
     * Each group is identified by a composite key, which is a string formed by joining the values
     * of the specified keys with a pipe (`|`). The result is an object where each property is a group,
     * and its value is an array of items belonging to that group.
     *
     * @param pData - The array of objects to group.
     * @param pKeys - The list of keys to group by. The order of keys determines the composite key structure.
     * @returns An object mapping composite keys to arrays of grouped items.
     *
     * @example
     * ```typescript
     * const data = [
     *   { a: 1, b: 2 },
     *   { a: 1, b: 3 },
     *   { a: 2, b: 2 }
     * ];
     * const grouped = groupByMultipleKeys(data, ['a', 'b']);
     * // grouped = {
     * //   '1|2': [{ a: 1, b: 2 }],
     * //   '1|3': [{ a: 1, b: 3 }],
     * //   '2|2': [{ a: 2, b: 2 }]
     * // }
     * ```
     */
    static groupByMultipleKeys(pData, pKeys) {
        return pData.reduce((pAcc, pItem) => {
            const groupKey = pKeys.map(pKey => pItem[pKey]).join('|');
            (pAcc[groupKey] = pAcc[groupKey] || []).push(pItem);
            return pAcc;
        }, {});
    }
    /**
     * Transforms all object keys so that the first character of each key is lowercase.
     *
     * @template T - The type of the returned object (defaults to `Record<string, unknown>`).
     * @param {Record<string, unknown>} pObj - The input object whose keys should be transformed.
     * @returns {T} A new object with transformed keys.
     *
     * @throws {Error} If any key is empty or invalid.
     *
     * @example
     * // Input: { UserName: "Alice", Age: 25 }
     * const result = transformObjectKeys({ UserName: "Alice", Age: 25 });
     * // Output: { userName: "Alice", age: 25 }
     */
    static transformObjectKeys(pObj) {
        const result = {};
        for (let [key, value] of Object.entries(pObj)) {
            if (!key || key.length === 0)
                throw new Error('Something went wrong when transformObjectKeys!!');
            key = key.charAt(0).toLowerCase() + key.slice(1);
            const newKey = key;
            result[newKey] = value;
        }
        return result;
    }
    /**
     * Determines whether a value is an object
     * (as opposed to a value type, an array, or a Date).
     *
     * @param pValue Value to test.
     */
    static isObject(pValue) {
        return pValue != null && typeof pValue == 'object' && !(pValue instanceof Date) && !(pValue instanceof Array);
    }
    /**
     * Determines whether an object is empty
     * (contains no enumerable properties).
     *
     * @param pObject Object to test.
     */
    static isEmpty(pObject) {
        for (const k in pObject)
            return false;
        return true;
    }
    /**
     * Determines whether an object is a function.
     *
     * @param value Value to test.
     */
    static isFunction(pObject) {
        return isFunction(pObject);
    }
    /**
     * Determines whether the given object is a Promise.
     *
     * @param pObj The object to test.
     * @returns True if the object is a Promise; otherwise, false.
     *
     * @example
     * isPromise(Promise.resolve(123)); // true
     * isPromise(123); // false
     */
    static isPromise(pObj) {
        return isPromise(pObj);
    }
    static isWritableSignal(pValue) {
        return isWritableSignal(pValue);
    }
    /**
     * Checks if an object contains a property matching the given value (case-insensitive).
     *
     * @param pObject - Object to check.
     * @param pValue - Property name to find.
     * @returns Matching property name if found; otherwise `null`.
     */
    static containsProperty(pObject, pValue) {
        for (const key in pObject) {
            if (key == pValue || (typeof key == 'string' && key.toLowerCase() == pValue.toLowerCase())) {
                return key;
            }
        }
        return '';
    }
    static hasProperty(pOwner, pPropName, pOutProp) {
        if (pOwner == null || BravoStringExtensions.isNullOrEmpty(pPropName))
            return false;
        let propName = this.canSetValue(pOwner, pPropName) ? pPropName : undefined;
        if (BravoStringExtensions.isNullOrEmpty(propName)) {
            const propLowerCase = pPropName.toLowerCase();
            propName = this.canSetValue(pOwner, propLowerCase) ? propLowerCase : undefined;
        }
        if (BravoStringExtensions.isNullOrEmpty(propName)) {
            const propFirstLowerCase = BravoStringExtensions.firstLowerCase(pPropName);
            propName = this.canSetValue(pOwner, propFirstLowerCase) ? propFirstLowerCase : undefined;
        }
        if (!BravoStringExtensions.isNullOrEmpty(propName)) {
            if (isNotNil(pOutProp))
                pOutProp.name = propName;
            return true;
        }
        return false;
    }
    static canSetValue(pObject, pKey) {
        if (!pObject || typeof pObject !== 'object')
            return false;
        // 1️⃣ field thường trên instance
        if (Object.prototype.hasOwnProperty.call(pObject, pKey)) {
            const desc = Object.getOwnPropertyDescriptor(pObject, pKey);
            // writable field
            if (!desc)
                return true;
            if ('writable' in desc)
                return desc.writable !== false;
            // accessor bị shadow
            return !!desc.set;
        }
        // 2️⃣ setter trên prototype chain
        let proto = Object.getPrototypeOf(pObject);
        while (proto) {
            const desc = Object.getOwnPropertyDescriptor(proto, pKey);
            if (desc) {
                // có setter → set được
                if (desc.set)
                    return true;
                // chỉ getter → không set được
                if (desc.get && !desc.set)
                    return false;
                // data prop trên prototype
                if ('writable' in desc)
                    return desc.writable !== false;
            }
            proto = Object.getPrototypeOf(proto);
        }
        // 3️⃣ key chưa tồn tại → JS cho phép tạo mới
        return false;
    }
}

/**
 * Utility class for working with TypeScript Enums.
 * Provides methods for retrieving enum values, parsing flags,
 * and performing case-insensitive enum lookups.
 */
class BravoEnumExtensions {
    /**
     * Checks whether a given value matches a key of the specified enum type.
     *
     * The comparison is case-insensitive if both the enum key and the value are strings.
     * If a match is found and `pOutArgs` is provided, the corresponding enum value
     * (either numeric or string-based) will be assigned to `pOutArgs.resultValue`.
     *
     * @param {Record<string, unknown>} pEnumType - The enum-like object to check against.
     * @param {unknown} pValue - The value to test against the enum keys.
     * @param {{ resultValue: unknown }} [pOutArgs] - Optional output parameter object
     * where the resolved enum value will be stored if a match is found.
     *
     * @returns {boolean} `true` if the value matches a key in the enum, otherwise `false`.
     *
     * @example
     * const Colors = { Red: 1, Green: 2, Blue: 3 };
     * let out = {};
     * isEnumType(Colors, "Green", out); // true, out.resultValue = 2
     *
     * isEnumType(Colors, "Yellow"); // false
     */
    static isEnumType(pEnumType, pValue, pOutArgs) {
        for (const keyEnum in pEnumType) {
            if (keyEnum == pValue ||
                (BravoStringExtensions.isString(keyEnum) &&
                    BravoStringExtensions.isString(pValue) &&
                    keyEnum.toLowerCase() == pValue.toLowerCase())) {
                if (pOutArgs) {
                    const key = parseInt(keyEnum);
                    if (!isNaN(key))
                        pOutArgs.resultValue = key;
                    else
                        pOutArgs.resultValue = pEnumType[keyEnum];
                }
                return true;
            }
        }
        return false;
    }
    /**
     * Returns all numeric values from an enum.
     *
     * @param {any} pValue - The enum object to extract values from.
     * @returns {Array<any>} An array of enum values (excluding string keys).
     *
     * @example
     * enum Permission { Read = 1, Write = 2, Execute = 4 }
     * const values = BravoEnumExtensions.getValuesEnum(Permission);
     * console.log(values); // [1, 2, 4]
     */
    static getValuesEnum(pValue) {
        if (pValue) {
            return BravoObjectExtensions.values(pValue).filter(pItem => typeof pItem !== 'string');
        }
        return [];
    }
    /**
     * Attempts to convert or match a given value to a specific enum type.
     * Supports numeric, string, and bitwise flag enums.
     *
     * @template T
     * @param {unknown} pValue - The value to match or convert.
     * @param {object} pEnumType - The enum type to compare against.
     * @returns {T | undefined} The matched enum value, or undefined if no match is found.
     *
     * @example
     * enum Permission { Read = 1, Write = 2, Execute = 4 }
     *
     * // Case-insensitive key lookup
     * const perm = BravoEnumExtensions.enumAttribute('read', Permission);
     * console.log(perm); // 1
     *
     * // Bitwise flag parsing
     * const flags = BravoEnumExtensions.enumAttribute('Read | Write', Permission);
     * console.log(flags); // 3
     */
    static enumAttribute(pValue, pEnumType) {
        if (!pEnumType || typeof pEnumType !== 'object') {
            console.warn(`Enum type ${pEnumType} invalid.`);
            return undefined;
        }
        if (pValue === undefined || pValue === null) {
            return pValue;
        }
        const enumValues = Object.values(pEnumType);
        const enumKeys = Object.keys(pEnumType);
        const isNumeric = BravoEnumExtensions.isNumericEnum(pEnumType);
        if (isNumeric) {
            const parsed = BravoEnumExtensions.parseEnumFlags(pEnumType, pValue);
            return parsed;
        }
        if (enumValues.includes(pValue)) {
            return pValue;
        }
        const matchedKey = enumKeys.find(pKey => pKey.toLowerCase() === pValue.toString().toLowerCase());
        if (matchedKey) {
            return pEnumType[matchedKey];
        }
        const matchedVal = enumValues.find(pVal => pVal.toString().toLowerCase() === pValue.toString().toLowerCase());
        return (matchedVal ?? undefined);
    }
    /**
     * Determines if an enum is numeric by checking for reverse key-value mapping.
     *
     * @param {object} pEnumObj - The enum to check.
     * @returns {boolean} True if the enum is numeric, otherwise false.
     *
     * @example
     * enum Color { Red = 1, Blue = 2 }
     * console.log(BravoEnumExtensions.isNumericEnum(Color)); // true
     *
     * enum Direction { Up = "UP", Down = "DOWN" }
     * console.log(BravoEnumExtensions.isNumericEnum(Direction)); // false
     */
    static isNumericEnum(pEnumObj) {
        return Object.keys(pEnumObj).some(pKey => typeof pEnumObj[pEnumObj[pKey]] === 'string');
    }
    /**
     * Parses bitwise (flags-style) enum values from a string or number.
     * Supports inputs like "Read | Write" or "Read, Write".
     *
     * @param {object} pEnumType - The enum type containing the flag values.
     * @param {any} pInput - The input value, either a string or number.
     * @returns {number} The combined numeric value of the matched flags.
     *
     * @example
     * enum Permission { Read = 1, Write = 2, Execute = 4 }
     *
     * // From string
     * const result = BravoEnumExtensions.parseEnumFlags(Permission, "Read | Write");
     * console.log(result); // 3
     *
     * // From number
     * const same = BravoEnumExtensions.parseEnumFlags(Permission, 3);
     * console.log(same); // 3
     */
    static parseEnumFlags(pEnumType, pInput) {
        if (typeof pInput === 'number') {
            return pInput;
        }
        if (typeof pInput === 'string') {
            const char = pInput.includes(',') ? ',' : '|';
            const flags = pInput.split(char).map(part => part.trim().toLowerCase());
            let result = 0;
            for (const key of Object.keys(pEnumType)) {
                if (isNaN(Number(key))) {
                    const keyLower = key.toLowerCase();
                    if (flags.includes(keyLower)) {
                        result |= pEnumType[key];
                    }
                }
            }
            return result;
        }
        return 0;
    }
    static asKeyofEnum(pKey, pEnum) {
        return pKey;
    }
}

class BravoRegexes {
    //#region General
    /**
     * Regular expression to validate phone numbers.
     * Matches phone numbers with optional country code.
     *
     * Examples:
     * ```
     * BravoRegexes.Phone.test("+84123456789") // true
     * BravoRegexes.Phone.test("0912345678")   // false (must be 9 digits after country code)
     * BravoRegexes.Phone.test("123456789")    // true
     * ```
     */
    static Phone = /^((\+?[0-9]{1,2})|([0-9]{1,2}))([0-9]{9})$/g;
    /**
     * Regular expression to validate email addresses.
     * Supports standard email formats.
     *
     * Examples:
     * ```
     * BravoRegexes.Email.test("example@email.com") // true
     * BravoRegexes.Email.test("user.name@domain.co") // true
     * BravoRegexes.Email.test("invalid-email@") // false
     * ```
     */
    static Email = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/g;
    /**
     * A regular expression to validate URLs with the following supported schemes: http, https, ftp, ftps, and sftp.
     *
     * The regex matches:
     * - URLs starting with one of the supported schemes followed by "://"
     * - Domain names (e.g., example.com) or IPv4 addresses (e.g., 192.168.1.1)
     * - Optional port numbers (e.g., :8080)
     * - Optional path segments (e.g., /path/to/resource)
     *
     * @example
     * // Valid URLs
     * BravoRegexes.Url.test('https://example.com'); // true
     * BravoRegexes.Url.test('ftp://192.168.1.1:21/files'); // true
     * BravoRegexes.Url.test('sftp://sub.domain.co.uk:2222/path'); // true
     *
     * @example
     * // Invalid URLs
     * BravoRegexes.Url.test('htp://example.com'); // false
     * BravoRegexes.Url.test('https://example'); // false
     * BravoRegexes.Url.test('http://256.256.256.256'); // false
     */
    static Url = /^(https?|ftps?|sftp):\/\/((([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,6})|(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}))(:[0-9]{1,5})?(\/.*)?$/;
    /**
     * Regular expression to match server file paths (absolute, UNC, URLs, and relative)
     *
     * Matches the following patterns:
     * - `\\` - UNC path (Universal Naming Convention) for Windows network shares
     *   Example: `\\server\share\file.txt`
     *
     * - `[a-zA-Z]:\\` - Windows absolute path with drive letter
     *   Example: `C:\Users\Documents\file.txt`, `D:\Projects\app.js`
     *
     * - `.+:\/\/` - URL with protocol scheme
     *   Example: `http://example.com/file.jpg`, `https://cdn.site.com/image.png`
     *
     * - `[^<>:"|*?]+` - Relative paths and file names (allows most characters except Windows forbidden ones)
     *   Example: `Temp/_Data/file (2).png`, `folder/file@#$%^&.txt`, `uploads/тест файл.jpg`
     *
     * @remarks
     * - This regular expression is designed for **broad validation** of file paths in both
     *   **server** and **web** contexts.
     * - It **accepts Unicode characters**, including Cyrillic, Arabic, Chinese, and accented Latin symbols.
     * - It **excludes** characters forbidden in Windows file systems: `<`, `>`, `:`, `"`, `|`, `*`, `?`.
     * - It does **not** validate the full correctness of URLs or enforce OS-specific folder structures.
     * - Intended for input sanitization, not for strict file system validation.
     * - For stronger validation (e.g., to ensure a file actually exists), additional logic should be implemented.
     *
     * @example
     * ```typescript
     * // Returns true - All valid server paths including special characters
     * BravoRegexes.FilePathServer.test('\\\\server\\share\\file.txt');                           // UNC path
     * BravoRegexes.FilePathServer.test('C:\\Windows\\System32\\cmd.exe');                        // Windows absolute
     * BravoRegexes.FilePathServer.test('https://example.com/api/data.json');                     // URL
     * BravoRegexes.FilePathServer.test('Temp/_Data/bae8bc0d-f312-a1ef-9178-f13637c05afe/19739.jpg'); // Relative path
     * BravoRegexes.FilePathServer.test('Temp/_Data/34b81236-aa90-06dc-b1a9-9f178f2823f0/drawing (2).png'); // Relative path with spaces
     * BravoRegexes.FilePathServer.test('uploads/images/файл.png');                              // Unicode characters
     * BravoRegexes.FilePathServer.test('folder/file@#$%^&!+=[]{}~`.txt');                       // Special characters
     * BravoRegexes.FilePathServer.test('data/مرحبا.json');                                       // Arabic characters
     * BravoRegexes.FilePathServer.test('files/测试文件.pdf');                                      // Chinese characters
     *
     * // Returns false - Invalid characters or empty paths
     * BravoRegexes.FilePathServer.test('folder/file<invalid>.txt');                             // Contains <
     * BravoRegexes.FilePathServer.test('folder/file>invalid.txt');                             // Contains >
     * BravoRegexes.FilePathServer.test('folder/file:invalid.txt');                             // Contains : (except in URLs)
     * BravoRegexes.FilePathServer.test('folder/file"invalid.txt');                             // Contains "
     * BravoRegexes.FilePathServer.test('folder/file|invalid.txt');                             // Contains |
     * BravoRegexes.FilePathServer.test('folder/file*invalid.txt');                             // Contains *
     * BravoRegexes.FilePathServer.test('folder/file?invalid.txt');                             // Contains ?
     * BravoRegexes.FilePathServer.test('');                                                      // Empty string
     * ```
     */
    static FilePathServer = /^(\\|[a-zA-Z]:\\|.+:\/\/|[^<>:"|*?]+)$/;
    /**
     * Regular expression to check if a local file path contains 'assets/' or 'assets\'.
     * @remarks
     * - This regex is **case-insensitive** (`/i` flag).
     *   For example, it matches both `assets/` and `ASSETS/`.
     * - It supports **cross-platform paths**, working on both Windows (`\`) and POSIX (`/`) systems.
     * - The pattern uses a **non-capturing group** `(?:^|[\\/])` to ensure that `assets` is either
     *   at the start of the path or preceded by a directory separator.
     * - It does **not** validate file existence — it only checks the path string structure.
     * - Useful for asset management, bundling, or filtering imported resource paths.
     * @example
     * BravoRegexes.AssetsPath.test('src/assets/image.png'); // true
     * BravoRegexes.AssetsPath.test('assets/file.txt'); // true
     * BravoRegexes.AssetsPath.test('public/images/file.png'); // false
     */
    static AssetsPath = /(?:^|[\\/])assets[\\/]/i;
    /**
     * Regular expression to match everything up to and including the last path separator (`/` or `\`) in a file path.
     *
     * @example
     * // Extract the file name from a path:
     * const path = "C:\\folder\\subfolder\\file.txt";
     * const fileName = path.replace(BravoRegexes.FileNameFromPath, ""); // "file.txt"
     *
     * @remarks
     * Useful for extracting the file name from a full file path.
     */
    static FileNameFromPath = /^.*[\\/]/;
    /**
     * Regular expression to match a CSS dimension value.
     * @remarks
     * This regular expression captures numeric CSS dimension values that include:
     * - An optional negative sign (`-`)
     * - An integer or decimal number (e.g. `10`, `-5.5`, `0.25`)
     * - A valid CSS unit: `px`, `%`, `vw`, `vh`, `rem`, or `em`
     * @example
     * // Valid dimension values
     * BravoRegexes.DimensionCss.test('10px'); // true
     * BravoRegexes.DimensionCss.test('50%'); // true
     * BravoRegexes.DimensionCss.test('20vw'); // true
     * BravoRegexes.DimensionCss.test('20rem'); // true
     **/
    static DimensionCss = /^(-?\d+(?:\.\d+)?)(px|%|vw|vh|rem|em)$/;
    /**
     * A regular expression that matches common CSS unit types.
     * This regex is useful for validating or extracting unit types from CSS values
     * such as `width`, `font-size`, or `margin`.
     *
     * Supported units include:
     * - `px` (pixels)
     * - `em` (relative to the font-size of the element)
     * - `rem` (relative to the font-size of the root element)
     * - `%` (percentage)
     * - `vw` (viewport width)
     * - `vh` (viewport height)
     *
     * The match is case-insensitive.
     *
     * @remarks
     * This regular expression only validates the unit type, **not** the numeric value
     * preceding it. For example, `20px` will not match the entire string — only `px` does.
     * To validate full CSS values (e.g., `20px`), you may use BravoRegexes.DimensionCss.
     *
     * @example
     * // Example usage:
     * const value = '20px';
     * const match = value.match(BravoRegexes.UnitTypeCss);
     * if (match) {
     *   console.log(`Valid CSS unit: ${match[0]}`);
     * } else {
     *   console.log('Invalid CSS unit.');
     * }
     */
    static UnitTypeCss = /^(px|em|rem|%|vw|vh)$/i;
    /**
     * Regular expression pattern to match temporary directory paths.
     * Matches paths starting with "temp" followed by an optional forward slash or backslash.
     * The pattern is case-insensitive.
     *
     * @example
     * // Matches: "temp", "temp/", "temp\\", "TEMP/", "Temp\\"
     * BravoRegexes.TempDirPattern.test("temp/file.txt"); // true
     * BravoRegexes.TempDirPattern.test("TEMP\\data"); // true
     * BravoRegexes.TempDirPattern.test("temporary"); // false
     */
    static TempDirPattern = /^temp[/\\]?/i;
    /**
     * Regular expression pattern to match public temporary directory paths.
     * Matches paths starting with "pub" followed by a separator, then "temp" with an optional separator.
     * The pattern is case-insensitive and handles both forward slashes and backslashes.
     *
     * @example
     * // Matches: "pub/temp", "pub\\temp\\", "PUB/TEMP/", "Pub\\Temp"
     * BravoRegexes.PublicTempDirPattern.test("pub/temp/cache"); // true
     * BravoRegexes.PublicTempDirPattern.test("PUB\\TEMP\\files"); // true
     * BravoRegexes.PublicTempDirPattern.test("public/temp"); // false
     * BravoRegexes.PublicTempDirPattern.test("pub/temporary"); // false
     */
    static PublicTempDirPattern = /^pub[/\\]temp[/\\]?/i;
    /**
     * @description
     * Checks whether a given file name or path has a valid image file extension.
     * Supports common formats: `.png`, `.jpg`, `.jpeg`, `.gif`, `.ico`.
     * The check is case-insensitive.
     *
     * @example
     * BravoRegexes.ImageExtensions.test("image.png");        // true
     * BravoRegexes.ImageExtensions.test("photo.JPG");        // true
     * BravoRegexes.ImageExtensions.test("document.pdf");     // false
     * BravoRegexes.ImageExtensions.test("/assets/icon.ico"); // true
     *
     * @remarks
     * This regex only checks the file **extension**, not the actual file content or MIME type.
     * For security-sensitive contexts (e.g., file uploads), you should verify the file’s MIME type
     * on the server side to prevent spoofed file extensions.
     *
     * It is also recommended to normalize file paths before testing them, as URLs or query strings
     * (e.g. `image.jpg?version=2`) may cause unexpected results unless handled separately.
     */
    static ImageExtensions = /\.(png|jpe?g|gif|ico)$/i;
    //#endregion General
    //#region CharacterRegex
    /**
     * Matches a single digit (0-9).
     * @example
     * BravoRegexes.Digit.test("5"); // true
     * BravoRegexes.Digit.test("a"); // false
     */
    static Digit = /^[0-9]$/;
    /**
     * Matches a single uppercase or lowercase letter (A-Z, a-z).
     * @example
     * BravoRegexes.Letter.test("A"); // true
     * BravoRegexes.Letter.test("9"); // false
     */
    static Letter = /^[A-Za-z]$/;
    /**
     * Matches a single alphanumeric character (A-Z, a-z, 0-9).
     * @example
     * BravoRegexes.AlphaNumeric.test("G"); // true
     * BravoRegexes.AlphaNumeric.test("7"); // true
     * BravoRegexes.AlphaNumeric.test("%"); // false
     */
    static AlphaNumeric = /^[A-Za-z0-9]$/;
    /**
     * Matches a single hexadecimal character (0-9, A-F, a-f).
     * @example
     * BravoRegexes.Hexadecimal.test("F"); // true
     * BravoRegexes.Hexadecimal.test("g"); // false
     */
    static Hexadecimal = /^[0-9A-Fa-f]$/;
    /**
     * Matches a single special character (any character that is not a letter or digit).
     * @example
     * BravoRegexes.Special.test("!"); // true
     * BravoRegexes.Special.test("A"); // false
     */
    static Special = /^[^A-Za-z0-9]$/;
    /**
     * Matches any uppercase letter (A-Z).
     * @example
     * BravoRegexes.UpperCase.test("G"); // true
     * BravoRegexes.UpperCase.test("g"); // false
     */
    static UpperCase = /[A-Z]/;
    /**
     * Matches any lowercase letter (a-z).
     * @example
     * BravoRegexes.LowerCase.test("g"); // true
     * BravoRegexes.LowerCase.test("G"); // false
     */
    static LowerCase = /[a-z]/;
    /**
     * Matches a string containing at least one letter and one number.
     * @example
     * BravoRegexes.LetterAndNumber.test("abc123"); // true
     * BravoRegexes.LetterAndNumber.test("abcdef"); // false
     * BravoRegexes.LetterAndNumber.test("123456"); // false
     */
    static LetterAndNumber = /^(?=.*[a-zA-Z])(?=.*\d).+$/;
    /**
     * Matches a string containing at least one special character.
     * @example
     * BravoRegexes.SpecialChar.test("hello@world"); // true
     * BravoRegexes.SpecialChar.test("helloworld"); // false
     */
    static SpecialChar = /[!@#$%^&*()_+\-=\\[\]{};':"\\|,.<>\\/?]+/;
    //#endregion CharacterRegex
    /**
     * @description
     * Regex to split the main URL path from query parameters (`?`) or hash fragments (`#`).
     *
     * @example
     * const url = "/auth?token=abc#section";
     * const [basePath] = url.split(BravoRegexes.QueryOrHashSeparator);
     * console.log(basePath); // "/auth"
     *
     * @remarks
     * This regex is useful for separating the core path from query strings or hash fragments.
     * It does not validate whether the URL itself is well-formed; it only detects separators (`?` or `#`).
     */
    static QueryOrHashSeparator = /[?#]/;
    /**
     * @description
     * Regex to check whether a URL contains query parameters.
     *
     * @example
     * const url = "/auth?token=123";
     * console.log(BravoRegexes.QueryString.test(url)); // true
     *
     * @remarks
     * Matches any `?` followed by at least one character.
     * Use this to quickly determine if a URL includes a query string.
     * Note that it does not parse or validate the structure of the query parameters.
     */
    static QueryString = /\?.+/;
    /**
     * @description
     * Regex to check whether a URL contains a hash fragment (`#`).
     *
     * @example
     * const url = "/auth#section";
     * console.log(BravoRegexes.HashFragment.test(url)); // true
     *
     * @remarks
     * Matches any `#` followed by one or more characters.
     * Useful for detecting in-page navigation fragments (e.g., `#section1`).
     * Like `QueryString`, this regex does not validate the fragment format.
     */
    static HashFragment = /#.+/;
    /**
     * @description
     * Regex to remove both query parameters and hash fragments, keeping only the main path.
     *
     * @example
     * const url = "/auth?token=123#section";
     * const cleanUrl = url.replace(BravoRegexes.FullUrlCleanup, '');
     * console.log(cleanUrl); // "/auth"
     *
     * @remarks
     * Matches any `?` or `#` followed by any number of characters until the end of the string.
     * This is ideal for cleaning URLs before processing routing or path comparison logic.
     * It does not decode URL-encoded characters or normalize slashes.
     */
    static FullUrlCleanup = /[?#].*/;
    /**
     * @description
     * Regex to parse sort expressions that may include column names (with or without brackets)
     * and optional sort directions (`ASC` or `DESC`).
     *
     * @example
     * const sort1 = "[Customer Name] ASC".match(BravoRegexes.SortPattern);
     * // => ["[Customer Name] ASC", "Customer Name", "", " ASC", "ASC"]
     *
     * const sort2 = "CustomerID desc".match(BravoRegexes.SortPattern);
     * // => ["CustomerID desc", undefined, "CustomerID", " desc", "desc"]
     *
     * @remarks
     * - Matches column names either enclosed in brackets `[Column Name]` or plain names like `ColumnName`.
     * - Optionally captures the sorting direction (`ASC` or `DESC`) after whitespace.
     * - Case-insensitive (`i` flag) to allow flexible input like `asc`, `Asc`, or `DESC`.
     *
     * Typical use cases:
     * - Parsing SQL-like ORDER BY expressions.
     * - Extracting column and direction for client-side sorting logic.
     */
    static SortPattern = /\[([^\]]*)\]|(\w*)(\s(ASC|DESC)*)*/i;
    /**
     * Escapes all special characters in a string so it can be safely used
     * inside a regular expression pattern.
     *
     * This includes characters such as: ., *, +, ?, ^, $, { }, ( ), |, [ ], \\
     *
     * @param {string} pString - The input string that may contain regex special characters.
     * @returns {string} The escaped string, safe for insertion into a RegExp.
     */
    static escapeRegex(pString) {
        return pString.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }
}

class Reflection {
    static _apiMap = 'api:map:';
    static _apiMapJsonObject = `${Reflection._apiMap}jsonObject`;
    static _designType = 'design:type';
    static _designParamTypes = 'design:paramtypes';
    static getBaseClass(pTarget) {
        return pTarget ? Reflect.getPrototypeOf(pTarget) : undefined;
    }
    static getJsonPropertiesMetadata(pTarget, pName) {
        if (!pTarget) {
            return undefined;
        }
        const key = `${Reflection._apiMap}${pName || pTarget.constructor.name}`;
        return Reflect.getMetadata(key, pTarget);
    }
    static getParamTypes(pTarget) {
        return pTarget ? Reflect.getMetadata(Reflection._designParamTypes, pTarget) : undefined;
    }
    static getJsonObjectMetadata(pType) {
        return pType ? Reflect.getMetadata(Reflection._apiMapJsonObject, pType) : undefined;
    }
    static getType(pTarget, pKey) {
        return pTarget ? Reflect.getMetadata(Reflection._designType, pTarget, pKey) : undefined;
    }
    static isJsonObject(pType) {
        return pType ? Reflect.hasOwnMetadata(Reflection._apiMapJsonObject, pType) : false;
    }
    static setJsonPropertiesMetadata(pValue, pTarget) {
        if (!pTarget) {
            return;
        }
        const key = `${Reflection._apiMap}${pTarget.constructor.name}`;
        Reflect.defineMetadata(key, pValue, pTarget);
    }
    static setJsonObject(pValue, pTarget) {
        if (!pTarget) {
            return;
        }
        Reflect.defineMetadata(Reflection._apiMapJsonObject, pValue, pTarget);
    }
    static setType(pType, pTarget, pKey) {
        if (!pTarget || !pType) {
            return;
        }
        Reflect.defineMetadata(Reflection._designType, pType, pTarget, pKey);
    }
}

const hasConstructor = (pFunc) => {
    if (typeof pFunc !== 'function') {
        return false;
    }
    try {
        Reflect.construct(String, [], pFunc);
    }
    catch {
        return false;
    }
    return true;
};
const isJsonObject = (propertyType) => Reflection.isJsonObject(propertyType);
const isArray = (pValue) => Array.isArray(pValue);
const isObject = (pValue) => pValue !== null && typeof pValue === 'object' && !isArray(pValue);
const isPredicate = (pValue) => {
    if (!pValue) {
        return false;
    }
    const paramTypes = Reflection.getParamTypes(pValue);
    const valueLength = pValue.length;
    return (valueLength === 1 || valueLength === 2) && !paramTypes;
};
const differenceArray = (pArr1, pArr2) => pArr1.filter(pElement1 => !pArr2.some(pElement2 => pElement1 === pElement2));
const isDateObject = (pValue) => toString.call(pValue) === '[object Date]';
const isDateValue = (pValue) => {
    if (isDateObject(pValue) || isArray(pValue)) {
        return false;
    }
    return !isNaN(Date.parse(pValue));
};

class JsonSerializerOptions {
    errorCallback = logError;
    nullishPolicy = {
        undefined: 'remove',
        null: 'allow',
    };
    additionalPropertiesPolicy = 'remove';
    formatPropertyName;
}
const throwError = (pMessage) => {
    throw new Error(pMessage);
};
const logError = (pMessage) => {
    console.error(pMessage);
};

class JsonSerializer {
    options = new JsonSerializerOptions();
    constructor(pOptions) {
        this.options = { ...this.options, ...pOptions };
    }
    deserialize(pValue, pType) {
        if (BravoStringExtensions.isString(pValue)) {
            pValue = tryParse(pValue);
        }
        if (BravoArrayExtensions.isArray(pValue)) {
            return this.deserializeObjectArray(BravoArrayExtensions.asArray(pValue), pType);
        }
        else if (isObject(pValue)) {
            return this.deserializeObject(pValue, pType);
        }
        this._error(`Fail to deserialize: value is not an Array nor an Object.\nReceived: ${JSON.stringify(pValue)}.`);
        return undefined;
    }
    deserializeObject(pObj, pType) {
        if (pObj === null) {
            if (this.options.nullishPolicy.null === 'disallow') {
                this._error('Fail to deserialize: null is not assignable to type Object.');
            }
            return null;
        }
        if (pObj === undefined) {
            if (this.options.nullishPolicy.undefined === 'disallow') {
                this._error('Fail to deserialize: undefined is not assignable to type Object.');
            }
            return undefined;
        }
        if (BravoStringExtensions.isString(pObj)) {
            pObj = tryParse(pObj);
        }
        if (!isObject(pObj)) {
            this._error(`Fail to deserialize: type '${typeof pObj}' is not assignable to type 'Object'.\nReceived: ${JSON.stringify(pObj)}`);
            return undefined;
        }
        let instance;
        if (hasConstructor(pType)) {
            const tmpInstance = Object.create(pType.prototype);
            const jsonObjectMetadata = Reflection.getJsonObjectMetadata(tmpInstance.constructor);
            const constructorParams = jsonObjectMetadata?.constructorParams ?? [];
            instance = new pType(...constructorParams);
        }
        else {
            instance = pType;
        }
        const jsonPropertiesMetadata = this._getJsonPropertiesMetadata(instance);
        if (!jsonPropertiesMetadata) {
            return instance;
        }
        const jsonPropertiesMetadataKeys = Object.keys(jsonPropertiesMetadata);
        jsonPropertiesMetadataKeys.forEach(pKey => {
            const metadata = jsonPropertiesMetadata[pKey];
            const property = this._deserializeProperty(instance, pKey, pObj, metadata);
            this._checkRequiredProperty(metadata, instance, pKey, property, pObj, false);
            let value = instance[pKey];
            if (property !== value && ((property === null && value === undefined) || !isNullish(property))) {
                value = property;
            }
            if (this._isAllowedProperty(pKey, value, metadata)) {
                instance[pKey] = value;
            }
        });
        if (this.options.additionalPropertiesPolicy === 'remove') {
            return instance;
        }
        const additionalProperties = differenceArray(Object.keys(pObj), jsonPropertiesMetadataKeys);
        if (!additionalProperties.length) {
            return instance;
        }
        if (this.options.additionalPropertiesPolicy === 'disallow') {
            this._error(`Additional properties detected in ${JSON.stringify(pObj)}: ${additionalProperties}.`);
        }
        else if (this.options.additionalPropertiesPolicy === 'allow') {
            additionalProperties.forEach(pKey => (instance[pKey] = pObj[pKey]));
        }
        return instance;
    }
    deserializeObjectArray(pArray, pType) {
        if (pArray === null) {
            if (this.options.nullishPolicy.null === 'disallow') {
                this._error('Fail to deserialize: null is not assignable to type Array.');
            }
            return null;
        }
        if (pArray === undefined) {
            if (this.options.nullishPolicy.undefined === 'disallow') {
                this._error('Fail to deserialize: undefined is not assignable to type Array.');
            }
            return undefined;
        }
        if (BravoStringExtensions.isString(pArray)) {
            pArray = tryParse(pArray);
        }
        if (!BravoArrayExtensions.isArray(pArray)) {
            this._error(`Fail to deserialize: type '${typeof pArray}' is not assignable to type 'Array'.\nReceived: ${JSON.stringify(pArray)}`);
            return undefined;
        }
        return BravoArrayExtensions.asArray(pArray).reduce((pDeserializedArray, pObj) => {
            const deserializedObject = this.deserializeObject(pObj, pType);
            if (!isNullish(deserializedObject) ||
                (deserializedObject === null && this.options.nullishPolicy.null !== 'remove') ||
                (deserializedObject === undefined && this.options.nullishPolicy.undefined !== 'remove')) {
                pDeserializedArray.push(deserializedObject);
            }
            return pDeserializedArray;
        }, []);
    }
    serialize(pValue) {
        if (BravoArrayExtensions.isArray(pValue)) {
            return this.serializeObjectArray(BravoArrayExtensions.asArray(pValue));
        }
        else if (isObject(pValue)) {
            return this._serializeObject(pValue);
        }
        this._error(`Fail to serialize: value is not an Array nor an Object.\nReceived: ${JSON.stringify(pValue)}.`);
        return undefined;
    }
    _serializeObject(pInstance) {
        if (pInstance === null) {
            if (this.options.nullishPolicy.null === 'disallow') {
                this._error('Fail to serialize: null is not assignable to type Object.');
            }
            return null;
        }
        if (pInstance === undefined) {
            if (this.options.nullishPolicy.undefined === 'disallow') {
                this._error('Fail to serialize: undefined is not assignable to type Object.');
            }
            return undefined;
        }
        if (!isObject(pInstance)) {
            return pInstance;
        }
        const jsonPropertiesMetadata = this._getJsonPropertiesMetadata(pInstance);
        if (!jsonPropertiesMetadata) {
            return pInstance;
        }
        const json = {};
        const instanceKeys = Object.keys(pInstance);
        const jsonPropertiesMetadataKeys = Object.keys(jsonPropertiesMetadata);
        jsonPropertiesMetadataKeys.forEach(pKey => {
            const metadata = jsonPropertiesMetadata[pKey];
            if (instanceKeys.includes(pKey)) {
                let initialValue;
                if (metadata.beforeSerialize) {
                    initialValue = pInstance[pKey];
                    pInstance[pKey] = metadata.beforeSerialize(pInstance[pKey], pInstance);
                }
                let property = this._serializeProperty(pInstance, pKey, metadata);
                if (metadata.afterSerialize) {
                    property = metadata.afterSerialize(property, pInstance);
                }
                pInstance[pKey] = initialValue || pInstance[pKey];
                if (BravoArrayExtensions.isArray(metadata.pName)) {
                    BravoArrayExtensions.asArray(metadata.pName).forEach((pName) => {
                        if (this._isAllowedProperty(pName, property[pName])) {
                            json[pName] = property[pName];
                        }
                    });
                }
                else {
                    this._checkRequiredProperty(metadata, pInstance, pKey, property, pInstance);
                    if (this._isAllowedProperty(pKey, property, metadata)) {
                        if (!metadata.pIsNameOverridden && this.options.formatPropertyName !== undefined) {
                            const name = this.options.formatPropertyName(metadata.pName);
                            json[name] = property;
                        }
                        else {
                            json[metadata.pName] = property;
                        }
                    }
                }
            }
            else {
                if (BravoArrayExtensions.isArray(metadata.pName)) {
                    BravoArrayExtensions.asArray(metadata.pName).forEach(pName => {
                        if (this._isAllowedProperty(pName, undefined)) {
                            json[pName] = undefined;
                        }
                    });
                }
                else {
                    this._checkRequiredProperty(metadata, pInstance, pKey, undefined, pInstance);
                    if (this._isAllowedProperty(pKey, undefined, metadata)) {
                        json[metadata.pName] = undefined;
                    }
                }
            }
        });
        if (this.options.additionalPropertiesPolicy === 'remove') {
            return json;
        }
        const additionalProperties = differenceArray(instanceKeys, jsonPropertiesMetadataKeys);
        if (!additionalProperties.length) {
            return json;
        }
        if (this.options.additionalPropertiesPolicy === 'disallow') {
            this._error(`Additional properties detected in ${JSON.stringify(pInstance)}: ${additionalProperties}.`);
        }
        else if (this.options.additionalPropertiesPolicy === 'allow') {
            additionalProperties.forEach(pKey => (json[pKey] = pInstance[pKey]));
        }
        return json;
    }
    serializeObjectArray(pArray) {
        if (pArray === null) {
            if (this.options.nullishPolicy.null === 'disallow') {
                this._error('Fail to serialize: null is not assignable to type Array.');
            }
            return null;
        }
        if (pArray === undefined) {
            if (this.options.nullishPolicy.undefined === 'disallow') {
                this._error('Fail to serialize: undefined is not assignable to type Array.');
            }
            return undefined;
        }
        if (!BravoArrayExtensions.isArray(pArray)) {
            this._error(`Fail to serialize: type '${typeof pArray}' is not assignable to type 'Array'.\nReceived: ${JSON.stringify(pArray)}.`);
            return undefined;
        }
        return pArray.reduce((pSerializedArray, pObj) => {
            const serializeObject = this._serializeObject(pObj);
            if (!isNullish(serializeObject) ||
                (serializeObject === null && this.options.nullishPolicy.null !== 'remove') ||
                (serializeObject === undefined && this.options.nullishPolicy.undefined !== 'remove')) {
                pSerializedArray.push(serializeObject);
            }
            return pSerializedArray;
        }, []);
    }
    _checkRequiredProperty(pMetadata, pInstance, pKey, property, pObj, pIsSerialization = true) {
        if (pMetadata.required && isNullish(property) && isNullish(pInstance[pKey])) {
            const instanceName = pInstance['constructor'].name;
            this._error(`Fail to ${pIsSerialization ? 'serialize' : 'deserialize'}: Property '${pKey}' is required in ${instanceName} ${JSON.stringify(pObj)}.`);
        }
    }
    _deserializeProperty(pInstance, pPropertyKey, pObj, pMetadata) {
        if (isNullish(pObj)) {
            return undefined;
        }
        let dataSource = this._getDataSource(pObj, pMetadata, this.options.formatPropertyName);
        if (isNullish(dataSource)) {
            return dataSource;
        }
        const type = Reflection.getType(pInstance, pPropertyKey);
        const { isArrayProperty, isSetProperty, isMapProperty, isDictionaryProperty } = this._getDataStructureInformation(type, pInstance[pPropertyKey], pMetadata);
        let propertyType = pMetadata.type || type;
        if (pMetadata.beforeDeserialize) {
            dataSource = pMetadata.beforeDeserialize(dataSource, pInstance);
        }
        let property;
        const predicate = pMetadata.predicate;
        if (isDictionaryProperty || isMapProperty) {
            property = this._deserializeDictionary(dataSource, propertyType, predicate);
            if (isMapProperty) {
                property = new Map(Object.entries(property));
            }
        }
        else if (isArrayProperty || isSetProperty) {
            property = this._deserializeArray(dataSource, propertyType, predicate);
            if (isSetProperty) {
                property = new Set(property);
            }
        }
        else if ((!isJsonObject(propertyType) && !predicate) || (predicate && !predicate(dataSource, pObj))) {
            property = this._deserializePrimitive(dataSource, propertyType.name);
        }
        else {
            propertyType = pMetadata.predicate ? pMetadata.predicate(dataSource, pObj) : propertyType;
            property = this.deserializeObject(dataSource, propertyType);
        }
        if (pMetadata.afterDeserialize) {
            property = pMetadata.afterDeserialize(property, pInstance);
        }
        return property;
    }
    _deserializePrimitive(pValue, pType) {
        if (isNullish(pType)) {
            return pValue;
        }
        pType = pType.toLowerCase();
        if (typeof pValue === pType) {
            return pValue;
        }
        const error = `Fail to deserialize: type '${typeof pValue}' is not assignable to type '${pType}'.\nReceived: ${JSON.stringify(pValue)}`;
        switch (pType) {
            case 'string': {
                const string = pValue.toString();
                if (string === '[object Object]') {
                    this._error(error);
                    return undefined;
                }
                return string;
            }
            case 'number': {
                if (!isNumber(pValue)) {
                    this._error(error);
                    return undefined;
                }
                return +pValue;
            }
            case 'boolean': {
                this._error(error);
                return undefined;
            }
            case 'date': {
                if (!isDateValue(pValue)) {
                    this._error(error);
                    return undefined;
                }
                return new Date(pValue);
            }
            default:
                return pValue;
        }
    }
    _deserializeDictionary(pDict, pType, pPredicate) {
        if (!isObject(pDict)) {
            this._error(`Fail to deserialize: type '${typeof pDict}' is not assignable to type 'Dictionary'.\nReceived: ${JSON.stringify(pDict)}.`);
            return undefined;
        }
        const obj = {};
        Object.keys(pDict).forEach(pKey => {
            const predicateType = pPredicate ? pPredicate(pDict[pKey], pDict) : undefined;
            if (!isJsonObject(pType) && !predicateType) {
                obj[pKey] = this._deserializePrimitive(pDict[pKey], typeof pDict[pKey]);
            }
            else {
                obj[pKey] = this.deserializeObject(pDict[pKey], predicateType || pType);
            }
        });
        return obj;
    }
    _deserializeArray(pArray, pType, pPredicate) {
        if (!BravoArrayExtensions.isArray(pArray)) {
            this._error(`Fail to deserialize: type '${typeof pArray}' is not assignable to type 'Array'.\nReceived: ${JSON.stringify(pArray)}`);
            return undefined;
        }
        return pArray.reduce((pDeserializedArray, pObj) => {
            let deserializedValue;
            if (!isJsonObject(pType) && !pPredicate) {
                deserializedValue = this._deserializePrimitive(pObj, typeof pObj);
            }
            else {
                pType = pPredicate ? pPredicate(pObj, pArray) : pType;
                deserializedValue = this.deserializeObject(pObj, pType);
            }
            if (!isNullish(deserializedValue) ||
                (deserializedValue === null && this.options.nullishPolicy.null !== 'remove') ||
                (deserializedValue === undefined && this.options.nullishPolicy.undefined !== 'remove')) {
                pDeserializedArray.push(deserializedValue);
            }
            return pDeserializedArray;
        }, []);
    }
    _error(pMessage) {
        if (this.options.errorCallback) {
            this.options.errorCallback(pMessage);
        }
    }
    _getClassesJsonPropertiesMetadata(pClassNames, pInstance) {
        if (!pClassNames) {
            return [];
        }
        return pClassNames.reduce((pResult, pClassName) => {
            const metadata = Reflection.getJsonPropertiesMetadata(pInstance, pClassName);
            if (metadata) {
                pResult.push(metadata);
            }
            return pResult;
        }, []);
    }
    _getDataSource(pJson, { pName, pIsNameOverridden }, pFormat) {
        if (BravoArrayExtensions.isArray(pName)) {
            const data = {};
            BravoArrayExtensions.asArray(pName).forEach((pValue) => (data[pValue] = pJson[pValue]));
            return data;
        }
        else if (!pIsNameOverridden && pFormat) {
            pName = pFormat(pName);
            return pJson[pName];
        }
        return pJson[pName];
    }
    _getDataStructureInformation(pType, pProperty, pMetadata) {
        if (pMetadata.dataStructure) {
            return {
                isArrayProperty: pMetadata.dataStructure === 'array' || false,
                isDictionaryProperty: pMetadata.dataStructure === 'dictionary' || false,
                isMapProperty: pMetadata.dataStructure === 'map' || false,
                isSetProperty: pMetadata.dataStructure === 'set' || false,
            };
        }
        const typeName = pType?.name?.toLowerCase();
        /**
         * When a property is set as possibly undefined the type change
         * to object even if it is an array, a set or a map.
         */
        return typeName === 'object'
            ? {
                isArrayProperty: BravoArrayExtensions.isArray(pProperty),
                isDictionaryProperty: false,
                isMapProperty: isMap(pProperty),
                isSetProperty: isSet(pProperty),
            }
            : {
                isArrayProperty: typeName === 'array',
                isDictionaryProperty: false,
                isMapProperty: typeName === 'map',
                isSetProperty: typeName === 'set',
            };
    }
    _getJsonPropertiesMetadata(pInstance) {
        const { baseClassNames } = Reflection.getJsonObjectMetadata(pInstance.constructor) ?? {};
        const instanceMap = Reflection.getJsonPropertiesMetadata(pInstance);
        if (!instanceMap && (!baseClassNames || !baseClassNames.length)) {
            return instanceMap;
        }
        if (baseClassNames && baseClassNames.length) {
            const basePropertiesMetadata = this._getClassesJsonPropertiesMetadata(baseClassNames, pInstance);
            return this._mergeJsonPropertiesMetadata(...basePropertiesMetadata, instanceMap);
        }
        return instanceMap;
    }
    _isAllowedProperty(pName, pValue, pMetadata) {
        if (isNullish(pValue)) {
            if (this.options.nullishPolicy[`${pValue}`] === 'disallow') {
                this._error(`Disallowed ${pValue} value detected: ${pName}.`);
                return false;
            }
            else if (this.options.nullishPolicy[`${pValue}`] === 'remove') {
                return false;
            }
        }
        if (pMetadata && !isNullish(pMetadata.defaultValue) && pValue === pMetadata.defaultValue)
            return false;
        return true;
    }
    _mergeJsonPropertiesMetadata(...pMetadataMaps) {
        const jsonPropertiesMetadata = {};
        pMetadataMaps.forEach(pMetadataMap => {
            if (pMetadataMap) {
                Object.keys(pMetadataMap).forEach(pKey => {
                    jsonPropertiesMetadata[pKey] = {
                        ...jsonPropertiesMetadata[pKey],
                        ...pMetadataMap[pKey],
                    };
                });
            }
        });
        return jsonPropertiesMetadata;
    }
    _serializeDictionary(pDict) {
        if (!isObject(pDict)) {
            this._error(`Fail to serialize: type '${typeof pDict}' is not assignable to type 'Dictionary'.\nReceived: ${JSON.stringify(pDict)}.`);
            return undefined;
        }
        const obj = {};
        Object.keys(pDict).forEach(pKey => {
            obj[pKey] = this._serializeObject(pDict[pKey]);
        });
        return obj;
    }
    _serializeProperty(pInstance, pKey, pMetadata) {
        const property = pInstance[pKey];
        const type = Reflection.getType(pInstance, pKey);
        const { isArrayProperty, isDictionaryProperty, isMapProperty, isSetProperty } = this._getDataStructureInformation(type, property, pMetadata);
        const predicate = pMetadata.predicate;
        const propertyType = pMetadata.type || type;
        const isJsonObjectProperty = isJsonObject(propertyType);
        if (property && (isJsonObjectProperty || predicate)) {
            if (isArrayProperty || isSetProperty) {
                const array = isSetProperty ? Array.from(property) : property;
                return this.serializeObjectArray(array);
            }
            if (isDictionaryProperty || isMapProperty) {
                if (!isMapProperty) {
                    return this._serializeDictionary(property);
                }
                const obj = {};
                property.forEach((pValue, pMapKey) => {
                    if (BravoStringExtensions.isString(pMapKey)) {
                        obj[pMapKey] = pValue;
                    }
                    else {
                        this._error(`Fail to serialize: type of '${typeof pMapKey}' is not assignable to type 'string'.\nReceived: ${JSON.stringify(pMapKey)}.`);
                    }
                });
                return this._serializeDictionary(obj);
            }
            return this._serializeObject(property);
        }
        if (propertyType?.name?.toLocaleLowerCase() === 'date' && isDateObject(property)) {
            return property.toJSON();
        }
        return property;
    }
}

const getBaseClassNames = (pTarget) => {
    const baseClass = Reflection.getBaseClass(pTarget);
    return baseClass && baseClass.name ? [...getBaseClassNames(baseClass), baseClass.name] : [];
};
const JsonObject = (pOptions) => (pTarget) => {
    const baseClassNames = getBaseClassNames(pTarget);
    const constructorParams = pOptions?.constructorParams ?? [];
    Reflection.setJsonObject({ baseClassNames, constructorParams }, pTarget);
};

const JsonConstants = {
    ReturnValuePropName: 'returnValue',
    OutputValuePropName: 'outputValue',
    CaseSensitivePropName: 'caseSensitive',
    PrefixPropName: 'prefix',
    DataSetNamePropName: 'dataSetName',
    TablesPropName: 'tables',
    RelationsPropName: 'relations',
    TableNamePropName: 'tableName',
    ColumnsPropName: 'columns',
    RowsPropName: 'rows',
    SortPropName: 'sort',
    ExtendedPropertiesPropName: 'extendedProperties',
    UniqueKeysPropName: 'uniqueKeys',
    ColumnNamePropName: 'columnName',
    CaptionPropName: 'caption',
    DefaultValuePropName: 'defaultValue',
    IsKeyPropName: 'isKey',
    AllowDBNullPropName: 'allowDBNull',
    AutoIncrementPropName: 'autoIncrement',
    AutoIncrementSeedPropName: 'autoIncrementSeed',
    AutoIncrementStepPropName: 'autoIncrementStep',
    DataTypePropName: 'dataType',
    DateTimeModePropName: 'dateTimeMode',
    MaxLengthPropName: 'maxLength',
    ReadOnlyPropName: 'readOnly',
    UniquePropName: 'unique',
    RowStatePropName: 'rowState',
    RowCurrentItemsPropName: 'currentItems',
    RowOriginalItemsPropName: 'originalItems',
    RelationNamePropName: 'relationName',
    ParentTablePropName: 'parentTable',
    ParentColumnsPropName: 'parentColumns',
    ChildTablePropName: 'childTable',
    ChildColumnsPropName: 'childColumns',
    CommandTimeoutPropName: 'commandTimeout',
    CommandTypePropName: 'commandType',
    UpdatedRowSourcePropName: 'updatedRowSource',
    CommandTextPropName: 'commandText',
    ParametersPropName: 'parameters',
    TransactionLevelPropName: 'transactionLevel',
    DbTypePropName: 'dbType',
    DirectionPropName: 'direction',
    IsNullablePropName: 'isNullable',
    SizePropName: 'size',
    SourceColumnPropName: 'sourceColumn',
    SourceVersionPropName: 'sourceVersion',
    ParameterNamePropName: 'prn',
    ParameterValuePropName: 'val',
    ScalePropName: 'scale',
    PrecisionPropName: 'precision',
};
const propNames = new Map([
    [JsonConstants.ReturnValuePropName, 'rtv'],
    [JsonConstants.OutputValuePropName, 'opv'],
    [JsonConstants.CaseSensitivePropName, 'cst'],
    [JsonConstants.PrefixPropName, 'prf'],
    [JsonConstants.DataSetNamePropName, 'dsn'],
    [JsonConstants.TablesPropName, 'tbl'],
    [JsonConstants.RelationsPropName, 'rlt'],
    [JsonConstants.TableNamePropName, 'tbl'],
    [JsonConstants.ColumnsPropName, 'cln'],
    [JsonConstants.CaptionPropName, 'cap'],
    [JsonConstants.RowsPropName, 'rws'],
    [JsonConstants.SortPropName, 'sot'],
    [JsonConstants.ExtendedPropertiesPropName, 'etp'],
    [JsonConstants.UniqueKeysPropName, 'unk'],
    [JsonConstants.ColumnNamePropName, 'cln'],
    [JsonConstants.DefaultValuePropName, 'dfv'],
    [JsonConstants.AllowDBNullPropName, 'adn'],
    [JsonConstants.AutoIncrementPropName, 'aic'],
    [JsonConstants.AutoIncrementStepPropName, 'aist'],
    [JsonConstants.AutoIncrementSeedPropName, 'ais'],
    [JsonConstants.IsKeyPropName, 'iky'],
    [JsonConstants.DataTypePropName, 'dtp'],
    [JsonConstants.MaxLengthPropName, 'mlg'],
    [JsonConstants.ReadOnlyPropName, 'rol'],
    [JsonConstants.UniquePropName, 'unq'],
    [JsonConstants.RowStatePropName, 'rst'],
    [JsonConstants.RowCurrentItemsPropName, 'crt'],
    [JsonConstants.RowOriginalItemsPropName, 'ori'],
    [JsonConstants.RelationNamePropName, 'rln'],
    [JsonConstants.ParentTablePropName, 'ptn'],
    [JsonConstants.ParentColumnsPropName, 'pcn'],
    [JsonConstants.ChildTablePropName, 'ctn'],
    [JsonConstants.ChildColumnsPropName, 'ccn'],
    [JsonConstants.DbTypePropName, 'dbt'],
    [JsonConstants.DirectionPropName, 'drt'],
    [JsonConstants.IsNullablePropName, 'ina'],
    [JsonConstants.SizePropName, 'sze'],
    [JsonConstants.SourceColumnPropName, 'scl'],
    [JsonConstants.SourceVersionPropName, 'svs'],
    [JsonConstants.ParameterNamePropName, 'prn'],
    [JsonConstants.ParameterValuePropName, 'val'],
    [JsonConstants.ScalePropName, 'sca'],
    [JsonConstants.PrecisionPropName, 'prc'],
    [JsonConstants.CommandTimeoutPropName, 'cto'],
    [JsonConstants.CommandTypePropName, 'ctp'],
    [JsonConstants.UpdatedRowSourcePropName, 'urs'],
    [JsonConstants.CommandTextPropName, 'cmt'],
    [JsonConstants.ParametersPropName, 'prm'],
    [JsonConstants.TransactionLevelPropName, 'ttl'],
]);

const JsonProperty = (pOptions) => (pTarget, pKey, pIndex) => {
    if (pKey === undefined && pTarget['prototype']) {
        const type = Reflection.getParamTypes(pTarget)[pIndex];
        const keys = extractPropertiesFromConstructor(pTarget['prototype'].constructor);
        pKey = keys.get(pIndex);
        pTarget = pTarget['prototype'];
        Reflection.setType(type, pTarget, pKey);
    }
    const metadata = Reflection.getJsonPropertiesMetadata(pTarget) ?? {};
    metadata[pKey] = buildJsonPropertyMetadata(pKey, pOptions);
    Reflection.setJsonPropertiesMetadata(metadata, pTarget);
};
const extractPropertiesFromConstructor = (pCtor) => {
    // Clean constructor
    const ctorWithoutClassBody = pCtor.toString().split('}')[0];
    const ctorWithoutComments = ctorWithoutClassBody.replace(/(\/\*[\s\S]*?\*\/|\/\/.*$)/gm, '');
    const ctorOnSingleLine = ctorWithoutComments.replace(/[\r\t\n\v\f ]/g, '');
    const ctorLength = ctorOnSingleLine.length;
    let char;
    // When using React in production, 'this' in the constructor
    // is replaced by a char and appears at the end of it.
    if (ctorOnSingleLine[ctorLength - 2] === ',') {
        char = ctorOnSingleLine[ctorLength - 1];
    }
    // Parse function body
    const constructorParamPattern = /(?:.*(?:constructor|function).*?(?=\())(?:\()(.+?(?=\)))/m;
    const propertyPattern = char
        ? new RegExp(`(?:(this|${char}|\\(${char}=t.call\\(this(,.)*\\)\\))\\.)([^,;\n}]+)`, 'gm')
        : new RegExp(`(?:(this)\\.)([^,;\n}]+)`, 'gm');
    const properties = new Map();
    const paramsExecArray = constructorParamPattern.exec(ctorOnSingleLine);
    if (!paramsExecArray || !paramsExecArray.length) {
        return properties;
    }
    const params = paramsExecArray[1].split(',');
    // Get properties
    let match;
    while ((match = propertyPattern.exec(ctorOnSingleLine))) {
        const matchIndex = match.length - 1;
        const matchResult = match[matchIndex].split('=');
        const index = params.findIndex(param => param === matchResult[1]);
        if (index > -1) {
            properties.set(index, matchResult[0]);
        }
    }
    return properties;
};
const buildJsonPropertyMetadata = (pKey, pOptions) => {
    let metadata = { pName: pKey.toString() };
    if (!pOptions) {
        return metadata;
    }
    if (BravoStringExtensions.isString(pOptions)) {
        metadata.pName = propNames.get(pOptions) || BravoStringExtensions.asString(pOptions);
        metadata.pIsNameOverridden = true;
        return metadata;
    }
    if (isObject(pOptions)) {
        metadata = { ...metadata, ...pOptions };
        if (pOptions.name) {
            if (BravoStringExtensions.isString(pOptions.name)) {
                metadata.pName = propNames.get(pOptions.name) || pOptions.name;
            }
            else {
                const props = new Array();
                pOptions.name.map((pStr) => props.push(propNames.get(pStr) || pStr));
                metadata.pName = props;
            }
            metadata.pIsNameOverridden = true;
        }
        if (isPredicate(pOptions.type)) {
            delete metadata.type;
            metadata.predicate = pOptions.type;
        }
    }
    return metadata;
};

/**
 * Generated bundle index. Do not edit.
 */

export { ArrayBase, BravoArrayExtensions, BravoBooleanExtensions, BravoComparableMap, BravoConverterExtensions, BravoEnumExtensions, BravoNumberExtensions, BravoObjectExtensions, BravoRegexes, BravoStringBuilder, BravoStringComparer, BravoStringExtensions, BravoUTF8, BravoUnicode, JsonConstants, JsonObject, JsonProperty, JsonSerializer, NotifyCollectionChangedActionEnum, NotifyCollectionChangedEventArgs, ObservableArray, ObservableMap, asFunction, asNumber, asType, assert, decodeHTMLEntities, escapeHtml, escapeReplacement, isDefined, isFunction, isKeyOf, isMap, isNotNil, isNullish, isNumber, isObjectGuard, isPrimitive, isPromise, isSet, isString, isUndefined, isWritableSignal, propNames, tryCast, tryParse, valuesComparer };
//# sourceMappingURL=bravo-infra-core-utils-data-extensions.mjs.map
