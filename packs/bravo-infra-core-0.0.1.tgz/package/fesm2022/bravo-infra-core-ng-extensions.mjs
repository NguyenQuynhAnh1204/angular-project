import { DataTypeEnum } from '@bravo-infra/core/definition';
import { BravoNumberExtensions } from '@bravo-infra/core/utils/data-extensions';
import { BravoMoment } from '@bravo-infra/core/utils/dates';
import * as i0 from '@angular/core';
import { assertInInjectionContext, inject, Injector, runInInjectionContext, effect, untracked, EnvironmentInjector, DestroyRef, createEnvironmentInjector, Injectable, provideEnvironmentInitializer, ElementRef, InjectionToken, computed, signal, isSignal } from '@angular/core';
import { defer, merge, fromEvent, map, shareReplay, ReplaySubject, Subject, combineLatest, identity, startWith, isObservable, distinctUntilChanged, from, pipe, debounceTime, takeUntil, Observable, share, BehaviorSubject } from 'rxjs';
import { DOCUMENT } from '@angular/common';
import { toSignal, toObservable, takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { tap } from 'rxjs/operators';
import { Router, ActivatedRoute } from '@angular/router';

/**
 * A property decorator factory that intercepts property assignments
 * and applies a transformation function before setting the value.
 *
 * This is useful for:
 * - Enum parsing
 * - Input sanitization
 * - Type conversion (e.g. string → number)
 * - Applying normalization logic whenever a property is updated
 *
 * @param {IInputTransformOptions} pOptions - The configuration options containing the transformation logic.
 * @returns {PropertyDecorator} - A decorator that transforms property assignments.
 *
 * @example
 * import { InputSetter } from './InputSetter';
 * import { BravoEnumExtensions } from './BravoEnumExtensions';
 *
 * enum Permission { Read = 1, Write = 2, Execute = 4 }
 *
 * class UserPermissions {
 *   private _permissions: number = 0;
    @InputSetter({ transform: enumAttribute, enumType: Permission })
 *   set permissions(value: number) {
 *     this._permissions = value;
 *   }
 *   get permissions(): number {
 *     return this._permissions;
 *   }
 * }
 *
 * const user = new UserPermissions();
 * user.permissions = 'Read | Write';
 * console.log(user.permissions); // 3
 */
function InputSetter(pOptions) {
    return (pTarget, pPropertyKey, pDescriptor) => {
        const get = pDescriptor.get;
        const set = pDescriptor.set;
        const transformFn = pOptions.transform;
        // Override the getter (unchanged)
        pDescriptor.get = function () {
            return get.call(this);
        };
        // Override the setter to apply transformation before setting
        pDescriptor.set = function (pValue) {
            const newValue = transformFn ? transformFn(pValue, pOptions.enumType) : pValue;
            set.call(this, newValue);
        };
        return pDescriptor;
    };
}

const FORMAT_FN_MAP = {
    [DataTypeEnum.Date]: (pValue) => BravoMoment.ensureFormat(pValue),
    [DataTypeEnum.Number]: (pValue) => BravoNumberExtensions.ensureFormat(pValue),
};
/**
 * A property decorator that intercepts the setter and automatically normalizes
 * the incoming format string based on the given format type.
 *
 * This avoids manually calling ensureFormat() inside every setter.
 *
 * @param {DataTypeEnum} pType - The format type to apply normalization for.
 * @returns {MethodDecorator} - A decorator that transforms the value before it reaches the setter.
 *
 * @example
 * readonly #format = signal(BravoAppSettings.settings.dateFormat);
 *
 * @Input()
 * @InputEnsureFormat(BravoFormatType.Date)
 * public get format() {
 *     return this.#format();
 * }
 * public set format(pValue: string) {
 *     this.#format.set(pValue); // pValue is already normalized
 * }
 */
function EnsureFormat(pType) {
    return (pTarget, pPropertyKey, pDescriptor) => {
        const originalSet = pDescriptor.set;
        const formatFn = FORMAT_FN_MAP[pType];
        pDescriptor.set = function (pValue) {
            originalSet.call(this, formatFn(pValue));
        };
        return pDescriptor;
    };
}

function assertInjector(pCallback, pInjector, pRunnerCallback) {
    !pInjector && assertInInjectionContext(pCallback);
    const assertedInjector = pInjector ?? inject(Injector);
    if (!pRunnerCallback)
        return assertedInjector;
    return runInInjectionContext(assertedInjector, pRunnerCallback);
}

function effectOnceIf(pConditionCallback, pExecutionCallback, pOptions) {
    const assertedInjector = assertInjector(effectOnceIf, pOptions?.injector);
    return runInInjectionContext(assertedInjector, () => {
        const effectRef = effect(pOnCleanupCallback => {
            const hasCondition = pConditionCallback();
            if (hasCondition) {
                untracked(() => pExecutionCallback(hasCondition, pOnCleanupCallback));
                effectRef.destroy();
            }
        }, pOptions);
        return effectRef;
    });
}

/**
 * This explicit effect function will take the dependencies and the function to run when the dependencies change.
 * const count = signal(0);
 * const state = signal('idle');
 *
 * explicitEffect([count, state], ([count, state], cleanup) => {
 *   console.log('count updated', count, state);
 *
 *   cleanup(() => {
 *     console.log('cleanup');
 *   });
 * });
 * ```
 *
 * @param pDeps - The dependencies that the effect will run on
 * @param pCallback - The function to run when the dependencies change
 * @param pOptions - The options for the effect with the addition of defer (it allows the computation to run on first change, not immediately)
 */
function explicitEffect(pDeps, pCallback, pOptions) {
    let defer = pOptions && pOptions.defer;
    return effect(pOnCleanupCallback => {
        const depValues = pDeps.map(pS => pS());
        untracked(() => {
            if (!defer) {
                pCallback(depValues, pOnCleanupCallback);
            }
            defer = false;
        });
    }, pOptions);
}

class InjectLazyImpl {
    #overrides = new WeakMap(); // no need to clean up
    override(pType, pMock) {
        this.#overrides.set(pType, pMock);
    }
    get(pInjector, pLoaderCallback) {
        return defer(() => pLoaderCallback().then(pServiceOrDefault => {
            const type = 'default' in pServiceOrDefault ? pServiceOrDefault.default : pServiceOrDefault;
            // Check if we have overrides, O(1), low overhead
            if (this.#overrides.has(type)) {
                const module = this.#overrides.get(type);
                return new module();
            }
            // If the service uses DestroyRef.onDestroy() it will never be called.
            // Even if injector is a NodeInjector, this works only with providedIn: root.
            // So it's the root injector that will provide the DestroyRef (and thus never call OnDestroy).
            // The solution would be to create an EnvironmentInjector that provides the class we just lazy-loaded.
            if (!(pInjector instanceof EnvironmentInjector)) {
                // We're passing a node injector to the function
                // This is the DestroyRef of the component
                const destroyRef = pInjector.get(DestroyRef);
                // This is the parent injector of the environmentInjector we're creating
                const environmentInjector = pInjector.get(EnvironmentInjector);
                // Creating an environment injector to destroy it afterward
                const newInjector = createEnvironmentInjector([type], environmentInjector);
                // Destroy the injector to trigger DestroyRef.onDestroy on our service
                destroyRef.onDestroy(() => newInjector.destroy());
                // We want to create the new instance of our service with our new injector
                pInjector = newInjector;
            }
            return pInjector.get(type);
        }));
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: InjectLazyImpl, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: InjectLazyImpl, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: InjectLazyImpl, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });
/**
 * Helper function to mock the lazy-loaded module in `injectAsync`
 *
 * @usage
 * TestBed.configureTestingModule({
 *   providers: [
 *     mockLazyProvider(SandboxService, fakeSandboxService)
 *   ]
 * });
 */
function mockLazyProvider(pType, pMock) {
    return [
        {
            provide: provideEnvironmentInitializer,
            multi: true,
            useValue: () => {
                inject(InjectLazyImpl).override(pType, pMock);
            },
        },
    ];
}

/**
 * Loads a service lazily. The service is loaded when the observable is subscribed to.
 *
 * @param pLoaderCallback A function that returns a promise of the service to load.
 * @param pInjector The injector to use to load the service. If not provided, the current injector is used.
 * @returns An observable of the service.
 *
 * @example
 * ```ts
 * const dataService$ = injectLazy(() => import('./data-service').then((m) => m.MyService));
 * or
 * const dataService$ = injectLazy(() => import('./data-service'));
 * ```
 */
function injectLazy(pLoaderCallback, pInjector) {
    pInjector = assertInjector(injectLazy, pInjector);
    const injectImpl = pInjector.get(InjectLazyImpl);
    return injectImpl.get(pInjector, pLoaderCallback);
}

function injectActiveElement(pInjector) {
    return assertInjector(injectActiveElement, pInjector, () => {
        const doc = inject(DOCUMENT);
        return merge(fromEvent(doc, 'focus', { capture: true, passive: true }).pipe(map(() => true)), fromEvent(doc, 'blur', { capture: true, passive: true }).pipe(map(() => false))).pipe(map(pHasFocus => (pHasFocus ? doc.activeElement : null)), shareReplay({ refCount: true, bufferSize: 1 }));
    });
}

/**
 * Injects the `DestroyRef` service and returns a `ReplaySubject` that emits
 * when the component is destroyed.
 *
 * @throws {Error} If no `DestroyRef` is found.
 * @returns {ReplaySubject<void>} A `ReplaySubject` that emits when the component is destroyed.
 *
 * @example
 * // In your component:
 * export class MyComponent {
 *   #destroy$ = injectDestroy();
 *
 *   getData() {
 *     return this.service.getData()
 *       .pipe(takeUntil(this.#destroy$))
 *       .subscribe(data => { ... });
 *   }
 * }
 */
const injectDestroy = (pInjector) => {
    pInjector = assertInjector(injectDestroy, pInjector);
    return runInInjectionContext(pInjector, () => {
        const destroyRef = inject(DestroyRef);
        const subject$ = new ReplaySubject(1);
        destroyRef.onDestroy(() => {
            subject$.next();
            subject$.complete();
        });
        Object.assign(subject$, {
            onDestroy: destroyRef.onDestroy.bind(destroyRef),
        });
        return subject$;
    });
};

/**
 * Injects an observable that emits whenever the element is intersecting the viewport.
 * The observable will complete when the element is destroyed.
 * @param options
 *
 * @example
 * export class MyComponent {
 *   private destroyRef = inject(DestroyRef);
 *
 *   isIntersecting$ = injectIsIntersecting();
 *   isInViewport$ = this.isIntersecting$.pipe(
 *     filter(x => x.intersectionRatio > 0),
 *     take(1),
 *   );
 *
 *   ngOnInit() {
 *     this.getData().subscribe();
 *   }
 *
 *   getData() {
 *     // Only fetch data when the element is in the viewport
 *     return this.isInViewport$.pipe(
 *       switchMap(() => this.service.getData()),
 *       takeUntil(this.destroy$)
 *     );
 *   }
 * }
 */
const injectIsIntersecting = ({ injector, element } = {}) => {
    return assertInjector(injectDestroy, injector, () => {
        const el = element ?? inject(ElementRef).nativeElement;
        const inInViewportService = inject(IsInViewportService);
        const destroyRef = inject(DestroyRef);
        const sub = inInViewportService.observe(el);
        destroyRef.onDestroy(() => {
            inInViewportService.unobserve(el);
        });
        return sub;
    });
};
class IsInViewportService {
    observerListeners = new Map();
    observer;
    createObserver() {
        this.observer = new IntersectionObserver(pEntries => {
            for (const entry of pEntries) {
                this.intersect(entry.target, entry);
            }
        }, {
            threshold: [0, 0.1, 0.5, 0.95, 0.99, 1.0],
        });
    }
    observe(pElement) {
        if (!this.observer) {
            this.createObserver();
        }
        let elementIntersectSubject = this.observerListeners.get(pElement);
        if (this.observerListeners.has(pElement)) {
            if (!elementIntersectSubject)
                throw new Error(`No listener found for element ${pElement}`);
            return elementIntersectSubject;
        }
        this.observerListeners.set(pElement, new Subject());
        this.observer?.observe(pElement);
        elementIntersectSubject = this.observerListeners.get(pElement);
        if (!elementIntersectSubject)
            throw new Error(`No listener found for element ${pElement}`);
        return elementIntersectSubject;
    }
    unobserve(pElement) {
        this.observer?.unobserve(pElement);
        this.observerListeners.get(pElement)?.complete();
        this.observerListeners.delete(pElement);
        if (this.observerListeners.size === 0) {
            this.disconnect();
        }
    }
    intersect(pElement, pEntry) {
        const subject = this.observerListeners.get(pElement);
        // only emit if the subject is subscribed to
        if (subject?.observed) {
            subject.next(pEntry);
        }
    }
    disconnect() {
        this.observer?.disconnect();
        this.observer = undefined;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: IsInViewportService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: IsInViewportService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: IsInViewportService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

function createInjectFn(pToken) {
    return function (pThis, { injector: pInjector, ...pInjectOptions } = {}) {
        pInjector = assertInjector(pThis, pInjector);
        return runInInjectionContext(pInjector, () => inject(pToken, pInjectOptions));
    };
}
function createProvideFn(pToken, pFactoryCallback, pOpts = {}) {
    const { deps = [], multi = false, extraProviders = [], isFunctionValue: isFunctionValueFromOpts = false } = pOpts;
    return (pValue, pIsFunctionValue = isFunctionValueFromOpts) => {
        let provider;
        if (typeof pValue !== 'undefined') {
            const factory = typeof pValue === 'function' ? (pIsFunctionValue ? () => pValue : pValue) : () => pValue;
            provider = {
                provide: pToken,
                useFactory: factory,
                multi,
            };
        }
        else {
            provider = {
                provide: pToken,
                useFactory: pFactoryCallback,
                deps: deps,
                multi,
            };
        }
        return [extraProviders, provider];
    };
}
/**
 * `createInjectionToken` accepts a factory function and returns a tuple of `injectFn`, `provideFn`, and the `InjectionToken`
 * that the factory function is for.
 *
 * @param {Function} pFactoryCallback - Factory Function that returns the value for the `InjectionToken`
 * @param {CreateInjectionTokenOptions} pOptions - object to control how the `InjectionToken` behaves
 * @returns {CreateInjectionTokenReturn}
 *
 * @example
 * ```ts
 * const [injectCounter, provideCounter, COUNTER] = createInjectionToken(() => signal(0));
 *
 * export class Counter {
 *  counter = injectCounter(); // WritableSignal<number>
 * }
 * ```
 */
function createInjectionToken(pFactoryCallback, pOptions) {
    const tokenName = pFactoryCallback.name || pFactoryCallback.toString();
    const opts = pOptions ?? { isRoot: true };
    opts.isRoot ??= true;
    // NOTE: multi tokens cannot be a root token. It has to be provided (provideFn needs to be invoked)
    // for the 'multi' flag to work properly
    if (opts.multi) {
        opts.isRoot = false;
    }
    if (opts.isRoot) {
        if (opts.token) {
            throw new Error(`\
createInjectionToken is creating a root InjectionToken but an external token is passed in.
`);
        }
        const token = new InjectionToken(`Token for ${tokenName}`, {
            factory: () => {
                if (opts.deps && Array.isArray(opts.deps)) {
                    return pFactoryCallback(...opts.deps.map(pDep => {
                        pDep = (Array.isArray(pDep) ? pDep.at(-1) : pDep);
                        return inject(pDep);
                    }));
                }
                return pFactoryCallback();
            },
        });
        const injectFn = createInjectFn(token);
        return [
            injectFn,
            createProvideFn(token, pFactoryCallback, opts),
            token,
            () => ({
                provide: provideEnvironmentInitializer,
                useValue: () => injectFn(),
                multi: true,
            }),
        ];
    }
    const token = opts.token || new InjectionToken(`Token for ${tokenName}`);
    return [
        createInjectFn(token),
        createProvideFn(token, pFactoryCallback, opts),
        token,
        () => [],
    ];
}
function createNoopInjectionToken(pDescription, pOptions) {
    const token = pOptions?.token || new InjectionToken(pDescription);
    return [
        createInjectFn(token),
        createProvideFn(token, () => null, (pOptions || {})),
        token,
        () => [],
    ];
}

/**
 * Returns a signal that emits the previous value of the given signal.
 * The first time the signal is emitted, the previous value will be the same as the current value.
 *
 * @example
 * ```ts
 * const value = signal(0);
 * const previous = computedPrevious(value);
 *
 * effect(() => {
 *  console.log('Current value:', value());
 *  console.log('Previous value:', previous());
 * });
 *
 * Logs:
 * // Current value: 0
 * // Previous value: 0
 *
 * value.set(1);
 *
 * Logs:
 * // Current value: 1
 * // Previous value: 0
 *
 * value.set(2);
 *
 * Logs:
 * // Current value: 2
 * // Previous value: 1
 *```
 *
 * @param pSource Signal to compute previous value for
 * @returns Signal that emits previous value of `s`
 */
function computedPrevious(pSource) {
    let current = null;
    let previous = untracked(() => pSource()); // initial value is the current value
    return computed(() => {
        current = pSource();
        const result = previous;
        previous = current;
        return result;
    });
}

/**
 * Creates a signal notifier that can be used to notify effects or other consumers.
 *
 * @returns A notifier object.
 */
function createNotifier() {
    const sourceSignal = signal(0, ...(ngDevMode ? [{ debugName: "sourceSignal" }] : []));
    return {
        notify: () => {
            sourceSignal.update(pPre => (pPre >>> 0) + 1);
        },
        listen: sourceSignal.asReadonly(),
    };
}

/**
 * `derivedFrom` is a function that takes an array/object with `Observable` or `Signal` values and returns a `Signal` that
 * emits the values of the `Observable` or `Signal` values. It is similar to `combineLatest` but it will emit
 * when the value of the `Observable` or `Signal` changes.
 *
 * @param {ObservableSignalInputTuple} sources - array/object of `Observable` or `Signal` values
 * @param {OperatorFunction} [operator] - operator to apply to the `Observable` or `Signal` values
 * @param {DerivedFromOptions} [options] - options to pass initialValue and/or injector to use to inject the `Observable` or `Signal` values
 * @returns {Signal} - `Signal` that emits the values of the `Observable` or `Signal` values
 *
 * @example
 *
 * ```ts
 * export class MyComponent {
 *  private readonly filtersService = inject(FiltersService);
 *  readonly pageNumber = signal(1);
 *
 *  readonly data = derivedFrom(
 *   [this.pageNumber, this.filtersService.filters$],
 *   pipe(
 *     switchMap(([pageNumber, filters]) => this.dataService.getData(pageNumber, filters)),
 *     startWith([])
 *   );
 * }
 * ```
 */
function derivedFrom(...pArgs) {
    const { normalizedSources, hasInitValue, operator, options } = _normalizeArgs(pArgs);
    const injector = assertInjector(derivedFrom, options?.injector);
    /* try { // Custom error handling for derivedFrom */
    const ret = hasInitValue
        ? toSignal(combineLatest(normalizedSources).pipe(operator), {
            initialValue: options.initialValue,
            injector,
        })
        : toSignal(combineLatest(normalizedSources).pipe(operator), {
            injector,
            requireSync: true,
        });
    return ret;
}
function _normalizeArgs(pArgs) {
    if (!pArgs || !pArgs.length || typeof pArgs[0] !== 'object')
        //valid even for Array
        throw new TypeError('derivedFrom needs sources');
    const hasOperator = typeof pArgs[1] === 'function';
    if (pArgs.length == 3 && !hasOperator)
        throw new TypeError('derivedFrom needs pipeable operator as a second argument');
    if (!hasOperator)
        pArgs.splice(1, 0, identity);
    const [sources, operator, options] = pArgs;
    const hasInitValue = !!options && 'initialValue' in options;
    const normalizedSources = Object.entries(sources).reduce((acc, [keyOrIndex, source]) => {
        if (isSignal(source)) {
            acc[keyOrIndex] = toObservable(source, {
                injector: options?.injector,
            }).pipe(startWith(untracked(source)) /* this is done because toObservable doesn't immediatly emit initialValue of the signal */);
        }
        else if (isObservable(source)) {
            acc[keyOrIndex] = source.pipe(distinctUntilChanged());
        }
        else if (typeof source === 'function') {
            const computedFn = computed(source, ...(ngDevMode ? [{ debugName: "computedFn" }] : []));
            acc[keyOrIndex] = toObservable(computedFn, {
                injector: options?.injector,
            }).pipe(startWith(source()));
        }
        else {
            acc[keyOrIndex] = from(source).pipe(distinctUntilChanged());
        }
        return acc;
    }, (Array.isArray(sources) ? [] : {}));
    return { normalizedSources, operator, hasInitValue, options };
}

/**
 * Creates a lazy singleton proxy for any object.
 *
 * The underlying instance is NOT created immediately.
 * It will only be created on the first property access (get/set).
 *
 * This is especially useful for:
 * - Lazy initialization (avoid heavy setup until needed)
 * - Angular dependency injection (via `inject`)
 * - Deferring object creation until runtime conditions are met
 *
 * @template T - The type of the singleton instance
 * @param pCreateInstance - A factory function that returns a new instance of T
 *
 * @returns An object containing:
 * - `proxy`: A proxy that behaves like the real instance (with full IntelliSense)
 * - `reset`: A function to clear the current instance so it will be recreated on next access
 *
 * @example
 * // Basic usage
 * class ApiService {
 *   getData() {
 *     return 'data';
 *   }
 * }
 *
 * const { proxy: api } = createSingletonProxy(() => new ApiService());
 *
 * // Instance is created here (lazy)
 * api.getData();
 *
 * @example
 * // Lazy initialization (instance is NOT created until used)
 * const { proxy: service } = createSingletonProxy(() => {
 *   console.log('Created!');
 *   return new ApiService();
 * });
 *
 * // Nothing logged yet
 *
 * service.getData(); // 👉 logs "Created!"
 *
 * @example
 * // With reset (force recreate instance)
 * const singleton = createSingletonProxy(() => new ApiService());
 *
 * singleton.proxy.getData();
 *
 * singleton.reset(); // clear instance
 *
 * singleton.proxy.getData(); // 👉 new instance created again
 * @remarks
 * - The proxy fully preserves the type of T (IntelliSense works as expected).
 * - The instance is shared (singleton) until `reset()` is called.
 */
function createSingletonProxy(pCreateInstance, pInjector) {
    let instance;
    const getInstance = () => {
        if (!instance) {
            if (pInjector)
                instance = runInInjectionContext(pInjector, pCreateInstance);
            else
                instance = pCreateInstance();
        }
        return instance;
    };
    const handler = {
        get(_, prop, __) {
            const target = getInstance();
            const value = Reflect.get(target, prop, target);
            return typeof value === 'function' ? value.bind(target) : value;
        },
        set(_, prop, pValue, pReceiver) {
            return Reflect.set(getInstance(), prop, pValue, pReceiver);
        },
    };
    const target = {};
    const proxy = new Proxy(target, handler);
    return {
        proxy,
        reset: () => (instance = undefined),
    };
}
/**
 * Lazy singleton proxy (NULLABLE version)
 * - Preserve null semantics
 * - Safe access (không crash khi null)
 */
function createSingletonProxyNullable(pFactory) {
    let instance;
    const getInstance = () => {
        if (instance === undefined)
            instance = pFactory();
        return instance;
    };
    const handler = {
        get(_, pProp, pReceiver) {
            const target = getInstance();
            if (target == null)
                return undefined;
            const value = Reflect.get(target, pProp, pReceiver);
            return typeof value === 'function' ? value.bind(target) : value;
        },
        set(_, prop, pValue, pReceiver) {
            const target = getInstance();
            if (target == null)
                return false;
            return Reflect.set(target, prop, pValue, pReceiver);
        },
    };
    const proxy = new Proxy({}, handler);
    return {
        proxy: proxy,
        reset: () => (instance = undefined),
    };
}

function lazyInject(pToken) {
    const assertedInjector = inject(Injector);
    const factory = () => {
        return runInInjectionContext(assertedInjector, () => {
            return inject(pToken);
        });
    };
    return createSingletonProxy(() => factory()).proxy;
}

function mergeFrom(...pArgs) {
    const [sources, operator = identity, options = {}] = parseArgs(pArgs);
    const normalizedSources = sources.map(pSource => {
        if (isSignal(pSource)) {
            return toObservable(pSource, { injector: options.injector }).pipe(startWith(untracked(pSource)));
        }
        if (!isObservable(pSource)) {
            pSource = from(pSource);
        }
        return pSource.pipe(distinctUntilChanged());
    });
    const merged = merge(...normalizedSources).pipe(operator);
    return assertInjector(mergeFrom, options.injector, () => {
        if (options.initialValue !== undefined) {
            return toSignal(merged, { initialValue: options.initialValue });
        }
        return toSignal(merged, { requireSync: true });
    });
}
function parseArgs(pArgs) {
    if (pArgs.length === 0) {
        throw new Error(`[Bravo] mergeFrom: Expected at least one argument, got none.`);
    }
    if (pArgs.length === 1) {
        return [pArgs[0], undefined, undefined];
    }
    if (pArgs.length === 2) {
        const isOperator = typeof pArgs[1] === 'function';
        if (isOperator) {
            return [
                pArgs[0],
                pArgs[1],
                undefined,
            ];
        }
        return [
            pArgs[0],
            undefined,
            pArgs[1],
        ];
    }
    return pArgs;
}

const defaultResizeOptions = {
    box: 'content-box',
    scroll: false,
    offsetSize: false,
    debounce: { scroll: 50, resize: 0 },
    emitInitialResult: false,
};
const [injectResizeOptions, provideResizeOptions, RESIZE_OPTIONS] = createInjectionToken(() => defaultResizeOptions);
// return ResizeResult observable
function createResizeStream({ debounce, scroll, offsetSize, box, emitInitialResult }, pNativeElement, pDocument) {
    const window = pDocument.defaultView;
    const screen = window?.screen;
    const isSupport = !!window?.ResizeObserver;
    let observer;
    let lastBounds;
    let lastEntries = [];
    const torndown$ = new ReplaySubject();
    const scrollContainers = findScrollContainers(pNativeElement, window, pDocument.body);
    // set actual debounce values early, so effects know if they should react accordingly
    const scrollDebounce = debounce ? (typeof debounce === 'number' ? debounce : debounce.scroll) : null;
    const resizeDebounce = debounce ? (typeof debounce === 'number' ? debounce : debounce.resize) : null;
    const debounceAndTorndown = (pDebounce) => {
        return pipe(debounceTime(pDebounce ?? 0), takeUntil(torndown$));
    };
    return new Observable(pSubscriber => {
        if (!isSupport) {
            pSubscriber.error('[resize] your browser does not support ResizeObserver. Please consider using a polyfill');
            return;
        }
        if (emitInitialResult) {
            const [result] = calculateResult(pNativeElement, window, offsetSize, []);
            pSubscriber.next(result);
        }
        const callback = (pEntries) => {
            lastEntries = pEntries;
            const [result, size] = calculateResult(pNativeElement, window, offsetSize, pEntries);
            pSubscriber.next(result);
            if (!areBoundsEqual(lastBounds || {}, size))
                lastBounds = size;
        };
        const boundCallback = () => void callback(lastEntries);
        observer = new ResizeObserver(callback);
        observer.observe(pNativeElement, { box });
        if (scroll) {
            if (scrollContainers) {
                scrollContainers.forEach(pScrollContainer => {
                    fromEvent(pScrollContainer, 'scroll', {
                        capture: true,
                        passive: true,
                    })
                        .pipe(debounceAndTorndown(scrollDebounce))
                        .subscribe(boundCallback);
                });
            }
            fromEvent(window, 'scroll', { capture: true, passive: true })
                .pipe(debounceAndTorndown(scrollDebounce))
                .subscribe(boundCallback);
        }
        fromEvent(window, 'resize').pipe(debounceAndTorndown(resizeDebounce)).subscribe(boundCallback);
        if (screen && 'orientation' in screen && 'addEventListener' in screen.orientation) {
            fromEvent(screen.orientation, 'change').pipe(debounceAndTorndown(scrollDebounce)).subscribe(boundCallback);
        }
        else if (window && 'orientationchange' in window) {
            fromEvent(window, 'orientationchange').pipe(debounceAndTorndown(scrollDebounce)).subscribe(boundCallback);
        }
        return () => {
            if (observer) {
                observer.unobserve(pNativeElement);
                observer.disconnect();
            }
            torndown$.next();
            torndown$.complete();
        };
    }).pipe(debounceTime(scrollDebounce ?? 0), share({ connector: () => new ReplaySubject(1) }));
}
function calculateResult(pNativeElement, pWindow, pOffsetSize, pEntries) {
    const { left, top, width, height, bottom, right, x, y } = pNativeElement.getBoundingClientRect();
    const size = { left, top, width, height, bottom, right, x, y };
    if (pNativeElement instanceof HTMLElement && pOffsetSize) {
        size.height = pNativeElement.offsetHeight;
        size.width = pNativeElement.offsetWidth;
    }
    Object.freeze(size);
    return [{ entries: pEntries, dpr: pWindow.devicePixelRatio, ...size }, size];
}
// Returns a list of scroll offsets
function findScrollContainers(pElement, pWindow, pDocumentBody) {
    const result = [];
    if (!pElement || !pWindow || pElement === pDocumentBody)
        return result;
    const { overflow, overflowX, overflowY } = pWindow.getComputedStyle(pElement);
    if ([overflow, overflowX, overflowY].some(prop => prop === 'auto' || prop === 'scroll'))
        result.push(pElement);
    return [...result, ...findScrollContainers(pElement.parentElement, pWindow, pDocumentBody)];
}
// Checks if element boundaries are equal
const keys = [
    'x',
    'y',
    'top',
    'bottom',
    'left',
    'right',
    'width',
    'height',
];
const areBoundsEqual = (pA, pB) => keys.every(pKey => pA[pKey] === pB[pKey]);

/**
 * Creates a history record with the current timestamp.
 * @param pValue The value to store in the history record.
 * @returns A SignalHistoryRecord object.
 */
function createHistoryRecord(pValue) {
    return { value: pValue, timestamp: Date.now() };
}
/**
 * Enhances a writable signal with undo/redo history functionality.
 *
 * @param pSource The writable signal to track.
 * @param pOptions Configuration options for the history.
 * @returns An object with `history`, `undo`, `redo`, `canUndo`, and `canRedo` properties.
 */
function signalHistory(pSource, pOptions) {
    const injector = assertInjector(signalHistory, pOptions?.injector);
    return runInInjectionContext(injector, () => {
        const capacity = pOptions?.capacity ?? 100; // Default capacity is 100 records
        // Initialize the undo and redo stacks as signals
        const undoStack = signal([], ...(ngDevMode ? [{ debugName: "undoStack" }] : []));
        const redoStack = signal([], ...(ngDevMode ? [{ debugName: "redoStack" }] : []));
        // Initialize with the current value of the source signal.
        // This ensures that the history always starts with the initial value.
        const initialRecord = createHistoryRecord(pSource());
        undoStack.set([initialRecord]);
        // Computed signal to provide the history of changes
        const history = computed(() => [...undoStack()], ...(ngDevMode ? [{ debugName: "history" }] : []));
        // Computed signals to indicate if undo/redo actions are available
        const canUndo = computed(() => undoStack().length > 1, ...(ngDevMode ? [{ debugName: "canUndo" }] : [])); // Can undo if there's more than just the initial state
        const canRedo = computed(() => redoStack().length > 0, ...(ngDevMode ? [{ debugName: "canRedo" }] : [])); // Can redo if there's more than just the initial state
        // Current value (taken from the last record in the undoStack)
        const currentValue = computed(() => {
            const stack = undoStack();
            return stack.length ? stack[stack.length - 1].value : pSource();
        }, ...(ngDevMode ? [{ debugName: "currentValue" }] : []));
        // Previous value (taken from the penultimate record)
        const previousValue = computed(() => {
            const stack = undoStack();
            return stack.length > 1 ? stack[stack.length - 2].value : undefined;
        }, ...(ngDevMode ? [{ debugName: "previousValue" }] : []));
        // Use explicitEffect to track changes to the source signal
        explicitEffect([pSource], ([pValue]) => {
            const lastValue = undoStack()[undoStack().length - 1]?.value;
            // skip if the value is the same as the last value
            if (pValue === lastValue)
                return;
            // skip if the value should not be recorded
            if (pOptions?.shouldRecord && !pOptions?.shouldRecord(pValue, lastValue))
                return;
            const newRecord = createHistoryRecord(pValue);
            // Update the undo stack with the new record
            undoStack.update(pStack => {
                const newStack = [...pStack, newRecord];
                return capacity ? newStack.slice(-capacity) : newStack; // Apply capacity limit if provided
            });
            // Clear the redo stack when a new change is made,
            // because a new change invalidates the redo stack.
            redoStack.set([]);
        }, { defer: true, injector: pOptions?.injector });
        /**
         * Undo the last change to the source signal.
         */
        const undo = () => {
            if (undoStack().length > 1) {
                // Prevent undoing the initial state
                // Get the last record from the undo stack
                const currentRecord = undoStack()[undoStack().length - 1];
                // Remove the last record from the undo stack
                undoStack.update(pStack => pStack.slice(0, -1));
                // Add the current record to the redo stack
                redoStack.update(pStack => [currentRecord, ...pStack]);
                const previousRecord = undoStack()[undoStack().length - 1];
                // Set the source signal to the previous value
                pSource.set(previousRecord.value);
            }
        };
        /**
         * Redo the last undone change to the source signal.
         */
        const redo = () => {
            if (redoStack().length) {
                // Get the first record from the redo stack as we want to remove it
                const nextRecord = redoStack()[0];
                // Remove the first record from the redo stack
                redoStack.update(pStack => pStack.slice(1));
                // Add the next record to the undo stack
                undoStack.update(pStack => [...pStack, nextRecord]);
                // Set the source signal to the next value
                pSource.set(nextRecord.value);
            }
        };
        /**
         * Reset the history to the current state.
         */
        const reset = () => {
            const currentRecord = undoStack()[undoStack().length - 1];
            undoStack.set([currentRecord]);
            redoStack.set([]);
        };
        /**
         * Clear the history. This will remove all history records.
         */
        const clear = () => {
            undoStack.set([]);
            redoStack.set([]);
        };
        // Return the history, currentValue, previousValue, undo/redo/reset/clear functions, and canUndo/canRedo signals
        return {
            currentValue,
            previousValue,
            history,
            undo,
            redo,
            reset,
            clear,
            canUndo,
            canRedo,
        };
    });
}

/**
 * Function `toLazySignal()` is a proxy function that will call the original
 * `toSignal()` function when the returned signal is read for the first time.
 */
function toLazySignal(pSource, pOptions) {
    const injector = assertInjector(toLazySignal, pOptions?.injector);
    let s;
    return computed(() => {
        if (!s) {
            s = untracked(() => toSignal(pSource, { ...pOptions, injector }));
        }
        return s();
    });
}

function toObservableDefer(pSource, pOptions) {
    !pOptions?.injector && assertInInjectionContext(toObservableDefer);
    const injector = pOptions?.injector ?? inject(Injector);
    const subject = new ReplaySubject(1);
    const previousValue = computedPrevious(pSource);
    const watcher = explicitEffect([pSource], () => {
        let value;
        try {
            value = pSource();
        }
        catch (err) {
            subject.error(err);
            return;
        }
        if (previousValue() === value)
            return;
        subject.next(value);
    });
    injector.get(DestroyRef).onDestroy(() => {
        watcher.destroy();
        subject.complete();
    });
    return subject.asObservable();
}

/**
 * 📌 `debug<T>` - Logs detailed information about RxJS Observables with intuitive icons.
 *
 * 🛠️ **Usage:**
 * - Insert `debug(tag, options?)` into an `Observable` pipeline to track events.
 * - Supports logging for events: `next` (new value), `error` (error occurred), `complete` (completed),
 *   `subscribe` (subscription started), `unsubscribe` (subscription canceled), and `finalize` (finalization).
 * - Allows customization of `subscribe`, `unsubscribe`, and `finalize` logs via `ExtraNotifications`.
 *
 * 🔹 **Parameters:**
 * @param {string} tag - A name or description to identify the `Observable`.
 * @param {ExtraNotifications} [extraNotifications] - Optional logging configuration.
 *        - `subscribe`: Logs when the `Observable` is subscribed to.
 *        - `unsubscribe`: Logs when the `Observable` is unsubscribed.
 *        - `finalize`: Logs when the `Observable` finalizes.
 *
 * 📌 **Example Usage:**
 * ```typescript
 * import { of } from 'rxjs';
 * import { delay } from 'rxjs/operators';
 *
 * of('Hello World')
 *   .pipe(
 *     debug('Test Observable', { finalize: true }),
 *     delay(1000)
 *   )
 *   .subscribe();
 * ```
 *
 * 📝 **Console Output (Assuming after 1 second):**
 * ```
 * 2025-03-26T12:00:00.123Z [Test Observable: 🟠 Next] Hello World
 * 2025-03-26T12:00:01.125Z [Test Observable: ✅ Completed]
 * 2025-03-26T12:00:01.126Z [Test Observable: 🔚 Finalized]
 * ```
 */
function debug(pTag, pExtraNotifications) {
    const formatNotification = (pNotification, pIcon, pData) => [
        new BravoMoment(new Date()).format('yyyy-MM-dd hh:mm:ss'),
        `[${pTag}: ${pIcon} ${pNotification}]`,
        pData,
    ];
    return tap({
        next: pValue => console.log(...formatNotification('Next', '🟠', pValue)),
        error: pErr => console.error(...formatNotification('Error', '🛑', pErr)),
        complete: () => console.warn(...formatNotification('Completed', '✅')),
        subscribe: () => pExtraNotifications?.subscribe && console.info(...formatNotification('Subscribed', '📡')),
        unsubscribe: () => pExtraNotifications?.unsubscribe && console.info(...formatNotification('Unsubscribed', '🚫')),
        finalize: () => pExtraNotifications?.finalize && console.info(...formatNotification('Finalized', '🔚')),
    });
}

/**
 * `injectResize` returns an `Observable<ResizeResult>` that observes the `resize` event on the Host element
 * of the component. `options` passed in is merged with default options
 *
 * @see {@link defaultResizeOptions}
 *
 * @param {Partial<ResizeOptions>} [pOptions={}]
 * @see {@link ResizeOptions}
 *
 * @returns {Observable<ResizeResult>}
 * @see {@link ResizeResult}
 */
function injectResize(pOptions = {}) {
    const [{ nativeElement }, document, destroyRef] = [
        inject(ElementRef),
        inject(DOCUMENT),
        inject(DestroyRef),
    ];
    const mergedOptions = { ...injectResizeOptions(), ...pOptions };
    return createResizeStream(mergedOptions, nativeElement, document).pipe(takeUntilDestroyed(destroyRef));
}

/**
 * @desc Provides dependency injection for localStorage and sessionStorage in Angular.
 *       Allows components and services to interact with browser storage using WritableSignal.
 *       Supports automatic synchronization, custom serialization, and Angular's DI system.
 */
/**
 * @desc Injection token for localStorage.
 */
const LOCAL_STORAGE = new InjectionToken('LOCAL_STORAGE', {
    providedIn: 'root',
    factory: () => localStorage,
});
/**
 * @desc Provides a custom implementation for localStorage.
 */
function provideLocalStorageImpl(pImpl) {
    return {
        provide: LOCAL_STORAGE,
        useValue: pImpl,
    };
}
/**
 * @desc Injection token for sessionStorage.
 */
const SESSION_STORAGE = new InjectionToken('SESSION_STORAGE', {
    providedIn: 'root',
    factory: () => sessionStorage,
});
/**
 * @desc Provides a custom implementation for sessionStorage.
 */
function provideSessionStorageImpl(pImpl) {
    return {
        provide: SESSION_STORAGE,
        useValue: pImpl,
    };
}
/**
 * @desc Checks if the storage options contain a default value.
 */
function isStorageWithDefaultValue(pOptions) {
    return 'defaultValue' in pOptions;
}
/**
 * @desc Checks if a value is a function.
 */
function isFunction(pValue) {
    return typeof pValue === 'function';
}
/**
 * @desc Attempts to execute a function, returning a default value on failure.
 */
function goodTry(pTryCallback, defaultValue) {
    try {
        return pTryCallback();
    }
    catch {
        return defaultValue;
    }
}
/**
 * @desc Parses a JSON string, returning undefined if the value is 'undefined'.
 */
function parseJSON(pValue) {
    return pValue === 'undefined' ? undefined : JSON.parse(pValue);
}
/**
 * @desc Injects a storage mechanism (localStorage or sessionStorage) into a WritableSignal.
 */
const injectStorage = (pKey, pStorageType, pOptions = {}) => {
    const storage = pStorageType === 'local' ? inject(LOCAL_STORAGE) : inject(SESSION_STORAGE);
    if (isStorageWithDefaultValue(pOptions)) {
        const defaultValue = isFunction(pOptions.defaultValue) ? pOptions.defaultValue() : pOptions.defaultValue;
        return internalInjectStorage(pKey, storage, pOptions, defaultValue);
    }
    return internalInjectStorage(pKey, storage, pOptions, undefined);
};
/**
 * @desc Internal function to handle the interaction with storage.
 */
const internalInjectStorage = (pKey, pStorage, pOptions, pDefaultValue) => {
    const stringify = isFunction(pOptions.stringify) ? pOptions.stringify : JSON.stringify;
    const parse = isFunction(pOptions.parse) ? pOptions.parse : parseJSON;
    const storageSync = pOptions.storageSync ?? true;
    return assertInjector(injectStorage, pOptions.injector, () => {
        const destroyRef = inject(DestroyRef);
        const window = inject(DOCUMENT).defaultView;
        if (!window) {
            throw new Error('Cannot access window element');
        }
        const initialStoredValue = goodTry(() => pStorage.getItem(pKey), null);
        const internalSignal = signal(initialStoredValue ? goodTry(() => parse(initialStoredValue), pDefaultValue) : pDefaultValue, ...(ngDevMode ? [{ debugName: "internalSignal" }] : []));
        /**
         * @desc Synchronizes the signal value with storage.
         */
        const syncValueWithStorage = (pValue) => {
            const newValue = goodTry(() => (pValue === undefined ? null : stringify(pValue)), null);
            try {
                if (newValue === pStorage.getItem(pKey)) {
                    return;
                }
                if (newValue === null) {
                    pStorage.removeItem(pKey);
                }
                else {
                    pStorage.setItem(pKey, newValue);
                }
                window.dispatchEvent(new StorageEvent(`storage`, {
                    key: pKey,
                    newValue,
                    storageArea: pStorage,
                }));
            }
            catch {
                // ignore errors
            }
        };
        if (storageSync) {
            const originalSet = internalSignal.set;
            const originalUpdate = internalSignal.update;
            internalSignal.set = (pNewValue) => {
                originalSet(pNewValue);
                syncValueWithStorage(pNewValue);
            };
            internalSignal.update = (pUpdateFn) => {
                let newValue;
                originalUpdate(pValue => (newValue = pUpdateFn(pValue)));
                syncValueWithStorage(newValue);
            };
            /**
             * @desc Event listener to update signal when storage changes externally.
             */
            const onStorage = (pEvent) => {
                if (pEvent.storageArea === pStorage && pEvent.key === pKey) {
                    const newValue = pEvent.newValue !== null ? parse(pEvent.newValue) : pDefaultValue;
                    internalSignal.set(newValue);
                }
            };
            window.addEventListener('storage', onStorage);
            destroyRef.onDestroy(() => {
                window.removeEventListener('storage', onStorage);
            });
        }
        return internalSignal;
    });
};

function injectNavigationState(pKeyOrTransform, pOptions = {}) {
    return assertInjector(injectNavigationState, pOptions?.injector, () => {
        // Inject router
        const router = inject(Router);
        // Extract options
        const { parse, defaultValue } = pOptions;
        // Function to get state
        const getState = () => router.getCurrentNavigation()?.extras.state ?? undefined;
        // Create state subject with a valid initial state
        const stateSubject = new BehaviorSubject(getState() ?? {});
        // Check if `keyOrTransform` exists
        if (!pKeyOrTransform) {
            return toSignal(stateSubject.asObservable());
        }
        // If `keyOrTransform` is a function, apply it safely
        if (typeof pKeyOrTransform === 'function') {
            return toSignal(stateSubject.pipe(map(pState => (pState ? pKeyOrTransform(pState) : defaultValue))), {
                initialValue: pKeyOrTransform(stateSubject.value ?? {}),
            });
        }
        // Function to get state value by key
        const getStateValue = (pState) => {
            const value = pState?.[pKeyOrTransform]; // Safe access
            return value !== undefined && value !== null ? (parse ? parse(value) : value) : defaultValue ?? null;
        };
        // Default return with transformed state
        return toSignal(stateSubject.pipe(map(getStateValue)), { initialValue: getStateValue(stateSubject.value) });
    });
}

/**
 * Injects the params from the current route.
 * If a key is provided, it will return the value of that key.
 * If a transform function is provided, it will return the result of that function.
 * Otherwise, it will return the entire params object.
 *
 * @template T - The expected type of the read value.
 * @param pKeyOrParamsTransform OPTIONAL The key of the param to return, or a transform function to apply to the params object
 * @param {ParamsOptions} pOptions - Optional configuration options for the parameter.
 * @returns {Signal} A `Signal` that emits the transformed value of the specified parameter, or the entire parameters object if no key is provided.
 *
 * @example
 * const userId = injectParams('id'); // returns the value of the 'id' param
 * const userId = injectParams(p => p['id'] as string); // same as above but can be used with a custom transform function
 * const params = injectParams(); // returns the entire params object
 *
 */
function injectParams(pKeyOrParamsTransform, pOptions = {}) {
    return assertInjector(injectParams, pOptions?.injector, () => {
        const route = inject(ActivatedRoute);
        const params = route.snapshot.params;
        const { parse, defaultValue } = pOptions;
        if (!pKeyOrParamsTransform) {
            return toSignal(route.params, { initialValue: params });
        }
        if (typeof pKeyOrParamsTransform === 'function') {
            return toSignal(route.params.pipe(map(pKeyOrParamsTransform)), {
                initialValue: pKeyOrParamsTransform(params),
            });
        }
        const getParam = (params) => {
            const param = params?.[pKeyOrParamsTransform];
            if (!param) {
                return defaultValue ?? null;
            }
            return parse ? parse(param) : param;
        };
        return toSignal(route.params.pipe(map(getParam)), {
            initialValue: getParam(params),
        });
    });
}

function openDB(pConfig) {
    return new Promise((pResolve, pReject) => {
        const request = indexedDB.open(pConfig.dbName, pConfig.version ?? 1);
        request.onupgradeneeded = pEvent => {
            const db = pEvent.target.result;
            if (!db.objectStoreNames.contains(pConfig.storeName)) {
                db.createObjectStore(pConfig.storeName, { keyPath: pConfig.keyPath });
            }
        };
        request.onsuccess = () => pResolve(request.result);
        request.onerror = () => pReject(request.error);
    });
}
/**
 * Initializes and manages a table (object store) in IndexedDB.
 * The data is wrapped in a WritableSignal for reactive usage in Angular.
 * Automatically synchronizes data across multiple browser tabs using BroadcastChannel.
 *
 * @template T The type of records stored in the object store.
 *
 * @param {Object} pConfig Configuration for IndexedDB connection.
 * @param {string} pConfig.dbName The database name.
 * @param {string} pConfig.storeName The name of the object store (table).
 * @param {string} pConfig.keyPath The key path used as the primary key in the object store.
 * @param {number} [pConfig.version=1] The database version.
 *
 * @returns {Object} An object containing methods to interact with the store and the reactive signal:
 * @returns {WritableSignal<T[]>} return.items A signal containing all records in the store.
 * @returns {() => Promise<void>} return.refresh Reloads all data from IndexedDB into the signal.
 * @returns {(item: T) => Promise<void>} return.add Adds a new record; throws if key already exists.
 * @returns {(item: T) => Promise<void>} return.set Adds or updates a record (put).
 * @returns {(id: IDBValidKey, updateFn: (item: T) => T) => Promise<void>} return.update Updates a record by id.
 * @returns {(id: IDBValidKey) => Promise<void>} return.delete Deletes a record by id.
 * @returns {(id: IDBValidKey) => Promise<T | undefined>} return.get Retrieves a record by id.
 *
 * @example
 * ```ts
 * const { items, add, set, update, delete: deleteItem, get } = injectIndexedDBTable<User>({
 *   dbName: 'appDB',
 *   storeName: 'users',
 *   keyPath: 'userId',
 * });
 *
 * // Get current list
 * console.log(items());
 *
 * // Add a new record
 * await add({ userId: 1, name: 'Alice' });
 *
 * // Update a record
 * await update(1, user => ({ ...user, name: 'Bob' }));
 *
 * // Delete a record
 * await deleteItem(1);
 *
 * // Get a record by id
 * const user = await get(1);
 * ```
 *
 * @note
 * - Data is automatically synchronized between browser tabs using BroadcastChannel.
 * - BroadcastChannel will be automatically closed when the component or service is destroyed via DestroyRef.
 * - Only works in browser environments where window is available.
 */
function injectIndexedDBTable(pConfig) {
    const items = signal([], ...(ngDevMode ? [{ debugName: "items" }] : []));
    const destroyRef = inject(DestroyRef);
    const window = inject(DOCUMENT).defaultView;
    if (!window)
        throw new Error('Window object not available');
    // Tạo BroadcastChannel chung cho tên db + store
    const channelName = `${pConfig.dbName}_${pConfig.storeName}_channel`;
    const broadcast = new BroadcastChannel(channelName);
    async function refresh() {
        const db = await openDB(pConfig);
        const tx = db.transaction(pConfig.storeName, 'readonly');
        const store = tx.objectStore(pConfig.storeName);
        const allItems = await new Promise((pResolve, pReject) => {
            const req = store.getAll();
            req.onsuccess = () => pResolve(req.result);
            req.onerror = () => pReject(req.error);
        });
        items.set(allItems);
    }
    async function notifyChange() {
        broadcast.postMessage({ type: 'change' });
    }
    async function add(pItem) {
        const db = await openDB(pConfig);
        await new Promise((pResolve, pReject) => {
            const tx = db.transaction(pConfig.storeName, 'readwrite');
            const store = tx.objectStore(pConfig.storeName);
            const req = store.add(pItem);
            req.onsuccess = () => pResolve();
            req.onerror = () => pReject(req.error);
        });
        await notifyChange();
        await refresh();
    }
    async function set(pItem) {
        const db = await openDB(pConfig);
        await new Promise((pResolve, pReject) => {
            const tx = db.transaction(pConfig.storeName, 'readwrite');
            const store = tx.objectStore(pConfig.storeName);
            const req = store.put(pItem);
            req.onsuccess = () => pResolve();
            req.onerror = () => pReject(req.error);
        });
        await notifyChange();
        await refresh();
    }
    async function update(pId, pUpdateCallback) {
        const current = await get(pId);
        if (!current)
            throw new Error('Item not found');
        const updated = pUpdateCallback(current);
        await set(updated);
    }
    async function deleteItem(pId) {
        const db = await openDB(pConfig);
        await new Promise((pResolve, pReject) => {
            const tx = db.transaction(pConfig.storeName, 'readwrite');
            const store = tx.objectStore(pConfig.storeName);
            const req = store.delete(pId);
            req.onsuccess = () => pResolve();
            req.onerror = () => pReject(req.error);
        });
        await notifyChange();
        await refresh();
    }
    async function deleteAll() {
        const db = await openDB(pConfig);
        await new Promise((pResolve, pReject) => {
            const tx = db.transaction(pConfig.storeName, 'readwrite');
            const store = tx.objectStore(pConfig.storeName);
            const req = store.clear();
            req.onsuccess = () => pResolve();
            req.onerror = () => pReject(req.error);
        });
        await notifyChange();
        await refresh();
    }
    async function get(pId) {
        const db = await openDB(pConfig);
        return new Promise((pResolve, pReject) => {
            const tx = db.transaction(pConfig.storeName, 'readonly');
            const store = tx.objectStore(pConfig.storeName);
            const req = store.get(pId);
            req.onsuccess = () => pResolve(req.result);
            req.onerror = () => pReject(req.error);
        });
    }
    broadcast.onmessage = pEvent => {
        if (pEvent.data?.type === 'change') {
            refresh();
        }
    };
    destroyRef.onDestroy(() => {
        broadcast.close();
    });
    refresh();
    return {
        items,
        refresh,
        add,
        set,
        update,
        delete: deleteItem,
        get,
        deleteAll,
    };
}

/**
 * Creates an auto-wired `Effect` using the current injection context.
 *
 * Useful when working in places without an implicit injection context
 * (e.g. `ngOnInit`, `afterNextRender`).
 *
 * @returns A function that registers an Angular `effect`.
 *
 * @example
 * ```ts
 * @Component()
 * export class MyComponent {
 *   @Input({ required: true }) data!: Signal<Data>;
 *
 *   private autoEffect = injectAutoEffect();
 *
 *   constructor() {
 *     // Not safe: input not initialized yet
 *     effect(() => {
 *       console.log(this.data());
 *     });
 *   }
 *
 *   ngOnInit() {
 *     //Safe: input is available
 *     this.autoEffect(() => {
 *       console.log(this.data());
 *     });
 *   }
 * }
 * ```
 */
function injectAutoEffect(pInjector) {
    return assertInjector(injectAutoEffect, pInjector, () => {
        const assertedInjector = inject(Injector);
        const injectorOptions = { injector: assertedInjector };
        return (pAutoEffectCallback, pOptions = {}) => {
            return effect(pOnCleanup => {
                const maybeCleanup = pAutoEffectCallback(assertedInjector);
                if (typeof maybeCleanup === 'function') {
                    pOnCleanup(() => maybeCleanup());
                }
            }, Object.assign(pOptions, injectorOptions));
        };
    });
}

const EMAIL_REGEX = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/g;
function validateEmail() {
    return (pControl) => {
        const regex = new RegExp(EMAIL_REGEX);
        const isEmail = regex.test(pControl.value);
        return isEmail ? null : { invalidEmail: true };
    };
}

const PHONE_REGEX = /^((\+?[0-9]{1,2})|([0-9]{1,2}))([0-9]{9})$/g;
function validatePhone() {
    return (pControl) => {
        const regex = new RegExp(PHONE_REGEX);
        const isPhoneNumber = regex.test(pControl.value);
        return isPhoneNumber ? null : { invalidPhoneNumber: true };
    };
}

/**
 * Generated bundle index. Do not edit.
 */

export { EnsureFormat, InputSetter, IsInViewportService, LOCAL_STORAGE, RESIZE_OPTIONS, SESSION_STORAGE, assertInjector, calculateResult, computedPrevious, createInjectionToken, createNoopInjectionToken, createNotifier, createResizeStream, createSingletonProxy, createSingletonProxyNullable, debug, defaultResizeOptions, derivedFrom, effectOnceIf, explicitEffect, findScrollContainers, injectActiveElement, injectAutoEffect, injectDestroy, injectIndexedDBTable, injectIsIntersecting, injectLazy, injectNavigationState, injectParams, injectResize, injectResizeOptions, injectStorage, lazyInject, mergeFrom, provideLocalStorageImpl, provideResizeOptions, provideSessionStorageImpl, signalHistory, toLazySignal, toObservableDefer, validateEmail, validatePhone };
//# sourceMappingURL=bravo-infra-core-ng-extensions.mjs.map
