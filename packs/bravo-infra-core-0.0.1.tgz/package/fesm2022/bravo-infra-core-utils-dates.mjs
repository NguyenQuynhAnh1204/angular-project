import { CustomKey, KoreanKey, ChineseKey, JapaneseKey, EnglishKey, VietNameseKey, BravoAppSettings } from '@bravo-infra/core/utils/global-settings';
import * as DateUtil from 'date-fns';
import { getWeeksInMonth } from 'date-fns';
import { vi, ko, zhCN, ja, enUS } from 'date-fns/locale';

const LocalMap = {
    [VietNameseKey]: vi,
    [EnglishKey]: enUS,
    [JapaneseKey]: ja,
    [ChineseKey]: zhCN,
    [KoreanKey]: ko,
    [CustomKey]: vi,
};
class BravoMoment {
    static now() {
        return new BravoMoment(new Date());
    }
    static set(pDate, pValues, pOptions) {
        return new BravoMoment(DateUtil.set(pDate, pValues, pOptions));
    }
    #date;
    #patternFormat = '';
    get patternFormat() {
        return this.#patternFormat ? this.#patternFormat : BravoAppSettings.settings.dateFormat;
    }
    #locale;
    get locale() {
        return this.#locale ? this.#locale : LocalMap[BravoAppSettings.settings.locale];
    }
    get currentFormat() {
        return this.format(this.patternFormat);
    }
    constructor(pInput, pPatternFormat, pLocal) {
        if (pPatternFormat)
            this.#patternFormat = pPatternFormat;
        if (pLocal)
            this.#locale = pLocal;
        if (pInput == undefined)
            this.#date = BravoMoment.now().#date;
        else if (pInput instanceof BravoMoment)
            this.#date = pInput.#date;
        else if (pInput instanceof Date)
            this.#date = pInput;
        else if (typeof pInput === 'string') {
            //?NOTE: giá trị là string có thể là date iso hoặc 1 chuỗi định dạng ngày tháng
            this.#date = BravoMoment.autoParseDate(pInput)?.toDate() || new Date(pInput);
        }
        else
            this.#date = new Date(pInput);
    }
    #updateDate(pNewDate) {
        this.#date = pNewDate;
        return this;
    }
    static getLocal(pLangKey) {
        return LocalMap[pLangKey];
    }
    //#region ISO  Methods
    startOfISOWeek(pOptions) {
        return this.#updateDate(DateUtil.startOfISOWeek(this.#date, pOptions));
    }
    endOfISOWeek(pOptions) {
        return this.#updateDate(DateUtil.endOfISOWeek(this.#date, pOptions));
    }
    startOfISOWeekYear(pOptions) {
        return this.#updateDate(DateUtil.startOfISOWeekYear(this.#date, pOptions));
    }
    endOfISOWeekYear(pOptions) {
        return this.#updateDate(DateUtil.endOfISOWeekYear(this.#date, pOptions));
    }
    getISOWeek(pOptions) {
        return DateUtil.getISOWeek(this.#date, pOptions);
    }
    getISOWeekYear(pOptions) {
        return DateUtil.getISOWeekYear(this.#date, pOptions);
    }
    static parseISO(pDate, pOptions) {
        return DateUtil.parseISO(pDate, pOptions);
    }
    formatISO(pOptions) {
        return DateUtil.formatISO(this.#date, pOptions);
    }
    formatISO9075(pOptions) {
        return DateUtil.formatISO9075(this.#date, pOptions);
    }
    //#endregion ISO Week Methods
    //#region Date Manipulation Methods
    addDays(pDays, pOptions) {
        return this.#updateDate(DateUtil.addDays(this.#date, pDays, pOptions));
    }
    subDays(pDays, pOptions) {
        return this.#updateDate(DateUtil.subDays(this.#date, pDays, pOptions));
    }
    addMonths(pMonths, pOptions) {
        return this.#updateDate(DateUtil.addMonths(this.#date, pMonths, pOptions));
    }
    subMonths(pMonths, pOptions) {
        return this.#updateDate(DateUtil.subMonths(this.#date, pMonths, pOptions));
    }
    addYears(pYears, pOptions) {
        return this.#updateDate(DateUtil.addYears(this.#date, pYears, pOptions));
    }
    subYears(pYears) {
        return this.#updateDate(DateUtil.subYears(this.#date, pYears));
    }
    startOfMonth(pOptions) {
        return this.#updateDate(DateUtil.startOfMonth(this.#date, pOptions));
    }
    endOfMonth(pOptions) {
        return this.#updateDate(DateUtil.endOfMonth(this.#date, pOptions));
    }
    startOfWeek(pOptions) {
        pOptions ??= {};
        if (!pOptions.locale)
            pOptions.locale = this.locale;
        if (!pOptions.weekStartsOn)
            pOptions.weekStartsOn = BravoAppSettings.settings.weekStartOn;
        return this.#updateDate(DateUtil.startOfWeek(this.#date, pOptions));
    }
    endOfWeek(pOptions) {
        pOptions ??= {};
        if (!pOptions.locale)
            pOptions.locale = this.locale;
        if (!pOptions.weekStartsOn)
            pOptions.weekStartsOn = BravoAppSettings.settings.weekStartOn;
        return this.#updateDate(DateUtil.endOfWeek(this.#date, pOptions));
    }
    setMonth(pMonth, pOptions) {
        return this.#updateDate(DateUtil.setMonth(this.#date, pMonth, pOptions));
    }
    setDay(pDay, pOptions) {
        return this.#updateDate(DateUtil.setDay(this.#date, pDay, pOptions));
    }
    setYear(pYear, pOptions) {
        return this.#updateDate(DateUtil.setYear(this.#date, pYear, pOptions));
    }
    setHours(pHours, pOptions) {
        return this.#updateDate(DateUtil.setHours(this.#date, pHours, pOptions));
    }
    setMinutes(pMinutes, pOptions) {
        return this.#updateDate(DateUtil.setMinutes(this.#date, pMinutes, pOptions));
    }
    setSeconds(pSeconds, pOptions) {
        return this.#updateDate(DateUtil.setSeconds(this.#date, pSeconds, pOptions));
    }
    static lastDayOfMonth(pDate, pOptions) {
        const moment = new BravoMoment(pDate);
        return DateUtil.lastDayOfMonth(moment.toDate(), pOptions);
    }
    lastDayOfMonth(pOptions) {
        return this.#updateDate(BravoMoment.lastDayOfMonth(this.#date, pOptions));
    }
    //#endregion Date Manipulation Methods
    //#region Comparison Methods
    static isValid(pDate) {
        const moment = new BravoMoment(pDate);
        return DateUtil.isValid(moment.#date);
    }
    isSunday() {
        return this.getDay() == 0;
    }
    isValid() {
        return BravoMoment.isValid(this);
    }
    isSameDay(pDate, pOptions) {
        return DateUtil.isSameDay(this.#date, new BravoMoment(pDate).toDate(), pOptions);
    }
    isSameMonth(pDate, pOptions) {
        return DateUtil.isSameMonth(this.#date, new BravoMoment(pDate).toDate(), pOptions);
    }
    isSameYear(pDate, pOptions) {
        return DateUtil.isSameYear(this.#date, new BravoMoment(pDate).toDate(), pOptions);
    }
    isToday(pOptions) {
        return DateUtil.isToday(this.#date, pOptions);
    }
    isToMonth() {
        return this.getMonth() === new BravoMoment().getMonth();
    }
    isToYear() {
        return this.getYear() === new BravoMoment().getYear();
    }
    static isLeapYear(pYear) {
        return DateUtil.isLeapYear(pYear);
    }
    isDate() {
        return DateUtil.isDate(this.#date);
    }
    static isDate(pValue) {
        return DateUtil.isDate(pValue);
    }
    isBefore(pDate) {
        return DateUtil.isBefore(this.#date, new BravoMoment(pDate).toDate());
    }
    isAfter(pDate) {
        return DateUtil.isAfter(this.#date, new BravoMoment(pDate).toDate());
    }
    isEqual(pDate) {
        return DateUtil.isEqual(this.#date, new BravoMoment(pDate).toDate());
    }
    static isEqual(pDate, pDate2) {
        return DateUtil.isEqual(new BravoMoment(pDate).toDate(), new BravoMoment(pDate2).toDate());
    }
    static isTimeFormat(pFormat) {
        if (!pFormat)
            return false;
        return pFormat.match(/H|h|m|s|t|a/g) != null;
    }
    static isDayInMonth(pDay, pMonth, pYear) {
        if (pDay < 1)
            return false;
        const maxDay = this.lastDayOfMonth(new Date(pYear, pMonth, 1)).getDate();
        return pDay <= maxDay;
    }
    //#endregion Comparison Methods
    //#region Difference Methods
    differenceInMinutes(pDate, pOptions) {
        return DateUtil.differenceInMinutes(this.#date, new BravoMoment(pDate).toDate(), pOptions);
    }
    differenceInHours(pDate, pOptions) {
        return DateUtil.differenceInHours(this.#date, new BravoMoment(pDate).toDate(), pOptions);
    }
    differenceInDays(pDate, pOptions) {
        return DateUtil.differenceInDays(this.#date, new BravoMoment(pDate).toDate(), pOptions);
    }
    differenceInMonths(pDate, pOptions) {
        return DateUtil.differenceInMonths(this.#date, new BravoMoment(pDate).toDate(), pOptions);
    }
    differenceInYears(pDate, pOptions) {
        return DateUtil.differenceInYears(this.#date, new BravoMoment(pDate).toDate(), pOptions);
    }
    differenceInSeconds(pDate, pOptions) {
        return DateUtil.differenceInSeconds(this.#date, new BravoMoment(pDate).toDate(), pOptions);
    }
    //#endregion Difference Methods
    //#region getters
    getDay(pOptions) {
        return DateUtil.getDay(this.#date, pOptions);
    }
    getMonth(pOptions) {
        return DateUtil.getMonth(this.#date, pOptions);
    }
    getYear(pOptions) {
        return DateUtil.getYear(this.#date, pOptions);
    }
    //immutable
    getWeeks(pOptions) {
        pOptions ??= {};
        if (!pOptions.weekStartsOn)
            pOptions.weekStartsOn = BravoAppSettings.settings.weekStartOn;
        const start = this.clone().startOfMonth().startOfWeek(pOptions);
        const end = this.clone().endOfMonth().endOfWeek(pOptions);
        const days = BravoMoment.eachDayOfInterval(start, end);
        return Array.from({
            length: getWeeksInMonth(this.#date, pOptions),
        }, (_, pIndex) => days.slice(pIndex * 7, (pIndex + 1) * 7).map(pDay => new BravoMoment(pDay, this.#patternFormat)));
    }
    //immutable
    getMonths(pattern = 'MMM', pNumberOfRow) {
        const numberMonthInYear = 12;
        const itemPerRow = numberMonthInYear / pNumberOfRow;
        const months = Array.from({ length: numberMonthInYear }, (_, pIndex) => {
            const month = 0 + pIndex;
            return new BravoMoment(DateUtil.setMonth(this.#date, month), pattern || this.#patternFormat);
        });
        return Array.from({ length: pNumberOfRow }, (_, pIndex) => months.slice(pIndex * itemPerRow, (pIndex + 1) * itemPerRow));
    }
    //immutable
    getYears(pNumberOfRow, pItemPerRow) {
        const currentYear = this.getYear(); //current year
        const mount = pNumberOfRow * pItemPerRow;
        const half = Math.floor(mount / 2);
        const startYear = currentYear - half; //start year
        // create array BravoMoment from startYear, stay day,month and hours
        const years = Array.from({ length: mount }, (_, pIndex) => {
            const year = startYear + pIndex;
            return new BravoMoment(DateUtil.setYear(this.#date, year), this.#patternFormat);
        });
        return Array.from({ length: Math.ceil(mount / pNumberOfRow) }, (_, i) => years.slice(i * pItemPerRow, (i + 1) * pItemPerRow));
    }
    //immutable
    getDays(pattern = 'EEE', pOptions) {
        if (!pattern)
            pattern = 'EEE';
        pOptions ??= {};
        if (!pOptions.locale)
            pOptions.locale = this.locale;
        if (!pOptions.weekStartsOn)
            pOptions.weekStartsOn = BravoAppSettings.settings.weekStartOn;
        const days = Array.from({ length: 7 }, (_, pIndex) => DateUtil.format(new Date(2000, 0, pIndex + 3), pattern, pOptions));
        if (pOptions?.weekStartsOn === 0) {
            const sunday = days.pop();
            if (sunday)
                days.unshift(sunday);
        }
        return days;
    }
    getTime() {
        return this.#date.getTime();
    }
    getFullYear() {
        return this.#date.getFullYear();
    }
    getDate() {
        return this.#date.getDate();
    }
    getHours() {
        return this.#date.getHours();
    }
    getMinutes() {
        return this.#date.getMinutes();
    }
    getSeconds() {
        return this.#date.getSeconds();
    }
    getMilliseconds() {
        return this.#date.getMilliseconds();
    }
    toDate() {
        return this.#date;
    }
    //#endregion getters
    static ensureFormat(pFormat) {
        if (!pFormat)
            return pFormat;
        return pFormat
            .replace(/yyyy/g, 'yyyy')
            .replace(/yy/g, 'yy')
            .replace(/y/g, 'y')
            .replace(/MMMM/g, 'MMMM')
            .replace(/MMM/g, 'MMM')
            .replace(/MM/g, 'MM')
            .replace(/M/g, 'M')
            .replace(/dddd/g, 'EEEE')
            .replace(/ddd/g, 'EEE')
            .replace(/dd/g, 'dd')
            .replace(/d/g, 'd')
            .replace(/HH/g, 'HH')
            .replace(/H/g, 'H')
            .replace(/hh/g, 'hh')
            .replace(/h/g, 'h')
            .replace(/mm/g, 'mm')
            .replace(/m/g, 'm')
            .replace(/ss/g, 'ss')
            .replace(/s/g, 's')
            .replace(/tt/g, 'aa')
            .replace(/t/g, 'aa')
            .replace(/[fF]{1,7}/g, 'SSS')
            .replace(/q/g, 'Q')
            .replace(/zzz/g, 'XXX');
    }
    //#region Utility Methods
    static parseDate(pInput, pFormat, pReferenceDate = new Date(), pOptions) {
        pOptions ??= {};
        if (!pOptions.weekStartsOn)
            pOptions.weekStartsOn = BravoAppSettings.settings.weekStartOn;
        if (!pOptions.locale)
            pOptions.locale = BravoMoment.getLocal(BravoAppSettings.settings.locale);
        return new BravoMoment(DateUtil.parse(pInput, pFormat, pReferenceDate, pOptions));
    }
    static eachDayOfInterval(pStartDate, pEndDate, pOptions) {
        return DateUtil.eachDayOfInterval({ start: new BravoMoment(pStartDate).#date, end: new BravoMoment(pEndDate).toDate() }, pOptions);
    }
    static getQuarterBegin(pDate) {
        return DateUtil.startOfQuarter(new BravoMoment(pDate).toDate());
    }
    format(pPattern = this.patternFormat, pOptions) {
        pOptions ??= {};
        if (!pOptions?.locale)
            pOptions.locale = this.locale;
        if (!pOptions?.weekStartsOn)
            pOptions.weekStartsOn = BravoAppSettings.settings.weekStartOn;
        return BravoMoment.format(this.toDate(), pPattern, pOptions);
    }
    static format(pDate, pattern, pOptions) {
        pOptions ??= {};
        if (pOptions?.locale)
            pOptions.locale = BravoMoment.getLocal(BravoAppSettings.settings.locale);
        if (pOptions?.weekStartsOn)
            pOptions.weekStartsOn = BravoAppSettings.settings.weekStartOn;
        const format = BravoAppSettings.settings.getDateFormatPattern(pattern) || pattern;
        pDate = new BravoMoment(pDate).toDate();
        try {
            return DateUtil.format(pDate, format, pOptions);
        }
        catch {
            return pDate.toLocaleDateString();
        }
    }
    toISOString() {
        return this.#date.toISOString();
    }
    clone() {
        return new BravoMoment(this.#date ? new Date(this.#date) : undefined, this.#patternFormat);
    }
    //#endregion Utility Methods
    static asDate(pDate) {
        return new BravoMoment(pDate).toDate();
    }
    static autoParseDate(pDateString, pCulture) {
        if (!pCulture)
            pCulture = BravoAppSettings.settings.currentCulture;
        const possibleFormats = BravoAppSettings.settings.datePartsRegions[pCulture];
        for (const format of possibleFormats) {
            const parsedDate = BravoMoment.parseManualDate(pDateString, format);
            if (parsedDate && BravoMoment.isValid(parsedDate))
                return new BravoMoment(parsedDate, format);
        }
        console.warn('⛔ Invalid date input.');
        return null;
    }
    static parseManualDate(pValue, pFormat, pDefaultDate = new Date()) {
        pValue = pValue.trim();
        if (!pValue || !pFormat) {
            return null;
        }
        // Handle culture-invariant formats
        if (pFormat === 'u') {
            const parsed = new Date(pValue);
            return BravoMoment.isValid(parsed) ? parsed : null;
        }
        // Handle RFC 3339 format
        if (pFormat === 'R' || pFormat === 'r') {
            // check format is 'R' hoặc 'r' (RFC 3339)
            // Regex để bắt các thành phần ngày giờ trong chuỗi RFC 3339
            // Cấu trúc: [yyyy-MM-dd] [hh:mm[:ss]]
            const rx = /(([0-9]+)-([0-9]+)-([0-9]+))?\s?(([0-9]+):([0-9]+)(:([0-9]+))?)?/;
            // apply regex lên chuỗi value
            const match = pValue.match(rx);
            // Nếu không khớp với pattern thì trả về null
            if (!match)
                return null;
            let date;
            // Xử lý khi có phần ngày (match[1]) hoặc phần giờ (match[5])
            if (match[1] || match[5]) {
                // Nếu có phần ngày (yyyy-MM-dd)
                date = match[1]
                    ? new Date(parseInt(match[2]), parseInt(match[3]) - 1, parseInt(match[4])) // Tạo Date từ y,m,d
                    : new Date(); // Nếu không có ngày thì dùng ngày hiện tại
                // Nếu có phần giờ (hh:mm[:ss])
                if (match[5]) {
                    // Set giờ, phút
                    date.setHours(parseInt(match[6]));
                    date.setMinutes(parseInt(match[7]));
                    // Set giây nếu có (match[8] là dấu ':' nếu có giây)
                    date.setSeconds(match[8] ? parseInt(match[9]) : 0);
                }
            }
            // Nếu không có cả ngày lẫn giờ thì thử parse trực tiếp
            else
                date = new Date(pValue);
            return BravoMoment.isValid(date) ? date : null;
        }
        // Convert custom format tokens to date-fns format tokens
        const convertedFormat = BravoMoment.ensureFormat(pFormat); // Timezone (vd: +07:00);
        // Handle fiscal year, era, and other special cases from the old function
        // Try parsing with date-fns first
        try {
            const parsedDate = BravoMoment.parseDate(pValue, convertedFormat, pDefaultDate);
            if (parsedDate.isValid()) {
                // Additional validation from the old function
                let year = parsedDate.getFullYear();
                // Validate year
                // Xử lý năm 2 chữ số
                if (year < 100) {
                    year += year < 50 ? 2000 : 1900;
                    parsedDate.setYear(year);
                }
                else if (year < 1000) {
                    year += year < 500 ? 2000 : 1000;
                    parsedDate.setYear(year);
                }
                if (year > 9999) {
                    console.warn('❌ Not accept year > 9999!!!');
                    return null;
                }
                return parsedDate.isValid() ? parsedDate.#date : null;
            }
        }
        catch (pEx) {
            // Fall through to manual parsing if date-fns fails
        }
        // Fallback to manual parsing
        const formatParts = this.#parseDateFormat(convertedFormat);
        const valueParts = pValue.match(/\d+|[a-zA-Z]+/g);
        if (!formatParts || !valueParts) {
            //  || formatParts.length !== valueParts.length //?NOTE: bỏ điều kiện này vì sẽ hỗ trợ autoCorrect nếu thiếu: BravoMoment.parseManualDate('25/12', 'dd/MM/yyyy') -> 25/12/năm hiện tại
            return null;
        }
        let parsedYear = pDefaultDate.getFullYear();
        let parsedMonth = pDefaultDate.getMonth();
        let parsedDay = pDefaultDate.getDate();
        let parsedHour = 0;
        let parsedMinute = 0;
        let parsedSecond = 0;
        let parsedMillisecond = 0;
        let isPM = false;
        // Parse components
        const minLength = Math.min(formatParts.length, valueParts.length);
        for (let i = 0; i < minLength; i++) {
            const part = formatParts[i];
            const valuePart = valueParts[i];
            switch (part) {
                case 'yyyy':
                    parsedYear = parseInt(valuePart, 10);
                    break;
                case 'yy':
                    parsedYear = parseInt(valuePart, 10);
                    parsedYear += parsedYear < 50 ? 2000 : 1900;
                    break;
                case 'y':
                    parsedYear = parseInt(valuePart, 10);
                    break;
                case 'MMMM':
                case 'MMM': {
                    parsedMonth = this.#getMonthFromName(valuePart);
                    if (parsedMonth === -1)
                        return null;
                    break;
                }
                case 'MM':
                case 'M':
                    parsedMonth = parseInt(valuePart, 10) - 1;
                    break;
                case 'dd':
                case 'd':
                    parsedDay = parseInt(valuePart, 10);
                    break;
                case 'HH':
                case 'H':
                    parsedHour = parseInt(valuePart, 10);
                    break;
                case 'hh':
                case 'h':
                    parsedHour = parseInt(valuePart, 10);
                    break;
                case 'mm':
                case 'm':
                    parsedMinute = parseInt(valuePart, 10);
                    break;
                case 'ss':
                case 's':
                    parsedSecond = parseInt(valuePart, 10);
                    break;
                case 'fffffff':
                case 'ffffff':
                case 'fffff':
                case 'ffff':
                case 'fff':
                case 'ff':
                case 'f':
                    parsedMillisecond = parseInt(valuePart.padEnd(3, '0'), 10);
                    break;
                case 'tt':
                case 't':
                case 'aa':
                case 'a':
                    isPM = valuePart.toLowerCase().startsWith('p');
                    break;
            }
        }
        // Adjust for PM
        if (isPM && parsedHour < 12) {
            parsedHour += 12;
        }
        else if (!isPM && parsedHour === 12) {
            parsedHour = 0;
        }
        // Handle two-digit years
        if (parsedYear < 100) {
            parsedYear += parsedYear < 50 ? 2000 : 1900;
        }
        // VALIDATION SECTION =============================================
        // 1. Validate year range
        if (parsedYear < 1000 || parsedYear > 9999) {
            console.warn('❌ Not accept year < 1000 || year > 9999!!!');
            return null;
        }
        // 2. Validate month range
        if (parsedMonth < 0 || parsedMonth > 11) {
            return null;
        }
        // 3. Special February validation
        let maxDay = 31;
        if (parsedMonth === 1) {
            // February
            const isLeapYear = (parsedYear % 4 === 0 && parsedYear % 100 !== 0) || parsedYear % 400 === 0;
            maxDay = isLeapYear ? 29 : 28;
        }
        // 4. Validate other months
        else if ([3, 5, 8, 10].includes(parsedMonth)) {
            // April, June, September, November
            maxDay = 30;
        }
        // 5. Validate day
        if (parsedDay < 1 || parsedDay > maxDay) {
            return null;
        }
        // 6. Validate time components
        if (parsedHour < 0 ||
            parsedHour > 23 ||
            parsedMinute < 0 ||
            parsedMinute > 59 ||
            parsedSecond < 0 ||
            parsedSecond > 59 ||
            parsedMillisecond < 0 ||
            parsedMillisecond > 999) {
            return null;
        }
        // Create and validate final date
        const finalDate = new Date(parsedYear, parsedMonth, parsedDay, parsedHour, parsedMinute, parsedSecond, parsedMillisecond);
        return DateUtil.isValid(finalDate) ? finalDate : null;
    }
    static #parseDateFormat(pFormat) {
        return (pFormat.match(/(yyyy|yy|y|MMMM|MMM|MM|M|dddd|ddd|dd|d|HH|H|hh|h|mm|m|ss|s|fffffff|ffffff|fffff|ffff|fff|ff|f|tt|t|aa|a)/g) || []);
    }
    static #monthNameCache = {};
    static #getMonthFromName(pName) {
        const culture = BravoAppSettings.settings.currentLang;
        if (!this.#monthNameCache[culture]) {
            const moment = new BravoMoment();
            // get months (MMMM) and (MMM)
            const fullMonths = moment
                .getMonths('MMMM', 1)
                .flat()
                .map(pItem => pItem.currentFormat.toLowerCase());
            const shortMonths = moment
                .getMonths('MMM', 1)
                .flat()
                .map(pItem => pItem.currentFormat.toLowerCase());
            // save caches
            this.#monthNameCache[culture] = {
                full: fullMonths,
                short: shortMonths,
            };
        }
        const { full, short } = this.#monthNameCache[culture];
        const lowerName = pName.toLowerCase();
        const fullIndex = full.findIndex(pMonth => pMonth.startsWith(lowerName));
        if (fullIndex !== -1)
            return fullIndex;
        const shortIndex = short.findIndex(pMonth => pMonth.startsWith(lowerName));
        if (shortIndex !== -1)
            return shortIndex;
        // not found
        return -1;
    }
}

const ISO_8601_FULL = /^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(\.\d+)?(([+-]\d\d:\d\d)|Z)?$/i;
const EpochMicroTimeDiff = 621355968000000000;
//TODO: Đưa các logic tương tác trực tiếp vào date qua moment
class BravoDateExtensions {
    static calculateExpiredTime(pDateNow, pDateExpired) {
        if (!pDateNow || !pDateExpired)
            return 0;
        let dateNow = pDateNow;
        let dateExpired = pDateExpired;
        // if parseISO false (date invalid), try use Date constructor
        if (!BravoMoment.isValid(dateNow))
            dateNow = new Date(pDateNow);
        if (!BravoMoment.isValid(dateExpired))
            dateExpired = new Date(pDateExpired);
        if (!BravoMoment.isValid(dateNow) || !BravoMoment.isValid(dateExpired))
            return 0;
        const momentExpired = new BravoMoment(dateExpired);
        const momentDateNow = new BravoMoment(dateNow);
        return momentExpired.differenceInSeconds(momentDateNow);
    }
    static reviveUtcDate(pKey, pValue) {
        if (typeof pValue !== 'string') {
            return pValue;
        }
        if (pValue === '0001-01-01T00:00:00') {
            return null;
        }
        const match = ISO_8601_FULL.exec(pValue);
        if (!match)
            return pValue;
        return new Date(pValue);
    }
    static get minValue() {
        return new Date(1900, 0, 1);
    }
    /**
     * @deprecated
     * Using BravoDateMoment instead of
     */
    static clone(pDate) {
        return new Date(pDate.getTime());
    }
    /**
     * @deprecated
     * Using BravoDateMoment instead of
     */
    static isDate(pValue) {
        return BravoMoment.isDate(pValue);
    }
    /**
     * @deprecated
     * Using BravoDateMoment instead of
     */
    static isEqual(pDate, pDate2) {
        return BravoMoment.isEqual(new BravoMoment(pDate).toDate(), new BravoMoment(pDate2).toDate());
    }
    /**
     * @deprecated
     * Using BravoMoment instead of
     */
    static date(pDate) {
        return new Date(pDate.getFullYear(), pDate.getMonth(), pDate.getDate());
    }
    /**
     * @deprecated
     * Using BravoDateMoment instead of
     */
    static month(pDate) {
        return pDate.getMonth() + 1;
    }
    /**
     * @deprecated
     * Using BravoDateMoment instead of
     */
    static year(pDate) {
        return pDate.getFullYear();
    }
    /**
     * Calculates the day of the year for a given date.
     * @deprecated
     * @param pDate - The date for which to determine the day of the year.
     * @returns The day of the year (1-based), where January 1st is 1 and December 31st is 365 or 366 (for leap years).
     */
    static dayOfYear(pDate) {
        const start = new Date(pDate.getFullYear(), 0, 1, 12);
        const target = new Date(pDate.getFullYear(), pDate.getMonth(), pDate.getDate(), 12);
        const diff = Math.round((+target - +start) / 86400000);
        return diff + 1;
    }
    /**
     * @deprecated
     * Using BravoDateMoment instead of
     */
    static day(pDate) {
        return pDate.getDate();
    }
    /**
     * @deprecated
     * Using BravoDateMoment instead of
     */
    static addMonths(pDate, pValue) {
        const date = new Date(pDate.getTime());
        date.setMonth(date.getMonth() + pValue);
        return date;
    }
    /**
     * @deprecated
     * Using BravoDateMoment instead of
     */
    static addDays(pDate, pValue) {
        const date = new Date(pDate.getTime());
        date.setDate(date.getDate() + pValue);
        return date;
    }
    static asDate(pDate) {
        return BravoMoment.isValid(pDate) ? new BravoMoment(pDate).toDate() : pDate;
    }
    static get now() {
        return BravoMoment.now().toDate();
    }
    static get utcNow() {
        const date = new Date();
        return this.toUniversalTime(date);
    }
    /**
     * Converts the given local Date object to its equivalent UTC (universal) time.
     *
     * @param pDate - The local Date object to convert.
     * @returns A new Date object representing the same moment in UTC.
     */
    static toUniversalTime(pDate) {
        return new Date(pDate.getTime() + pDate.getTimezoneOffset() * 60000);
    }
    /**
     * Converts the given date to the local time equivalent.
     *
     * @param pDate - The date to be converted.
     * @returns A new `Date` object representing the local time equivalent of the input date.
     */
    static toLocalTime(pDate) {
        let date = new Date(pDate);
        const localOffset = date.getTimezoneOffset() * 60000;
        const localTime = date.getTime();
        const time = localTime - localOffset;
        date = new Date(time);
        return date;
    }
    /**
     * Converts a .NET binary date value (ticks) to a JavaScript `Date` object.
     *
     * @param pValue - The .NET binary date value (number of ticks since 0001-01-01T00:00:00Z).
     * @returns A JavaScript `Date` object representing the same point in time.
     *
     * @remarks
     * .NET `DateTime` ticks are measured in 100-nanosecond intervals since 0001-01-01T00:00:00Z.
     * This method adjusts for the local timezone offset and the difference between the .NET epoch and the JavaScript epoch.
     */
    static fromBinary(pValue) {
        const ticksToMicroTime = (pValue + new Date().getTimezoneOffset() * 600000000 - EpochMicroTimeDiff) / 10000;
        return new Date(ticksToMicroTime);
    }
    /**
     * Converts a JavaScript `Date` object to a .NET binary (ticks) representation.
     *
     * .NET ticks are the number of 100-nanosecond intervals since 0001-01-01T00:00:00Z.
     * This method returns the UTC ticks (not local time).
     *
     * @param pDate - The `Date` object to convert.
     * @returns The .NET binary representation of the date as a `number`.
     */
    static toBinary(pDate) {
        return pDate.getTime() * 10000 + EpochMicroTimeDiff - pDate.getTimezoneOffset() * 600000000;
    }
}

const MILLIS_PER_SECOND = 1000;
const MILLIS_PER_MINUTE = MILLIS_PER_SECOND * 60; //     60,000
const MILLIS_PER_HOUR = MILLIS_PER_MINUTE * 60; //  3,600,000
const MILLIS_PER_DAY = MILLIS_PER_HOUR * 24; // 86,400,000
class BravoTimeSpan {
    #millis;
    static #interval(pValue, pScale) {
        if (Number.isNaN(pValue)) {
            throw new Error("value can't be NaN");
        }
        const tmp = pValue * pScale;
        const millis = BravoTimeSpan.#round(tmp + (pValue >= 0 ? 0.5 : -0.5));
        if (millis > BravoTimeSpan.maxValue.totalMilliseconds || millis < BravoTimeSpan.minValue.totalMilliseconds) {
            throw new TimeSpanOverflowError('TimeSpanTooLong');
        }
        return new BravoTimeSpan(millis);
    }
    static #round(pNumber) {
        if (pNumber < 0) {
            return Math.ceil(pNumber);
        }
        else if (pNumber > 0) {
            return Math.floor(pNumber);
        }
        return 0;
    }
    static #timeToMilliseconds(pHour, pMinute, pSecond) {
        const totalSeconds = pHour * 3600 + pMinute * 60 + pSecond;
        if (totalSeconds > BravoTimeSpan.maxValue.totalSeconds || totalSeconds < BravoTimeSpan.minValue.totalSeconds) {
            throw new TimeSpanOverflowError('TimeSpanTooLong');
        }
        return totalSeconds * MILLIS_PER_SECOND;
    }
    static get zero() {
        return new BravoTimeSpan(0);
    }
    static get maxValue() {
        return new BravoTimeSpan(Number.MAX_SAFE_INTEGER);
    }
    static get minValue() {
        return new BravoTimeSpan(Number.MIN_SAFE_INTEGER);
    }
    static fromDays(pValue) {
        return BravoTimeSpan.#interval(pValue, MILLIS_PER_DAY);
    }
    static fromHours(pValue) {
        return BravoTimeSpan.#interval(pValue, MILLIS_PER_HOUR);
    }
    static fromMilliseconds(pValue) {
        return BravoTimeSpan.#interval(pValue, 1);
    }
    static fromMinutes(pValue) {
        return BravoTimeSpan.#interval(pValue, MILLIS_PER_MINUTE);
    }
    static fromSeconds(pValue) {
        return BravoTimeSpan.#interval(pValue, MILLIS_PER_SECOND);
    }
    static fromTime(pDaysOrHours, pHoursOrMinutes, pMinutesOrSeconds, pSeconds = 0, pMilliseconds = 0) {
        if (pMilliseconds != undefined) {
            return this.#fromTimeStartingFromDays(pDaysOrHours, pHoursOrMinutes, pMinutesOrSeconds, pSeconds, pMilliseconds);
        }
        else {
            return this.#fromTimeStartingFromHours(pDaysOrHours, pHoursOrMinutes, pMinutesOrSeconds);
        }
    }
    static #fromTimeStartingFromHours(pHours, pMinutes, pSeconds) {
        const millis = BravoTimeSpan.#timeToMilliseconds(pHours, pMinutes, pSeconds);
        return new BravoTimeSpan(millis);
    }
    static #fromTimeStartingFromDays(pDays, pHours, pMinutes, pSeconds, pMilliseconds) {
        const totalMilliSeconds = pDays * MILLIS_PER_DAY +
            pHours * MILLIS_PER_HOUR +
            pMinutes * MILLIS_PER_MINUTE +
            pSeconds * MILLIS_PER_SECOND +
            pMilliseconds;
        if (totalMilliSeconds > BravoTimeSpan.maxValue.totalMilliseconds ||
            totalMilliSeconds < BravoTimeSpan.minValue.totalMilliseconds) {
            throw new TimeSpanOverflowError('TimeSpanTooLong');
        }
        return new BravoTimeSpan(totalMilliSeconds);
    }
    constructor(pMillis) {
        this.#millis = pMillis;
    }
    get days() {
        return BravoTimeSpan.#round(this.#millis / MILLIS_PER_DAY);
    }
    get hours() {
        return BravoTimeSpan.#round((this.#millis / MILLIS_PER_HOUR) % 24);
    }
    get minutes() {
        return BravoTimeSpan.#round((this.#millis / MILLIS_PER_MINUTE) % 60);
    }
    get seconds() {
        return BravoTimeSpan.#round((this.#millis / MILLIS_PER_SECOND) % 60);
    }
    get milliseconds() {
        return BravoTimeSpan.#round(this.#millis % 1000);
    }
    get totalDays() {
        return this.#millis / MILLIS_PER_DAY;
    }
    get totalHours() {
        return this.#millis / MILLIS_PER_HOUR;
    }
    get totalMinutes() {
        return this.#millis / MILLIS_PER_MINUTE;
    }
    get totalSeconds() {
        return this.#millis / MILLIS_PER_SECOND;
    }
    get totalMilliseconds() {
        return this.#millis;
    }
    add(pTimeSpan) {
        const result = this.#millis + pTimeSpan.totalMilliseconds;
        return new BravoTimeSpan(result);
    }
    subtract(pTimeSpan) {
        const result = this.#millis - pTimeSpan.totalMilliseconds;
        return new BravoTimeSpan(result);
    }
}
class TimeSpanOverflowError extends Error {
    constructor(pMessage) {
        super(pMessage);
        this.name = 'TimeSpanOverflowError';
        Object.setPrototypeOf(this, TimeSpanOverflowError.prototype);
    }
}

/**
 * Generated bundle index. Do not edit.
 */

export { BravoDateExtensions, BravoMoment, BravoTimeSpan, TimeSpanOverflowError };
//# sourceMappingURL=bravo-infra-core-utils-dates.mjs.map
