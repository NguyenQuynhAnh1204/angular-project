var index = void 0;

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=bravo-infra-core.mjs.map
