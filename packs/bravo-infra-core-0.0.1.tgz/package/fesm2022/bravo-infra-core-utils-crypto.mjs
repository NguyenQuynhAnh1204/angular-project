import * as CryptoJS from 'crypto-js';
import * as forge from 'node-forge';
import { BravoConverterExtensions, BravoStringExtensions, BravoUnicode, BravoUTF8 } from '@bravo-infra/core/utils/data-extensions';
import FingerprintJS from '@fingerprintjs/fingerprintjs';

class BravoRSACrypto {
    #privateKey = null;
    #publicKey = null;
    /**
     * Generates an RSA key pair with the specified key size.
     */
    async generateKeyPair(pKeySize = 2048) {
        return new Promise((pResolve, pReject) => {
            forge.pki.rsa.generateKeyPair({ bits: pKeySize, workers: -1 }, (pErr, pKeyPair) => {
                if (pErr)
                    pReject(pErr);
                else {
                    this.#privateKey = pKeyPair.privateKey;
                    this.#publicKey = pKeyPair.publicKey;
                    pResolve();
                }
            });
        });
    }
    #base64ToBigInt(pBase64) {
        const bytes = forge.util.decode64(pBase64);
        return new forge.jsbn.BigInteger(forge.util.bytesToHex(bytes), 16);
    }
    #parseXmlElement(pXml, pTag) {
        const parser = new DOMParser();
        const xmlDoc = parser.parseFromString(pXml, 'application/xml');
        return xmlDoc.getElementsByTagName(pTag)[0]?.textContent || '';
    }
    /**
     * Loads a private key from an XML string.
     */
    loadPrivateKeyFromXml(pXml) {
        const parseRsaKeyValue = (pXmlStr) => {
            const parser = new DOMParser();
            const xmlDoc = parser.parseFromString(pXmlStr, 'application/xml');
            function get(pName) {
                return xmlDoc.getElementsByTagName(pName)[0]?.textContent || '';
            }
            function base64ToBigInt(pBase64) {
                const bytes = forge.util.decode64(pBase64);
                return new forge.jsbn.BigInteger(forge.util.createBuffer(bytes).toHex(), 16);
            }
            return forge.pki.setRsaPrivateKey(base64ToBigInt(get('Modulus')), base64ToBigInt(get('Exponent')), base64ToBigInt(get('D')), base64ToBigInt(get('P')), base64ToBigInt(get('Q')), base64ToBigInt(get('DP')), base64ToBigInt(get('DQ')), base64ToBigInt(get('InverseQ')));
        };
        this.#privateKey = parseRsaKeyValue(pXml);
        this.#publicKey = forge.pki.rsa.setPublicKey(this.#privateKey.n, this.#privateKey.e);
    }
    /**
     * Loads a public key from an XML string.
     */
    loadPublicKeyFromXml(pXml) {
        const modulus = this.#base64ToBigInt(this.#parseXmlElement(pXml, 'Modulus'));
        const exponent = this.#base64ToBigInt(this.#parseXmlElement(pXml, 'Exponent'));
        this.#publicKey = forge.pki.rsa.setPublicKey(modulus, exponent);
    }
    /**
     * Loads a private key from a PEM string.
     */
    loadPrivateKeyFromPem(pPrivateKeyPem) {
        this.#privateKey = forge.pki.privateKeyFromPem(pPrivateKeyPem);
    }
    loadPublicKeyFromPem(pPublicKeyPem) {
        this.#publicKey = forge.pki.publicKeyFromPem(pPublicKeyPem);
    }
    getPrivateKeyPem() {
        if (!this.#privateKey)
            throw new Error('Not have private key!!!');
        return forge.pki.privateKeyToPem(this.#privateKey);
    }
    getPublicKeyPem() {
        if (!this.#publicKey)
            throw new Error('Not have public key!');
        return forge.pki.publicKeyToPem(this.#publicKey);
    }
    /**
     * Signs a string using the private key and returns the Base64 signature.
     */
    sign(pData) {
        if (!this.#privateKey)
            throw new Error('Not have private key!!!');
        const md = forge.md.sha256.create();
        md.update(pData, 'utf8');
        const signature = this.#privateKey.sign(md);
        return forge.util.encode64(signature);
    }
    /**
     * Signs a file using the private key and returns the Base64 signature.
     */
    async signFile(pFile) {
        if (!this.#privateKey)
            throw new Error('Not have private key!!!');
        const buffer = await pFile.arrayBuffer();
        const binaryData = forge.util.createBuffer(new Uint8Array(buffer));
        const md = forge.md.sha256.create();
        md.update(binaryData.bytes(), 'binary');
        const signature = this.#privateKey.sign(md);
        return forge.util.encode64(signature);
    }
    /**
     * Verifies a signature using the public key.
     */
    verify(pData, pSignatureBase64) {
        if (!this.#publicKey)
            throw new Error('Not have public key!');
        const md = forge.md.sha256.create();
        md.update(pData, 'utf8');
        const signature = forge.util.decode64(pSignatureBase64);
        return this.#publicKey.verify(md.digest().bytes(), signature);
    }
    /**
     * Verifies a file signature using the public key.
     */
    async verifyFile(pFile, pSignatureBase64) {
        if (!this.#publicKey)
            throw new Error('Not have public key!');
        const buffer = await pFile.arrayBuffer();
        const binaryData = forge.util.createBuffer(new Uint8Array(buffer));
        const md = forge.md.sha256.create();
        md.update(binaryData.bytes(), 'binary');
        const signature = forge.util.decode64(pSignatureBase64);
        return this.#publicKey.verify(md.digest().bytes(), signature);
    }
    encrypt(pData) {
        if (!this.#publicKey)
            throw new Error('Not have public key!');
        const encryptedBytes = this.#publicKey.encrypt(pData, 'RSA-OAEP', {
            md: forge.md.sha256.create(),
        });
        return forge.util.encode64(encryptedBytes);
    }
    decrypt(pEncryptedBase64) {
        if (!this.#privateKey)
            throw new Error('Not have private key!!');
        const encryptedBytes = forge.util.decode64(pEncryptedBase64);
        const decrypted = this.#privateKey.decrypt(encryptedBytes, 'RSA-OAEP', {
            md: forge.md.sha256.create(),
            mgf1: { md: forge.md.sha1.create() },
        });
        return decrypted;
    }
}

class BravoCryptoExtension {
    /**
     * Root key used for hashing operations.
     */
    static defaultRootKey = '0G8hTzpxEcMA';
    /**
     * Encrypts data using RSA with a provided public key (PEM or XML format).
     * @param pData The data to encrypt.
     * @param pPublicKeyPemOrXml The public key in PEM or XML format.
     * @returns The encrypted data as a string.
     */
    static encryptRSA(pData, pPublicKeyPemOrXml) {
        const rsaCrypto = new BravoRSACrypto();
        if (pPublicKeyPemOrXml.includes('BEGIN PUBLIC KEY')) {
            rsaCrypto.loadPublicKeyFromPem(pPublicKeyPemOrXml);
        }
        else {
            rsaCrypto.loadPublicKeyFromXml(pPublicKeyPemOrXml);
        }
        return rsaCrypto.encrypt(pData);
    }
    /**
     * Encrypts a string using AES encryption with a given key.
     * @param pData The string to encrypt.
     * @param pKey The encryption key.
     * @returns The encrypted string.
     */
    static encryptAES(pData, pKey) {
        return CryptoJS.AES.encrypt(pData, pKey).toString();
    }
    /**
     * Decrypts an AES-encrypted string using the given key.
     * @param pEncryptedData The encrypted data.
     * @param pKey The decryption key.
     * @returns The decrypted string.
     */
    static decryptAES(pEncryptedData, pKey) {
        return CryptoJS.AES.decrypt(pEncryptedData, pKey).toString(CryptoJS.enc.Utf8);
    }
    /**
     * Computes the SHA-256 hash of a given string.
     * @param pInput The input string.
     * @returns The SHA-256 hash as a string.
     */
    static computeSHA256(pInput) {
        return CryptoJS.SHA256(pInput).toString();
    }
    /**
     * Computes the MD5 hash of a given string and returns the result as a byte array.
     * @param pInput The input string.
     * @returns A Uint8Array containing the hash bytes.
     */
    static computeMD5HashBytes(pInput) {
        if (!pInput)
            return;
        const hash = CryptoJS.MD5(CryptoJS.enc.Utf16LE.parse(pInput));
        return BravoConverterExtensions.fromBase64String(hash.toString(CryptoJS.enc.Base64));
    }
    /**
     * Computes the MD5 hash of a given string and returns the result in uppercase hexadecimal format.
     * @param pInput The input string.
     * @returns The MD5 hash as an uppercase hexadecimal string.
     */
    static computeMD5Hash(pInput) {
        return CryptoJS.MD5(CryptoJS.enc.Utf16LE.parse(pInput)).toString(CryptoJS.enc.Hex).toUpperCase();
    }
    /**
     * Computes an MD5-based hash using the default root key.
     * @returns A Uint8Array containing the hash bytes.
     */
    static generateRootKeyHash() {
        const hash = CryptoJS.MD5(CryptoJS.enc.Base64.parse(BravoCryptoExtension.defaultRootKey));
        return BravoConverterExtensions.fromBase64String(hash.toString(CryptoJS.enc.Base64));
    }
    /**
     * Computes a checksum using a raw checksum and an identifier.
     * @param pRawChecksum The raw checksum as a Uint8Array.
     * @param pId The identifier number.
     * @returns The computed checksum as a Uint8Array.
     */
    static computeChecksum(pRawChecksum, pId) {
        const formattedString = BravoStringExtensions.format('{0}', `${pId}`).trim() +
            BravoConverterExtensions.toBase64String(pRawChecksum);
        const bytes = BravoUnicode.getBytes(formattedString);
        const hash = CryptoJS.MD5(CryptoJS.enc.Base64.parse(BravoConverterExtensions.toBase64String(bytes)));
        return BravoConverterExtensions.fromBase64String(hash.toString(CryptoJS.enc.Base64));
    }
    /**
     * Computes an MD5 hash for a given input.
     * @param pInput The input string.
     * @returns The computed MD5 hash as a string.
     */
    static computeMD5(pInput) {
        return CryptoJS.MD5(pInput).toString();
    }
    /**
     * Verifies whether the provided checksum matches the computed checksum for a given ID and password.
     * @param pChecksum The checksum to verify.
     * @param pId The identifier number.
     * @param pPassword The password used in the hashing process.
     * @returns True if the checksum is valid, otherwise false.
     */
    static verifyChecksum(pChecksum, pId, pPassword) {
        let computedValue = pId.toString() + pPassword;
        const computedBytes = this.computeMD5HashBytes(computedValue);
        if (!computedBytes)
            return false;
        let computedChecksum = BravoConverterExtensions.toBase64String(computedBytes);
        if (pChecksum === computedChecksum)
            return true;
        computedValue = pId.toString() + BravoConverterExtensions.toBase64String(computedBytes);
        computedChecksum = BravoConverterExtensions.toBase64String(computedBytes);
        return pChecksum === computedChecksum;
    }
}
/**
 * Generates a short hash name for a given input.
 * @param pContent The input content (string or object).
 * @returns A 9-character substring of the SHA-256 hash.
 */
function generateShortHashName(pContent) {
    if (!BravoStringExtensions.isString(pContent))
        pContent = JSON.stringify(pContent);
    const hash = BravoCryptoExtension.computeSHA256(pContent);
    return hash.substr(0, 9);
}

/**
 * BravoBrowserIdentifier
 *
 * Utility class to obtain a stable browser identifier for the current visitor.
 * It first tries to obtain an identifier from the FingerprintJS library.
 * If that fails (e.g. FingerprintJS not available or an error occurs),
 * it falls back to generating and persisting a UUID in localStorage.
 *
 * Usage:
 *   const id = await BravoBrowserIdentifier.getBrowserIdentifier();
 */
class BravoBrowserIdentifier {
    /**
     * Get a browser identifier for the current visitor.
     *
     * This method attempts to load FingerprintJS and return the visitorId.
     * If any error occurs (library not available, network error, etc.),
     * it will read a persisted UUID from localStorage or generate a new one,
     * persist it, and return that fallback value.
     *
     * @returns {Promise<string>} A promise resolving to a stable identifier string.
     */
    static async getBrowserIdentifier() {
        try {
            const fpPromise = FingerprintJS.load();
            // Get the visitor identifier when you need it.
            const fp = await fpPromise;
            const { visitorId } = await fp.get();
            return visitorId;
        }
        catch {
            // Fallback: use or create a persisted UUID in localStorage
            const uniqueID = localStorage.getItem('browserUniqueID') || BravoBrowserIdentifier.generateUUID();
            localStorage.setItem('browserUniqueID', uniqueID);
            return uniqueID;
        }
    }
    /**
     * Generate a RFC-4122-like version 4 UUID (pseudo-random).
     *
     * NOTE: This implementation uses Math.random and is not suitable for
     * cryptographic purposes. It is intended only as a stable, random-looking
     * fallback identifier.
     *
     * @returns {string} A randomly generated UUID string in the form:
     *                   xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx
     */
    static generateUUID() {
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
            const r = (Math.random() * 16) | 0;
            const v = c === 'x' ? r : (r & 0x3) | 0x8;
            return v.toString(16);
        });
    }
}

const DefaultKey = 'B66c2abbcd0e7';
const MAGIC_HEADER = 'XOR!';
class BravoCryptography {
    /**
     * Encrypts a string using a simple XOR cipher with a given key.
     *
     * - The text is first prefixed with a `MAGIC_HEADER`.
     * - The combined string is converted to UTF-8 bytes.
     * - Each byte is XORed with the corresponding byte from the key
     *   (repeating the key if it is shorter).
     * - The result is returned as a Base64-encoded string.
     *
     * ⚠️ Note: XOR cipher is **not secure** for production use,
     * it should only be used for lightweight obfuscation.
     *
     * @param pText - The plain text to encrypt.
     * @param pKey - The key used for XOR encryption.
     * @returns A Base64-encoded string of the encrypted data.
     */
    static encryptXor(pText, pKey) {
        const plainBytes = BravoUTF8.getBytes(MAGIC_HEADER + pText);
        const keyBytes = BravoUTF8.getBytes(pKey);
        const result = new Uint8Array(plainBytes.length);
        for (let i = 0; i < plainBytes.length; i++) {
            result[i] = plainBytes[i] ^ keyBytes[i % keyBytes.length];
        }
        return BravoConverterExtensions.toBase64String(result);
    }
    static hashBytes(pBytes) {
        const base64 = BravoConverterExtensions.toBase64String(pBytes);
        const hash = CryptoJS.MD5(CryptoJS.enc.Base64.parse(base64)).toString(CryptoJS.enc.Base64);
        return BravoConverterExtensions.fromBase64String(hash);
    }
    static hashString(pInput, pPrefix) {
        const str = BravoStringExtensions.format('{0}{1}', pPrefix, pInput);
        return CryptoJS.MD5(str).toString(CryptoJS.enc.Base64);
    }
    static #getKey(pKey) {
        const key = CryptoJS.MD5(pKey);
        key.words.push(key.words[0], key.words[1]);
        return key;
    }
    static encryptBytes(pInput, pKey) {
        try {
            const key = this.#getKey(pKey);
            const data = BravoConverterExtensions.toBase64String(pInput);
            const encrypt = CryptoJS.TripleDES.encrypt(CryptoJS.enc.Base64.parse(data), key, {
                mode: CryptoJS.mode.ECB,
                padding: CryptoJS.pad.Pkcs7,
            });
            return encrypt.toString();
        }
        catch {
            return pInput;
        }
    }
    static encryptString(pInput, pKey) {
        try {
            const key = this.#getKey(pKey);
            const encrypt = CryptoJS.TripleDES.encrypt(pInput, key, {
                mode: CryptoJS.mode.ECB,
                padding: CryptoJS.pad.Pkcs7,
            });
            return encrypt.toString();
        }
        catch {
            return pInput;
        }
    }
    static decryptBytes(pInput, pKey) {
        try {
            const key = this.#getKey(pKey);
            const data = BravoConverterExtensions.toBase64String(pInput);
            const decrypted = CryptoJS.TripleDES.decrypt(data, key, {
                mode: CryptoJS.mode.ECB,
                padding: CryptoJS.pad.Pkcs7,
            });
            const result = decrypted.toString(CryptoJS.enc.Base64);
            return BravoStringExtensions.isNullOrEmpty(result) || result == 'BqB'
                ? pInput
                : BravoConverterExtensions.fromBase64String(result);
        }
        catch {
            return pInput;
        }
    }
    static decryptString(pInput, pKey) {
        // if (!String.isBase64(pInput)) return pInput;
        try {
            const key = this.#getKey(pKey);
            const decrypted = CryptoJS.TripleDES.decrypt(pInput, key, {
                mode: CryptoJS.mode.ECB,
                padding: CryptoJS.pad.Pkcs7,
            });
            const result = decrypted.toString(CryptoJS.enc.Utf8);
            return BravoStringExtensions.isNullOrEmpty(result) ? pInput : result;
        }
        catch {
            return pInput;
        }
    }
    static #getKeyWithSHA512(pKey, pLength = 24) {
        if (BravoStringExtensions.isNullOrEmpty(pKey))
            pKey = DefaultKey;
        if (BravoStringExtensions.isNullOrEmpty(pKey))
            throw new Error('Key must have valid value.');
        const hash = CryptoJS.SHA512(pKey);
        const key = this.fromWordArray(hash).slice(0, pLength);
        return this.toWordArray(key);
    }
    static decrypt(pzEncryptedText, pKey) {
        const keyByte = this.#getKeyWithSHA512(pKey);
        if (BravoStringExtensions.isNullOrEmpty(pzEncryptedText))
            throw new Error('The encrypted text must have valid value.');
        const combined = BravoConverterExtensions.fromBase64String(pzEncryptedText);
        const ivBytes = combined.slice(0, 16);
        const byteEncrypt = combined.slice(16, combined.length);
        const decrypted = CryptoJS.AES.decrypt(BravoConverterExtensions.toBase64String(byteEncrypt), keyByte, {
            iv: this.toWordArray(ivBytes),
            mode: CryptoJS.mode.CBC,
            padding: CryptoJS.pad.Pkcs7,
        });
        const data = BravoConverterExtensions.fromBase64String(decrypted.toString(CryptoJS.enc.Base64));
        return BravoUTF8.getString(data);
    }
    static encrypt(pText, pKey) {
        const keyByte = this.#getKeyWithSHA512(pKey);
        if (BravoStringExtensions.isNullOrEmpty(pText))
            throw new Error('The text must have valid value.');
        const buffer = CryptoJS.enc.Utf8.parse(pText);
        const ivBytes = new Uint8Array(16);
        crypto.getRandomValues(ivBytes);
        const encrypted = CryptoJS.AES.encrypt(buffer, keyByte, {
            iv: this.toWordArray(ivBytes),
            mode: CryptoJS.mode.CBC,
            padding: CryptoJS.pad.Pkcs7,
        }).toString();
        const encryptedBytes = BravoConverterExtensions.fromBase64String(encrypted);
        const combined = new Uint8Array(ivBytes.length + encryptedBytes.length);
        combined.set(ivBytes);
        combined.set(encryptedBytes, ivBytes.length);
        return BravoConverterExtensions.toBase64String(combined);
    }
    static toWordArray(pData) {
        if (pData instanceof Uint8Array) {
            const words = [];
            let i = 0;
            const len = pData.length;
            while (i < len) {
                words.push((pData[i++] << 24) | (pData[i++] << 16) | (pData[i++] << 8) | pData[i++]);
            }
            return CryptoJS.lib.WordArray.create(words, words.length * 4);
        }
        return CryptoJS.enc.Base64.parse(pData);
    }
    static fromWordArray(pWordArray) {
        const len = pWordArray.words.length, u8Array = new Uint8Array(len << 2);
        let word, i, offset = 0;
        for (i = 0; i < len; i++) {
            word = pWordArray.words[i];
            u8Array[offset++] = word >> 24;
            u8Array[offset++] = (word >> 16) & 0xff;
            u8Array[offset++] = (word >> 8) & 0xff;
            u8Array[offset++] = word & 0xff;
        }
        return u8Array;
    }
}

/**
 * Generated bundle index. Do not edit.
 */

export { BravoBrowserIdentifier, BravoCryptoExtension, BravoCryptography, BravoRSACrypto, generateShortHashName };
//# sourceMappingURL=bravo-infra-core-utils-crypto.mjs.map
