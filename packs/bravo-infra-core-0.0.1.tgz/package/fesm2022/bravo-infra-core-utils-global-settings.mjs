import { signal } from '@angular/core';

var BravoLangEnum;
(function (BravoLangEnum) {
    BravoLangEnum[BravoLangEnum["Vietnamese"] = 1066] = "Vietnamese";
    BravoLangEnum[BravoLangEnum["English"] = 1033] = "English";
    BravoLangEnum[BravoLangEnum["Japanese"] = 1041] = "Japanese";
    BravoLangEnum[BravoLangEnum["Chinese"] = 2052] = "Chinese";
    BravoLangEnum[BravoLangEnum["Korean"] = 1042] = "Korean";
    BravoLangEnum[BravoLangEnum["Custom"] = 127] = "Custom";
})(BravoLangEnum || (BravoLangEnum = {}));
const VietNameseKey = 'vi';
const EnglishKey = 'en';
const JapaneseKey = 'ja';
const ChineseKey = 'zh';
const KoreanKey = 'ko';
const CustomKey = 'custom';
const BravoLangKeyArray = [VietNameseKey, EnglishKey, JapaneseKey, ChineseKey, KoreanKey, CustomKey];
const LCIDToLangMap = {
    [BravoLangEnum.Vietnamese]: VietNameseKey,
    [BravoLangEnum.English]: EnglishKey,
    [BravoLangEnum.Japanese]: JapaneseKey,
    [BravoLangEnum.Chinese]: ChineseKey,
    [BravoLangEnum.Korean]: KoreanKey,
    [BravoLangEnum.Custom]: CustomKey,
};
const CultureMap = {
    [VietNameseKey]: 'vi-VN',
    [EnglishKey]: 'en-US',
    [JapaneseKey]: 'ja-JP',
    [ChineseKey]: 'zh-CN',
    [KoreanKey]: 'ko-KR',
    [CustomKey]: 'vi-VN',
};

const NUMBER_FORMAT = {
    '.': '.',
    ',': ',',
    '-': '-',
    '+': '+',
    '%': '%',
    percent: {
        pattern: ['-n%', 'n%'],
    },
    currency: {
        decimals: 2,
        symbol: '$',
        pattern: ['($n)', '$n'],
    },
};
const DATE_FORMAT_PATTERNS = {
    d: 'M/d/yyyy',
    D: 'dddd, MMMM dd, yyyy',
    f: 'dddd, MMMM dd, yyyy h:mm tt',
    F: 'dddd, MMMM dd, yyyy h:mm:ss tt',
    t: 'h:mm tt',
    T: 'h:mm:ss tt',
    M: 'MMMM d',
    m: 'MMMM d',
    Y: 'MMMM, yyyy',
    y: 'MMMM, yyyy',
    g: 'M/d/yyyy h:mm tt',
    G: 'M/d/yyyy h:mm:ss tt',
    s: 'yyyy"-"MM"-"dd"T"HH":"mm":"ss',
    o: 'yyyy"-"MM"-"dd"T"HH":"mm":"ss"."fffffffK',
    O: 'yyyy"-"MM"-"dd"T"HH":"mm":"ss"."fffffffK',
    U: 'dddd, MMMM dd, yyyy h:mm:ss tt',
};
const DATE_PARTS_REGION = {
    'en-US': [
        'M/d/yyyy',
        'M/d/yy',
        'MM/dd/yy',
        'MM/dd/yyyy',
        'yy/MM/dd',
        'yy-MM-dd',
        'dd-MMM-yy',
        'dd-MMM-yyyy',
        'dd MMM yyyy',
        'dddd, MMMM d, yyyy',
        'MMMM d, yyyy',
        'dddd, d MMMM, yyyy',
        'd MMMM, yyyy',
        'h:mm tt',
        'hh:mm tt',
        'H:mm',
        'HH:mm',
        'h:mm:ss tt',
        'hh:mm:ss tt',
        'H:mm:ss',
        'HH:mm:ss',
        'MMM dd yyyy hh:mm:ss.fff',
        'yyyy-MM-dd hh:mm:ss.fff',
        'MMM dd yyyy hh:mm tt',
        'MMM dd yyyy hh:mmtt',
        'MMM dd yyyy hh:mm:ss:fff tt',
        'MM/dd/yyyy HH:mm:ss',
        'MM/dd/yyyy HH:mm',
        'MM/dd/yyyy HH:mm tt',
        'dd MMM yyyy hh:mm:ss tt',
        'yyyy/MM/dd HH:mm:ss',
        'MM/yy',
        'MM/yyyy',
        'yyyy/MM',
    ],
    'vi-VN': [
        'dd/MM/yyyy',
        'dd/MM/yyyy HH:mm',
        'dd/MM/yyyy HH:mm:ss',
        'dd/MM/yy',
        'dd/MM/yy HH:mm',
        'dd-MM-yy',
        'dd-MM-yyyy',
        'yyyy-MM-dd',
        'dd MMMM yyyy',
        'dddd, d MMMM, yyyy',
        'dd.MM.yy',
        'dd.MM.yyyy',
        'h:mm tt',
        'hh:mm tt',
        'H:mm',
        'HH:mm',
        'h:mm:ss tt',
        'hh:mm:ss tt',
        'H:mm:ss',
        'HH:mm:ss',
        'dd/MM/yyyy hh:mm:ss tt',
        'dd/MM/yyyy h:mm',
        'dd/MM/yyyy h:mm tt',
        'dd-MM-yy hh:mm:ss tt',
        'dd-MM-yyyy h:mm tt',
        'MM/yy',
        'MM/yyyy',
        'yyyy/MM',
        'dd MMM yyyy hh:mm:ss tt',
        'd/M/yyyy HH:mm',
        'd/M/yyyy HH:mm:ss',
        'd/M/yyyy hh:mm:ss tt',
    ],
    'ja-JP': [
        'yyyy/MM/dd',
        'yy/MM/dd',
        'yy/M/d',
        'yyyy/M/d',
        'yyyy-MM-dd',
        'tt h:mm',
        'tt hh:mm',
        'H:mm',
        'HH:mm',
        'tt h:mm',
        'tt hh:mm:ss',
        'H:mm:ss',
        'HH:mm:ss',
        'yyyy-MM-dd hh:mm:ss',
        'yyyy-MM-dd hh:mm:ss.fff',
        'MM/yy',
        'MM/yyyy',
        'yyyy/MM',
        'dd MMM yyyy hh:mm:ss tt',
    ],
    'ko-KR': [
        'yyyy-MM-dd',
        'yy-MM-dd',
        'yy-M-d',
        'yyyy-M-d',
        'tt h:mm',
        'tt hh:mm',
        'H:mm',
        'HH:mm',
        'tt h:mm',
        'tt hh:mm:ss',
        'H:mm:ss',
        'HH:mm:ss',
        'yyyy-MM-dd hh:mm:ss',
        'yyyy-MM-dd hh:mm:ss.fff',
        'MM/yy',
        'MM/yyyy',
        'yyyy/MM',
        'dd MMM yyyy hh:mm:ss tt',
    ],
    'zh-CN': [
        'yyyy/M/d',
        'yyyy/MM/dd',
        'yyyy-MM-dd',
        'tt h:mm',
        'tt hh:mm',
        'H:mm',
        'HH:mm',
        'tt h:mm',
        'tt hh:mm:ss',
        'H:mm:ss',
        'HH:mm:ss',
        'yyyy-MM-dd hh:mm:ss',
        'yyyy-MM-dd hh:mm:ss.fff',
        'MM/yy',
        'MM/yyyy',
        'yyyy/MM',
        'dd MMM yyyy hh:mm:ss tt',
    ],
};
class BravoAppSettings {
    prefixLibAssets = 'ui';
    static _injector;
    static #settings;
    static get settings() {
        const settings = this._injector?.get(BravoAppSettings, null);
        if (settings)
            return settings;
        this.#settings ??= new BravoAppSettings();
        return this.#settings;
    }
    _browserIdentifier;
    get browserIdentifier() {
        return this._browserIdentifier;
    }
    //*idleMinuteInterval;
    #idleMinuteInterval = -1;
    get idleMinuteInterval() {
        return this.#idleMinuteInterval;
    }
    set idleMinuteInterval(pValue) {
        this.#idleMinuteInterval = pValue;
    }
    //*currentLang
    _currentLang = signal(BravoLangEnum.Vietnamese, ...(ngDevMode ? [{ debugName: "_currentLang" }] : []));
    get currentLang() {
        return this._currentLang();
    }
    set currentLang(pVal) {
        this._currentLang.set(pVal);
    }
    //*currentLangString
    get currentLangString() {
        return BravoLangEnum[this.currentLang];
    }
    //*currentLangKey;
    get currentLangKey() {
        return LCIDToLangMap[this.currentLang];
    }
    get currentLangId() {
        return this.getLangCollection().findIndex(pItem => pItem == this.currentLang);
    }
    #isDevMode = signal(false, ...(ngDevMode ? [{ debugName: "#isDevMode" }] : []));
    get isDevMode() {
        return this.#isDevMode();
    }
    set isDevMode(pVal) {
        this.#isDevMode.set(pVal);
    }
    //*validFileExt
    #validFileExt = signal('', ...(ngDevMode ? [{ debugName: "#validFileExt" }] : []));
    get validFileExt() {
        return this.#validFileExt();
    }
    set validFileExt(pValue) {
        this.#validFileExt.set(pValue);
    }
    //*staticFolderConfig
    #staticFolderConfig = signal('', ...(ngDevMode ? [{ debugName: "#staticFolderConfig" }] : []));
    /**get static folder config of backend*/
    get staticFolderConfig() {
        return this.#staticFolderConfig();
    }
    set staticFolderConfig(pValue) {
        this.#staticFolderConfig.set(pValue);
    }
    //*apiPortalUrl
    #apiPortalUrl = '';
    get apiPortalUrl() {
        return this.#apiPortalUrl;
    }
    set apiPortalUrl(pValue) {
        this.#apiPortalUrl = pValue;
    }
    //*notificationServerUrl
    #notificationServerUrl = '';
    get notificationServerUrl() {
        return this.#notificationServerUrl;
    }
    set notificationServerUrl(pValue) {
        this.#notificationServerUrl = pValue;
    }
    //*fontScale
    _fontScale = signal(1, ...(ngDevMode ? [{ debugName: "_fontScale" }] : []));
    get fontScale() {
        return this._fontScale();
    }
    set fontScale(pValue) {
        this._fontScale.set(pValue);
    }
    //*ssoConfig
    #ssoConfig = '';
    get ssoConfig() {
        return this.#ssoConfig;
    }
    set ssoConfig(pValue) {
        this.#ssoConfig = pValue;
    }
    #prefixNameStore = '';
    get prefixNameStore() {
        return this.#prefixNameStore;
    }
    set prefixNameStore(pVal) {
        this.#prefixNameStore = pVal;
    }
    //#region culture
    #currentCulture = signal('en-US', ...(ngDevMode ? [{ debugName: "#currentCulture" }] : []));
    get currentCulture() {
        return this.#currentCulture();
    }
    getLangCollection() {
        return [
            BravoLangEnum.Vietnamese,
            BravoLangEnum.English,
            BravoLangEnum.Japanese,
            BravoLangEnum.Chinese,
            BravoLangEnum.Korean,
        ];
    }
    getCultureInfo(pLanguage) {
        return CultureMap[pLanguage] || 'en-US';
    }
    fixDateTimeString(pStr, pLangCi) {
        if (pStr === '' || pLangCi == null || pLangCi !== BravoLangEnum.Vietnamese)
            return pStr;
        return pStr.replace('Tháng ', '');
    }
    //#endregion culture
    //*locale
    #locale = signal('en', ...(ngDevMode ? [{ debugName: "#locale" }] : []));
    get locale() {
        return this.#locale();
    }
    set locale(pValue) {
        this.#locale.set(pValue);
    }
    //*dateFormat
    #dateFormat = signal('dd/MM/yyyy', ...(ngDevMode ? [{ debugName: "#dateFormat" }] : []));
    get dateFormat() {
        return this.#dateFormat();
    }
    set dateFormat(pValue) {
        this.#dateFormat.set(pValue);
    }
    //*weekStartOn
    #weekStartOn = signal(0, ...(ngDevMode ? [{ debugName: "#weekStartOn" }] : []));
    get weekStartOn() {
        return this.#weekStartOn();
    }
    set weekStartOn(pValue) {
        this.#weekStartOn.set(pValue);
    }
    //*numericFormat
    #numericFormat = signal('n0', ...(ngDevMode ? [{ debugName: "#numericFormat" }] : []));
    get numericFormat() {
        return this.#numericFormat();
    }
    set numericFormat(pValue) {
        this.#numericFormat.set(pValue);
    }
    datePartsRegions = DATE_PARTS_REGION;
    numberFormatCache = {};
    numberFormat = NUMBER_FORMAT;
    /**Format shortcut pattern */
    dateFormatPatterns = DATE_FORMAT_PATTERNS;
    /**Sử dụng để lấy date format pattern */
    getDateFormatPattern(pKey) {
        return this.dateFormatPatterns[pKey];
    }
    /**Sử dụng để đặt date format pattern */
    setDateFormatPattern(pKey, pValue) {
        return (this.dateFormatPatterns[pKey] = pValue);
    }
    buildKeyStore(pKey) {
        if (!this.prefixNameStore)
            return pKey;
        return `${this.prefixNameStore}_${pKey}`;
    }
    /**Using when get configuration of app */
    static setupConfiguration(pConfigResponse) {
        this.settings.staticFolderConfig = pConfigResponse.staticFolderConfig;
        this.settings.apiPortalUrl = pConfigResponse.apiPortalUrl;
        this.settings.ssoConfig = pConfigResponse.ssoConfig;
        this.settings.notificationServerUrl = pConfigResponse.notificationServerUrl;
    }
}

/**
 * Generated bundle index. Do not edit.
 */

export { BravoAppSettings, BravoLangEnum, BravoLangKeyArray, ChineseKey, CultureMap, CustomKey, EnglishKey, JapaneseKey, KoreanKey, LCIDToLangMap, VietNameseKey };
//# sourceMappingURL=bravo-infra-core-utils-global-settings.mjs.map
