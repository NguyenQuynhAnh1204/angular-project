var DataTypeEnum;
(function (DataTypeEnum) {
    /** Object (anything). */
    DataTypeEnum[DataTypeEnum["Object"] = 0] = "Object";
    /** String. */
    DataTypeEnum[DataTypeEnum["String"] = 1] = "String";
    /** Number. */
    DataTypeEnum[DataTypeEnum["Number"] = 2] = "Number";
    /** Boolean. */
    DataTypeEnum[DataTypeEnum["Boolean"] = 3] = "Boolean";
    /** Date (date and time). */
    DataTypeEnum[DataTypeEnum["Date"] = 4] = "Date";
    /** Array. */
    DataTypeEnum[DataTypeEnum["Array"] = 5] = "Array";
})(DataTypeEnum || (DataTypeEnum = {}));

/**
 * Generated bundle index. Do not edit.
 */

export { DataTypeEnum };
//# sourceMappingURL=bravo-infra-core-definition.mjs.map
