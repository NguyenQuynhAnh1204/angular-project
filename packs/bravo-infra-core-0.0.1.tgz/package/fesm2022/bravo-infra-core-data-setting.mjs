import { ExprPattern, BravoExpression, OperatorEnum, QuoteExprPattern, ExprGroupPattern, BravoExpressionEvaluator } from '@bravo-infra/core/expression';
import { BravoCryptoExtension } from '@bravo-infra/core/utils/crypto';
import { BravoStringExtensions, BravoEnumExtensions, BravoStringBuilder } from '@bravo-infra/core/utils/data-extensions';
import { __decorate, __metadata } from 'tslib';
import { InputSetter } from '@bravo-infra/core/ng-extensions';
import { CommandTypeEnum, TypeCodeEnum } from '@bravo-infra/core/data';
import { RootName, BravoLayoutData, BravoLayoutItem, AttributeNameEnum } from '@bravo-infra/core/serializations';
import { BravoLangEnum } from '@bravo-infra/core/utils/global-settings';

class ParameterSetting {
    _name = BravoStringExtensions.empty;
    get name() {
        return this._name;
    }
    set name(pVal) {
        this._name = pVal;
    }
    _value;
    get value() {
        return this._value;
    }
    set value(pVal) {
        this._value = pVal;
    }
    _layoutKey = BravoStringExtensions.empty;
    get layoutKey() {
        return this._layoutKey;
    }
    set layoutKey(pVal) {
        this._layoutKey = pVal;
    }
    constructor(params) {
        this.name = params?.name || BravoStringExtensions.empty;
        this.layoutKey = params?.layoutKey || BravoStringExtensions.empty;
        this.value = params?.value;
    }
    copyTo(pSetting) {
        pSetting.name = this.name;
        pSetting.value = this.value;
        pSetting.layoutKey = this.layoutKey;
    }
}

class CommandSetting {
    _commandType = CommandTypeEnum.Procedure;
    get commandType() {
        return this._commandType;
    }
    set commandType(pVal) {
        this._commandType = pVal;
    }
    _commandName = BravoStringExtensions.empty;
    get commandName() {
        return this._commandName;
    }
    set commandName(pVal) {
        this._commandName = pVal;
    }
    _expr = BravoStringExtensions.empty;
    get expr() {
        return this._expr;
    }
    set expr(pVal) {
        this._expr = pVal;
    }
    _layoutKey = BravoStringExtensions.empty;
    get layoutKey() {
        return this._layoutKey;
    }
    set layoutKey(pVal) {
        this._layoutKey = pVal;
    }
    _parameterCollection = null;
    get parameterCollection() {
        return this._parameterCollection ?? (this._parameterCollection = new Array());
    }
    _columns = null;
    get columns() {
        return this._columns ?? (this._columns = new Map());
    }
    copyTo(pSetting) {
        const commandCopy = pSetting;
        commandCopy.commandType = this.commandType;
        commandCopy.commandName = this.commandName;
        commandCopy.expr = this.expr;
        commandCopy.layoutKey = this.layoutKey;
        commandCopy.parameterCollection.length = 0;
        if (this._parameterCollection != null)
            for (const param of this.parameterCollection) {
                const paramCopy = new ParameterSetting();
                param.copyTo(paramCopy);
                commandCopy.parameterCollection.push(paramCopy);
            }
        commandCopy.columns.clear();
        if (this._columns != null) {
            for (const [key, value] of this.columns) {
                commandCopy.columns.set(key, value);
            }
        }
    }
}
__decorate([
    InputSetter({ transform: BravoEnumExtensions.enumAttribute, enumType: CommandTypeEnum }),
    __metadata("design:type", Number),
    __metadata("design:paramtypes", [Number])
], CommandSetting.prototype, "commandType", null);

var JoinTypeEnum;
(function (JoinTypeEnum) {
    JoinTypeEnum[JoinTypeEnum["Inner"] = 0] = "Inner";
    JoinTypeEnum[JoinTypeEnum["Left"] = 1] = "Left";
    JoinTypeEnum[JoinTypeEnum["Right"] = 2] = "Right";
    JoinTypeEnum[JoinTypeEnum["Full"] = 3] = "Full";
})(JoinTypeEnum || (JoinTypeEnum = {}));
var SelectTypeEnum;
(function (SelectTypeEnum) {
    SelectTypeEnum[SelectTypeEnum["All"] = 0] = "All";
    SelectTypeEnum[SelectTypeEnum["Distinct"] = 1] = "Distinct";
    SelectTypeEnum[SelectTypeEnum["Except"] = 2] = "Except";
    SelectTypeEnum[SelectTypeEnum["Intersect"] = 3] = "Intersect";
    SelectTypeEnum[SelectTypeEnum["If"] = 4] = "If";
})(SelectTypeEnum || (SelectTypeEnum = {}));
var ForEachJoinEnum;
(function (ForEachJoinEnum) {
    ForEachJoinEnum[ForEachJoinEnum["All"] = 0] = "All";
    ForEachJoinEnum[ForEachJoinEnum["Distinct"] = 1] = "Distinct";
    ForEachJoinEnum[ForEachJoinEnum["Except"] = 2] = "Except";
    ForEachJoinEnum[ForEachJoinEnum["Intersect"] = 3] = "Intersect";
})(ForEachJoinEnum || (ForEachJoinEnum = {}));
var CombineOperatorEnum;
(function (CombineOperatorEnum) {
    CombineOperatorEnum[CombineOperatorEnum["And"] = 0] = "And";
    CombineOperatorEnum[CombineOperatorEnum["Or"] = 1] = "Or";
})(CombineOperatorEnum || (CombineOperatorEnum = {}));

class ExpressionSetting {
    constructor(pzExpression, pzExpr) {
        this.value = pzExpression || BravoStringExtensions.empty;
        this.expr = pzExpr || BravoStringExtensions.empty;
    }
    _expr = BravoStringExtensions.empty;
    get expr() {
        return this._expr;
    }
    set expr(pVal) {
        this._expr = pVal;
    }
    _value = BravoStringExtensions.empty;
    get value() {
        return this._value;
    }
    set value(pVal) {
        this._value = pVal;
    }
    _collection = null;
    get collection() {
        return this._collection ?? (this._collection = new Array());
    }
    _layoutKey = BravoStringExtensions.empty;
    get layoutKey() {
        return this._layoutKey;
    }
    set layoutKey(pVal) {
        this._layoutKey = pVal;
    }
    copyTo(pSetting) {
        pSetting.expr = this.expr;
        pSetting.layoutKey = this.layoutKey;
        pSetting.value = this.value;
        pSetting.collection.length = 0;
        if (this._collection != null)
            for (const item of this.collection) {
                const itemCopy = new ExpressionSetting();
                item.copyTo(itemCopy);
                pSetting.collection.push(itemCopy);
            }
    }
}

class FilterSetting {
    constructor(pzFilterKey, pzExpr, pCombineOperator) {
        this.filterKey = pzFilterKey || BravoStringExtensions.empty;
        this.expr = pzExpr || BravoStringExtensions.empty;
        this.combineOperator = pCombineOperator || CombineOperatorEnum.And;
    }
    _combineOperator = CombineOperatorEnum.And;
    get combineOperator() {
        return this._combineOperator;
    }
    set combineOperator(pVal) {
        this._combineOperator = pVal;
    }
    _expr = BravoStringExtensions.empty;
    get expr() {
        return this._expr;
    }
    set expr(pVal) {
        this._expr = pVal;
    }
    _collection = null;
    get collection() {
        return this._collection ?? (this._collection = new Array());
    }
    _filterKey = BravoStringExtensions.empty;
    get filterKey() {
        return this._filterKey;
    }
    set filterKey(pVal) {
        this._filterKey = pVal;
    }
    _layoutKey = BravoStringExtensions.empty;
    get layoutKey() {
        return this._layoutKey;
    }
    set layoutKey(pVal) {
        this._layoutKey = pVal;
    }
    _operand = BravoStringExtensions.empty;
    get operand() {
        return this._operand;
    }
    set operand(pVal) {
        this._operand = pVal;
    }
    _operator = BravoStringExtensions.empty;
    get operator() {
        return this._operator;
    }
    set operator(pVal) {
        this._operator = pVal;
    }
    _value1 = BravoStringExtensions.empty;
    get value1() {
        return this._value1;
    }
    set value1(pVal) {
        this._value1 = pVal;
    }
    _value2 = BravoStringExtensions.empty;
    get value2() {
        return this._value2;
    }
    set value2(pVal) {
        this._value2 = pVal;
    }
    copyTo(pSetting) {
        pSetting.filterKey = this.filterKey || BravoStringExtensions.empty;
        pSetting.expr = this.expr;
        pSetting.layoutKey = this.layoutKey;
        pSetting.operand = this.operand;
        pSetting.combineOperator = this.combineOperator;
        pSetting.operator = this.operator;
        pSetting.value1 = this.value1;
        pSetting.value2 = this.value2;
        pSetting.collection.length = 0;
        if (this._collection != null)
            for (const item of this.collection) {
                const itemCopy = new FilterSetting();
                item.copyTo(itemCopy);
                pSetting.collection.push(itemCopy);
            }
    }
}

const IdColumn = 'Id';
class TableSetting {
    //#region properties
    _dbName = BravoStringExtensions.empty;
    get dbName() {
        return this._dbName;
    }
    set dbName(pVal) {
        this._dbName = pVal;
    }
    _schema = BravoStringExtensions.empty;
    get schema() {
        return this._schema;
    }
    set schema(pVal) {
        this._schema = pVal;
    }
    _name = BravoStringExtensions.empty;
    get name() {
        return this._name;
    }
    set name(pVal) {
        this._name = pVal;
    }
    _alias = BravoStringExtensions.empty;
    get alias() {
        return this._alias;
    }
    set alias(pVal) {
        this._alias = pVal;
    }
    _dataCode = BravoStringExtensions.empty;
    get dataCode() {
        return this._dataCode;
    }
    set dataCode(pVal) {
        this._dataCode = pVal;
    }
    _source = BravoStringExtensions.empty;
    get source() {
        return this._source;
    }
    set source(pVal) {
        this._source = pVal;
    }
    _selectType = SelectTypeEnum.All;
    get selectType() {
        return this._selectType;
    }
    set selectType(pVal) {
        this._selectType = pVal;
    }
    _ifCondition = BravoStringExtensions.empty;
    get ifCondition() {
        return this._ifCondition;
    }
    set ifCondition(pVal) {
        this._ifCondition = pVal;
    }
    _joinType = JoinTypeEnum.Inner;
    get joinType() {
        return this._joinType;
    }
    set joinType(pVal) {
        this._joinType = pVal;
    }
    _joinCondition = BravoStringExtensions.empty;
    get joinCondition() {
        return this._joinCondition;
    }
    set joinCondition(pVal) {
        this._joinCondition = pVal;
    }
    _joinExpr = BravoStringExtensions.empty;
    get joinExpr() {
        return this._joinExpr;
    }
    set joinExpr(pVal) {
        this._joinExpr = pVal;
    }
    _joinCollection;
    get joinCollection() {
        return this._joinCollection ?? (this._joinCollection = new Array());
    }
    _sourceCollection;
    get sourceCollection() {
        return this._sourceCollection ?? (this._sourceCollection = new Array());
    }
    _commandCollection;
    get commandCollection() {
        return this._commandCollection ?? (this._commandCollection = new Array());
    }
    _beforeCommit;
    get beforeCommit() {
        return this._beforeCommit ?? (this._beforeCommit = new Array());
    }
    _afterCommit;
    get afterCommit() {
        return this._afterCommit ?? (this._afterCommit = new Array());
    }
    _columns = BravoStringExtensions.empty;
    get columns() {
        return this._columns;
    }
    set columns(pVal) {
        this._columns = pVal;
    }
    _sort = BravoStringExtensions.empty;
    get sort() {
        return this._sort;
    }
    set sort(pVal) {
        this._sort = pVal;
    }
    _sortCollection;
    get sortCollection() {
        return this._sortCollection ?? (this._sortCollection = new Array());
    }
    _group = BravoStringExtensions.empty;
    get group() {
        return this._group;
    }
    set group(pVal) {
        this._group = pVal;
    }
    _groupCollection;
    get groupCollection() {
        return this._groupCollection ?? (this._groupCollection = new Array());
    }
    _filterKey = BravoStringExtensions.empty;
    get filterKey() {
        return this._filterKey;
    }
    set filterKey(pVal) {
        this._filterKey = pVal;
    }
    _filterCollection;
    get filterCollection() {
        return this._filterCollection ?? (this._filterCollection = new Array());
    }
    _having = BravoStringExtensions.empty;
    get having() {
        return this._having;
    }
    set having(pVal) {
        this._having = pVal;
    }
    _havingCollection;
    get havingCollection() {
        return this._havingCollection ?? (this._havingCollection = new Array());
    }
    _limit = -1;
    get limit() {
        return this._limit;
    }
    set limit(pVal) {
        this._limit = pVal;
    }
    _forEach = BravoStringExtensions.empty;
    get forEach() {
        return this._forEach;
    }
    set forEach(pVal) {
        this._forEach = pVal;
    }
    _forJoin = ForEachJoinEnum.All;
    get forEachJoin() {
        return this._forJoin;
    }
    set forEachJoin(pVal) {
        this._forJoin = pVal;
    }
    _expr = BravoStringExtensions.empty;
    get expr() {
        return this._expr;
    }
    set expr(pVal) {
        this._expr = pVal;
    }
    _layoutKey = BravoStringExtensions.empty;
    get layoutKey() {
        return this._layoutKey;
    }
    set layoutKey(pVal) {
        this._layoutKey = pVal;
    }
    _parentTable = BravoStringExtensions.empty;
    get parentTable() {
        return this._parentTable;
    }
    set parentTable(pzTable) {
        this._parentTable = pzTable;
    }
    _childKey = BravoStringExtensions.empty;
    get childKey() {
        return this._childKey;
    }
    set childKey(pVal) {
        this._childKey = pVal;
    }
    _parentKey = BravoStringExtensions.empty;
    get parentKey() {
        return this._parentKey;
    }
    set parentKey(pVal) {
        this._parentKey = pVal;
    }
    _primaryKey = IdColumn;
    get primaryKey() {
        return this._primaryKey;
    }
    set primaryKey(pzPrimaryKey) {
        this._primaryKey = pzPrimaryKey;
    }
    _isTemp = false;
    get isTemp() {
        return this._isTemp;
    }
    set isTemp(pbIsTemp) {
        this._isTemp = pbIsTemp;
    }
    _extendedProperties;
    get extendedProperties() {
        return this._extendedProperties ?? (this._extendedProperties = new Map());
    }
    //#endregion properties
    copyTo(pSetting) {
        pSetting.dbName = this.dbName;
        pSetting.schema = this.schema;
        pSetting.name = this.name;
        pSetting.alias = this.alias;
        pSetting.dataCode = this.dataCode;
        pSetting.source = this.source;
        pSetting.selectType = this.selectType;
        pSetting.ifCondition = this.ifCondition;
        pSetting.joinType = this.joinType;
        pSetting.joinCondition = this.joinCondition;
        pSetting.joinExpr = this.joinExpr;
        pSetting.columns = this.columns;
        pSetting.sort = this.sort;
        pSetting.group = this.group;
        pSetting.filterKey = this.filterKey;
        pSetting.having = this.having;
        pSetting.limit = this.limit;
        pSetting.forEach = this.forEach;
        pSetting.forEachJoin = this.forEachJoin;
        pSetting.expr = this.expr;
        pSetting.layoutKey = this.layoutKey;
        pSetting.parentTable = this.parentTable;
        pSetting.childKey = this.childKey;
        pSetting.parentKey = this.parentKey;
        pSetting.primaryKey = this.primaryKey;
        pSetting.isTemp = this.isTemp;
        pSetting.joinCollection.length = 0;
        if (this._joinCollection != null)
            for (const tsJoin of this.joinCollection) {
                const tsJoinCopy = new TableSetting();
                tsJoin.copyTo(tsJoinCopy);
                pSetting.joinCollection.push(tsJoinCopy);
            }
        pSetting.sourceCollection.length = 0;
        if (this._sourceCollection != null)
            for (const tsSource of this.sourceCollection) {
                const tsSourceCopy = new TableSetting();
                tsSource.copyTo(tsSourceCopy);
                pSetting.joinCollection.push(tsSourceCopy);
            }
        pSetting.commandCollection.length = 0;
        if (this._commandCollection != null)
            for (const command of this.commandCollection) {
                const commandCopy = new CommandSetting();
                command.copyTo(commandCopy);
                pSetting.commandCollection.push(commandCopy);
            }
        pSetting.beforeCommit.length = 0;
        if (this._beforeCommit != null)
            for (const command of this.beforeCommit) {
                const commandCopy = new CommandSetting();
                command.copyTo(commandCopy);
                pSetting.beforeCommit.push(commandCopy);
            }
        pSetting.afterCommit.length = 0;
        if (this._afterCommit != null)
            for (const command of this.afterCommit) {
                const commandCopy = new CommandSetting();
                command.copyTo(commandCopy);
                pSetting.afterCommit.push(commandCopy);
            }
        pSetting.sortCollection.length = 0;
        if (this._sortCollection != null)
            for (const sort of this.sortCollection) {
                const sortCopy = new ExpressionSetting();
                sort.copyTo(sortCopy);
                pSetting.sortCollection.push(sortCopy);
            }
        pSetting.groupCollection.length = 0;
        if (this._groupCollection != null)
            for (const group of this.groupCollection) {
                const groupCopy = new ExpressionSetting();
                group.copyTo(groupCopy);
                pSetting.groupCollection.push(groupCopy);
            }
        pSetting.filterCollection.length = 0;
        if (this._filterCollection != null)
            for (const filter of this.filterCollection) {
                const filterCopy = new FilterSetting();
                filter.copyTo(filterCopy);
                pSetting.filterCollection.push(filterCopy);
            }
        pSetting.havingCollection.length = 0;
        if (this._havingCollection != null)
            for (const having of this.havingCollection) {
                const havingCopy = new FilterSetting();
                having.copyTo(havingCopy);
                pSetting.havingCollection.push(havingCopy);
            }
    }
}
__decorate([
    InputSetter({ transform: BravoEnumExtensions.enumAttribute, enumType: SelectTypeEnum }),
    __metadata("design:type", Number),
    __metadata("design:paramtypes", [Number])
], TableSetting.prototype, "selectType", null);
__decorate([
    InputSetter({ transform: BravoEnumExtensions.enumAttribute, enumType: JoinTypeEnum }),
    __metadata("design:type", Number),
    __metadata("design:paramtypes", [Number])
], TableSetting.prototype, "joinType", null);
__decorate([
    InputSetter({ transform: BravoEnumExtensions.enumAttribute, enumType: ForEachJoinEnum }),
    __metadata("design:type", Number),
    __metadata("design:paramtypes", [Number])
], TableSetting.prototype, "forEachJoin", null);

class BravoDbQueryHelper {
    static buildFilter(pArgs, pExpr) {
        let pFilter;
        if (pArgs instanceof TableSetting) {
            pFilter = new FilterSetting(pArgs.filterKey, BravoStringExtensions.empty, CombineOperatorEnum.And);
            pFilter.collection.push(...pArgs.filterCollection);
        }
        else {
            pFilter = pArgs;
        }
        if (pExpr != null && !BravoStringExtensions.isNullOrEmpty(pFilter.expr) && !pExpr.isTrue(pFilter.expr))
            return BravoStringExtensions.empty;
        const sb = new BravoStringBuilder();
        if (!BravoStringExtensions.isNullOrEmpty(pFilter.filterKey) && pFilter.filterKey)
            sb.append(pExpr != null ? pExpr.evaluateText(pFilter.filterKey) : pFilter.filterKey);
        let op = pFilter.combineOperator;
        const sbGroup = new BravoStringBuilder();
        for (const filterSetting of pFilter.collection) {
            const strFt = this.buildFilter(filterSetting, pExpr);
            if (BravoStringExtensions.isNullOrEmpty(strFt) || strFt.length < 1)
                continue;
            if (sbGroup.length > 0)
                sbGroup.appendFormat(' {0} ', op);
            sbGroup.appendFormat('({0})', strFt);
            op = filterSetting.combineOperator;
        }
        if (sbGroup.length > 0) {
            if (sb.length > 0)
                sb.appendFormat(' {0} ', CombineOperatorEnum[pFilter.combineOperator]);
            sb.appendFormat('({0})', sbGroup);
        }
        return sb.toString();
    }
    static buildSort(pArgs, pExpr) {
        let srt;
        if (pArgs instanceof TableSetting) {
            srt = new ExpressionSetting(pArgs.sort, BravoStringExtensions.empty);
            srt.collection.push(...pArgs.sortCollection);
        }
        else {
            srt = pArgs;
        }
        if (pExpr && !BravoStringExtensions.isNullOrEmpty(srt.expr) && !pExpr.isTrue(srt.expr))
            return BravoStringExtensions.empty;
        const sb = new BravoStringBuilder();
        if (!BravoStringExtensions.isNullOrEmpty(srt.value))
            sb.append(pExpr ? pExpr.evaluateText(srt.value) : srt.value);
        const sbGroup = new BravoStringBuilder();
        for (const expr of srt.collection) {
            const strExpr = this.buildSort(expr, pExpr);
            if (BravoStringExtensions.isNullOrEmpty(strExpr) || strExpr.length < 1)
                continue;
            if (sbGroup.length > 0)
                sbGroup.append(', ');
            sbGroup.appendFormat('{0}', strExpr);
        }
        if (sbGroup.length > 0) {
            if (sb.length > 0)
                sb.append(', ');
            sb.appendFormat('{0}', sbGroup.toString());
        }
        return sb.toString();
    }
    static collectLayoutExprs(pTable) {
        let exprs = pTable.extendedProperties.get('TableExpressionCollection');
        if (exprs == null) {
            exprs = new Set();
            pTable.extendedProperties.set('TableExpressionCollection', exprs);
            this.#internalCollectLayoutExprs(pTable, exprs);
        }
        return exprs;
    }
    static #internalCollectLayoutExprs(pTable, pCollection) {
        const collector = (pInput) => {
            if (BravoStringExtensions.isNullOrEmpty(pInput))
                return;
            pInput.replace(ExprPattern, (p, pExpr) => {
                if (!BravoStringExtensions.isNullOrEmpty(pExpr) && pCollection)
                    pCollection.add(pExpr);
                return pExpr;
            });
        };
        const tableCollector = (pTables) => {
            if (pTables.length < 1)
                return;
            for (const table of pTables) {
                this.#internalCollectLayoutExprs(table, pCollection);
            }
        };
        const commandCollector = (pCommands) => {
            if (pCommands.length < 1)
                return;
            for (const command of pCommands) {
                collector(command.commandName);
                if (!BravoStringExtensions.isNullOrEmpty(command.expr) && pCollection)
                    pCollection.add(command.expr);
            }
        };
        const expressionCollector = (pExprs) => {
            if (pExprs.length < 1)
                return;
            for (const expr of pExprs) {
                collector(expr.value);
                if (!BravoStringExtensions.isNullOrEmpty(expr.expr) && pCollection)
                    pCollection.add(expr.expr);
                expressionCollector(expr.collection);
            }
        };
        const filterCollector = (pFilters) => {
            if (pFilters.length < 1)
                return;
            for (const filter of pFilters) {
                if (filter.filterKey)
                    collector(filter.filterKey);
                if (!BravoStringExtensions.isNullOrEmpty(filter.expr) && pCollection)
                    pCollection.add(filter.expr);
                filterCollector(filter.collection);
            }
        };
        collector(pTable.dbName);
        collector(pTable.schema);
        collector(pTable.name);
        collector(pTable.alias);
        collector(pTable.dataCode);
        collector(pTable.source);
        collector(pTable.ifCondition);
        collector(pTable.joinCondition);
        if (!BravoStringExtensions.isNullOrEmpty(pTable.joinExpr) && pCollection)
            pCollection.add(pTable.joinExpr);
        tableCollector(pTable.sourceCollection);
        tableCollector(pTable.joinCollection);
        commandCollector(pTable.commandCollection);
        commandCollector(pTable.beforeCommit);
        commandCollector(pTable.afterCommit);
        collector(pTable.columns);
        collector(pTable.sort);
        expressionCollector(pTable.sortCollection);
        collector(pTable.group);
        expressionCollector(pTable.groupCollection);
        collector(pTable.filterKey);
        filterCollector(pTable.filterCollection);
        collector(pTable.having);
        filterCollector(pTable.havingCollection);
        if (!BravoStringExtensions.isNullOrEmpty(pTable.expr) && pCollection)
            pCollection.add(pTable.expr);
    }
    static containsColumn(pTable, pzColumnName) {
        if (BravoStringExtensions.isNullOrEmpty(pTable.columns))
            return false;
        const columns = this.parseColumns(pTable.columns);
        if (!columns || columns.size < 1)
            return false;
        return (columns.has(pzColumnName) ||
            columns.has('*') ||
            columns.has(BravoStringExtensions.format('{0}.*', pTable.alias)) ||
            columns.has(BravoStringExtensions.format('{0}.*', pTable.name)));
    }
    static getColumnExpr(pSetting, pzColumnName) {
        if (!this.containsColumn(pSetting, pzColumnName))
            return null;
        const colExpr = this.parseColumns(pSetting.columns).get(pzColumnName);
        return colExpr ?? pzColumnName;
    }
    static #cacheTableSetting = new Map();
    static parseColumns(pColumnList) {
        if (BravoStringExtensions.isNullOrEmpty(pColumnList))
            return new Map();
        const cacheKey = BravoCryptoExtension.computeMD5Hash(pColumnList);
        if (this.#cacheTableSetting.has(cacheKey))
            return this.#cacheTableSetting.get(cacheKey);
        const columns = new Map();
        const exprs = BravoExpression.create(BravoStringExtensions.format('{0}({1})', OperatorEnum[OperatorEnum.ColumnName], pColumnList.replace(new RegExp(`${QuoteExprPattern}|${ExprGroupPattern}`, 'g'), (p, pQuoteExpr, pExpr) => {
            if (!BravoStringExtensions.isNullOrEmpty(pQuoteExpr))
                return BravoStringExtensions.format('[##{0}$$]', pQuoteExpr.replace(/'/g, "''"));
            if (!BravoStringExtensions.isNullOrEmpty(pExpr))
                return BravoStringExtensions.format("'##{0}$$'", pExpr.replace(/'/g, "''"));
            return BravoStringExtensions.empty;
        })));
        if (exprs != null && exprs.length > 0 && exprs[0].Expressions != null && exprs[0].Expressions.length > 0) {
            const args = BravoExpressionEvaluator.getArgumentExpressions(exprs[0].Expressions[0]);
            for (const arg of args) {
                let expr = arg
                    .buildString()
                    .replace(/\[##/g, '{=')
                    .replace(/\$\$\]/, '}')
                    .replace(/'##/g, '{=')
                    .replace(/\$\$'/g, '}');
                if (BravoStringExtensions.isNullOrEmpty(expr))
                    continue;
                let name = BravoStringExtensions.empty;
                if (expr.includes(' ')) {
                    const pos = expr.lastIndexOf(' as ', expr.length - 1);
                    if (pos > 0) {
                        name = expr.substring(pos + ' as '.length).trim();
                        expr = expr.substring(0, pos);
                    }
                }
                // * or (tablename|tablealias).*
                else if (/(\*|\w+\.\*)+/g.test(expr)) {
                    name = expr;
                }
                // columnname or (tablename|tablealias).columnname
                else {
                    if (expr.includes('.'))
                        name = expr.split('.')[1].trim();
                    else
                        name = expr;
                }
                if (BravoStringExtensions.isNullOrEmpty(name))
                    continue;
                if (columns.has(name))
                    throw new Error(BravoStringExtensions.format("Column '{0}' already exists.", name));
                columns.set(name, expr);
            }
        }
        this.#cacheTableSetting.set(cacheKey, columns);
        return columns;
    }
    static getColumnName(pColumnName) {
        if (BravoStringExtensions.isNullOrEmpty(pColumnName))
            return BravoStringExtensions.empty;
        const columns = pColumnName.split('.');
        if (columns.length > 0)
            return columns[columns.length - 1];
        return BravoStringExtensions.empty;
    }
    static getColumnExpression(pTable, pzColumnName, pAliasExpressionOnly = false) {
        if (!pTable ||
            BravoStringExtensions.isNullOrEmpty(pzColumnName) ||
            pzColumnName.includes('.') ||
            pzColumnName.includes(' '))
            return pzColumnName;
        if (this.containsColumn(pTable, pzColumnName)) {
            const expr = this.parseColumns(pTable.columns).get(pzColumnName);
            if (expr != null &&
                (!pAliasExpressionOnly ||
                    new RegExp(BravoStringExtensions.format('^\\w+.{0}$', pzColumnName)).test(pzColumnName)))
                return expr;
        }
        return pzColumnName;
    }
    static parseSort(pzSort) {
        const sorts = new Map();
        if (BravoStringExtensions.isNullOrEmpty(pzSort))
            return sorts;
        const matches = pzSort.matchAll(/(?:\([^()]*(?:\([^()]*\)[^()]*)*\)|(?:[^,]))+/g);
        if (matches == null)
            return sorts;
        for (const match of matches) {
            if (!match || BravoStringExtensions.isNullOrEmpty(match.at(0)))
                continue;
            let isOrder = true, expr = BravoStringExtensions.empty;
            if (match && match.length > 0)
                expr = BravoStringExtensions.trimEndChar(BravoStringExtensions.format('0', match.at(0)).trim(), ';')
                    .replace('[', '')
                    .replace(']', '');
            let colName = expr;
            if (colName.includes(' ')) {
                const sort = colName.split(' ').filter(p => p);
                if (sort.length > 2 ||
                    (sort.length > 1 &&
                        !BravoStringExtensions.compareStrings(sort[1].trim(), 'ASC', true) &&
                        !BravoStringExtensions.compareStrings(sort[1].trim(), 'DESC', true))) {
                    isOrder = false;
                }
                else {
                    colName = sort[0].trim();
                    if (sort.length > 1 && BravoStringExtensions.compareStrings(sort[1].trim(), 'DESC', true))
                        isOrder = false;
                }
            }
            if (isOrder !== null && colName.includes('('))
                isOrder = null;
            if (isOrder != null)
                colName = this.getColumnName(colName);
            else
                colName = BravoStringExtensions.guName();
            sorts.set(colName, { sortOrder: isOrder, expr: expr });
        }
        return sorts;
    }
}

const TableSettingKey = 'TableSetting';
class TableSettingExtensions {
    static TableDbNamePartitioned = 'DBNamePartitioned';
    static TableSchema = 'Schema';
    static TableName = 'Name';
    static TableAlias = 'Alias';
    static TableDataCode = 'DataCode';
    static TableSelectType = 'SelectType';
    static TableIfCondition = 'IfCondition';
    static TableLimitRows = 'Limit';
    static TableJoinCollection = 'JoinCollection';
    static TableJoinType = 'JoinType';
    static TableJoinCondition = 'JoinCondition';
    static TableFilterCollection = 'FilterCollection';
    static TableHaving = 'Having';
    static TableHavingCollection = 'HavingCollection';
    static TableGroupBy = 'Group';
    static TableGroupByCollection = 'GroupCollection';
    static TableSort = 'Sort';
    static TableSortCollection = 'SortCollection';
    static TableForEach = 'ForEach';
    static TableForEachJoin = 'ForEachJoin';
    static TableColumns = 'Columns';
    static TableSource = 'Source';
    static TableChildKey = 'ChildKey';
    static TableParentKey = 'ParentKey';
    static TablePrimaryKey = 'PrimaryKey';
    static TableSourceCollection = 'SourceCollection';
    static TableFilterKey = 'FilterKey';
    static TableCollection = 'TableCollection';
    static TableCommandCollection = 'CommandCollection';
    static TableCommandType = 'CommandType';
    static TableCommandName = 'CommandName';
    static TableParameterCollection = 'Parameters';
    static TableChildCollection = 'ChildCollection';
    static TableBeforeCommitEvent = 'BeforeCommit';
    static TableAfterCommitEvent = 'AfterCommit';
    static TableExpressionCollection = 'Expressions';
    static Expression = 'Expr';
    static CombineOperator = 'CombineOperator';
    static DataMember = 'DataMember';
    static ColCollectionProp = 'Cols';
    static RowCollectionProp = 'Rows';
    static ControlCollectionProp = 'Controls';
    static TextProp = 'Text';
    static NameProp = 'Name';
    static StyleProp = 'Style';
    static UserDataProp = 'UserData';
    static TextFormatProp = 'TextFormat';
    static ItemCollectionProp = 'Items';
    static TabPageCollectionProp = 'Pages';
    static #LangCollection = BravoEnumExtensions.getValuesEnum(BravoLangEnum);
    static getTableSetting(pTable) {
        if (!pTable || !pTable.extendedProperties.has(TableSettingKey))
            return new TableSetting();
        return pTable && pTable.extendedProperties.get(TableSettingKey);
    }
    static isValidMobileCollectionControlLayoutData(pLayoutData) {
        return (pLayoutData.contains('ClassName') &&
            pLayoutData.getChildLayoutItem('ClassName')?.str(BravoLangEnum.English) == 'BravoListItem');
    }
    static isValidCollectionControlLayoutData(pLayoutData) {
        return pLayoutData.contains(this.DataMember) && pLayoutData.containsChildLayoutData(this.ColCollectionProp);
    }
    static isValidDataControlLayoutData(pLayoutData) {
        return pLayoutData.contains('Assembly') || pLayoutData.contains('ClassName');
    }
    static isValidLookupLayoutData(pLayoutData) {
        if (!this.isValidDataControlLayoutData(pLayoutData))
            return false;
        const lookupKey = pLayoutData.contains('LookupKey')
            ? pLayoutData.get('LookupKey')?.str(BravoLangEnum.English)
            : null;
        if (!BravoStringExtensions.isNullOrEmpty(lookupKey))
            return true;
        const lookupSource = pLayoutData.contains('zLookupSource')
            ? pLayoutData.get('zLookupSource')?.str(BravoLangEnum.English)
            : null;
        if (!BravoStringExtensions.isNullOrEmpty(lookupSource))
            return true;
        return false;
    }
    static findTable(pTableSettingCollection, pTableNameOrAlias) {
        for (const tableSetting of pTableSettingCollection)
            if (tableSetting &&
                (BravoStringExtensions.compareStrings(tableSetting.alias, pTableNameOrAlias, true) ||
                    BravoStringExtensions.compareStrings(tableSetting.name, pTableNameOrAlias, true)))
                return tableSetting;
        return null;
    }
    static getSourceName(pTableSetting) {
        return !BravoStringExtensions.isNullOrEmpty(pTableSetting.alias) ? pTableSetting.alias : pTableSetting.name;
    }
    static scanDataControls(pLayoutData, pTableSettingCollection, pScanCaption = true, pScanLookup = false, pScanSetting = false, ...pAdditionalLayoutCollection) {
        const tablesDataControls = new Map();
        if (!pScanCaption && !pScanLookup && !pScanSetting)
            return tablesDataControls;
        if (pTableSettingCollection == null || pTableSettingCollection.length < 1)
            return tablesDataControls;
        const scanLayoutCollection = new Array(...pAdditionalLayoutCollection);
        if (pLayoutData != null)
            scanLayoutCollection.splice(0, 0, pLayoutData);
        if (scanLayoutCollection.length < 1)
            return tablesDataControls;
        const out = {};
        for (const layout of scanLayoutCollection)
            this._scanLayoutDataControls({
                pTableDataControls: tablesDataControls,
                pLayoutData: layout,
                pTableSettingCollection,
                pOut: out,
                pScanCaption,
                pScanLookup,
                pScanSetting,
            });
        return tablesDataControls;
    }
    static _scanLayoutDataControls({ pTableDataControls, pLayoutData, pTableSettingCollection, pOut, pScanCaption = true, pScanLookup = false, pScanSetting = false, pIsReporter = false, pDefaultTable, }) {
        if (!pOut)
            pOut = {};
        if (!pLayoutData || pLayoutData.count < 1)
            return;
        for (const [, item] of pLayoutData) {
            if (!item.value || !item.isData)
                continue;
            let ts;
            const ldatControl = item.data();
            let dataMember = ldatControl.contains(this.DataMember)
                ? ldatControl.get(TableSettingExtensions.DataMember)?.str(BravoLangEnum.English)
                : null;
            if (BravoStringExtensions.compareStrings(item.name, 'panelReporter', true)) {
                this._scanLayoutDataControls({
                    pTableDataControls,
                    pLayoutData: ldatControl.getChildLayoutData(this.ControlCollectionProp),
                    pTableSettingCollection,
                    pOut,
                    pScanCaption,
                    pScanLookup,
                    pScanSetting,
                    pIsReporter: true,
                });
                continue;
            }
            if (pIsReporter) {
                if (ldatControl.containsChildLayoutData('Content')) {
                    if (!dataMember)
                        dataMember = 'Table1';
                    ts = this.findTable(pTableSettingCollection, dataMember);
                    if (ts == null) {
                        ts = new TableSetting();
                        ts.name = dataMember;
                        pTableSettingCollection?.push(ts);
                    }
                    this._scanLayoutCollectionControlDataControls({
                        pTableDataControls,
                        pLayoutData: ldatControl.getChildLayoutData('Content'),
                        pTableSetting: ts,
                        pScanCaption,
                        pScanLookup,
                        pScanSetting,
                    });
                }
                continue;
            }
            // Collection control
            if (this.isValidCollectionControlLayoutData(ldatControl)) {
                ts = TableSettingExtensions.findTable(pTableSettingCollection, dataMember);
                if (ts != null) {
                    if (!this.isValidMobileCollectionControlLayoutData(ldatControl)) {
                        TableSettingExtensions._scanLayoutCollectionControlDataControls({
                            pTableDataControls,
                            pLayoutData: ldatControl,
                            pTableSetting: ts,
                            pScanCaption,
                            pScanLookup,
                            pScanSetting,
                        });
                    }
                    else {
                        const dataMemberItem = ldatControl.getChildLayoutItem(this.DataMember);
                        ldatControl.remove(this.DataMember);
                        try {
                            this._scanLayoutDataControls({
                                pTableDataControls,
                                pLayoutData: ldatControl,
                                pTableSettingCollection,
                                pOut,
                                pScanCaption,
                                pScanLookup,
                                pScanSetting,
                                pIsReporter,
                                pDefaultTable: ts,
                            });
                        }
                        finally {
                            if (dataMemberItem)
                                ldatControl.add(dataMemberItem);
                        }
                    }
                }
                if (ldatControl.containsChildLayoutData(this.ItemCollectionProp))
                    this._scanLayoutDataControls({
                        pTableDataControls,
                        pLayoutData: ldatControl.getChildLayoutData(this.ItemCollectionProp),
                        pTableSettingCollection,
                        pOut,
                        pScanCaption,
                        pScanLookup,
                        pScanSetting,
                    });
                continue;
            }
            if (pScanCaption &&
                (ldatControl.contains(TableSettingExtensions.TextProp) ||
                    ldatControl.contains(TableSettingExtensions.TextFormatProp)) &&
                !ldatControl.contains(TableSettingExtensions.ControlCollectionProp) &&
                !ldatControl.contains(TableSettingExtensions.ItemCollectionProp) &&
                !ldatControl.contains(TableSettingExtensions.TabPageCollectionProp))
                pOut.lastLabelItemText = ldatControl.contains(TableSettingExtensions.TextFormatProp)
                    ? ldatControl.get(TableSettingExtensions.TextFormatProp)
                    : ldatControl.get(TableSettingExtensions.TextProp);
            if (!BravoStringExtensions.isNullOrEmpty(dataMember)) {
                const s = ldatControl.get(TableSettingExtensions.DataMember)?.str(BravoLangEnum.English).split('.') ?? [];
                if (s.length > 1) {
                    ts = TableSettingExtensions.findTable(pTableSettingCollection, s[0]);
                    dataMember = s[1];
                }
                else if (pDefaultTable) {
                    ts = pDefaultTable;
                    dataMember = s[0];
                }
                else {
                    ts = pTableSettingCollection.find(pTableSetting => {
                        return (BravoStringExtensions.compareStrings(pTableSetting.name, 'ParametersTable', true) &&
                            BravoStringExtensions.compareStrings(pTableSetting.alias, 'ParametersTable', true));
                    });
                    if (!ts)
                        ts = pTableSettingCollection[0];
                    dataMember = s[0];
                }
                if (pOut.lastLabelItemText != null) {
                    if (ts != null && !BravoStringExtensions.isNullOrEmpty(dataMember))
                        TableSettingExtensions._addDataControl(pTableDataControls, ts, dataMember, {
                            pCaption: pOut.lastLabelItemText,
                        });
                    pOut.lastLabelItemText = undefined;
                }
                if (pScanLookup || pScanSetting) {
                    if (ts == null)
                        continue;
                    const addControl = pScanSetting && TableSettingExtensions.isValidDataControlLayoutData(ldatControl);
                    const addLookup = pScanLookup && TableSettingExtensions.isValidLookupLayoutData(ldatControl);
                    if (addControl || addLookup)
                        this._addDataControl(pTableDataControls, ts, dataMember, {
                            pLookup: addLookup ? ldatControl : undefined,
                            pControl: addControl ? ldatControl : undefined,
                        });
                }
            }
            else {
                this._scanLayoutDataControls({
                    pTableDataControls,
                    pLayoutData: ldatControl,
                    pTableSettingCollection,
                    pOut,
                    pScanCaption,
                    pScanLookup,
                    pScanSetting,
                    pIsReporter: false,
                    pDefaultTable,
                });
            }
        }
    }
    static scanCollectionControlDataControls(pLayoutData, pTableSetting, pScanCaption = true, pScanLookup = false, pScanSetting = false) {
        const tablesDataControls = new Map();
        this._scanLayoutCollectionControlDataControls({
            pTableDataControls: tablesDataControls,
            pLayoutData,
            pTableSetting,
            pScanCaption,
            pScanLookup,
            pScanSetting,
        });
        return tablesDataControls.has(pTableSetting)
            ? tablesDataControls.get(pTableSetting)
            : new Map();
    }
    static _scanLayoutCollectionControlDataControls({ pTableDataControls, pLayoutData, pTableSetting, pScanCaption = true, pScanLookup = false, pScanSetting = false, }) {
        if (!pLayoutData || pLayoutData.count < 1)
            return;
        if (pScanCaption && pLayoutData.contains(this.TextProp))
            this._addDataControl(pTableDataControls, pTableSetting, RootName, {
                pCaption: pLayoutData.get(this.TextProp),
            });
        const ldatColCollection = pLayoutData.getChildLayoutData(this.ColCollectionProp);
        if (!ldatColCollection || ldatColCollection.count < 1)
            return;
        const scanCaption = (pColName, pRowCollectionLayoutData) => {
            if (pRowCollectionLayoutData == null || pRowCollectionLayoutData.count < 1)
                return;
            const mergedCellRegex = new RegExp(BravoStringExtensions.format('(?:\\b)(?<name>{0})(?:\\s*):(?:\\s*)(?<value>[^;]*);', TableSettingExtensions.UserDataProp));
            const getMergedCellItemText = (pColumnCollection, pMergedKey) => {
                for (const [, itemCol] of pColumnCollection) {
                    if (itemCol.value == null || !itemCol.isData)
                        continue;
                    const ldatRows = itemCol.data().getChildLayoutData(TableSettingExtensions.RowCollectionProp);
                    if (ldatRows == null || ldatRows.count < 1)
                        continue;
                    for (const [, itemRow] of ldatRows) {
                        if (itemRow.value == null || !itemRow.isData)
                            continue;
                        const ldatRow = itemRow.data();
                        if (!ldatRow.contains(TableSettingExtensions.TextProp) ||
                            !ldatRow.contains(TableSettingExtensions.StyleProp))
                            continue;
                        const style = ldatRow.get(TableSettingExtensions.StyleProp)?.str(BravoLangEnum.English);
                        if (style) {
                            const merge = mergedCellRegex.exec(style)?.groups;
                            if (merge != null && BravoStringExtensions.compareStrings(merge['value'], pMergedKey))
                                return ldatRow.get(TableSettingExtensions.TextProp);
                        }
                    }
                }
                return undefined;
            };
            const ldatCaption = new BravoLayoutData();
            for (const [, kpRow] of pRowCollectionLayoutData) {
                if (kpRow == null || !kpRow.isData)
                    continue;
                const ldatRow = kpRow.data();
                let itemText;
                if (ldatRow.contains(TableSettingExtensions.TextProp)) {
                    itemText = ldatRow.get(TableSettingExtensions.TextProp);
                }
                else {
                    // Merged cell
                    if (ldatRow.contains(TableSettingExtensions.StyleProp)) {
                        const style = ldatRow.get(TableSettingExtensions.StyleProp)?.str(BravoLangEnum.English);
                        if (style) {
                            const merge = mergedCellRegex.exec(style)?.groups;
                            if (merge != null && !BravoStringExtensions.isNullOrEmpty(merge['value']))
                                itemText = getMergedCellItemText(ldatColCollection, merge['value']);
                        }
                    }
                }
                if (itemText == null)
                    continue;
                for (const lang of TableSettingExtensions.#LangCollection) {
                    const newVal = itemText.str(lang);
                    if (BravoStringExtensions.isNullOrEmpty(newVal))
                        continue;
                    const oldVal = ldatCaption.get(BravoLangEnum[lang])?.str(lang);
                    if (BravoStringExtensions.compareStrings(oldVal, newVal, false))
                        continue;
                    const itemCaption = ldatCaption.get(BravoLangEnum[lang]);
                    if (!itemCaption)
                        continue;
                    if (!BravoStringExtensions.isNullOrEmpty(oldVal))
                        itemCaption.value = oldVal + '/' + newVal;
                    else
                        itemCaption.value = newVal;
                }
            }
            this._addDataControl(pTableDataControls, pTableSetting, pColName, {
                pCaption: new BravoLayoutItem(TableSettingExtensions.TextProp, ldatCaption),
            });
        };
        const scanControl = (pColName, pEditorLayoutData, pIsFileHandle = false) => {
            if (!pEditorLayoutData || pEditorLayoutData.count < 1)
                return;
            // Grid editor control
            if (!pIsFileHandle && pEditorLayoutData.containsChildLayoutData(this.ControlCollectionProp)) {
                if (!pScanLookup)
                    return;
                const ldatControlCollection = pEditorLayoutData.getChildLayoutData(this.ControlCollectionProp);
                if (!ldatControlCollection)
                    return;
                const isControlCondition = !pEditorLayoutData.contains('ClassName') && pEditorLayoutData.contains(this.Expression);
                const conditionExpr = !isControlCondition
                    ? null
                    : pEditorLayoutData.get(this.Expression)?.str(BravoLangEnum.English);
                const ldatCondition = new BravoLayoutData();
                for (const [key, kp] of ldatControlCollection) {
                    if (!kp.value || !kp.isData)
                        continue;
                    const ldat = kp.data();
                    if (!this.isValidLookupLayoutData(ldat))
                        continue;
                    // Condition editor
                    if (isControlCondition) {
                        // Checking: _zConditionExpr == _kp.Key
                        ldatCondition.addLayoutItem(key, ldat);
                    }
                    // Multiline editor
                    else {
                        let subColName = pColName;
                        if (ldat.contains(this.NameProp))
                            subColName =
                                ldat.get(this.NameProp)?.str(BravoLangEnum.English) ?? BravoStringExtensions.empty;
                        this._addDataControl(pTableDataControls, pTableSetting, subColName, {
                            pLookup: ldat,
                        });
                    }
                }
                if (ldatCondition.count > 0) {
                    const ldat = new BravoLayoutData();
                    ldat.addLayoutItem(this.ControlCollectionProp, ldatCondition);
                    ldat.addLayoutItem(this.Expression, conditionExpr);
                    this._addDataControl(pTableDataControls, pTableSetting, pColName, { pLookup: ldat });
                }
                return;
            }
            const addControl = pScanSetting && (pIsFileHandle || this.isValidDataControlLayoutData(pEditorLayoutData));
            const addLookup = pScanLookup && this.isValidLookupLayoutData(pEditorLayoutData);
            if (addControl || addLookup)
                this._addDataControl(pTableDataControls, pTableSetting, pColName, {
                    pLookup: addLookup ? pEditorLayoutData : undefined,
                    pControl: addControl ? pEditorLayoutData : undefined,
                });
        };
        for (const [, kpCol] of ldatColCollection) {
            if (kpCol.value == null || !kpCol.isData)
                continue;
            const ldatCol = kpCol.data();
            const colName = ldatCol.contains(this.NameProp)
                ? ldatCol.get(this.NameProp)?.str(BravoLangEnum.English)
                : kpCol.name;
            if (pScanCaption)
                scanCaption(colName, ldatCol.getChildLayoutData(this.RowCollectionProp));
            if (pScanLookup || pScanSetting) {
                let ldatFileHandle = pScanSetting ? ldatCol.getChildLayoutData('FileHandle') : null;
                if (ldatFileHandle != null) {
                    const ldatNew = new BravoLayoutData();
                    ldatNew.addLayoutItem('FileHandle', ldatFileHandle);
                    ldatFileHandle = ldatNew;
                }
                scanControl(colName, ldatFileHandle ?? ldatCol.getChildLayoutData('Editor'), !!ldatFileHandle);
            }
        }
    }
    static _addDataControl(pTableDataControls, pTableSetting, pName, pData) {
        if ((!pData.pCaption || !pData.pCaption.value) &&
            (!pData.pLookup || pData.pLookup.count < 1) &&
            (!pData.pControl || pData.pControl.count < 1))
            return;
        let controlSettingCollection = pTableSetting ? pTableDataControls.get(pTableSetting) : null;
        if (!controlSettingCollection)
            pTableDataControls.set(pTableSetting, (controlSettingCollection = new Map()));
        const controlSetting = controlSettingCollection.get(pName);
        if (!controlSetting) {
            const settingLayoutItem = new BravoLayoutItem(this.ControlCollectionProp, new BravoLayoutData());
            if (pData.pControl && pData.pControl.count > 0)
                settingLayoutItem.data().addLayoutItem('Control_0', pData.pControl);
            let lookupLayoutItem;
            if (pData.pLookup && pData.pLookup.count > 0)
                lookupLayoutItem = new BravoLayoutItem('Lookup', pData.pLookup);
            controlSettingCollection.set(pName, new ControlLayoutSetting({
                caption: pData.pCaption,
                lookup: lookupLayoutItem,
                setting: settingLayoutItem,
            }));
        }
        else {
            if (controlSetting.caption == null && pData.pCaption != null)
                controlSetting.caption = pData.pCaption;
            if (controlSetting.lookup == null && pData.pLookup != null && pData.pLookup.count > 0)
                controlSetting.lookup = new BravoLayoutItem('Lookup', pData.pLookup);
            if (pData.pControl != null && pData.pControl.count > 0) {
                const ldatSettings = controlSetting.setting?.data();
                ldatSettings.addLayoutItem(BravoStringExtensions.format('Control_{0:G}', ldatSettings.count), pData.pControl);
            }
        }
    }
    static createTableSetting(pTableLayoutItem, pTemplateLayoutData) {
        const ts = new TableSetting();
        const templateKey = pTableLayoutItem?.getAttributeValue(AttributeNameEnum.Template)?.toString();
        const ldatTableTemplate = BravoStringExtensions.isNullOrEmpty(templateKey)
            ? undefined
            : pTemplateLayoutData?.getChildLayoutData(this.TableCollection, templateKey);
        this._readLayoutTableSetting(ts, pTableLayoutItem, ldatTableTemplate);
        return ts;
    }
    static _readLayoutTableSetting(pTable, pTableLayoutItem, pTableTemplateLayoutData, pDefaultTableLayoutData) {
        pTable.layoutKey = pTableLayoutItem.name;
        const ldatTable = pTableLayoutItem?.data();
        if (!ldatTable && !pTableTemplateLayoutData) {
            pTable.name = pTableLayoutItem.name;
            return;
        }
        // DbNamePartitioned
        pTable.dbName = BravoLayoutData.getItemValue(this.TableDbNamePartitioned, ldatTable, pTableTemplateLayoutData, {
            pbIgnoreUnion: true,
            pDefaultLayoutData: pDefaultTableLayoutData,
        });
        // Schema
        pTable.schema = BravoLayoutData.getItemValue(this.TableSchema, ldatTable, pTableTemplateLayoutData, {
            pbIgnoreUnion: true,
            pDefaultLayoutData: pDefaultTableLayoutData,
        });
        // Name
        pTable.name = BravoLayoutData.getItemValue(this.TableName, ldatTable, pTableTemplateLayoutData, {
            pbIgnoreUnion: true,
            pDefaultLayoutData: pDefaultTableLayoutData,
        });
        // Alias
        pTable.alias = BravoLayoutData.getItemValue(this.TableAlias, ldatTable, pTableTemplateLayoutData, {
            pbIgnoreUnion: true,
            pDefaultLayoutData: pDefaultTableLayoutData,
        });
        // DataCode
        pTable.dataCode = BravoLayoutData.getItemValue(this.TableDataCode, ldatTable, pTableTemplateLayoutData, {
            pbIgnoreUnion: true,
            pDefaultLayoutData: pDefaultTableLayoutData,
        });
        // Source
        pTable.source = BravoLayoutData.getItemValue(this.TableSource, ldatTable, pTableTemplateLayoutData, {
            pbIgnoreUnion: true,
            pDefaultLayoutData: pDefaultTableLayoutData,
        });
        // ChildKey
        pTable.childKey = BravoLayoutData.getItemValue(this.TableChildKey, ldatTable, pTableTemplateLayoutData, {
            pbIgnoreUnion: true,
            pDefaultLayoutData: pDefaultTableLayoutData,
        });
        // ParentKey
        pTable.parentKey = BravoLayoutData.getItemValue(this.TableParentKey, ldatTable, pTableTemplateLayoutData, {
            pbIgnoreUnion: true,
            pDefaultLayoutData: pDefaultTableLayoutData,
        });
        // PrimaryKey
        pTable.primaryKey = BravoLayoutData.getItemValue(this.TablePrimaryKey, ldatTable, pTableTemplateLayoutData, {
            pDefaultValue: 'Id',
            pbIgnoreUnion: true,
            pDefaultLayoutData: pDefaultTableLayoutData,
        });
        // Expr
        pTable.expr = BravoLayoutData.getItemValue(this.Expression, ldatTable, pTableTemplateLayoutData, {
            pzUnionSeperator: ' AND ',
            pDefaultLayoutData: pDefaultTableLayoutData,
        });
        // SelectType
        let out = { resultValue: null };
        if (BravoEnumExtensions.isEnumType(SelectTypeEnum, BravoLayoutData.getItemValue(this.TableSelectType, ldatTable, pTableTemplateLayoutData, {
            pbIgnoreUnion: true,
            pDefaultLayoutData: pDefaultTableLayoutData,
        }), out) &&
            out.resultValue != null)
            pTable.selectType = out.resultValue;
        // IfCondition
        pTable.ifCondition = BravoLayoutData.getItemValue(this.TableIfCondition, ldatTable, pTableTemplateLayoutData, {
            pzUnionSeperator: ' AND ',
            pDefaultLayoutData: pDefaultTableLayoutData,
        });
        // Limit
        pTable.limit = BravoLayoutData.getItemValue(this.TableLimitRows, ldatTable, pTableTemplateLayoutData, {
            pDefaultValue: -1,
            pbIgnoreUnion: true,
            pType: TypeCodeEnum.Int32,
            pDefaultLayoutData: pDefaultTableLayoutData,
        });
        // Columns
        pTable.columns = BravoLayoutData.getItemValue(this.TableColumns, ldatTable, pTableTemplateLayoutData, {
            pDefaultLayoutData: pDefaultTableLayoutData,
        });
        // SourceCollection
        const ldatSourceCollection = BravoLayoutData.getItemValue(this.TableSourceCollection, ldatTable, pTableTemplateLayoutData, {
            pType: TypeCodeEnum.Object,
            pDefaultLayoutData: pDefaultTableLayoutData,
        });
        if (ldatSourceCollection && ldatSourceCollection.count > 0) {
            for (const [key, kp] of ldatSourceCollection) {
                const ldatTemplate = pTableTemplateLayoutData?.getChildLayoutData(this.TableSourceCollection, key);
                const tsSource = new TableSetting();
                tsSource.layoutKey = key;
                pTable.sourceCollection.push(tsSource);
                if (kp || ldatTemplate) {
                    const ldatDefault = ldatTemplate != null && pDefaultTableLayoutData != null ? new BravoLayoutData() : undefined;
                    if (ldatDefault != null)
                        pDefaultTableLayoutData
                            ?.openChildLayoutData(this.TableSourceCollection)
                            .addLayoutItem(key, ldatDefault);
                    this._readLayoutTableSetting(tsSource, kp, ldatTemplate, ldatDefault);
                }
                if (BravoStringExtensions.isNullOrEmpty(tsSource.name))
                    tsSource.name = key;
                else if (BravoStringExtensions.isNullOrEmpty(tsSource.alias))
                    tsSource.alias = key;
            }
        }
        // JoinCollection
        const ldatJoinCollection = BravoLayoutData.getItemValue(this.TableJoinCollection, ldatTable, pTableTemplateLayoutData, {
            pType: TypeCodeEnum.Object,
            pDefaultLayoutData: pDefaultTableLayoutData,
        });
        if (ldatJoinCollection && ldatJoinCollection.count > 0) {
            for (const [key, kp] of ldatJoinCollection) {
                const ldat = kp.data();
                const ldatTemplate = pTableTemplateLayoutData?.getChildLayoutData(this.TableJoinCollection, key);
                const ldatDefault = ldatTemplate != null && pDefaultTableLayoutData != null ? new BravoLayoutData() : undefined;
                if (ldatDefault != null)
                    pDefaultTableLayoutData
                        ?.openChildLayoutData(this.TableJoinCollection)
                        .addLayoutItem(key, ldatDefault);
                const tsJoin = new TableSetting();
                tsJoin.layoutKey = key;
                pTable.joinCollection.push(tsJoin);
                const out = { resultValue: null };
                if (BravoEnumExtensions.isEnumType(JoinTypeEnum, BravoLayoutData.getItemValue(this.TableJoinType, ldat, ldatTemplate, {
                    pDefaultValue: JoinTypeEnum[JoinTypeEnum.Left],
                    pDefaultLayoutData: ldatDefault,
                })) &&
                    out.resultValue != null)
                    tsJoin.joinType = out.resultValue;
                tsJoin.joinCondition = BravoLayoutData.getItemValue(this.TableJoinCollection, ldat, ldatTemplate, {
                    pzUnionSeperator: ' AND ',
                    pDefaultLayoutData: ldatDefault,
                });
                tsJoin.joinExpr = BravoLayoutData.getItemValue(this.Expression, ldat, ldatTemplate, {
                    pzUnionSeperator: ' AND ',
                    pDefaultLayoutData: ldatDefault,
                });
                if (kp || ldatTemplate)
                    this._readLayoutTableSetting(tsJoin, kp, ldatTemplate, ldatDefault);
                if (BravoStringExtensions.isNullOrEmpty(tsJoin.name))
                    tsJoin.name = key;
                else if (BravoStringExtensions.isNullOrEmpty(tsJoin.alias))
                    tsJoin.alias = key;
            }
        }
        // CommandCollection
        const ldatCommandCollection = BravoLayoutData.getItemValue(this.TableCommandCollection, ldatTable, pTableTemplateLayoutData, {
            pType: TypeCodeEnum.Object,
            pDefaultLayoutData: pDefaultTableLayoutData,
        });
        if (ldatCommandCollection && ldatCommandCollection.count > 0) {
            this._readLayoutCommands(pTable.commandCollection, ldatCommandCollection);
        }
        // BeforeCommit
        const ldatBeforeCommit = BravoLayoutData.getItemValue(this.TableBeforeCommitEvent, ldatTable, pTableTemplateLayoutData, {
            pType: TypeCodeEnum.Object,
            pDefaultLayoutData: pDefaultTableLayoutData,
        });
        if (ldatBeforeCommit && ldatBeforeCommit.count > 0) {
            this._readLayoutCommands(pTable.beforeCommit, ldatBeforeCommit);
        }
        // AfterCommit
        const ldatAfterCommit = BravoLayoutData.getItemValue(this.TableAfterCommitEvent, ldatTable, pTableTemplateLayoutData, {
            pType: TypeCodeEnum.Object,
            pDefaultLayoutData: pDefaultTableLayoutData,
        });
        if (ldatAfterCommit && ldatAfterCommit.count > 0) {
            this._readLayoutCommands(pTable.afterCommit, ldatAfterCommit);
        }
        // Filter
        pTable.filterKey = BravoLayoutData.getItemValue(this.TableFilterKey, ldatTable, pTableTemplateLayoutData, {
            pzUnionSeperator: ' AND ',
            pDefaultLayoutData: pDefaultTableLayoutData,
        });
        // FilterCollection
        const ldatFilterCollection = BravoLayoutData.getItemValue(this.TableFilterCollection, ldatTable, pTableTemplateLayoutData, {
            pType: TypeCodeEnum.Object,
            pDefaultLayoutData: pDefaultTableLayoutData,
        });
        if (ldatFilterCollection && ldatFilterCollection.count > 0) {
            this._readLayoutFilters(pTable.filterCollection, ldatFilterCollection, pTableTemplateLayoutData?.getChildLayoutData(this.TableFilterCollection));
        }
        // Having
        pTable.having = BravoLayoutData.getItemValue(this.TableHaving, ldatTable, pTableTemplateLayoutData, {
            pzUnionSeperator: ' AND ',
        });
        // HavingCollection
        const ldatHavingCollection = BravoLayoutData.getItemValue(this.TableHavingCollection, ldatTable, pTableTemplateLayoutData, {
            pType: TypeCodeEnum.Object,
            pDefaultLayoutData: pDefaultTableLayoutData,
        });
        if (ldatHavingCollection && ldatHavingCollection.count > 0) {
            this._readLayoutFilters(pTable.havingCollection, ldatHavingCollection, pTableTemplateLayoutData?.getChildLayoutData(this.TableHavingCollection));
        }
        // Sort
        pTable.sort = BravoLayoutData.getItemValue(this.TableSort, ldatTable, pTableTemplateLayoutData, {
            pzUnionSeperator: ' AND ',
        });
        // SortCollection
        const ldatSortCollection = BravoLayoutData.getItemValue(this.TableSortCollection, ldatTable, pTableTemplateLayoutData, {
            pType: TypeCodeEnum.Object,
            pDefaultLayoutData: pDefaultTableLayoutData,
        });
        if (ldatSortCollection && ldatSortCollection.count > 0) {
            const ldatTemplate = pTableTemplateLayoutData?.getChildLayoutData(this.TableSortCollection);
            const ldatDefault = ldatTemplate != null && pDefaultTableLayoutData != null
                ? pDefaultTableLayoutData.openChildLayoutData(this.TableSortCollection)
                : undefined;
            this._readLayoutExpressions({
                pCollection: pTable.sortCollection,
                pLayoutData: ldatSortCollection,
                pTemplateLayoutData: ldatTemplate,
                pDefaultLayoutData: ldatDefault,
            });
        }
        // Group
        pTable.group = BravoLayoutData.getItemValue(this.TableGroupBy, ldatTable, pTableTemplateLayoutData, {
            pDefaultLayoutData: pDefaultTableLayoutData,
        });
        // GroupCollection
        const ldatGroupCollection = BravoLayoutData.getItemValue(this.TableGroupByCollection, ldatTable, pTableTemplateLayoutData, {
            pDefaultLayoutData: pDefaultTableLayoutData,
        });
        if (ldatGroupCollection != null && ldatGroupCollection.count > 0) {
            const ldatTemplate = pTableTemplateLayoutData?.getChildLayoutData(this.TableGroupByCollection);
            const ldatDefault = ldatTemplate != null && pDefaultTableLayoutData != null
                ? pDefaultTableLayoutData.openChildLayoutData(this.TableGroupByCollection)
                : undefined;
            this._readLayoutExpressions({
                pCollection: pTable.groupCollection,
                pLayoutData: ldatGroupCollection,
                pTemplateLayoutData: ldatTemplate,
                pDefaultLayoutData: ldatDefault,
                pzItemLayoutKey: this.TableGroupBy,
                pzItemCollectionLayoutKey: this.TableGroupByCollection,
            });
        }
        // ForEach
        pTable.forEach = BravoLayoutData.getItemValue(this.TableForEach, ldatTable, pTableTemplateLayoutData, {
            pbIgnoreUnion: true,
            pDefaultLayoutData: pDefaultTableLayoutData,
        });
        // ForEachJoin
        out = { resultValue: null };
        if (BravoEnumExtensions.isEnumType(ForEachJoinEnum, BravoLayoutData.getItemValue(this.TableForEachJoin, ldatTable, pTableTemplateLayoutData, {
            pDefaultValue: ForEachJoinEnum[ForEachJoinEnum.All],
            pbIgnoreUnion: true,
            pDefaultLayoutData: pDefaultTableLayoutData,
        })) &&
            out.resultValue != null)
            pTable.forEachJoin = out.resultValue;
        if (BravoStringExtensions.isNullOrEmpty(pTable.name))
            pTable.name = pTable.layoutKey;
        else if (BravoStringExtensions.isNullOrEmpty(pTable.alias))
            pTable.alias = pTable.layoutKey;
    }
    static _readLayoutCommands(pCollection, pLayoutData) {
        const ldatCmds = pLayoutData;
        if (!ldatCmds || ldatCmds.count < 1)
            return;
        for (const [key, kp] of ldatCmds) {
            if (!kp.value || !kp.isData)
                continue;
            const ldat = kp.data();
            const cmd = new CommandSetting();
            cmd.layoutKey = key;
            pCollection.push(cmd);
            if (ldat.contains(this.Expression))
                cmd.expr = ldat.get(this.Expression)?.str(BravoLangEnum.English) ?? BravoStringExtensions.empty;
            if (ldat.contains(this.TableCommandName))
                cmd.commandName =
                    ldat.get(this.TableCommandName)?.str(BravoLangEnum.English) ?? BravoStringExtensions.empty;
            const out = { resultValue: null };
            if (ldat.contains(this.TableCommandType) &&
                BravoEnumExtensions.isEnumType(CommandTypeEnum, ldat.get(this.TableCommandType)?.str(BravoLangEnum.English), out) &&
                out.resultValue != null)
                cmd.commandType = out.resultValue;
            if (ldat.containsChildLayoutData(this.TableParameterCollection)) {
                const l = ldat.getChildLayoutData(this.TableParameterCollection);
                if (l) {
                    for (const [key, kpParam] of l) {
                        if (BravoStringExtensions.isNullOrEmpty(key))
                            continue;
                        if (cmd.parameterCollection.some(p => BravoStringExtensions.compareStrings(p.name, key, true)))
                            throw new Error('Duplicate: ' + key);
                        cmd.parameterCollection.push(new ParameterSetting({
                            name: key,
                            value: kpParam.value,
                            layoutKey: kpParam.name,
                        }));
                    }
                }
            }
        }
    }
    static _readLayoutFilters(pFilterCollection, pLayoutData, pTemplateLayoutData, pzItemLayoutKey = this.TableFilterKey, pzItemCollectionLayoutKey = this.TableFilterCollection) {
        let ldatFilters = pLayoutData;
        if (ldatFilters == null) {
            ldatFilters = pTemplateLayoutData;
            pTemplateLayoutData = undefined;
        }
        if (ldatFilters == null || ldatFilters.count < 1)
            return;
        for (const [key, kp] of ldatFilters) {
            const ldat = kp.data();
            const ldatTemplate = pTemplateLayoutData?.getChildLayoutData(key);
            if (!ldat && !ldatTemplate)
                continue;
            const filter = BravoLayoutData.getItemValue(pzItemLayoutKey, ldat, ldatTemplate, {
                pzUnionSeperator: ' AND ',
            });
            const expr = BravoLayoutData.getItemValue(this.Expression, ldat, ldatTemplate, {
                pzUnionSeperator: ' AND ',
            });
            const combine = { resultValue: CombineOperatorEnum.And };
            BravoEnumExtensions.isEnumType(CombineOperatorEnum, BravoLayoutData.getItemValue(this.CombineOperator, ldat, ldatTemplate, {
                pDefaultValue: CombineOperatorEnum[CombineOperatorEnum.And],
            }), combine);
            const filterSetting = new FilterSetting(filter, expr, combine.resultValue);
            filterSetting.layoutKey = key;
            pFilterCollection.push(filterSetting);
            const ldatGroup = BravoLayoutData.getItemValue(pzItemCollectionLayoutKey, ldat, ldatTemplate);
            if (ldatGroup && ldatGroup.count > 0) {
                const group = new Array();
                this._readLayoutFilters(group, ldatGroup, ldatTemplate?.getChildLayoutData(pzItemCollectionLayoutKey), pzItemLayoutKey, pzItemCollectionLayoutKey);
                if (group && group.length > 0)
                    filterSetting.collection.push(...group);
            }
        }
    }
    static _readLayoutExpressions({ pCollection, pLayoutData, pTemplateLayoutData, pDefaultLayoutData, pzItemLayoutKey = this.TableSort, pzItemCollectionLayoutKey = this.TableSortCollection, }) {
        let ldatExprs = pLayoutData;
        if (ldatExprs == null) {
            ldatExprs = pTemplateLayoutData;
            pTemplateLayoutData = undefined;
            if (pDefaultLayoutData && ldatExprs) {
                const itemCollection = pDefaultLayoutData.get(pzItemCollectionLayoutKey);
                if (itemCollection)
                    itemCollection.value = ldatExprs;
            }
        }
        if (ldatExprs == null || ldatExprs.count < 1)
            return;
        for (const [key, kp] of ldatExprs) {
            const ldat = kp.data();
            const ldatTemplate = pTemplateLayoutData?.getChildLayoutData(key);
            if (!ldat && !ldatTemplate)
                continue;
            const ldatDefault = ldatTemplate && pDefaultLayoutData ? new BravoLayoutData() : null;
            if (ldatDefault)
                pDefaultLayoutData?.openChildLayoutData(pzItemCollectionLayoutKey).addLayoutItem(key, ldatDefault);
            const colExpr = BravoLayoutData.getItemValue(pzItemLayoutKey, ldat, ldatTemplate, {
                pzUnionSeperator: ' AND ',
                pDefaultLayoutData: ldatDefault,
            });
            const expr = BravoLayoutData.getItemValue(this.Expression, ldat, ldatTemplate, {
                pzUnionSeperator: ' AND ',
                pDefaultLayoutData: ldatDefault,
            });
            const exprSetting = new ExpressionSetting(colExpr, expr);
            exprSetting.layoutKey = key;
            pCollection.push(exprSetting);
            const ldatGroup = BravoLayoutData.getItemValue(pzItemCollectionLayoutKey, ldat, ldatTemplate);
            if (ldatGroup && ldatGroup.count > 0) {
                const group = new Array();
                const ldatGroupTemplate = ldatTemplate?.getChildLayoutData(pzItemCollectionLayoutKey);
                const ldatGroupDefault = ldatGroupTemplate != null && pDefaultLayoutData != null ? new BravoLayoutData() : undefined;
                if (ldatGroupDefault != null)
                    ldatDefault?.openChildLayoutData(pzItemCollectionLayoutKey).addLayoutItem(key, ldatGroupDefault);
                this._readLayoutExpressions({
                    pCollection: group,
                    pLayoutData: ldatGroup,
                    pTemplateLayoutData: ldatGroupTemplate,
                    pDefaultLayoutData: ldatGroupDefault,
                    pzItemLayoutKey,
                    pzItemCollectionLayoutKey,
                });
                if (group && group.length > 0)
                    exprSetting.collection.push(...group);
            }
        }
    }
}
class ControlLayoutSetting {
    caption;
    lookup;
    setting;
    constructor(pArgs) {
        this.caption = pArgs.caption;
        this.lookup = pArgs.lookup;
        this.setting = pArgs.setting;
    }
}

/**
 * Generated bundle index. Do not edit.
 */

export { BravoDbQueryHelper, CombineOperatorEnum, CommandSetting, ControlLayoutSetting, ExpressionSetting, FilterSetting, ForEachJoinEnum, JoinTypeEnum, ParameterSetting, SelectTypeEnum, TableSetting, TableSettingExtensions };
//# sourceMappingURL=bravo-infra-core-data-setting.mjs.map
