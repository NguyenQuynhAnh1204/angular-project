import { TypeCodeEnum, BravoDataConvertUtil, SerializeOptionEnum, DataRowStateEnum, DataRowVersionEnum, DataViewRowStateEnum, BravoDataInterfaceNamingConstants, buildSortString, BravoDataTable, BravoDataSet, BravoParameterCollection, BravoDataParameter, ParameterDirectionEnum, DbTypeEnum, BravoDataRelation, BravoDataColumn, BravoUniqueConstraint, BravoDataRow, BravoXmlStringTypeEnum, XmlWriteModeEnum, XmlReadModeEnum } from '@bravo-infra/core/data';
import { BravoCryptography } from '@bravo-infra/core/utils/crypto';
import { tryCast, BravoBooleanExtensions, BravoNumberExtensions, BravoStringExtensions, BravoEnumExtensions, ObservableArray, BravoComparableMap, BravoStringBuilder, BravoStringComparer, BravoArrayExtensions, JsonProperty, JsonObject, JsonSerializer, BravoConverterExtensions, isUndefined, tryParse, BravoObjectExtensions } from '@bravo-infra/core/utils/data-extensions';
import { BravoZipTool } from '@bravo-infra/core/utils/files';
import { BravoAppSettings, BravoLangEnum } from '@bravo-infra/core/utils/global-settings';
import * as sax from 'sax';
import { BravoExpressionEvaluator, OperatorEnum, BravoExpression, ClauseExpression } from '@bravo-infra/core/expression';
import { __decorate, __metadata } from 'tslib';
import { BravoMoment } from '@bravo-infra/core/utils/dates';

var AttributeNameEnum;
(function (AttributeNameEnum) {
    AttributeNameEnum[AttributeNameEnum["LayoutName"] = 0] = "LayoutName";
    AttributeNameEnum[AttributeNameEnum["Expression"] = 1] = "Expression";
    AttributeNameEnum[AttributeNameEnum["Expr"] = 2] = "Expr";
    AttributeNameEnum[AttributeNameEnum["Condition"] = 3] = "Condition";
    AttributeNameEnum[AttributeNameEnum["Resource"] = 4] = "Resource";
    AttributeNameEnum[AttributeNameEnum["Encrypt"] = 5] = "Encrypt";
    AttributeNameEnum[AttributeNameEnum["Template"] = 6] = "Template";
    //Reference,
    //Ref,
    AttributeNameEnum[AttributeNameEnum["Merge"] = 7] = "Merge";
    //Union
    //Parameters
})(AttributeNameEnum || (AttributeNameEnum = {}));

var MergeActionEnum;
(function (MergeActionEnum) {
    MergeActionEnum[MergeActionEnum["Default"] = 0] = "Default";
    MergeActionEnum[MergeActionEnum["Override"] = 1] = "Override";
    MergeActionEnum[MergeActionEnum["Union"] = 2] = "Union";
})(MergeActionEnum || (MergeActionEnum = {}));

const BravoExpressionInterfaceNamingConstants = {
    IBravoLayoutData: 'IBravoLayoutData',
};

const ExpressionAttribute = 'Expression';
const AbbvExpressionAttribute = 'Expr';
const EncryptAttribute = 'Encrypt';
const LAYOUT_K = '?o!O:q\u0011?';
class BravoLayoutItem {
    static LayoutNameAttribute = 'LayoutName';
    name;
    value;
    description;
    attributes;
    type;
    parent;
    set parentItem(pVal) {
        this.parent = pVal;
    }
    get parentItem() {
        return this.parent;
    }
    get bHasAttributes() {
        return !!this.attributes && Object.keys(this.attributes).length > 0;
    }
    constructor(pName, pValue, pDescription, pAttributes) {
        this.name = pName;
        this.value = pValue;
        this.description = pDescription;
        this.attributes = pAttributes || {};
    }
    get isData() {
        return tryCast(this.value, 'IBravoLayoutData') !== null;
    }
    isEncrypt() {
        return (this.bHasAttributes &&
            this.attributes[EncryptAttribute] &&
            BravoBooleanExtensions.asBoolean(this.attributes[EncryptAttribute]));
    }
    isExpression() {
        return (this.bHasAttributes &&
            ((this.attributes['expr'] && BravoBooleanExtensions.asBoolean(this.attributes['expr'])) ||
                (this.attributes[ExpressionAttribute] &&
                    BravoBooleanExtensions.asBoolean(this.attributes[ExpressionAttribute])) ||
                (this.attributes[AbbvExpressionAttribute] &&
                    BravoBooleanExtensions.asBoolean(this.attributes[AbbvExpressionAttribute]))));
    }
    data() {
        return tryCast(this.value, 'IBravoLayoutData');
    }
    bool() {
        return this.value == 'true' || this.value == 'True';
    }
    number() {
        return BravoNumberExtensions.asNumber(this.value);
    }
    str(pLangKey) {
        if (pLangKey == null)
            pLangKey = BravoAppSettings.settings.currentLang;
        if (!BravoStringExtensions.isString(pLangKey))
            pLangKey = BravoLangEnum[pLangKey];
        if (this.value != null) {
            const layoutData = this.value;
            if (layoutData && tryCast(this.value, BravoExpressionInterfaceNamingConstants.IBravoLayoutData) != null) {
                if (layoutData.contains(pLangKey)) {
                    if (layoutData.get(pLangKey)?.attributes[AttributeNameEnum[AttributeNameEnum.Resource].toLowerCase()] != null) {
                        const expr = new BravoExpressionEvaluator();
                        return BravoStringExtensions.format('{0}', expr.evaluate(`${OperatorEnum[OperatorEnum.ResourceText]}(` +
                            `'${layoutData.get(pLangKey)?.attributes[AttributeNameEnum[AttributeNameEnum.Resource].toLowerCase()]}','${pLangKey}')`));
                    }
                }
                return layoutData.contains(pLangKey) && layoutData.get(pLangKey)
                    ? layoutData.get(pLangKey)?.value
                    : BravoStringExtensions.empty;
            }
        }
        if (this.attributes[AttributeNameEnum[AttributeNameEnum.Resource].toLowerCase()] != null) {
            const expr = new BravoExpressionEvaluator();
            return BravoStringExtensions.format('{0}', expr.evaluate(`${OperatorEnum[OperatorEnum.ResourceText]}(` +
                `'${this.attributes[AttributeNameEnum[AttributeNameEnum.Resource].toLowerCase()]}','${pLangKey}')`));
        }
        const val = BravoStringExtensions.format('{0}', this.value);
        if (this.isEncrypt()) {
            const plainText = BravoCryptography.decryptString(val, LAYOUT_K);
            if (!BravoStringExtensions.compareStrings(plainText, val))
                return plainText;
        }
        return val;
    }
    valueAs(pLanguage = BravoLangEnum.English, pType = TypeCodeEnum.Object) {
        if (this.value == null)
            return;
        if (pType == TypeCodeEnum.Object) {
            if (this.isData)
                return this.data();
            return;
        }
        if (pType == TypeCodeEnum.String)
            return this.str(pLanguage);
        return BravoDataConvertUtil.convertValue(this.value, pType);
    }
    getAttributeValue(pAttribute) {
        if (!this.bHasAttributes)
            return null;
        return (this.attributes[AttributeNameEnum[pAttribute]] ??
            this.attributes[AttributeNameEnum[pAttribute]?.toLowerCase()] ??
            null);
    }
    getMergeAction() {
        const merge = this.getAttributeValue(AttributeNameEnum.Merge)?.toString();
        if (BravoStringExtensions.isNullOrEmpty(merge))
            return MergeActionEnum.Default;
        const out = { resultValue: MergeActionEnum.Default };
        if (BravoEnumExtensions.isEnumType(MergeActionEnum, merge, out))
            return out.resultValue;
        return MergeActionEnum.Default;
    }
    getHierarchy(pOutArgs, pExcludeRoot = false, pIgnoreCurrentLocation = false) {
        if (pOutArgs == null)
            pOutArgs = { pLayoutNameAttribute: null };
        else
            pOutArgs.pLayoutNameAttribute = null;
        const keys = new ObservableArray();
        let it = pIgnoreCurrentLocation ? this.parentItem : this;
        while (it) {
            if (it.attributes && it.attributes[BravoLayoutItem.LayoutNameAttribute])
                pOutArgs.pLayoutNameAttribute = it.attributes[BravoLayoutItem.LayoutNameAttribute];
            if (pExcludeRoot &&
                it.parentItem == null &&
                BravoStringExtensions.compareStrings(it?.name, 'root'))
                break;
            keys.splice(0, 0, it.name);
            it = it.parentItem;
        }
        return keys;
    }
}

function copyOptions(pOptions) {
    let key;
    const copy = {};
    for (key in pOptions) {
        if (Object.prototype.hasOwnProperty.call(pOptions, key)) {
            copy[key] = pOptions[key];
        }
    }
    return copy;
}
function ensureFlagExists(pItem, pOptions, pDefalut = false) {
    if (!(pItem in pOptions) || typeof pOptions[pItem] !== 'boolean') {
        pOptions[pItem] = pDefalut;
    }
}
function ensureSpacesExists(pOptions) {
    if (!('spaces' in pOptions) || (typeof pOptions.spaces !== 'number' && typeof pOptions.spaces !== 'string')) {
        pOptions.spaces = 0;
    }
}
function ensureKeyExists(pKey, pOptions) {
    if (!(pKey + 'Key' in pOptions) || typeof pOptions[pKey + 'Key'] !== 'string') {
        pOptions[pKey + 'Key'] = pOptions.compact ? '_' + pKey : pKey;
    }
}
function checkFnExists(pKey, pOptions) {
    return pKey + 'Fn' in pOptions;
}

let currentElement;
let options;
const RootName = 'root';
const ChartValue = 'Value';
const ReportChart = 'Chart';
const TagName = 'tagname';
const BravoLayoutDataInterfaceName = 'IBravoLayoutData';
class BravoLayoutData extends BravoComparableMap {
    get count() {
        return this.size;
    }
    get isEmpty() {
        return this.count < 1;
    }
    get(pKey) {
        if (!this.contains(pKey))
            this.set(pKey, new BravoLayoutItem(pKey, null));
        return super.get(pKey);
    }
    getKeys() {
        return Array.from(this.keys());
    }
    getValues() {
        return Array.from(this.values());
    }
    static createNew(pXml, pUserOptions) {
        if (!BravoStringExtensions.isString(pXml)) {
            const zipFile = BravoZipTool.open(pXml);
            try {
                if (!zipFile)
                    return;
                const layout = zipFile.readEntry('Xml');
                if (!BravoStringExtensions.isString(layout))
                    return;
                return this.createNewString(layout, pUserOptions);
            }
            finally {
                if (zipFile) {
                    zipFile.dispose();
                }
            }
        }
        return this.createNewString(pXml, pUserOptions);
    }
    static createNewString(pXml, pOptions) {
        if (!pXml)
            return null;
        pOptions = validateOptions(pOptions);
        const parser = sax.parser(true, {});
        const result = {};
        currentElement = result;
        parser.onopentag = onStartElement;
        parser.ontext = onText;
        // parser.oncomment = onComment;
        parser.onclosetag = onEndElement;
        parser.onerror = onError;
        parser.oncdata = onCdata;
        parser.ondoctype = onDoctype;
        parser.onprocessinginstruction = onInstruction;
        parser.write(pXml).close();
        if (result[pOptions.elementsKey]) {
            delete result[pOptions.elementsKey];
        }
        let l = result[pOptions.valueKey];
        if (l instanceof BravoLayoutData) {
            if (l.contains(RootName)) {
                l = l.getChildLayoutData(RootName);
                return l;
            }
            else if (l.count == 1) {
                return Array.from(l.values())[0].data();
            }
        }
        return new BravoLayoutData();
    }
    static getItemValue(pKey, pLayoutData, pTemplateLayoutData, pOption) {
        const pDefaultValue = pOption?.pDefaultValue, pbIgnoreUnion = pOption?.pbIgnoreUnion ?? false, pzUnionSeperator = pOption?.pzUnionSeperator ?? ', ', pLang = pOption?.pLang ?? BravoLangEnum.English, pType = pOption?.pType ?? TypeCodeEnum.String, pDefaultLayoutData = pOption?.pDefaultLayoutData;
        if (BravoStringExtensions.isNullOrEmpty(pKey))
            return pDefaultValue;
        let templateItem = pTemplateLayoutData?.getChildLayoutItem(pKey);
        let item = pLayoutData?.getChildLayoutItem(pKey);
        if (item == null) {
            item = templateItem;
            templateItem = undefined;
            if (pDefaultLayoutData && item) {
                pDefaultLayoutData.addLayoutItem(pKey, item.value);
            }
        }
        const hasTemplateValue = templateItem != null;
        const hasValue = item != null;
        if (!hasTemplateValue && !hasValue)
            return pDefaultValue;
        const merge = !hasTemplateValue || pbIgnoreUnion ? MergeActionEnum.Override : item?.getMergeAction();
        const isLayoutData = pType == TypeCodeEnum.Object && (templateItem?.isData || item?.isData);
        if (pDefaultLayoutData != null && hasTemplateValue && merge == MergeActionEnum.Union && !isLayoutData)
            pDefaultLayoutData.addLayoutItem(pKey, templateItem?.value);
        const defaultValue = hasTemplateValue ? templateItem?.valueAs(pLang, pType) : pDefaultValue;
        const value = item?.valueAs(pLang, pType);
        if (merge == MergeActionEnum.Override || merge == MergeActionEnum.Default) {
            if (isLayoutData && pTemplateLayoutData && pTemplateLayoutData.contains(pKey))
                pTemplateLayoutData.remove(pKey);
            return hasValue ? value : defaultValue;
        }
        if (isLayoutData) {
            let layoutDataMerge = tryCast(defaultValue, BravoLayoutData);
            let layoutDataUnion = tryCast(value, BravoLayoutData)?.clone();
            if (layoutDataUnion == null) {
                layoutDataUnion = layoutDataMerge;
                layoutDataMerge = null;
                if (pDefaultLayoutData != null && layoutDataUnion)
                    pDefaultLayoutData.addLayoutItem(pKey, layoutDataUnion);
                if (pTemplateLayoutData != null)
                    pTemplateLayoutData.remove(pKey);
            }
            if (layoutDataMerge && layoutDataUnion.count > 0) {
                const keys = layoutDataMerge.getKeys();
                for (let i = 0; i < keys.length; i++) {
                    if (layoutDataUnion.contains(keys[i]))
                        continue;
                    const layoutData = layoutDataMerge.getChildLayoutItem(keys[i]);
                    layoutDataUnion.add(layoutData);
                    if (pDefaultLayoutData && layoutData)
                        pDefaultLayoutData.openChildLayoutData(pKey).addLayoutItem(keys[i], layoutData.value);
                    if (pTemplateLayoutData) {
                        const removeKeys = new Array(pKey);
                        removeKeys.push(keys[i]);
                        if (pTemplateLayoutData.contains(...removeKeys))
                            pTemplateLayoutData.remove(...removeKeys);
                    }
                }
            }
            return layoutDataUnion;
        }
        const sbValue = new BravoStringBuilder();
        if (hasTemplateValue && defaultValue != null && defaultValue != pDefaultValue)
            sbValue.appendFormat('{0}', defaultValue);
        if (hasValue && value != null && value != pDefaultValue) {
            if (sbValue.length > 0 && !BravoStringExtensions.isNullOrEmpty(pzUnionSeperator))
                sbValue.append(pzUnionSeperator);
            sbValue.appendFormat('{0}', value);
        }
        return sbValue.toString();
    }
    static isValidKeyName(pzKeyName) {
        if (BravoStringExtensions.isNullOrEmpty(pzKeyName))
            return false;
        const arr = pzKeyName.split(' ');
        for (let i = 1; i < arr.length; i++) {
            if (!arr[i].match(new RegExp(/^\w+="[^"]*"$/g)))
                return false;
        }
        try {
            console.warn('********not sure');
            return true;
            // return string.Compare(XmlConvert.VerifyName(_s[0]), _s[0], false) == 0;
        }
        catch {
            return false;
        }
    }
    constructor() {
        super(BravoStringComparer.ordinalIgnoreCase);
    }
    contains(...pKeys) {
        if (pKeys.length < 2) {
            return super.has(pKeys[0]);
        }
        let layoutData = this;
        for (let i = 0; i < pKeys.length - 1; i++) {
            layoutData = layoutData.getChildLayoutData(pKeys[i]);
            if (!layoutData)
                return false;
        }
        return layoutData && layoutData.contains(pKeys[pKeys.length - 1]);
    }
    containsValue(pItem) {
        return this.contains(pItem.name);
    }
    containsChildLayoutData(...pKeys) {
        if (pKeys.length < 2) {
            const item = this.contains(pKeys[0]) ? this.get(pKeys[0]) : null;
            return item ? item.isData : false;
        }
        let layoutData = this;
        for (let i = 0; i < pKeys.length; i++) {
            layoutData = layoutData.getChildLayoutData(pKeys[i]);
            if (!layoutData)
                break;
        }
        return layoutData != null;
    }
    getChildLayoutData(...pKeys) {
        if (pKeys.length < 2)
            return this.containsChildLayoutData(pKeys[0]) ? this.get(pKeys[0])?.data() : undefined;
        let layoutData = this;
        for (let i = 0; i < pKeys.length; i++) {
            layoutData = layoutData.getChildLayoutData(pKeys[i]);
            if (!layoutData)
                break;
        }
        return layoutData;
    }
    getChildLayoutItem(...pKeys) {
        if (pKeys.length < 2) {
            return this.contains(pKeys[0]) ? this.get(pKeys[0]) : undefined;
        }
        let layoutData = this;
        for (let n = 0; n < pKeys.length - 1; n++) {
            layoutData = layoutData.getChildLayoutData(pKeys[n]);
            if (!layoutData)
                return;
        }
        return layoutData && layoutData.contains(pKeys[pKeys.length - 1])
            ? layoutData.get(pKeys[pKeys.length - 1])
            : undefined;
    }
    add(pItem) {
        if (this.contains(pItem.name)) {
            const item = this.get(pItem.name);
            item.value = pItem.value;
            item.description = pItem.description;
            if (pItem.bHasAttributes) {
                item.attributes = {};
                item.attributes = { ...pItem.attributes };
            }
            else if (item.bHasAttributes) {
                item.attributes = null;
            }
        }
        else {
            this.set(pItem.name, pItem);
        }
    }
    addLayoutItem(pKey, pValue, pDescription) {
        let name = pKey;
        const pos = name.indexOf(' ');
        if (pos > 0)
            name = name.substring(0, pos);
        if (!this.contains(name)) {
            this.set(name, new BravoLayoutItem(name, pValue, pDescription));
        }
        else {
            const item = this.get(name);
            item.value = pValue;
            item.description = pDescription;
        }
    }
    openChildLayoutData(...pKeys) {
        if (pKeys.length < 2) {
            if (this.contains(pKeys[0]) && this.get(pKeys[0])?.isData)
                return this.get(pKeys[0])?.data();
            if (!this.contains(pKeys[0]))
                this.set(pKeys[0], new BravoLayoutItem(pKeys[0], new BravoLayoutData()));
            else {
                const item = this.get(pKeys[0]);
                if (item)
                    item.value = new BravoLayoutData();
            }
            return this.get(pKeys[0])?.data();
        }
        let layout = this;
        for (let i = 0; i < pKeys.length; i++) {
            layout = layout.openChildLayoutData(pKeys[i]);
            if (!layout)
                break;
        }
        return layout;
    }
    serialize(pType = 'base64') {
        const zipTool = BravoZipTool.create();
        try {
            zipTool.addEntry('Xml', this.toString());
            return zipTool.save(pType);
        }
        finally {
            zipTool.dispose();
        }
    }
    remove(...pKeys) {
        if (pKeys.length < 2) {
            if (this.contains(pKeys[0]))
                this.delete(pKeys[0]);
            return;
        }
        let layoutData = this;
        for (let n = 0; n < pKeys.length - 1; n++) {
            layoutData = layoutData.getChildLayoutData(pKeys[n]);
            if (!layoutData)
                break;
        }
        if (layoutData && layoutData.contains(pKeys[pKeys.length - 1]))
            layoutData.remove(pKeys[pKeys.length - 1]);
    }
    clone(pIncludeHierarchy = false, pParentItem) {
        const layoutData = new BravoLayoutData();
        for (const [key, kp] of this) {
            const strKey = kp.value == null ? key : kp.name;
            layoutData.addLayoutItem(strKey, null);
            const item = layoutData.get(strKey);
            if (!item)
                continue;
            if (pIncludeHierarchy && pParentItem)
                item.parentItem = pParentItem;
            if (kp.value == null)
                continue;
            item.description = kp.description;
            item.value = kp.isData ? kp.data().clone(pIncludeHierarchy, item) : kp.value;
            if (kp.bHasAttributes) {
                for (const attrName in kp.attributes)
                    (layoutData.get(kp.name)?.attributes)[attrName] = kp.attributes[attrName];
            }
        }
        return layoutData;
    }
    toString(pRootName) {
        const document = new Document(); //document.implementation.createHTMLDocument('New Document');
        const rootName = pRootName ?? RootName;
        const parentNode = document.createElement(rootName);
        this._addChildNode(parentNode, this);
        return parentNode.outerHTML;
    }
    _addChildNode(pParentNode, pSubCollection) {
        for (const [, item] of pSubCollection) {
            if (!item)
                continue;
            if (item.description)
                pParentNode.appendChild(pParentNode.ownerDocument.createComment(item.description));
            const node = pParentNode.ownerDocument.createElement(item.name);
            if (item.bHasAttributes) {
                for (const attrName in item.attributes) {
                    const attr = node.ownerDocument.createAttribute(attrName);
                    attr.value = item.attributes[attrName];
                    node.attributes.setNamedItem(attr);
                }
            }
            if (item.isData && item.data()) {
                this._addChildNode(pParentNode.appendChild(node), item.data());
            }
            else {
                pParentNode.appendChild(node);
                if (item.value != null) {
                    let val = BravoStringExtensions.format('{0}', item.value);
                    if (BravoStringExtensions.compareStrings(item.name, ChartValue) &&
                        pParentNode &&
                        BravoStringExtensions.compareStrings(pParentNode.nodeName, ReportChart)) {
                        node.innerHTML = val;
                    }
                    else {
                        if (item.isEncrypt()) {
                            const plainText = BravoCryptography.decryptString(val, LAYOUT_K);
                            if (BravoStringExtensions.compareStrings(plainText, val))
                                val = BravoCryptography.encryptString(val, LAYOUT_K);
                        }
                        const text = node.ownerDocument.createTextNode(val);
                        node.appendChild(text);
                    }
                }
            }
        }
    }
    implementsInterface(pInterfaceName) {
        return pInterfaceName === BravoLayoutDataInterfaceName;
    }
}
function validateOptions(pUserOptions) {
    options = copyOptions(pUserOptions);
    ensureFlagExists('addParent', options, true);
    ensureFlagExists('ignoreDeclaration', options);
    ensureFlagExists('ignoreInstruction', options);
    ensureFlagExists('ignoreAttributes', options);
    ensureFlagExists('ignoreText', options);
    ensureFlagExists('ignoreComment', options);
    ensureFlagExists('ignoreCdata', options);
    ensureFlagExists('ignoreDoctype', options);
    ensureFlagExists('compact', options);
    ensureFlagExists('alwaysArray', options);
    ensureFlagExists('alwaysChildren', options);
    ensureFlagExists('trim', options);
    ensureFlagExists('nativeType', options);
    ensureFlagExists('sanitize', options);
    ensureFlagExists('instructionHasAttributes', options);
    ensureFlagExists('captureSpacesBetweenElements', options);
    ensureKeyExists('declaration', options);
    ensureKeyExists('instruction', options);
    ensureKeyExists('attributes', options);
    ensureKeyExists('text', options);
    ensureKeyExists('comment', options);
    ensureKeyExists('cdata', options);
    ensureKeyExists('doctype', options);
    ensureKeyExists('type', options);
    ensureKeyExists('name', options);
    ensureKeyExists('elements', options);
    ensureKeyExists('value', options);
    ensureKeyExists('parent', options);
    checkFnExists('doctype', options);
    checkFnExists('instruction', options);
    checkFnExists('cdata', options);
    checkFnExists('comment', options);
    checkFnExists('text', options);
    checkFnExists('instructionName', options);
    checkFnExists('elementName', options);
    checkFnExists('attributeName', options);
    checkFnExists('attributeValue', options);
    checkFnExists('attributes', options);
    return options;
}
function nativeType(pValue) {
    const nValue = Number(pValue);
    if (!isNaN(nValue)) {
        return nValue;
    }
    const bValue = pValue.toLowerCase();
    if (bValue === 'true') {
        return true;
    }
    else if (bValue === 'false') {
        return false;
    }
    return pValue;
}
function addField(pType, pValue) {
    let key;
    if (options.compact) {
        if (!currentElement[options[pType + 'Key']] && options.alwaysArray) {
            currentElement[options[pType + 'Key']] = [];
        }
        if (currentElement[options[pType + 'Key']] &&
            !BravoArrayExtensions.isArray(currentElement[options[pType + 'Key']])) {
            currentElement[options[pType + 'Key']] = [currentElement[options[pType + 'Key']]];
        }
        if (pType + 'Fn' in options && typeof pValue === 'string') {
            pValue = options[pType + 'Fn'](pValue, currentElement);
        }
        if (pType === 'instruction' && ('instructionFn' in options || 'instructionNameFn' in options)) {
            for (key in pValue) {
                if (Object.prototype.hasOwnProperty.call(pValue, key)) {
                    if ('instructionFn' in options) {
                        pValue[key] = options.instructionFn(pValue[key], key, currentElement);
                    }
                    else {
                        const temp = pValue[key];
                        delete pValue[key];
                        pValue[options.instructionNameFn(key, temp, currentElement)] = temp;
                    }
                }
            }
        }
        if (BravoArrayExtensions.isArray(currentElement[options[pType + 'Key']])) {
            currentElement[options[pType + 'Key']].push(pValue);
        }
        else {
            currentElement[options[pType + 'Key']] = pValue;
        }
    }
    else {
        if (!currentElement[options.elementsKey]) {
            currentElement[options.elementsKey] = [];
        }
        const element = {};
        element[options.typeKey] = pType;
        if (pType === 'instruction') {
            for (key in pValue) {
                if (Object.prototype.hasOwnProperty.call(pValue, key)) {
                    break;
                }
            }
            if (key == null || pValue[key] == null)
                return;
            element[options.nameKey] =
                'instructionNameFn' in options ? options.instructionNameFn(key, pValue, currentElement) : key;
            if (options.instructionHasAttributes) {
                element[options.attributesKey] = pValue[key][options.attributesKey];
                if ('instructionFn' in options) {
                    element[options.attributesKey] = options.instructionFn(element[options.attributesKey], key, currentElement);
                }
            }
            else {
                if ('instructionFn' in options) {
                    pValue[key] = options.instructionFn(pValue[key], key, currentElement);
                }
                element[options.instructionKey] = pValue[key];
            }
        }
        else {
            if (pType + 'Fn' in options) {
                pValue = options[pType + 'Fn'](pValue, currentElement);
            }
            element[options[pType + 'Key']] = pValue;
        }
        if (options.addParent) {
            element[options.parentKey] = currentElement;
        }
        currentElement[options.elementsKey].push(element);
    }
}
function manipulateAttributes(pAttributes) {
    if ('attributesFn' in options && pAttributes) {
        pAttributes = options.attributesFn(pAttributes, currentElement);
    }
    if ((options.trim || 'attributeValueFn' in options || 'attributeNameFn' in options) && pAttributes) {
        let key;
        for (key in pAttributes) {
            if (Object.prototype.hasOwnProperty.call(pAttributes, key)) {
                if (options.trim)
                    pAttributes[key] = pAttributes[key].trim();
                if ('attributeValueFn' in options)
                    pAttributes[key] = options.attributeValueFn(pAttributes[key], key, currentElement);
                if ('attributeNameFn' in options) {
                    const temp = pAttributes[key];
                    delete pAttributes[key];
                    pAttributes[options.attributeNameFn(key, pAttributes[key], currentElement)] = temp;
                }
            }
        }
    }
    return pAttributes;
}
function onInstruction(pInstruction) {
    let attributes = {};
    if (pInstruction.body && (pInstruction.name.toLowerCase() === 'xml' || options.instructionHasAttributes)) {
        const attrsRegExp = /([\w:-]+)\s*=\s*(?:"([^"]*)"|'([^']*)'|(\w+))\s*/g;
        let match;
        while ((match = attrsRegExp.exec(pInstruction.body)) !== null) {
            attributes[match[1]] = match[2] || match[3] || match[4];
        }
        attributes = manipulateAttributes(attributes);
    }
    if (pInstruction.name.toLowerCase() === 'xml') {
        if (options.ignoreDeclaration) {
            return;
        }
        currentElement[options.declarationKey] = {};
        if (Object.keys(attributes).length) {
            currentElement[options.declarationKey][options.attributesKey] = attributes;
        }
        if (options.addParent) {
            currentElement[options.declarationKey][options.parentKey] = currentElement;
        }
    }
    else {
        if (options.ignoreInstruction) {
            return;
        }
        if (options.trim) {
            pInstruction.body = pInstruction.body.trim();
        }
        const value = {};
        if (options.instructionHasAttributes && Object.keys(attributes).length) {
            value[pInstruction.name] = {};
            value[pInstruction.name][options.attributesKey] = attributes;
        }
        else {
            value[pInstruction.name] = pInstruction.body;
        }
        addField('instruction', value);
    }
}
function onStartElement(pTag) {
    let element, name, attributes;
    if (typeof pTag === 'object') {
        name = pTag.name;
        const attr = pTag.attributes;
        if (attr && attr[TagName]) {
            name = attr[TagName];
            delete attr[TagName];
        }
        attributes = attr;
    }
    if (!name)
        throw new Error(`Element name ${name} is null`);
    attributes = manipulateAttributes(attributes);
    if (!currentElement[options.elementsKey]) {
        currentElement[options.elementsKey] = [];
        currentElement[options.valueKey] = new BravoLayoutData();
    }
    if (options.compact) {
        element = {};
        if (!options.ignoreAttributes && attributes && Object.keys(attributes).length) {
            element[options.attributesKey] = {};
            let key;
            for (key in attributes) {
                if (Object.prototype.hasOwnProperty.call(attributes, key)) {
                    element[options.attributesKey][key] = attributes[key];
                }
            }
        }
        if (!(name in currentElement) && options.alwaysArray)
            currentElement[name] = [];
        if (currentElement[name] && !BravoArrayExtensions.isArray(currentElement[name]))
            currentElement[name] = [currentElement[name]];
        if (BravoArrayExtensions.isArray(currentElement[name]))
            currentElement[name].push(element);
        else
            currentElement[name] = element;
    }
    else {
        element = new BravoLayoutItem();
        element[options.typeKey] = 'element';
        element[options.nameKey] = name;
        if (!options.ignoreAttributes && attributes && Object.keys(attributes).length)
            element[options.attributesKey] = attributes;
        if (options.alwaysChildren) {
            element[options.elementsKey] = [];
            element[options.valueKey] = new BravoLayoutData();
        }
        if (currentElement[options.elementsKey])
            currentElement[options.elementsKey].push(element);
        if (currentElement[options.valueKey])
            currentElement[options.valueKey].set(name, element);
    }
    // if (options.addParent) {
    if (!BravoStringExtensions.compareStrings(name, RootName))
        element[options.parentKey] = currentElement;
    // }
    currentElement = element;
}
function onText(pText) {
    if (options.ignoreText || (pText && pText.trim() == '--')) {
        return;
    }
    if (!pText.trim() && !options.captureSpacesBetweenElements) {
        return;
    }
    if (options.trim) {
        pText = pText.trim();
    }
    if (options.nativeType) {
        pText = nativeType(pText);
    }
    if (options.sanitize) {
        pText = pText.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }
    currentElement[options.typeKey] = 'text';
    currentElement[options.elementsKey] = pText;
    currentElement[options.valueKey] = pText;
    //addField('text', text);
}
function onEndElement() {
    const parentElement = currentElement[options.parentKey];
    if (!options.addParent) {
        delete currentElement[options.parentKey];
    }
    if (currentElement[options.elementsKey]) {
        delete currentElement[options.elementsKey];
    }
    currentElement = parentElement;
}
function onCdata(pCdata) {
    if (options.ignoreCdata) {
        return;
    }
    if (options.trim) {
        pCdata = pCdata.trim();
    }
}
function onDoctype(pDoctype) {
    if (options.ignoreDoctype) {
        return;
    }
    pDoctype = pDoctype.replace(/^ /, '');
    if (options.trim) {
        pDoctype = pDoctype.trim();
    }
    addField('doctype', pDoctype);
}
function onError(pError) {
    pError.note = pError; //console.error(error);
}

class BravoLayoutItemUtil {
    static evalText(pLayoutItem, pExpressionEval, pLangKey, pDataItem) {
        if (!pLangKey)
            pLangKey = BravoAppSettings.settings.currentLangString;
        if (!pExpressionEval || !pLayoutItem || (!pLayoutItem.value && !pLayoutItem.bHasAttributes))
            return BravoStringExtensions.empty;
        if (pLayoutItem.isExpression()) {
            const text = pExpressionEval.evaluateText(pLayoutItem.str(pLangKey), pDataItem);
            return text;
        }
        else
            return pLayoutItem.str(pLangKey);
    }
}

const JsonConstants = {
    ReturnValuePropName: 'returnValue',
    OutputValuePropName: 'outputValue',
    CaseSensitivePropName: 'caseSensitive',
    PrefixPropName: 'prefix',
    DataSetNamePropName: 'dataSetName',
    TablesPropName: 'tables',
    RelationsPropName: 'relations',
    TableNamePropName: 'tableName',
    ColumnsPropName: 'columns',
    RowsPropName: 'rows',
    SortPropName: 'sort',
    ExtendedPropertiesPropName: 'extendedProperties',
    UniqueKeysPropName: 'uniqueKeys',
    ColumnNamePropName: 'columnName',
    CaptionPropName: 'caption',
    DefaultValuePropName: 'defaultValue',
    IsKeyPropName: 'isKey',
    AllowDBNullPropName: 'allowDBNull',
    AutoIncrementPropName: 'autoIncrement',
    AutoIncrementSeedPropName: 'autoIncrementSeed',
    AutoIncrementStepPropName: 'autoIncrementStep',
    DataTypePropName: 'dataType',
    DateTimeModePropName: 'dateTimeMode',
    MaxLengthPropName: 'maxLength',
    ReadOnlyPropName: 'readOnly',
    UniquePropName: 'unique',
    RowStatePropName: 'rowState',
    RowCurrentItemsPropName: 'currentItems',
    RowOriginalItemsPropName: 'originalItems',
    RelationNamePropName: 'relationName',
    ParentTablePropName: 'parentTable',
    ParentColumnsPropName: 'parentColumns',
    ChildTablePropName: 'childTable',
    ChildColumnsPropName: 'childColumns',
    CommandTimeoutPropName: 'commandTimeout',
    CommandTypePropName: 'commandType',
    UpdatedRowSourcePropName: 'updatedRowSource',
    CommandTextPropName: 'commandText',
    ParametersPropName: 'parameters',
    TransactionLevelPropName: 'transactionLevel',
    DbTypePropName: 'dbType',
    DirectionPropName: 'direction',
    IsNullablePropName: 'isNullable',
    SizePropName: 'size',
    SourceColumnPropName: 'sourceColumn',
    SourceVersionPropName: 'sourceVersion',
    ParameterNamePropName: 'prn',
    ParameterValuePropName: 'val',
    ScalePropName: 'scale',
    PrecisionPropName: 'precision',
};
const propNames = new Map([
    [JsonConstants.ReturnValuePropName, 'rtv'],
    [JsonConstants.OutputValuePropName, 'opv'],
    [JsonConstants.CaseSensitivePropName, 'cst'],
    [JsonConstants.PrefixPropName, 'prf'],
    [JsonConstants.DataSetNamePropName, 'dsn'],
    [JsonConstants.TablesPropName, 'tbl'],
    [JsonConstants.RelationsPropName, 'rlt'],
    [JsonConstants.TableNamePropName, 'tbl'],
    [JsonConstants.ColumnsPropName, 'cln'],
    [JsonConstants.CaptionPropName, 'cap'],
    [JsonConstants.RowsPropName, 'rws'],
    [JsonConstants.SortPropName, 'sot'],
    [JsonConstants.ExtendedPropertiesPropName, 'etp'],
    [JsonConstants.UniqueKeysPropName, 'unk'],
    [JsonConstants.ColumnNamePropName, 'cln'],
    [JsonConstants.DefaultValuePropName, 'dfv'],
    [JsonConstants.AllowDBNullPropName, 'adn'],
    [JsonConstants.AutoIncrementPropName, 'aic'],
    [JsonConstants.AutoIncrementStepPropName, 'aist'],
    [JsonConstants.AutoIncrementSeedPropName, 'ais'],
    [JsonConstants.IsKeyPropName, 'iky'],
    [JsonConstants.DataTypePropName, 'dtp'],
    [JsonConstants.MaxLengthPropName, 'mlg'],
    [JsonConstants.ReadOnlyPropName, 'rol'],
    [JsonConstants.UniquePropName, 'unq'],
    [JsonConstants.RowStatePropName, 'rst'],
    [JsonConstants.RowCurrentItemsPropName, 'crt'],
    [JsonConstants.RowOriginalItemsPropName, 'ori'],
    [JsonConstants.RelationNamePropName, 'rln'],
    [JsonConstants.ParentTablePropName, 'ptn'],
    [JsonConstants.ParentColumnsPropName, 'pcn'],
    [JsonConstants.ChildTablePropName, 'ctn'],
    [JsonConstants.ChildColumnsPropName, 'ccn'],
    [JsonConstants.DbTypePropName, 'dbt'],
    [JsonConstants.DirectionPropName, 'drt'],
    [JsonConstants.IsNullablePropName, 'ina'],
    [JsonConstants.SizePropName, 'sze'],
    [JsonConstants.SourceColumnPropName, 'scl'],
    [JsonConstants.SourceVersionPropName, 'svs'],
    [JsonConstants.ParameterNamePropName, 'prn'],
    [JsonConstants.ParameterValuePropName, 'val'],
    [JsonConstants.ScalePropName, 'sca'],
    [JsonConstants.PrecisionPropName, 'prc'],
    [JsonConstants.CommandTimeoutPropName, 'cto'],
    [JsonConstants.CommandTypePropName, 'ctp'],
    [JsonConstants.UpdatedRowSourcePropName, 'urs'],
    [JsonConstants.CommandTextPropName, 'cmt'],
    [JsonConstants.ParametersPropName, 'prm'],
    [JsonConstants.TransactionLevelPropName, 'ttl'],
]);

let BravoResponseData = class BravoResponseData {
    returnValue;
    outputValue;
    constructor(pArgs) {
        this.returnValue = pArgs.returnValue;
        this.outputValue = pArgs.outputValue;
    }
};
__decorate([
    JsonProperty(JsonConstants.ReturnValuePropName),
    __metadata("design:type", Object)
], BravoResponseData.prototype, "returnValue", void 0);
__decorate([
    JsonProperty(JsonConstants.OutputValuePropName),
    __metadata("design:type", Array)
], BravoResponseData.prototype, "outputValue", void 0);
BravoResponseData = __decorate([
    JsonObject(),
    __metadata("design:paramtypes", [Object])
], BravoResponseData);

let ExpressionParam = class ExpressionParam {
    operator = OperatorEnum.Unknown;
    value;
    expressions;
    clauses;
    clauseToken;
    attributes;
};
__decorate([
    JsonProperty('opr'),
    __metadata("design:type", Number)
], ExpressionParam.prototype, "operator", void 0);
__decorate([
    JsonProperty('val'),
    __metadata("design:type", Object)
], ExpressionParam.prototype, "value", void 0);
__decorate([
    JsonProperty({ name: 'eps', dataStructure: 'array', type: ExpressionParam }),
    __metadata("design:type", Array)
], ExpressionParam.prototype, "expressions", void 0);
__decorate([
    JsonProperty({ name: 'cls', dataStructure: 'array', type: ExpressionParam }),
    __metadata("design:type", Array)
], ExpressionParam.prototype, "clauses", void 0);
__decorate([
    JsonProperty('clt'),
    __metadata("design:type", Number)
], ExpressionParam.prototype, "clauseToken", void 0);
__decorate([
    JsonProperty({ name: 'atb', dataStructure: 'array', type: ExpressionParam }),
    __metadata("design:type", Array)
], ExpressionParam.prototype, "attributes", void 0);
ExpressionParam = __decorate([
    JsonObject()
], ExpressionParam);

class ExpressionSerializer {
    static fromExpression(pExprs) {
        if (!pExprs)
            return;
        if (typeof pExprs == 'string')
            return this.fromExpression(BravoExpression.create(pExprs));
        const exprsContract = new Array(pExprs.length);
        for (let i = 0; i < pExprs.length; i++) {
            exprsContract[i] = new ExpressionParam();
            this._fromExpression(exprsContract[i], pExprs[i]);
        }
        return exprsContract;
    }
    static _fromExpression(pExprContract, pExpr) {
        if (pExpr == null)
            return;
        pExprContract.operator = pExpr.Operator;
        pExprContract.value = pExpr.Value;
        if (pExpr.Expressions != null)
            pExprContract.expressions = this.fromExpression(pExpr.Expressions);
        if (pExpr.attributes?.length > 0)
            pExprContract.attributes = this.fromExpression(pExpr.attributes);
        if (pExpr instanceof ClauseExpression) {
            pExprContract.clauseToken = ClauseExpression.clauseTokens.indexOf(pExpr.zName);
            pExprContract.clauses = this.fromExpression(pExpr.getOptions());
        }
    }
}

var _a;
class BravoJsonSerializer extends JsonSerializer {
    //#region static
    static #containsConstraint(pTable, pConstraint) {
        if (!pTable.constraints)
            return false;
        for (const key of pTable.constraints) {
            if (Object.is(key, pConstraint))
                return true;
        }
        return false;
    }
    static #writeRowValues(pRow, pVersion, pColumns) {
        const items = [];
        for (let i = 0; i < pRow.table.columns.length; i++) {
            const col = pRow.table.columns[i];
            if (pColumns && !pColumns.includes(col.columnName))
                continue;
            const val = pRow.getValue(i, pVersion);
            items.push(_a.#convertValueNew(val, col.dataType));
        }
        return items;
    }
    static #convertValueNew(pValue, pDataType) {
        if (pValue === undefined)
            return undefined;
        if (pValue instanceof Uint8Array)
            return BravoConverterExtensions.toBase64String(pValue);
        if (pDataType == TypeCodeEnum.Object && pValue instanceof BravoLayoutData)
            return pValue.serialize('uint8array');
        return pValue;
    }
    static #setValue(pJsonObject, pPropertyName, pValue) {
        pPropertyName = propNames.get(pPropertyName) || pPropertyName;
        pJsonObject[pPropertyName] = pValue;
    }
    static #serializeUniqueConstraint(pObject, pUnique, pOptions) {
        const arr = pUnique.columns.map(col => {
            return col.ordinal;
        });
        this.#setValue(pObject, JsonConstants.ColumnNamePropName, arr);
    }
    static #serializeColumn(pObject, pColumn, pOptions) {
        const isIgnoreSchema = (pOptions & SerializeOptionEnum.Schema) != SerializeOptionEnum.Schema;
        _a.#setValue(pObject, JsonConstants.ColumnNamePropName, pColumn.columnName);
        if (!isUndefined(pColumn.defaultValue))
            _a.#setValue(pObject, JsonConstants.DefaultValuePropName, pColumn.defaultValue);
        if (!BravoStringExtensions.isNullOrEmpty(pColumn.expression))
            return;
        if (isIgnoreSchema)
            return;
        const isKey = pColumn.table.primaryKey && pColumn.table.primaryKey.includes(pColumn);
        if (isKey)
            _a.#setValue(pObject, JsonConstants.IsKeyPropName, true);
        if (!pColumn.allowDBNull)
            _a.#setValue(pObject, JsonConstants.AllowDBNullPropName, pColumn.allowDBNull);
        if (pColumn.autoIncrement)
            _a.#setValue(pObject, JsonConstants.AutoIncrementPropName, pColumn.autoIncrement);
        if (pColumn.autoIncrementSeed != null && pColumn.autoIncrementSeed != 0)
            _a.#setValue(pObject, JsonConstants.AutoIncrementSeedPropName, pColumn.autoIncrementSeed);
        if (pColumn.autoIncrementStep != null && pColumn.autoIncrementStep != 1)
            _a.#setValue(pObject, JsonConstants.AutoIncrementStepPropName, pColumn.autoIncrementStep);
        if (pColumn.dataType != TypeCodeEnum.String)
            _a.#setValue(pObject, JsonConstants.DataTypePropName, pColumn.dataType);
        if (pColumn.dataType == TypeCodeEnum.String && pColumn.maxLength != -1)
            _a.#setValue(pObject, JsonConstants.MaxLengthPropName, pColumn.maxLength);
        if (pColumn.readOnly)
            _a.#setValue(pObject, JsonConstants.ReadOnlyPropName, pColumn.readOnly);
        if (pColumn.unique)
            _a.#setValue(pObject, JsonConstants.UniquePropName, pColumn.unique);
    }
    static #serializeRowCollection(pObject, pRows, pColumns) {
        const rows = [];
        for (const row of pRows) {
            rows.push(this.#serializeRow(row, pColumns));
        }
        if (rows.length > 0)
            _a.#setValue(pObject, JsonConstants.RowsPropName, rows);
    }
    static #serializeRow(pRow, pColumns) {
        const jObject = {};
        if (pRow.rowState != DataRowStateEnum.Unchanged)
            _a.#setValue(jObject, JsonConstants.RowStatePropName, pRow.rowState);
        if (pRow.rowState != DataRowStateEnum.Detached) {
            switch (pRow.rowState) {
                case DataRowStateEnum.Unchanged:
                case DataRowStateEnum.Added: {
                    if (pRow.currentItems) {
                        _a.#setValue(jObject, JsonConstants.RowCurrentItemsPropName, _a.#writeRowValues(pRow, DataRowVersionEnum.Current, pColumns));
                    }
                    break;
                }
                case DataRowStateEnum.Deleted: {
                    if (pRow.hasVersion(DataRowVersionEnum.Original)) {
                        _a.#setValue(jObject, JsonConstants.RowOriginalItemsPropName, _a.#writeRowValues(pRow, DataRowVersionEnum.Original, pColumns));
                    }
                    break;
                }
                case DataRowStateEnum.Modified: {
                    if (pRow.currentItems) {
                        _a.#setValue(jObject, JsonConstants.RowCurrentItemsPropName, _a.#writeRowValues(pRow, DataRowVersionEnum.Current, pColumns));
                    }
                    _a.#setValue(jObject, JsonConstants.RowOriginalItemsPropName, _a.#writeRowValues(pRow, DataRowVersionEnum.Original, pColumns));
                    break;
                }
            }
        }
        return jObject;
    }
    //#endregion static
    //#region custom serialize
    serialize(pValue, pOptions = SerializeOptionEnum.Default, pExpr, pRowState = DataViewRowStateEnum.CurrentRows) {
        const dataTable = tryCast(pValue, BravoDataInterfaceNamingConstants.IDataTable);
        if (dataTable)
            return this.#serializeTable(dataTable, pOptions, pExpr, pRowState);
        const dataSet = dataTable == null && tryCast(pValue, BravoDataInterfaceNamingConstants.IDataSet);
        if (dataSet)
            return this.#serializeDataSet(dataSet, pOptions, pExpr);
        return super.serialize(pValue);
    }
    #serializeDataSet(pDataSet, pOptions, pExpr, pRowState = DataViewRowStateEnum.CurrentRows) {
        const jObject = {};
        if (!BravoStringExtensions.isNullOrEmpty(pDataSet.name) &&
            BravoStringExtensions.compareStrings(pDataSet.name, 'NewDataSet', true))
            _a.#setValue(jObject, JsonConstants.DataSetNamePropName, pDataSet.name);
        if (!BravoStringExtensions.isNullOrEmpty(pDataSet.prefix))
            _a.#setValue(jObject, JsonConstants.PrefixPropName, pDataSet.prefix);
        if (pDataSet.caseSensitive)
            _a.#setValue(jObject, JsonConstants.CaseSensitivePropName, pDataSet.caseSensitive);
        if (pDataSet.tables.length > 0) {
            const tables = [];
            for (let i = 0; i < pDataSet.tables.length; i++) {
                tables.push(this.#serializeTable(pDataSet.tables[i], pOptions, pExpr, pRowState));
            }
            _a.#setValue(jObject, JsonConstants.TablesPropName, tables);
        }
        if ((pOptions & SerializeOptionEnum.Relations) == SerializeOptionEnum.Relations &&
            pDataSet.relations.length > 0) {
            this.#serializeDataRelationCollection(jObject, pDataSet.relations);
        }
        return jObject;
    }
    #serializeTable(pTable, pOptions, pExpr, pRowState = DataViewRowStateEnum.CurrentRows) {
        const jObject = {};
        if (!pExpr)
            pExpr = new BravoExpressionEvaluator();
        if (!BravoStringExtensions.isNullOrEmpty(pTable.name))
            _a.#setValue(jObject, JsonConstants.TableNamePropName, pTable.name);
        if (pTable.columns.length > 0) {
            const columns = [];
            for (let i = 0; i < pTable.columns.length; i++) {
                const col = pTable.columns[i];
                col.setOrdinal(i);
                const jCol = {};
                _a.#serializeColumn(jCol, col, pOptions);
                columns.push(jCol);
            }
            _a.#setValue(jObject, JsonConstants.ColumnsPropName, columns);
        }
        if ((pOptions & SerializeOptionEnum.ViewSort) == SerializeOptionEnum.ViewSort &&
            !BravoStringExtensions.isNullOrEmpty(pTable.viewSort))
            _a.#setValue(jObject, JsonConstants.SortPropName, buildSortString(pTable));
        if ((pOptions & SerializeOptionEnum.ExtendedProperties) == SerializeOptionEnum.ExtendedProperties &&
            pTable.extendedProperties.size > 0) {
            const keyCollection = {};
            for (const [key, value] of pTable.extendedProperties) {
                if (!BravoStringExtensions.isString(value))
                    continue;
                const expr = pExpr.evaluateText(value?.toString());
                const exprs = ExpressionSerializer.fromExpression(expr);
                keyCollection[key] = exprs && exprs.length > 0 ? this.serialize(exprs) : undefined;
            }
            _a.#setValue(jObject, JsonConstants.ExtendedPropertiesPropName, keyCollection);
        }
        if ((pOptions & SerializeOptionEnum.Schema) == SerializeOptionEnum.Schema) {
            const uniqueKeys = [];
            for (let i = 0; i < pTable.constraints.length; i++) {
                const uniqueKey = tryCast(pTable.constraints[i], BravoDataInterfaceNamingConstants.IUniqueConstraint);
                if (uniqueKey == null || uniqueKey.isPrimaryKey)
                    continue;
                const jUniqueConstraint = {};
                _a.#serializeUniqueConstraint(jUniqueConstraint, uniqueKey, pOptions);
                uniqueKeys.push(jUniqueConstraint);
            }
            if (uniqueKeys.length > 0)
                _a.#setValue(jObject, JsonConstants.UniqueKeysPropName, uniqueKeys);
        }
        if ((pOptions & SerializeOptionEnum.Data) == SerializeOptionEnum.Data && pTable.rows.length > 0) {
            if ((pOptions & SerializeOptionEnum.RowState) == SerializeOptionEnum.RowState) {
                const rows = pTable.select(null, null, pRowState);
                if (rows && rows.length > 0)
                    _a.#serializeRowCollection(jObject, rows);
            }
            else {
                _a.#serializeRowCollection(jObject, pTable.rows);
            }
        }
        return jObject;
    }
    #serializeDataRelationCollection(pObject, pCollection) {
        const relationCollection = [];
        for (const relation of pCollection) {
            const obj = {};
            this.#serializeDataRelation(obj, relation);
            relationCollection.push(obj);
        }
        _a.#setValue(pObject, JsonConstants.RelationsPropName, relationCollection);
    }
    #serializeDataRelation(pObject, pRelation) {
        _a.#setValue(pObject, JsonConstants.RelationNamePropName, pRelation.relationName);
        _a.#setValue(pObject, JsonConstants.ParentTablePropName, pRelation.parentTable?.name);
        _a.#setValue(pObject, JsonConstants.ParentColumnsPropName, pRelation.parentColumns.map(pCol => pCol.columnName));
        _a.#setValue(pObject, JsonConstants.ChildTablePropName, pRelation.childTable?.name);
        _a.#setValue(pObject, JsonConstants.ChildColumnsPropName, pRelation.childColumns.map(pCol => pCol.columnName));
    }
    //#endregion custom serialize
    deserialize(pValue, pType, pOptions = SerializeOptionEnum.Default) {
        if (BravoStringExtensions.isString(pValue))
            pValue = tryParse(pValue);
        if (BravoObjectExtensions.isObject(pValue)) {
            return this.deserializeObject(pValue, pType, pOptions);
        }
        return super.deserialize(pValue, pType);
    }
    deserializeObject(pObject, pType, pOptions = SerializeOptionEnum.Default) {
        if (pType == BravoDataTable ||
            pType instanceof BravoDataTable ||
            pType == BravoDataSet ||
            pType instanceof BravoDataSet ||
            pType instanceof BravoResponseData ||
            pType instanceof BravoParameterCollection) {
            const object = BravoStringExtensions.isString(pObject) ? tryParse(pObject) : pObject;
            if (pType == BravoDataTable || pType instanceof BravoDataTable) {
                return this.#deserializeTable(object, tryCast(pType, BravoDataInterfaceNamingConstants.IDataTable), pOptions);
            }
            if (pType == BravoDataSet || pType instanceof BravoDataSet)
                return this.#deserializeDataSet(object, tryCast(pType, BravoDataInterfaceNamingConstants.IDataSet), pOptions);
            if (pType instanceof BravoResponseData)
                return this.#deserializeResponse(object, tryCast(pType, BravoResponseData), pOptions);
            if (BravoArrayExtensions.isArray(object) && pType instanceof BravoParameterCollection)
                return this.#deserializeParameterCollection(object, pType);
        }
        return super.deserializeObject(pObject, pType);
    }
    #deserializeResponse(pObj, pResponse, pOptions = SerializeOptionEnum.Default) {
        if (!pObj || !pResponse)
            return pResponse;
        const returnValue = getPropertyValue(pObj, JsonConstants.ReturnValuePropName);
        if (returnValue != null) {
            if (BravoObjectExtensions.isObject(returnValue) && BravoObjectExtensions.isObject(pResponse.returnValue)) {
                pResponse.returnValue = this.deserializeObject(returnValue, pResponse.returnValue, pOptions);
            }
            else {
                pResponse.returnValue = returnValue;
            }
        }
        const outputValue = BravoArrayExtensions.asArray(getPropertyValue(pObj, JsonConstants.OutputValuePropName, []));
        if (pResponse.outputValue instanceof BravoParameterCollection)
            this.#deserializeParameterCollection(outputValue, pResponse.outputValue);
        else if (outputValue.length > 0 && pResponse.outputValue instanceof Array) {
            for (let i = 0; i < outputValue.length; i++) {
                const o = outputValue[i];
                if (BravoObjectExtensions.isObject(o) && BravoObjectExtensions.isObject(pResponse.outputValue[i])) {
                    pResponse.outputValue[i] = this.deserializeObject(o, pResponse.outputValue[i]);
                }
                else {
                    pResponse.outputValue[i] = o;
                }
            }
        }
        return pResponse;
    }
    #deserializeParameterCollection(pArr, parameters) {
        if (!pArr || !parameters)
            return parameters;
        if (!parameters)
            parameters = new BravoParameterCollection();
        for (const jParam of pArr) {
            const paramName = getPropertyValue(jParam, JsonConstants.ParameterNamePropName, BravoStringExtensions.empty);
            let parameter = parameters.get(paramName);
            if (parameter == null) {
                parameter = new BravoDataParameter();
                parameters.push(parameter);
                parameter.parameterName = paramName;
                parameter.isNullable = getPropertyValue(jParam, JsonConstants.IsNullablePropName, true);
                parameter.sourceVersion = getPropertyValue(jParam, JsonConstants.SourceVersionPropName, DataRowVersionEnum.Current);
                parameter.sourceColumn = getPropertyValue(jParam, JsonConstants.SourceColumnPropName, BravoStringExtensions.empty);
                parameter.scale = getPropertyValue(jParam, JsonConstants.ScalePropName, 0);
                parameter.precision = getPropertyValue(jParam, JsonConstants.PrecisionPropName, 0);
            }
            parameter.value = getPropertyValue(jParam, JsonConstants.ParameterValuePropName);
            parameter.direction = getPropertyValue(jParam, JsonConstants.DirectionPropName, ParameterDirectionEnum.Input);
            const size = getPropertyValue(jParam, JsonConstants.SizePropName, 0);
            if (parameter.direction == ParameterDirectionEnum.Input && size == 0)
                parameter.size = -1;
            else if (size != 0)
                parameter.size = size;
            const output = { value: null };
            if (tryGetPropertyValue(jParam, JsonConstants.DbTypePropName, output, DbTypeEnum.String)) {
                const out = { resultValue: DbTypeEnum.String };
                if (BravoEnumExtensions.isEnumType(DbTypeEnum, output.value, out))
                    parameter.dbType = out.resultValue;
            }
        }
        return parameters;
    }
    #deserializeDataSet(pObj, pDataSet, pOptions = SerializeOptionEnum.Default) {
        if (!pObj)
            return pDataSet;
        if (!pDataSet)
            pDataSet = new BravoDataSet({ pExpressionEvaluator: new BravoExpressionEvaluator() });
        if (!pDataSet.name)
            pDataSet.name = getPropertyValue(pObj, JsonConstants.DataSetNamePropName, BravoStringExtensions.empty);
        pDataSet.caseSensitive = BravoBooleanExtensions.asBoolean(getPropertyValue(pObj, JsonConstants.CaseSensitivePropName, false));
        pDataSet.prefix = getPropertyValue(pObj, JsonConstants.PrefixPropName, BravoStringExtensions.empty);
        const jTables = BravoArrayExtensions.asArray(getPropertyValue(pObj, JsonConstants.TablesPropName, []));
        if (jTables?.length > 0) {
            let pos = 0;
            const isForceCreate = (pOptions & SerializeOptionEnum.CreateNonExistTable) == SerializeOptionEnum.CreateNonExistTable;
            for (const jTable of jTables) {
                const tbName = getPropertyValue(jTable, JsonConstants.TableNamePropName, BravoStringExtensions.empty);
                let table = tbName && pDataSet.tables.contains(tbName) ? pDataSet.tables.get(tbName) : null;
                if (table == null && (isForceCreate || pos >= pDataSet.tables.length)) {
                    table = pDataSet.tables.add(tbName);
                }
                if (table == null)
                    table = pDataSet.tables[pos];
                this.#deserializeTable(jTable, table, pOptions);
                pos++;
            }
        }
        const jRelations = BravoArrayExtensions.asArray(getPropertyValue(pObj, JsonConstants.RelationsPropName, []));
        if (jRelations?.length > 0) {
            for (const jRelation of jRelations) {
                const parentTable = pDataSet.tables.get(getPropertyValue(jRelation, JsonConstants.ParentTablePropName));
                if (!parentTable)
                    continue;
                const childTable = pDataSet.tables.get(getPropertyValue(jRelation, JsonConstants.ChildTablePropName));
                if (!childTable)
                    continue;
                let columns = BravoArrayExtensions.asArray(getPropertyValue(jRelation, JsonConstants.ParentColumnsPropName, []));
                const parentColumns = parentTable.columns.filter(pCol => columns.includes(pCol.columnName));
                columns = BravoArrayExtensions.asArray(getPropertyValue(jRelation, JsonConstants.ChildColumnsPropName, []));
                const childColumns = childTable.columns.filter(pCol => columns.includes(pCol.columnName));
                if (parentColumns.length == 0 || childColumns.length == 0)
                    continue;
                const relation = new BravoDataRelation(getPropertyValue(jRelation, JsonConstants.RelationNamePropName), parentColumns, childColumns);
                pDataSet.relations?.add(relation);
            }
        }
        return pDataSet;
    }
    #deserializeTable(pObj, pTable = null, pOptions = SerializeOptionEnum.Default) {
        if (pObj == null)
            return pTable;
        if (pTable == null)
            pTable = new BravoDataTable({ pExpressionEvaluator: new BravoExpressionEvaluator() });
        const isIgnoreSchema = (pOptions & SerializeOptionEnum.Schema) != SerializeOptionEnum.Schema;
        const isAddKey = !isIgnoreSchema &&
            (pTable.columns.length == 0 || pTable.primaryKey == null || pTable.primaryKey.length < 1);
        let keys = null;
        try {
            if (!pTable.name)
                pTable.name = getPropertyValue(pObj, JsonConstants.ColumnNamePropName, BravoStringExtensions.empty);
            //#region columns
            const columns = BravoArrayExtensions.asArray(getPropertyValue(pObj, JsonConstants.ColumnsPropName, []));
            if (columns && (!isIgnoreSchema || pTable.columns.length < 1)) {
                let ordinal = 0;
                for (const jCol of columns) {
                    const colName = getPropertyValue(jCol, JsonConstants.ColumnNamePropName, BravoStringExtensions.empty);
                    let colType = TypeCodeEnum.String;
                    const result = { resultValue: TypeCodeEnum.String };
                    if (BravoEnumExtensions.isEnumType(TypeCodeEnum, getPropertyValue(jCol, JsonConstants.DataTypePropName), result))
                        colType = result.resultValue;
                    const column = colName && pTable.columns.contains(colName)
                        ? pTable.columns.get(colName)
                        : new BravoDataColumn(colName, colType);
                    if (!column)
                        continue;
                    if (!isIgnoreSchema && pTable.rows.length <= 0 && column.table && column.dataType != colType)
                        column.dataType = colType;
                    const caption = getPropertyValue(jCol, JsonConstants.CaptionPropName);
                    if (caption)
                        column.caption = caption;
                    const isNew = column.table == null;
                    if (isNew)
                        pTable.columns.add(column);
                    if (ordinal < pTable.columns.length) {
                        moveObjectAtIndex(pTable.columns, pTable.columns.indexOf(column), ordinal);
                        column.setOrdinal(ordinal++);
                    }
                    if (isNew || column.allowDBNull)
                        column.allowDBNull = getPropertyValue(jCol, JsonConstants.AllowDBNullPropName, true);
                    const isReadOnly = getPropertyValue(jCol, JsonConstants.ReadOnlyPropName, false);
                    const isUnique = getPropertyValue(jCol, JsonConstants.UniquePropName, false);
                    const maxLength = getPropertyValue(jCol, JsonConstants.MaxLengthPropName, -1);
                    const isKey = getPropertyValue(jCol, JsonConstants.IsKeyPropName, false);
                    if (isNew) {
                        column.autoIncrement = getPropertyValue(jCol, JsonConstants.AutoIncrementPropName, false);
                        column.autoIncrementSeed = getPropertyValue(jCol, JsonConstants.AutoIncrementSeedPropName, 0);
                        column.autoIncrementStep = getPropertyValue(jCol, JsonConstants.AutoIncrementStepPropName, 1);
                        if (isUnique &&
                            (!isKey || pTable.primaryKey.length == 0 || !pTable.primaryKey.includes(column)))
                            column.unique = isUnique;
                    }
                    if (isReadOnly)
                        column.readOnly = isReadOnly;
                    if (isNew && !column.autoIncrement)
                        column.defaultValue = getPropertyValue(jCol, JsonConstants.DefaultValuePropName);
                    if (column.dataType == TypeCodeEnum.String && maxLength != -1)
                        column.maxLength = maxLength;
                    if (isAddKey && isKey) {
                        if (!keys)
                            keys = [];
                        keys.push(column);
                    }
                    if ((pOptions & SerializeOptionEnum.ExtendedProperties) == SerializeOptionEnum.ExtendedProperties) {
                        const jColExt = getPropertyValue(jCol, JsonConstants.ExtendedPropertiesPropName, BravoStringExtensions.empty);
                        if (jColExt) {
                            for (const key in jColExt) {
                                column.extendedProperties.set(key, jColExt[key]);
                            }
                        }
                    }
                }
            }
            //#endregion columns
            if ((pOptions & SerializeOptionEnum.ViewSort) == SerializeOptionEnum.ViewSort) {
                /* empty */
            }
            if ((pOptions & SerializeOptionEnum.ExtendedProperties) == SerializeOptionEnum.ExtendedProperties) {
                const jExt = getPropertyValue(pObj, JsonConstants.ExtendedPropertiesPropName, BravoStringExtensions.empty);
                if (jExt) {
                    for (const key in jExt) {
                        pTable.extendedProperties.set(key, jExt[key]);
                    }
                }
            }
            //#region unique keys
            if (!isIgnoreSchema) {
                let isPrimaryAsUnique = false;
                if (!keys)
                    keys = [];
                if (isAddKey && keys.length > 0) {
                    isPrimaryAsUnique = keys.some(pCol => pCol.allowDBNull);
                    if (!isPrimaryAsUnique)
                        pTable.primaryKey = keys;
                }
                const uniqueKeys = BravoArrayExtensions.asArray(getPropertyValue(pObj, JsonConstants.UniqueKeysPropName));
                if (uniqueKeys || isPrimaryAsUnique) {
                    if (isPrimaryAsUnique) {
                        const unique = new BravoUniqueConstraint(BravoStringExtensions.empty, true, ...keys);
                        if (!_a.#containsConstraint(pTable, unique))
                            pTable.constraints?.add(unique);
                    }
                    if (uniqueKeys?.length > 0) {
                        for (const jUnique of uniqueKeys) {
                            const columns = BravoArrayExtensions.asArray(getPropertyValue(jUnique, JsonConstants.ColumnsPropName));
                            if (columns?.length > 0) {
                                const col = columns.map(pCol => pTable.columns[pCol]);
                                const unique = new BravoUniqueConstraint('', false, ...col);
                                if (!_a.#containsConstraint(pTable, unique))
                                    pTable.constraints?.add(unique);
                            }
                        }
                    }
                }
            }
            //#endregion unique keys
            //#region rows
            const jRows = BravoArrayExtensions.asArray(getPropertyValue(pObj, JsonConstants.RowsPropName));
            if ((pOptions & SerializeOptionEnum.Data) == SerializeOptionEnum.Data &&
                pTable.columns.length > 0 &&
                jRows?.length > 0) {
                const bytesCols = new Array();
                const objectCols = new Array();
                const cacheCols = new Array();
                const defaultValueCols = new Map();
                const readonlyCols = new Array();
                const colsAutoIncrement = new Array();
                let ignoreDefaultValue = false;
                if (pTable.dataSet)
                    ignoreDefaultValue = pTable.dataSet.ignoreDefaultValue;
                for (let i = 0; i < pTable.columns.length; i++) {
                    const col = pTable.columns[i];
                    if (col.readOnly) {
                        col.readOnly = false;
                        readonlyCols.push(col);
                    }
                    if (col.dataType == TypeCodeEnum.ByteArray)
                        bytesCols.push(i);
                    else if (col.dataType == TypeCodeEnum.Object)
                        objectCols.push(i);
                    if (col.autoIncrement)
                        colsAutoIncrement.push(i);
                    cacheCols.push(col.columnName);
                    if (!ignoreDefaultValue)
                        defaultValueCols.set(i, col.defaultValue);
                }
                let isInsert = (pOptions & SerializeOptionEnum.Insert) == SerializeOptionEnum.Insert;
                if (isInsert && pTable.rows.length < 1)
                    isInsert = false;
                const isSuspendConstraint = (pOptions & SerializeOptionEnum.SuspendConstraint) == SerializeOptionEnum.SuspendConstraint;
                if (!isSuspendConstraint)
                    pTable.beginUpdate();
                const items = [];
                try {
                    const isPrimaryKey = pTable.primaryKey && pTable.primaryKey.length > 0;
                    const isAddRow = pTable.rows.length == 0;
                    for (const jRow of jRows) {
                        if (isInsert) {
                            const rowValue = readRowValues({
                                pRow: jRow,
                                pBytesCols: bytesCols,
                                pObjectCols: objectCols,
                                pCacheCols: cacheCols,
                                pDefaultValues: defaultValueCols,
                            });
                            const row = new BravoDataRow(pTable, rowValue.item);
                            row.currentItems = rowValue.itemsArray;
                            items.push(rowValue.item);
                            pTable.rows.push(row);
                        }
                        else {
                            let result = DataRowStateEnum.Unchanged;
                            const out = { resultValue: DataRowStateEnum.Unchanged };
                            if (BravoEnumExtensions.isEnumType(DataRowStateEnum, getPropertyValue(jRow, JsonConstants.RowStatePropName), out)) {
                                result = out.resultValue;
                            }
                            else if (containsPropertyValue(jRow, JsonConstants.RowCurrentItemsPropName) &&
                                containsPropertyValue(jRow, JsonConstants.RowOriginalItemsPropName)) {
                                result = DataRowStateEnum.Modified;
                            }
                            if (result == DataRowStateEnum.Unchanged) {
                                const rowValue = readRowValues({
                                    pRow: jRow,
                                    pBytesCols: bytesCols,
                                    pObjectCols: objectCols,
                                    pCacheCols: cacheCols,
                                    pDefaultValues: defaultValueCols,
                                });
                                if (isPrimaryKey || isAddRow) {
                                    // if (
                                    //     pTable.primaryKey.length > 0 &&
                                    //     WebDataTable.findIndexByPrimaryKey(pTable, _items, _row.item) >= 0
                                    // )
                                    //     continue;
                                    const row = new BravoDataRow(pTable, rowValue.item);
                                    row.currentItems = rowValue.itemsArray;
                                    if (!colsAutoIncrement || colsAutoIncrement.length > 0) {
                                        for (const index of colsAutoIncrement) {
                                            const col = pTable.columns[index];
                                            if (!col)
                                                continue;
                                            if (rowValue.item[col.columnName] == null) {
                                                col.init(rowValue.item);
                                                row.currentItems[index] = rowValue.item[col.columnName];
                                            }
                                        }
                                    }
                                    items.push(rowValue.item);
                                    pTable.rows.push(row);
                                }
                                else {
                                    pTable.loadDataRow(rowValue.item, false);
                                }
                            }
                            else if (result == DataRowStateEnum.Added) {
                                const rowValue = readRowValues({
                                    pRow: jRow,
                                    pBytesCols: bytesCols,
                                    pObjectCols: objectCols,
                                    pCacheCols: cacheCols,
                                    pDefaultValues: defaultValueCols,
                                });
                                pTable.loadDataRow(rowValue.item, false);
                                items.push(rowValue.item);
                            }
                            else if (result == DataRowStateEnum.Deleted) {
                                const rowValue = readRowValues({
                                    pRow: jRow,
                                    pBytesCols: bytesCols,
                                    pObjectCols: objectCols,
                                    pCacheCols: cacheCols,
                                    pDefaultValues: defaultValueCols,
                                    pVersion: DataRowVersionEnum.Original,
                                });
                                const row = pTable.loadDataRow(rowValue.item, false);
                                if (row) {
                                    row.acceptChanges();
                                    row.delete();
                                }
                            }
                            else if (result == DataRowStateEnum.Modified) {
                                let rowValue = readRowValues({
                                    pRow: jRow,
                                    pBytesCols: bytesCols,
                                    pObjectCols: objectCols,
                                    pCacheCols: cacheCols,
                                    pDefaultValues: defaultValueCols,
                                    pVersion: DataRowVersionEnum.Original,
                                });
                                const row = pTable.loadDataRow(rowValue.item, false);
                                if (row) {
                                    row.acceptChanges();
                                    rowValue = readRowValues({
                                        pRow: jRow,
                                        pBytesCols: bytesCols,
                                        pObjectCols: objectCols,
                                        pCacheCols: cacheCols,
                                        pDefaultValues: defaultValueCols,
                                    });
                                    row.currentItems = rowValue.itemsArray;
                                    for (const key in rowValue.item) {
                                        row.item[key] = rowValue.item[key];
                                    }
                                    pOptions &= ~SerializeOptionEnum.AcceptChanges;
                                }
                            }
                        }
                    }
                    if ((pOptions & SerializeOptionEnum.AcceptChanges) == SerializeOptionEnum.AcceptChanges)
                        pTable.acceptChanges();
                }
                finally {
                    if (pTable.sourceCollection instanceof ObservableArray) {
                        for (let i = 0; i < items.length; i++) {
                            pTable.sourceCollection.push(items[i]);
                        }
                    }
                    else {
                        pTable.sourceCollection = new ObservableArray(items);
                    }
                    if (!isSuspendConstraint)
                        pTable.endUpdate();
                    for (const col of readonlyCols) {
                        col.readOnly = true;
                    }
                }
            }
            //#endregion rowF
        }
        catch (ex) {
            console.warn(ex);
            throw ex;
        }
        return pTable;
    }
}
_a = BravoJsonSerializer;
function containsPropertyValue(pObject, propertyName) {
    propertyName = propNames.get(propertyName) || propertyName;
    return !isUndefined(pObject[propertyName]);
}
function tryGetPropertyValue(pObject, pPropertyName, pOutput, pDefaultValue) {
    pOutput.value = pDefaultValue;
    pPropertyName = propNames.get(pPropertyName) || pPropertyName;
    const val = pObject[pPropertyName];
    if (!isUndefined(val)) {
        pOutput.value = val;
        return true;
    }
    return false;
}
function getPropertyValue(pObject, pPropertyName, pDefaultValue) {
    pPropertyName = propNames.get(pPropertyName) || pPropertyName;
    const val = pObject[pPropertyName];
    if (isUndefined(val))
        return pDefaultValue;
    return val;
}
function moveObjectAtIndex(pArray, pSourceIndex, pDestIndex) {
    pArray.deferUpdate(() => {
        const placeholder = {};
        // remove the object from its initial position and
        // plant the placeholder object in its place to
        // keep the array length constant
        const objectToMove = pArray.splice(pSourceIndex, 1, placeholder)[0];
        // place the object in the desired position
        pArray.splice(pDestIndex, 0, objectToMove);
        // take out the temporary object
        pArray.splice(pArray.indexOf(placeholder), 1);
    });
}
function readRowValues({ pRow, pBytesCols, pObjectCols, pCacheCols, pDefaultValues, pVersion = DataRowVersionEnum.Current, }) {
    const propName = pVersion == DataRowVersionEnum.Current
        ? JsonConstants.RowCurrentItemsPropName
        : JsonConstants.RowOriginalItemsPropName;
    const jsonCurrentItems = BravoArrayExtensions.asArray(getPropertyValue(pRow, propName, []));
    const result = {
        itemsArray: new Array(jsonCurrentItems.length),
        item: {},
    };
    for (let index = 0; index < pCacheCols.length; index++) {
        let value = jsonCurrentItems[index];
        if (pBytesCols.includes(index) && BravoStringExtensions.isString(value)) {
            value = BravoConverterExtensions.fromBase64String(value);
        }
        //  else if (pObjectCols.includes(index) && pCacheCols[index] == 'LayoutData' && _val instanceof Uint8Array) {
        //     _val = BravoLayoutData.createNew(_val);
        // }
        else if (value == null && pDefaultValues.has(index)) {
            value = pDefaultValues.get(index);
        }
        result.item[pCacheCols[index]] = result.itemsArray[index] = value;
    }
    return result;
}

class BravoXmlHelper {
    static convertToXmlString(pDataSet, pTables = null, pColumns = null, pbUseTableAlias = false, pType = BravoXmlStringTypeEnum.AttributeMapping) {
        return this.writeDataSet(pDataSet, pTables, pColumns, pbUseTableAlias, pType);
    }
    static serializeDataSet(pDataSet, pTables = null, pColumns = null, pRowFilter = null, pRowState = DataRowStateEnum.Added | DataRowStateEnum.Modified | DataRowStateEnum.Unchanged, pbUseTableAlias = false, pType = BravoXmlStringTypeEnum.ElementMappingWithSchema, pFormat = null) {
        if (pDataSet == null)
            throw new Error('pDataSet');
        let dataSetName = 'NewDataSet';
        if (pDataSet.name)
            dataSetName = pDataSet.name;
        if (pFormat == null)
            pFormat = BravoAppSettings.settings.currentCulture;
        const sbXml = new BravoStringBuilder();
        sbXml.appendLine('<?xml version="1.0" standalone="yes"?>');
        sbXml.appendLine(BravoStringExtensions.format('<{0}>', dataSetName));
        if (pType == BravoXmlStringTypeEnum.ElementMappingWithSchema) {
            const ds = pDataSet;
            for (const table of ds.tables) {
                if (!pbUseTableAlias) {
                    const alias = BravoExpressionEvaluator.getSourceName(table);
                    if (BravoStringExtensions.compareStrings(table.name, alias, false))
                        table.name = alias;
                }
            }
            const sbSchema = new BravoStringBuilder();
            const sw = new StringWriter(sbSchema, pFormat);
            BravoXmlHelper.writeXmlSchema(ds, sw);
            // _sw.close();
            sbXml.append(sbSchema.toString());
        }
        for (const table of pDataSet.tables) {
            if ((pTables &&
                pTables.indexOf(table.name) < 0 &&
                pTables.indexOf(BravoExpressionEvaluator.getSourceName(table)) < 0) ||
                !pColumns)
                continue;
            sbXml.append(BravoXmlHelper.serializeDataTable(table, pColumns, pRowFilter, pRowState, pbUseTableAlias, pType));
        }
        sbXml.append(BravoStringExtensions.format('</{0}>', dataSetName));
        return sbXml.toString();
    }
    static serializeDataTable(pTable, pColumns, pRowFilter = null, pRowState = DataRowStateEnum.Added | DataRowStateEnum.Modified | DataRowStateEnum.Unchanged, pbUseTableAlias = true, pType) {
        if (pTable == null)
            throw new Error('pTable');
        let sort = null;
        if (BravoStringExtensions.isNullOrEmpty(pTable.viewSort) && pTable.primaryKey.length > 0)
            sort = BravoStringExtensions.format('{0} ASC', pTable.primaryKey[0].columnName);
        let viewRowState = DataViewRowStateEnum.None;
        if ((pRowState & DataRowStateEnum.Added) == DataRowStateEnum.Added)
            viewRowState |= DataRowStateEnum.Added;
        if ((pRowState & DataRowStateEnum.Modified) == DataRowStateEnum.Modified)
            viewRowState |= DataViewRowStateEnum.ModifiedCurrent;
        if ((pRowState & DataRowStateEnum.Unchanged) == DataRowStateEnum.Unchanged)
            viewRowState |= DataViewRowStateEnum.Unchanged;
        const dataRows = pTable.select(pRowFilter, sort, viewRowState);
        const sb = new BravoStringBuilder();
        const tbName = pbUseTableAlias ? pTable.name : BravoExpressionEvaluator.getSourceName(pTable);
        for (let r = 0; r < dataRows.length; r++) {
            sb.append('\t<');
            sb.append(tbName);
            if (pType != BravoXmlStringTypeEnum.AttributeMapping)
                sb.appendLine('>');
            const columns = pTable.columns;
            for (let c = 0; c < columns.length; c++) {
                if (pColumns != null && pColumns.length > 0 && pColumns.indexOf(columns[c].columnName) < 0)
                    continue;
                const col = columns[c], colName = col.columnName;
                const val = dataRows[r].getValue(col);
                if (val != null) {
                    const type = col.dataType;
                    let strVal = BravoStringExtensions.empty;
                    if (type == TypeCodeEnum.String) {
                        strVal = escapeXml(val.toString());
                    }
                    else if (type == TypeCodeEnum.DateTime) {
                        const outArgs = { datetime: null };
                        if (BravoDataConvertUtil.isDateTimeValue(val, outArgs))
                            strVal = BravoMoment.format(outArgs.datetime, 'yyyy/MM/dd HH:mm:ss');
                        else
                            strVal = val;
                    }
                    else if (type == TypeCodeEnum.ByteArray) {
                        strVal = BravoConverterExtensions.toBase64String(val);
                    }
                    else if (type == TypeCodeEnum.Boolean) {
                        strVal = val.toString();
                    }
                    else if (type == TypeCodeEnum.Byte) {
                        if (BravoBooleanExtensions.isBoolean(val))
                            strVal = BravoStringExtensions.format('{0}', BravoBooleanExtensions.asBoolean(val) ? 1 : 0);
                        else
                            strVal = BravoStringExtensions.format('{0}', val);
                    }
                    else {
                        strVal = BravoStringExtensions.format('{0}', val.toString());
                    }
                    if (pType == BravoXmlStringTypeEnum.AttributeMapping) {
                        sb.append(' ');
                        sb.append(colName);
                        sb.append('="');
                        sb.append(strVal);
                        sb.append('"');
                    }
                    else {
                        sb.append('\t\t<');
                        sb.append(colName);
                        sb.append('>');
                        sb.append(strVal);
                        sb.append('</');
                        sb.append(colName);
                        sb.appendLine('>');
                    }
                }
            }
            if (pType == BravoXmlStringTypeEnum.AttributeMapping) {
                sb.append(' />\n');
            }
            else {
                sb.append('\t</');
                sb.append(tbName);
                sb.appendLine('>');
            }
        }
        return sb.toString();
    }
    static writeDataSet(pDataSet, pTables = null, pColumns = null, pbUseTableAlias = false, pType = BravoXmlStringTypeEnum.ElementMappingWithSchema, pFormat = null) {
        if (pDataSet == null)
            throw new Error('pDataSet');
        let dataSetName = 'NewDataSet';
        if (pDataSet.name)
            dataSetName = pDataSet.name;
        if (pFormat == null)
            pFormat = BravoAppSettings.settings.currentCulture;
        const sbXml = new BravoStringBuilder();
        sbXml.appendLine('<?xml version="1.0" standalone="yes"?>');
        sbXml.appendLine(BravoStringExtensions.format('<{0}>', dataSetName));
        if (pType == BravoXmlStringTypeEnum.ElementMappingWithSchema) {
            const ds = pDataSet;
            for (const table of ds.tables) {
                if (pbUseTableAlias) {
                    const alias = BravoExpressionEvaluator.getAliasName(table);
                    if (BravoStringExtensions.compareStrings(table.name, alias, false))
                        table.name = alias;
                }
            }
            const sbSchema = new BravoStringBuilder();
            const sw = new StringWriter(sbSchema, pFormat);
            BravoXmlHelper.writeXmlSchema(ds, sw);
            // _sw.close();
            sbXml.append(sbSchema.toString());
        }
        for (const table of pDataSet.tables) {
            if ((pTables &&
                pTables.indexOf(table.name) < 0 &&
                pTables.indexOf(BravoExpressionEvaluator.getAliasName(table)) < 0) ||
                !pColumns)
                continue;
            sbXml.append(BravoXmlHelper.writeDataTable(table, pColumns, pbUseTableAlias, pType));
        }
        sbXml.append(BravoStringExtensions.format('</{0}>', dataSetName));
        return sbXml.toString();
    }
    static writeDataTable(pTable, pColumns, pbUseTableAlias, pType) {
        if (pTable == null)
            throw new Error('pTable');
        /* let _zSort = null;

        if (BravoStringExtensions.isNullOrEmpty(pTable.viewSort) && pTable.primaryKey.length > 0)
            _zSort = BravoStringExtensions.format('{0} ASC', pTable.primaryKey[0].columnName);

        const _drs = pTable.select(null, _zSort, DataViewRowState.CurrentRows); */
        const dataRows = pTable.select(null, null, DataViewRowStateEnum.CurrentRows);
        const sb = new BravoStringBuilder();
        const tbName = pbUseTableAlias ? BravoExpressionEvaluator.getAliasName(pTable) : pTable.name;
        for (let r = 0; r < dataRows.length; r++) {
            sb.append('\t<');
            sb.append(tbName);
            if (pType != BravoXmlStringTypeEnum.AttributeMapping)
                sb.appendLine('>');
            const columns = pTable.columns;
            for (let c = 0; c < columns.length; c++) {
                if (pColumns != null && pColumns.length > 0 && pColumns.indexOf(columns[c].columnName) < 0)
                    continue;
                const col = columns[c], colName = col.columnName;
                const val = dataRows[r].getValue(col);
                if (val != null) {
                    const type = col.dataType;
                    let strVal = BravoStringExtensions.empty;
                    if (type == TypeCodeEnum.String) {
                        strVal = escapeXml(val.toString());
                    }
                    else if (type == TypeCodeEnum.DateTime) {
                        const outArgs = { datetime: null };
                        if (BravoDataConvertUtil.isDateTimeValue(val, outArgs))
                            strVal = BravoMoment.format(outArgs.datetime, 'yyyy/MM/dd HH:mm:ss');
                        else
                            strVal = val;
                    }
                    else if (type == TypeCodeEnum.ByteArray) {
                        strVal = BravoConverterExtensions.toBase64String(val);
                    }
                    else if (type == TypeCodeEnum.Boolean) {
                        strVal = val.toString();
                    }
                    else if (type == TypeCodeEnum.Byte) {
                        if (BravoBooleanExtensions.isBoolean(val))
                            strVal = BravoStringExtensions.format('{0}', BravoBooleanExtensions.asBoolean(val) ? 1 : 0);
                        else
                            strVal = BravoStringExtensions.format('{0}', val);
                    }
                    else {
                        strVal = BravoStringExtensions.format('{0}', val.toString());
                    }
                    if (pType == BravoXmlStringTypeEnum.AttributeMapping) {
                        sb.append(' ');
                        sb.append(colName);
                        sb.append('="');
                        sb.append(strVal);
                        sb.append('"');
                    }
                    else {
                        sb.append('\t\t<');
                        sb.append(colName);
                        sb.append('>');
                        sb.append(strVal);
                        sb.append('</');
                        sb.append(colName);
                        sb.appendLine('>');
                    }
                }
            }
            if (pType == BravoXmlStringTypeEnum.AttributeMapping) {
                sb.append(' />\n');
            }
            else {
                sb.append('\t</');
                sb.append(tbName);
                sb.appendLine('>');
            }
        }
        return sb.toString();
    }
    static writeXmlSchema(pData, pStringWriter) {
        const sb = pStringWriter.stringBuilder;
        const dataTable = tryCast(pData, BravoDataInterfaceNamingConstants.IDataTable);
        const dataSet = tryCast(pData, BravoDataInterfaceNamingConstants.IDataSet);
        if (dataSet != null && sb) {
            sb.appendLine('  <xs:schema id="NewDataSet" xmlns="" xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns:msdata="urn:schemas-microsoft-com:xml-msdata" xmlns:msprop="urn:schemas-microsoft-com:xml-msprop">');
            sb.appendLine('\t<xs:element name="NewDataSet" msdata:IsDataSet="true" msdata:UseCurrentLocale="true">');
            sb.appendLine('\t  <xs:complexType>');
            sb.appendLine('\t\t<xs:choice minOccurs="0" maxOccurs="unbounded">');
            for (const table of dataSet.tables) {
                this.writeXmlSchema(table, pStringWriter);
            }
            sb.appendLine('\t\t</xs:choice>');
            sb.appendLine('\t  </xs:complexType>');
            sb.appendLine('\t</xs:element>');
            sb.appendLine('  </xs:schema>');
        }
        else if (dataTable && sb) {
            let sbProps = null;
            if (dataTable.extendedProperties && dataTable.extendedProperties.size > 0) {
                sbProps = new BravoStringBuilder();
                for (const [key, value] of dataTable.extendedProperties) {
                    const val = value;
                    if (value instanceof Object) {
                        continue;
                    }
                    sbProps.appendFormat(' msprop:{0}="{1}"', key, val);
                }
            }
            if (!sbProps)
                sbProps = new BravoStringBuilder();
            sb.appendFormat('\t\t  <xs:element name="{0}"{1}>', dataTable.name, sbProps?.toString());
            sb.appendLine();
            sb.appendLine('\t\t\t<xs:complexType>');
            sb.appendLine('\t\t\t  <xs:sequence>');
            for (const dataColumn of dataTable.columns) {
                let caption = '', strType = '', defaultVal = '';
                if (!BravoStringExtensions.isNullOrEmpty(dataColumn.caption))
                    caption = BravoStringExtensions.format(' msdata:Caption="{0}"', escapeXml(dataColumn.caption));
                if (dataColumn.dataType == TypeCodeEnum.String)
                    strType = BravoStringExtensions.format(' type="xs:{0}" minOccurs="0"', convertTypeCode(dataColumn.dataType));
                else
                    strType = BravoStringExtensions.format(' type="xs:{0}"', convertTypeCode(dataColumn.dataType));
                if (dataColumn.defaultValue !== null && dataColumn.defaultValue !== undefined) {
                    if (dataColumn.dataType == TypeCodeEnum.DateTime) {
                        const date = new Date(dataColumn.defaultValue).toISOString();
                        defaultVal = BravoStringExtensions.format(' default="{0}"', date);
                    }
                    else
                        defaultVal = BravoStringExtensions.format(' default="{0}"', dataColumn.defaultValue.toString());
                }
                sb.appendLine(BravoStringExtensions.format('\t\t\t\t<xs:element name="{0}"{1}{2}{3} />', dataColumn.columnName, caption, strType, defaultVal));
            }
            sb.appendLine('\t\t\t  </xs:sequence>');
            sb.appendLine('\t\t\t</xs:complexType>');
            sb.appendLine('\t\t  </xs:element>');
        }
    }
    static writeXmlDataSet(pDataSet, pMode) {
        if (pMode === XmlWriteModeEnum.DiffGram) {
            return this._writeXmlDiffGram(pDataSet);
        }
        if (pMode === XmlWriteModeEnum.WriteSchema) {
            return this.writeDataSet(pDataSet, undefined, undefined, undefined, BravoXmlStringTypeEnum.ElementMappingWithSchema);
        }
        return this.writeDataSet(pDataSet, undefined, undefined, undefined, BravoXmlStringTypeEnum.AttributeMapping);
    }
    static _writeXmlDiffGram(pDataSet) {
        const diffgrNS = 'urn:schemas-microsoft-com:xml-diffgram-v1';
        const msdataNS = 'urn:schemas-microsoft-com:xml-msdata';
        const xml = new BravoStringBuilder();
        const beforeAll = new BravoStringBuilder();
        const dsName = pDataSet.name || 'NewDataSet';
        xml.append(`<?xml version="1.0" standalone="yes"?>`);
        xml.appendFormat(`<diffgr:diffgram xmlns:msdata="{0}" xmlns:diffgr="{1}">`, msdataNS, diffgrNS);
        xml.appendFormat(`<{0}>`, dsName);
        pDataSet.tables.forEach(pTable => {
            const { documentElement, before } = this._writeXmlDiffGramFragment(pTable);
            xml.append(documentElement);
            if (before?.length > 0) {
                beforeAll.append(before);
            }
        });
        xml.appendFormat(`</{0}>`, dsName);
        if (beforeAll.length > 0) {
            xml.append(`<diffgr:before>`);
            xml.append(beforeAll);
            xml.append(`</diffgr:before>`);
        }
        xml.append(`</diffgr:diffgram>`);
        return xml.toString();
    }
    static _writeXmlDiffGramFragment(pTable) {
        const docElem = new BravoStringBuilder();
        const beforeElem = new BravoStringBuilder();
        pTable.rows.forEach((pRow, pIndex) => {
            const diffgrId = `${pTable.name}${pIndex + 1}`;
            const baseAttrs = [`diffgr:id="${diffgrId}"`, `msdata:rowOrder="${pIndex}"`];
            // DocumentElement part
            if (pRow.rowState !== DataRowStateEnum.Deleted) {
                const hasChanges = pRow.rowState === DataRowStateEnum.Added
                    ? 'inserted'
                    : pRow.rowState === DataRowStateEnum.Modified
                        ? 'modified'
                        : null;
                const changeAttr = hasChanges ? [`diffgr:hasChanges="${hasChanges}"`] : [];
                const attrs = [...baseAttrs, ...changeAttr].join(' ');
                docElem.appendFormat('<{0} {1}>', pTable.name, attrs);
                const current = pRow.currentItems;
                pTable.columns.forEach((pCol, pColIndex) => {
                    if (current[pColIndex] == null)
                        return;
                    let val = BravoDataConvertUtil.convertValue(current[pColIndex], pCol.dataType);
                    if (pCol.dataType == TypeCodeEnum.ByteArray && val instanceof Uint8Array)
                        val = BravoConverterExtensions.toBase64String(val);
                    docElem.appendFormat('<{0}>{1}</{0}>', pCol.columnName, val);
                });
                docElem.appendFormat('</{0}>', pTable.name);
            }
            // Before part (for modified or deleted)
            if (pRow.rowState === DataRowStateEnum.Modified || pRow.rowState === DataRowStateEnum.Deleted) {
                const attrs = baseAttrs.join(' ');
                beforeElem.appendFormat('<{0} {1}>', pTable.name, attrs);
                const original = pRow.originalItems;
                pTable.columns.forEach((pCol, pColIndex) => {
                    if (original[pColIndex] == null)
                        return;
                    let val = BravoDataConvertUtil.convertValue(original[pColIndex], pCol.dataType);
                    if (pCol.dataType == TypeCodeEnum.ByteArray && val instanceof Uint8Array)
                        val = BravoConverterExtensions.toBase64String(val);
                    beforeElem.appendFormat('<{0}>{1}</{0}>', pCol.columnName, val);
                });
                beforeElem.appendFormat('</{0}>', pTable.name);
            }
        });
        return { documentElement: docElem, before: beforeElem };
    }
    static readXmlDataSet(pDataSet, pXml, pMode) {
        if (pDataSet == null)
            throw new Error('pDataSet');
        if (pMode === XmlReadModeEnum.DiffGram) {
            this._readXmlDiffGram(pDataSet, pXml);
            return;
        }
        this._readXmlAuto(pDataSet, pXml);
    }
    static _readXmlAuto(pDataSet, pContent) {
        const parser = new DOMParser(), xmlDoc = parser.parseFromString(pContent, 'text/xml');
        if (xmlDoc == null || xmlDoc.childElementCount != 1)
            return;
        const ds = pDataSet;
        ds.name = xmlDoc.firstElementChild?.tagName;
        const dsXml = xmlDoc.firstElementChild;
        if (dsXml == null || !dsXml.hasChildNodes())
            return;
        const xmlSchema = ds.name ? xmlDoc.getElementById(ds.name) : null;
        if (xmlSchema != null && xmlSchema.tagName == 'xs:schema') {
            const xmlChoice = xmlSchema.getElementsByTagName('xs:choice');
            if (xmlChoice && xmlChoice.length == 1) {
                const xmlTables = xmlChoice.item(0);
                if (xmlTables)
                    for (let i = 0; i < xmlTables.children.length; i++) {
                        const xmlTable = xmlTables.children.item(i);
                        const tableName = xmlTable && xmlTable.getAttribute('name');
                        if (!tableName || ds.tables.contains(tableName))
                            continue;
                        const table = new BravoDataTable({ pName: tableName });
                        ds.tables.add(table);
                        if (xmlTable)
                            for (let att, i = 0, atts = xmlTable.attributes, n = atts.length; i < n; i++) {
                                att = atts[i];
                                if (att.nodeName.slice(0, 6) == 'msprop')
                                    table.extendedProperties.set(att.nodeName.slice(7), att.nodeValue);
                            }
                        const xmlSequence = xmlTable && xmlTable.getElementsByTagName('xs:sequence');
                        if (xmlSequence && xmlSequence.length == 1) {
                            const xmlCols = xmlSequence.item(0);
                            if (xmlCols)
                                for (let j = 0; j < xmlCols.children.length; j++) {
                                    const xmlCol = xmlCols.children.item(j);
                                    const colName = xmlCol && xmlCol.getAttribute('name');
                                    if (!colName)
                                        continue;
                                    let col;
                                    if (xmlCol != null && xmlCol.children.length != 0) {
                                        const attr = xmlCol
                                            .getElementsByTagName('xs:restriction')
                                            ?.item(0)
                                            ?.getAttribute('base');
                                        const base = attr
                                            ? convertStringToType(getStringType(attr))
                                            : TypeCodeEnum.String;
                                        col = new BravoDataColumn(colName, base);
                                    }
                                    else {
                                        const typeAttr = xmlCol?.getAttribute('type');
                                        const type = typeAttr
                                            ? convertStringToType(getStringType(typeAttr))
                                            : TypeCodeEnum.String;
                                        col = new BravoDataColumn(colName, type);
                                    }
                                    const caption = xmlCol && xmlCol.getAttribute('msdata:Caption');
                                    if (caption)
                                        col.caption = caption;
                                    table.columns.add(col);
                                }
                        }
                    }
            }
        }
        if (ds.tables.length > 0) {
            for (const table of ds.tables) {
                const xmlRows = xmlDoc.getElementsByTagName(table.name);
                if (xmlRows && xmlRows.length < 1)
                    continue;
                for (let i = 0; i < xmlRows.length; i++) {
                    const xmlRow = xmlRows.item(i);
                    if (xmlRow == null)
                        continue;
                    const row = table.newRow();
                    for (let j = 0; j < xmlRow.children.length; j++) {
                        const tagName = xmlRow.children.item(j)?.tagName;
                        if (tagName) {
                            let col = table.columns.get(tagName);
                            if (!col)
                                col = table.columns.add(tagName);
                            let val = xmlRow.children.item(j)?.textContent;
                            try {
                                val = BravoDataConvertUtil.convertValue(val, col.dataType);
                            }
                            catch {
                                //
                            }
                            row && row.setValue(tagName, val);
                        }
                    }
                    table.endEdit(row);
                }
            }
        }
        else if (dsXml.children.length > 0) {
            for (let i = 0; i < dsXml.children.length; i++) {
                const xmlTable = dsXml.children.item(i);
                const tableName = xmlTable?.tagName;
                if (!tableName)
                    continue;
                let table = null;
                if (!ds.tables.contains(tableName))
                    table = ds.tables.add(tableName);
                else
                    table = ds.tables.get(tableName) || null;
                const row = table && table.newRow();
                if (xmlTable?.children.length == 0) {
                    const attrs = xmlTable.getAttributeNames();
                    for (const key of attrs) {
                        let col = table && table.columns.get(key);
                        if (!col)
                            col = table && table.columns.add(key);
                        let val = xmlTable.getAttribute(key);
                        try {
                            if (col)
                                val = BravoDataConvertUtil.convertValue(val, col.dataType);
                        }
                        catch {
                            //
                        }
                        row && row.setValue(key, val);
                    }
                }
                else {
                    if (xmlTable)
                        for (let j = 0; j < xmlTable.children.length; j++) {
                            const tagName = xmlTable.children.item(j)?.tagName;
                            if (tagName) {
                                let col = table && table.columns.get(tagName);
                                if (!col)
                                    col = table && table.columns.add(tagName);
                                let val = xmlTable.children.item(j)?.textContent;
                                try {
                                    if (col)
                                        val = BravoDataConvertUtil.convertValue(val, col.dataType);
                                }
                                catch {
                                    //
                                }
                                row && row.setValue(tagName, val);
                            }
                        }
                }
                table && table.endEdit(row);
            }
        }
    }
    static _readXmlDiffGram(pDataSet, pXml) {
        const parser = new DOMParser();
        const doc = parser.parseFromString(pXml, 'application/xml');
        const diffgram = doc.documentElement;
        const newDataSet = diffgram.querySelector('NewDataSet');
        const before = diffgram.querySelector('diffgr\\:before') || diffgram.querySelector('before');
        if (newDataSet) {
            const mapCols = new Map();
            const childTables = Array.from(newDataSet.children);
            for (const node of childTables) {
                const changes = node.getAttribute('diffgr:hasChanges');
                if (changes == 'deleted')
                    continue;
                const tableName = node.nodeName;
                let table = pDataSet.tables.get(tableName);
                if (!table) {
                    table = new BravoDataTable({ pName: tableName });
                    pDataSet.tables.add(table);
                }
                let cols = mapCols.get(table.name);
                if (!cols) {
                    cols = new Map();
                    mapCols.set(table.name, cols);
                    if (table.columns.length > 0) {
                        table.columns.forEach((pCol, pColIndex) => cols && cols.set(pCol.columnName, { index: pColIndex, type: pCol.dataType }));
                    }
                }
                const currentItem = {};
                const currentArray = [];
                for (const col of Array.from(node.children)) {
                    if (cols.size > 0) {
                        const setting = cols.get(col.nodeName);
                        if (setting)
                            currentItem[col.nodeName] = currentArray[setting.index] = BravoDataConvertUtil.convertValue(col.textContent, setting.type);
                    }
                }
                const dr = new BravoDataRow(table, currentItem);
                dr.currentItems = currentArray;
                if (before?.children) {
                    const nodeOri = Array.from(before.children).find(p => p.nodeName === node.nodeName &&
                        p.getAttribute('msdata:rowOrder') === node.getAttribute('msdata:rowOrder'));
                    if (nodeOri) {
                        for (const col of Array.from(nodeOri.children)) {
                            const setting = cols.get(col.nodeName);
                            if (setting)
                                dr.originalItems[setting.index] = BravoDataConvertUtil.convertValue(col.textContent, setting.type);
                        }
                    }
                }
                if (changes == 'modified')
                    dr.rowState = DataRowStateEnum.Modified;
                else if (changes == 'inserted')
                    dr.rowState = DataRowStateEnum.Added;
                table.sourceCollection?.push(dr.item);
                table.rows.push(dr);
                if (table.currentPosition == -1) {
                    table.moveCurrentToFirst();
                }
            }
        }
    }
}
class StringWriter {
    _encoded;
    get encoded() {
        return this._encoded;
    }
    set encoded(pValue) {
        this._encoded = pValue;
    }
    _stringBuilder = null;
    get stringBuilder() {
        return this._stringBuilder;
    }
    set stringBuilder(pValue) {
        this._stringBuilder = pValue;
    }
    _format;
    get format() {
        return this._format;
    }
    set format(pValue) {
        this._format = pValue;
    }
    constructor(pStringBuilder, pFormat) {
        if (pStringBuilder)
            this._stringBuilder = pStringBuilder;
        if (pFormat)
            this._format = pFormat;
    }
    close() {
        if (this.stringBuilder)
            this.stringBuilder.clear();
    }
}
function convertTypeCode(pDataType) {
    let result = '';
    switch (pDataType) {
        case TypeCodeEnum.DateTime:
            result = 'dateTime';
            break;
        case TypeCodeEnum.Int16:
            result = 'int';
            break;
        case TypeCodeEnum.Int32:
            result = 'int';
            break;
        case TypeCodeEnum.Int64:
            result = 'int';
            break;
        case TypeCodeEnum.String:
            result = 'string';
            break;
        case TypeCodeEnum.Boolean:
            result = 'boolean';
            break;
        case TypeCodeEnum.Double:
            result = 'double';
            break;
        case TypeCodeEnum.Byte:
            result = 'unsignedByte';
            break;
        case TypeCodeEnum.Decimal:
            result = 'decimal';
            break;
        case TypeCodeEnum.Object:
            result = 'string';
            break;
        case TypeCodeEnum.ByteArray:
            result = 'base64Binary';
            break;
        default:
            break;
    }
    return result;
}
function getStringType(pAttr) {
    if (!pAttr || !pAttr.startsWith('xs:'))
        return pAttr;
    return pAttr.substring('xs:'.length);
}
function convertStringToType(pzType) {
    switch (pzType) {
        case 'dateTime':
            return TypeCodeEnum.DateTime;
        case 'int':
            return TypeCodeEnum.Int32;
        case 'string':
            return TypeCodeEnum.String;
        case 'boolean':
            return TypeCodeEnum.Boolean;
        case 'double':
            return TypeCodeEnum.Double;
        case 'unsignedByte':
            return TypeCodeEnum.Byte;
        case 'decimal':
            return TypeCodeEnum.Decimal;
        case 'base64Binary':
            return TypeCodeEnum.ByteArray;
        default:
            return TypeCodeEnum.String;
    }
}
const _ENTITYMAP = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;',
    '/': '&#x2F;',
};
function escapeXml(pText) {
    if (BravoStringExtensions.isString(pText)) {
        pText = pText.replace(/[&<>"']/g, function (s) {
            return _ENTITYMAP[s];
        });
    }
    return BravoStringExtensions.format('{0}', pText);
}

/**
 * Generated bundle index. Do not edit.
 */

export { AttributeNameEnum, BravoJsonSerializer, BravoLayoutData, BravoLayoutDataInterfaceName, BravoLayoutItem, BravoLayoutItemUtil, BravoResponseData, BravoXmlHelper, ExpressionParam, ExpressionSerializer, LAYOUT_K, RootName, StringWriter, containsPropertyValue, convertStringToType, escapeXml, getPropertyValue };
//# sourceMappingURL=bravo-infra-core-serializations.mjs.map
