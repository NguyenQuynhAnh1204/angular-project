import { IBravoExpressionBase, BrSafeAny, ITryCastPattern } from '@bravo-infra/core/definition';
import { ICollectionView, IEditableCollectionView, CollectionView, CollectionViewGroup, SortDescription, PropertyGroupDescription, NotifyCollectionChangedEventArgs } from '@mescius/wijmo';
import { ObservableArray, NotifyCollectionChangedActionEnum } from '@bravo-infra/core/utils/data-extensions';
import * as _bravo_infra_core_data from '@bravo-infra/core/data';
import * as rxjs from 'rxjs';
import { Observable } from 'rxjs';
import { BravoListChangedEventArgs, BravoCancelEventArgs, BravoDataEventArgs, BravoEventArgs } from '@bravo-infra/core/helper';
import { BravoCultureType } from '@bravo-infra/core/utils/global-settings';

declare enum TypeCodeEnum {
    Empty = 0,
    Object = 1,
    DBNull = 2,
    Boolean = 3,
    Char = 4,
    SByte = 5,
    Byte = 6,
    Int16 = 7,
    UInt16 = 8,
    Int32 = 9,
    UInt32 = 10,
    Int64 = 11,
    UInt64 = 12,
    Single = 13,
    Double = 14,
    Decimal = 15,
    DateTime = 16,
    String = 18,
    ByteArray = 19
}

declare enum DataRowStateEnum {
    Detached = 1,
    Unchanged = 2,
    Added = 4,
    Deleted = 8,
    Modified = 16
}

declare enum DataRowVersionEnum {
    Original = 256,
    Current = 512,
    Proposed = 1024,
    Default = 1536
}

declare enum DataRowActionEnum {
    Nothing = 0,
    Delete = 1,
    Change = 2,
    Rollback = 4,
    Commit = 8,
    Add = 16,
    ChangeOriginal = 32,
    ChangeCurrentAndOriginal = 64
}

declare enum RuleEnum {
    None = 0,
    Cascade = 1,
    SetNull = 2,
    SetDefault = 3
}

declare enum MissingSchemaActionEnum {
    Add = 1,
    Ignore = 2,
    Error = 3,
    AddWithKey = 4
}

declare enum BravoXmlStringTypeEnum {
    AttributeMapping = 0,
    ElementMappingWithSchema = 1
}
declare enum XmlWriteModeEnum {
    WriteSchema = 0,
    IgnoreSchema = 1,
    DiffGram = 2
}
declare enum XmlReadModeEnum {
    Auto = 0,
    ReadSchema = 1,
    IgnoreSchema = 2,
    InferSchema = 3,
    DiffGram = 4,
    Fragment = 5,
    InferTypedSchema = 6
}

declare enum DataViewRowStateEnum {
    None = 0,
    Unchanged = 2,
    Added = 4,
    Deleted = 8,
    ModifiedCurrent = 16,
    CurrentRows = 22,
    ModifiedOriginal = 32,
    OriginalRows = 42
}

declare enum DbTypeEnum {
    AnsiString = 0,
    Binary = 1,
    Byte = 2,
    Boolean = 3,
    Currency = 4,
    Date = 5,
    DateTime = 6,
    Decimal = 7,
    Double = 8,
    Guid = 9,
    Int16 = 10,
    Int32 = 11,
    Int64 = 12,
    Object = 13,
    SByte = 14,
    Single = 15,
    String = 16,
    Time = 17,
    UInt16 = 18,
    UInt32 = 19,
    UInt64 = 20,
    VarNumeric = 21,
    AnsiStringFixedLength = 22,
    StringFixedLength = 23,
    Xml = 25,
    DateTime2 = 26,
    DateTimeOffset = 27
}

declare enum SerializeOptionEnum {
    Data = 1,
    Schema = 2,
    Relations = 4,
    ExtendedProperties = 8,
    ViewSort = 16,
    SuspendConstraint = 32,
    AcceptChanges = 64,
    Insert = 128,
    CreateNonExistTable = 256,
    RowState = 512,
    Default = 99,
    All = 123
}

declare enum ParameterDirectionEnum {
    Input = 1,
    Output = 2,
    InputOutput = 3,
    ReturnValue = 6
}

declare enum CommandTypeEnum {
    Procedure = 0,
    Function = 1,
    Insert = 2,
    Update = 3,
    Api = 4
}

declare enum UpdateRowSourceEnum {
    None = 0,
    OutputParameters = 1,
    FirstReturnedRecord = 2,
    Both = 3
}

declare enum IsolationLevelEnum {
    Unspecified = -1,
    Chaos = 16,
    ReadUncommitted = 256,
    ReadCommitted = 4096,
    RepeatableRead = 65536,
    Serializable = 1048576,
    Snapshot = 16777216
}

interface IBravoDataColumn {
    columnName: string;
    dataType: TypeCodeEnum;
    defaultValue: unknown;
    allowDBNull: boolean;
    readOnly: boolean;
    expression: unknown;
    caption?: string;
    autoIncrement: boolean;
    autoIncrementSeed: number;
    autoIncrementStep: number;
    table: unknown;
    unique: boolean;
    ordinal: number;
    maxLength: number;
    get extendedProperties(): Map<string, unknown>;
}

interface IBravoDataColumnCollection extends ObservableArray<IBravoDataColumn> {
    add(pColumn: IBravoDataColumn): IBravoDataColumn;
    add(pColumn: string): IBravoDataColumn;
    add(pColumn: string, pType: number, pExpression?: string): IBravoDataColumn;
    contains(name: string): boolean;
    get(pColumnName: string): IBravoDataColumn | undefined;
}

interface IBravoConstraint {
    get inCollection(): boolean;
    dispose(): void;
    constraintName: string;
}

interface IBravoDataKey {
    getColumnNames(): string[];
}

interface IBravoDataRow {
    item: Record<string, unknown>;
    rowState: DataRowStateEnum;
    currentItems: unknown[];
    originalItems: unknown[];
    get table(): IBravoDataTable;
    get hasErrors(): boolean;
    endEdit(pColumn?: string): void;
    isNull(column: string | IBravoDataColumn, pVersion?: DataRowVersionEnum): boolean;
    getValue(key: string | IBravoDataColumn | number, pVersion?: DataRowVersionEnum, pisConvert?: boolean): unknown;
    setValue(key: string | number | IBravoDataColumn, value: unknown, forceUpdate?: boolean): void;
    getParentRow(pRelation: IBravoDataRelation, pVersion?: DataRowVersionEnum): IBravoDataRow | undefined;
    getChildRows(pRelation: IBravoDataRelation, pVersion?: DataRowVersionEnum): IBravoDataRow[];
    delete(): void;
    hasVersion(pVersion: DataRowVersionEnum): boolean;
    getColumnError(pColumn: unknown): string;
    setColumnError(pColumn: unknown, pzError: string | null): void;
}

interface IBravoForeignKeyConstraint extends IBravoConstraint {
    columns: IBravoDataColumn[];
    updateRule: RuleEnum;
    deleteRule: RuleEnum;
    cascadeUpdate(row: IBravoDataRow, col?: string, value?: unknown): void;
}

interface IBravoUniqueConstraint extends IBravoConstraint {
}

interface IBravoConstraintCollection extends ObservableArray<IBravoConstraint> {
    findKeyConstraint(pColumns: Array<IBravoDataColumn>): IBravoUniqueConstraint | null;
    findForeignKeyConstraint(pParentColumns: Array<IBravoDataColumn>, pChildColumns: Array<IBravoDataColumn>): IBravoForeignKeyConstraint | null;
    add(pConstraint: IBravoConstraint, pAddUniqueWhenAddingForeign?: boolean): void;
}

interface IBravoDataRelationCollection extends ObservableArray<IBravoDataRelation> {
    add(pRelation: string | IBravoDataRelation, pParentColumn?: IBravoDataColumn[], pChildColumn?: IBravoDataColumn[]): IBravoDataRelation;
    get(pKey: string): IBravoDataRelation | undefined;
    contains(pName: string): boolean;
}

interface IBravoDataRowCollection extends ObservableArray<IBravoDataRow> {
}

interface IBravoDataTableCollection extends ObservableArray<IBravoDataTable> {
    contains(pTableName: string): boolean;
    get(pTableName: string): IBravoDataTable | undefined;
}

interface IBravoDataSet {
    get tables(): IBravoDataTableCollection;
    get relations(): IBravoDataRelationCollection;
    get expressionEvaluator(): IBravoExpressionBase | undefined;
    name?: string;
    enforceConstraints: boolean;
    ignoreDefaultValue: boolean;
}

interface IBravoCollectionView extends ICollectionView {
}

interface IBravoDataTable extends IBravoCollectionView {
    name: string;
    isUpdating: boolean;
    currentItem: unknown;
    primaryKey: IBravoDataColumn[];
    get dataSet(): IBravoDataSet;
    get columns(): IBravoDataColumnCollection;
    get rows(): IBravoDataRowCollection;
    get extendedProperties(): Map<string, unknown>;
    get childRelations(): IBravoDataRelationCollection;
    get parentRelations(): IBravoDataRelationCollection;
    get constraints(): IBravoConstraintCollection;
    get defaultView(): IBravoCollectionView;
    endEdit(item: IBravoDataRow): void;
    newRowTemplate(item?: unknown): IBravoDataRow;
    newRow(): IBravoDataRow | undefined;
    addNew(): unknown;
    clone(): IBravoDataTable;
    onRefreshingViewRelation(): void;
    onRefreshViewRelation(): void;
    select(pFilterExpression: string | null, pSort?: string | null, pRecordStates?: DataViewRowStateEnum, pExpressionEvaluator?: IBravoExpressionBase): IBravoDataRow[];
}

interface IBravoDataRelation {
    childConstrainKey: IBravoForeignKeyConstraint;
    get childKey(): IBravoDataKey | undefined;
    get parentKey(): IBravoDataKey | undefined;
    get relationName(): string;
    get childTable(): IBravoDataTable | undefined;
    get parentTable(): IBravoDataTable | undefined;
}

interface IBravoBindingList {
    listChanged$: Observable<BravoListChangedEventArgs>;
    getCollection?(): unknown;
    dispose(): void;
}

interface IBravoEditableCollectionView<T = BrSafeAny> extends IEditableCollectionView<T> {
}

declare class BravoCollectionView<T = BrSafeAny> extends CollectionView<T> implements IBravoCollectionView {
}

declare class BravoCollectionViewGroup extends CollectionViewGroup {
}

declare class BravoSortDescription extends SortDescription {
}

declare class BravoPropertyGroupDescription extends PropertyGroupDescription {
}

declare class BravoDataColumn implements IBravoDataColumn {
    #private;
    get table(): IBravoDataTable;
    get columnName(): string;
    set columnName(pValue: string);
    get dataType(): TypeCodeEnum;
    set dataType(pValue: TypeCodeEnum);
    get maxLength(): number;
    set maxLength(pValue: number);
    get defaultValue(): unknown;
    set defaultValue(pVal: unknown);
    get errors(): number;
    set errors(pVal: number);
    get ordinal(): number;
    get autoInc(): AutoIncrementValue;
    get autoIncrement(): boolean;
    set autoIncrement(pVal: boolean);
    get autoIncrementSeed(): number;
    set autoIncrementSeed(pVal: number);
    get autoIncrementStep(): number;
    set autoIncrementStep(pVal: number);
    get allowDBNull(): boolean;
    set allowDBNull(pVal: boolean);
    get caption(): string | undefined;
    set caption(pVal: string | undefined);
    get readOnly(): boolean;
    set readOnly(pVal: boolean);
    get unique(): boolean;
    set unique(pVal: boolean);
    get expression(): string;
    set expression(pVal: string);
    get extendedProperties(): Map<string, unknown>;
    init(pItem: Record<string, unknown>): void;
    setUnique(pVal: boolean, pbManualCheck?: boolean): void;
    constructor(pName: string, pType?: TypeCodeEnum);
    setTable(pTable: IBravoDataTable): void;
    setOrdinal(pos: number): void;
    copy(pColumn: IBravoDataColumn): void;
    dispose(): void;
    implementsInterface(pInterfaceName: string): boolean;
}
declare class AutoIncrementValue {
    #private;
    get auto(): boolean;
    set auto(pVal: boolean);
    get current(): number;
    set current(pVal: number);
    get seed(): number;
    set seed(pValue: number);
    get step(): number;
    set step(pValue: number);
    moveAfter(): void;
    setCurrentAndIncrement(pVal: number): void;
}

declare class BravoDataColumnCollection extends ObservableArray<BravoDataColumn> implements IBravoDataColumnCollection {
    #private;
    get count(): number;
    private _isUsingExpression;
    get isUsingExpression(): boolean;
    constructor(pTable: IBravoDataTable);
    add(pColumn: BravoDataColumn): BravoDataColumn;
    add(pColumn: string): BravoDataColumn;
    add(pColumn: string, pType: number, pExpression?: string): BravoDataColumn;
    remove(pColumn: BravoDataColumn): boolean;
    get(pColumnName: string): BravoDataColumn | undefined;
    getIndex(pColumn: BravoDataColumn | string): number;
    contains(pName: string): boolean;
    dispose(): void;
}

declare class BravoConstraint implements IBravoConstraint {
    #private;
    dispose(): void;
    get constraintName(): string;
    set constraintName(pVal: string);
    protected _inCollection: boolean;
    get inCollection(): boolean;
    set inCollection(pValue: boolean);
}

declare class BravoDataKey implements IBravoDataKey {
    constructor(pColumns: IBravoDataColumn[], pCopyColumns: boolean);
    private _columns;
    get columns(): IBravoDataColumn[];
    get columnsReference(): Array<IBravoDataColumn>;
    get table(): IBravoDataTable;
    columnsEqual(pKey: BravoDataKey): boolean;
    private static _columnsEqual;
    getColumnNames(): string[];
    toArray(): IBravoDataColumn[];
    dispose(): void;
}

declare class BravoDataRelation implements IBravoDataRelation {
    #private;
    createConstraints?: boolean;
    get childKey(): BravoDataKey | undefined;
    get parentKey(): BravoDataKey | undefined;
    get parentColumns(): IBravoDataColumn[];
    get childColumns(): IBravoDataColumn[];
    get parentTable(): _bravo_infra_core_data.IBravoDataTable | undefined;
    get childTable(): _bravo_infra_core_data.IBravoDataTable | undefined;
    get relationName(): string;
    get parentConstrainKey(): IBravoUniqueConstraint;
    get childConstrainKey(): IBravoForeignKeyConstraint;
    get dataSet(): IBravoDataSet;
    setDataSet(pDataSet: IBravoDataSet): void;
    setParentKeyConstraint(pVal: IBravoUniqueConstraint): void;
    setChildKeyConstraint(pVal: IBravoForeignKeyConstraint): void;
    constructor(pRelationName: string, pParentColumns?: Array<IBravoDataColumn>, pChildColumns?: Array<IBravoDataColumn>, pCreateConstraints?: boolean);
    dispose(): void;
    implementsInterface(pInterfaceName: string): boolean;
}

declare class BravoDataRelationCollection extends ObservableArray<BravoDataRelation> {
    get(pKey: string): BravoDataRelation | undefined;
    add(pRelation: BravoDataRelation): BravoDataRelation;
    add(pRelation: string, pParentColumn: IBravoDataColumn[], pChildColumn: IBravoDataColumn[]): BravoDataRelation;
    getDataSet(): IBravoDataSet | undefined;
    protected _addCore(pRelation?: BravoDataRelation): void;
    contains(pName: string): boolean;
    protected _internalIndexOf(pName: string): number;
    isChildTable(pzTableName: string): boolean;
    dispose(): void;
}
declare class BravoDataTableRelationCollection extends BravoDataRelationCollection {
    #private;
    private _isParentCollection;
    constructor(pTable: IBravoDataTable, pIsParentCollection: boolean);
    protected _addCore(pRelation: BravoDataRelation): void;
    getDataSet(): IBravoDataSet;
    get(pKey: number | string): BravoDataRelation | undefined;
    dispose(): void;
}
declare class BravoDataSetRelationCollection extends BravoDataRelationCollection {
    private _dataSet;
    constructor(pDataSet: IBravoDataSet);
    protected _addCore(pRelation: BravoDataRelation): void;
    getDataSet(): IBravoDataSet;
}

declare class BravoUniqueConstraint extends BravoConstraint implements IBravoUniqueConstraint {
    #private;
    get isPrimaryKey(): boolean;
    get key(): BravoDataKey;
    get columns(): Array<IBravoDataColumn>;
    get inCollection(): boolean;
    set inCollection(pVal: boolean);
    constructor(pName?: string, pIsPrimaryKey?: boolean, ...pColumns: Array<IBravoDataColumn>);
    create(pConstraintName: string, ...pColumns: Array<IBravoDataColumn>): void;
    private _checkUniqueByConstraint;
    dispose(): void;
    private static _getKey;
    implementsInterface(pInterfaceName: string): boolean;
}

declare class BravoConstraintCollection extends ObservableArray<BravoConstraint> implements IBravoConstraintCollection {
    #private;
    add(pConstraint: BravoConstraint, pAddUniqueWhenAddingForeign?: boolean): void;
    findKeyConstraint(pColumns: Array<IBravoDataColumn>): BravoUniqueConstraint | null;
    findForeignKeyConstraint(pParentColumns: Array<IBravoDataColumn>, pChildColumns: Array<IBravoDataColumn>): BravoForeignKeyConstraint | null;
    dispose(): void;
}

declare class BravoDataColumnChangeEventArgs extends BravoCancelEventArgs {
    constructor(pRow: IBravoDataRow, pCol: IBravoDataColumn, pValue: unknown, pItem?: Record<string, unknown>);
    private _item?;
    get item(): Record<string, unknown> | undefined;
    private _col;
    get col(): IBravoDataColumn;
    private _row;
    get row(): IBravoDataRow;
    private _proposedValue;
    get proposedValue(): unknown;
    set proposedValue(pValue: unknown);
}

declare class BravoDataRowChangeEventArgs extends BravoCancelEventArgs {
    readonly row: IBravoDataRow;
    readonly action: DataRowActionEnum;
    constructor(pRow: IBravoDataRow, pAction: DataRowActionEnum);
}

declare class BravoDataTable extends BravoCollectionView implements IBravoDataTable {
    #private;
    constructor({ pName, pSourceCollection, pExpressionEvaluator, }?: {
        pName?: string;
        pSourceCollection?: unknown[];
        pExpressionEvaluator?: IBravoExpressionBase;
    });
    isOverrideCreateGroup: boolean;
    get expressionEvaluator(): IBravoExpressionBase | undefined;
    private readonly _refreshViewRelation$;
    get refreshViewRelation$(): rxjs.Observable<unknown>;
    onRefreshViewRelation(): void;
    private readonly _refreshingViewRelation$;
    get refreshingViewRelation$(): rxjs.Observable<unknown>;
    onRefreshingViewRelation(): void;
    private readonly _recordChanging$;
    get recordChanging$(): rxjs.Observable<unknown>;
    onRecordChanging(pEventArgs: BravoDataEventArgs): void;
    private readonly _recordChanged$;
    get recordChanged$(): rxjs.Observable<unknown>;
    onRecordChanged(): void;
    private readonly _commitEdit$;
    get commitEdit$(): rxjs.Observable<BravoDataEventArgs<any, any>>;
    raiseCommitEdit(pEventArgs: BravoDataEventArgs): void;
    private readonly _listChanged$;
    get listChanged$(): rxjs.Observable<BravoListChangedEventArgs>;
    onListChanged(pEventArgs: BravoListChangedEventArgs): void;
    private readonly _columnChanging$;
    get columnChanging$(): rxjs.Observable<BravoDataColumnChangeEventArgs>;
    onColumnChanging(pEventArgs: BravoDataColumnChangeEventArgs): void;
    private readonly _columnChanged$;
    get columnChanged$(): rxjs.Observable<BravoDataColumnChangeEventArgs>;
    onColumnChanged(pEventArgs: BravoDataColumnChangeEventArgs): void;
    private readonly _rowChanging$;
    get rowChanging$(): rxjs.Observable<BravoDataRowChangeEventArgs>;
    onRowChanging(pEventArgs: BravoDataRowChangeEventArgs | null, pRow: BravoDataRow, pAction: DataRowActionEnum): BravoDataRowChangeEventArgs;
    private readonly _rowChanged$;
    get rowChanged$(): rxjs.Observable<BravoDataRowChangeEventArgs>;
    onRowChanged(pEventArgs: BravoDataRowChangeEventArgs | null, pRow: BravoDataRow, pAction: DataRowActionEnum): BravoDataRowChangeEventArgs;
    private readonly _rowDeleting$;
    get rowDeleting$(): rxjs.Observable<BravoDataRowChangeEventArgs>;
    protected _onRowDeleting(pEventArgs: BravoDataRowChangeEventArgs): boolean;
    private readonly _rowDeleted$;
    get rowDeleted$(): rxjs.Observable<BravoDataRowChangeEventArgs>;
    protected _onRowDeleted(pEventArgs: BravoDataRowChangeEventArgs): void;
    private readonly _currentChanged$;
    get currentChanged$(): rxjs.Observable<unknown>;
    get childRelations(): BravoDataRelationCollection;
    get parentRelations(): BravoDataRelationCollection;
    get defaultView(): BravoCollectionView;
    get dataSet(): IBravoDataSet;
    setDataSet(pDataSet: IBravoDataSet): void;
    get constraints(): BravoConstraintCollection;
    get columns(): BravoDataColumnCollection;
    get rows(): BravoDataRowCollection;
    get row(): BravoDataRow | undefined;
    get primaryKey(): IBravoDataColumn[];
    set primaryKey(pVal: IBravoDataColumn[]);
    get name(): string;
    set name(pVal: string);
    get displayExpression(): string;
    set displayExpression(pVal: string);
    get extendedProperties(): Map<string, unknown>;
    get viewSort(): string;
    set viewSort(pVal: string);
    get hasErrors(): boolean;
    private _rowFilterFn;
    addNew(): any;
    newRow(): BravoDataRow | undefined;
    newRowTemplate(pItem?: Record<string, unknown>): BravoDataRow;
    select(pFilterExpression?: string | null, pSort?: string | null, pRecordStates?: DataViewRowStateEnum, pExpressionEvaluator?: IBravoExpressionBase): Array<BravoDataRow>;
    find(...pKeys: Array<unknown>): BravoDataRow | undefined;
    endEdit(pItem: IBravoDataRow | Record<string, unknown>): void;
    commitEdit(pColumn?: string | BravoDataColumn): void;
    commitNew(): void;
    cancelNew(): void;
    acceptChanges(): void;
    commitRow(pRow: BravoDataRow): void;
    newItemCreator: () => {};
    remove(pItem: Record<string, unknown>): void;
    getErrors(): Array<BravoDataRow>;
    clone(): BravoDataTable;
    dispose(): void;
    onCurrentChanged(pEventArgs?: BravoEventArgs): void;
    moveCurrentToPosition(pIndex: number): boolean;
    _sameValue(pVal1: unknown, pVal2: unknown, pLevel?: number): boolean;
    _extend(pDest: Record<string, unknown>, pSource: Record<string, unknown>, pLevel?: number): Record<string, unknown>;
    loadDataRow(pItem: BravoDataRow | Record<string, unknown>, pbAcceptChanges: boolean): BravoDataRow | null | undefined;
    merge(pTable: BravoDataTable | Array<Record<string, unknown>>, pPreserveChanges?: boolean, pMissingSchemaAction?: MissingSchemaActionEnum, pSetDefaultValue?: boolean): void;
    private _mergeColumn;
    mergeRows(pRows: Array<BravoDataRow>, pPreserveChanges?: boolean, pMissingSchemaAction?: MissingSchemaActionEnum): void;
    private _mergeArray;
    private _mergeRow;
    private _addRow;
    copy(): BravoDataTable;
    clear(): void;
    onCollectionChanged(pEventArgs?: NotifyCollectionChangedEventArgs<any>): void;
    handleCollectionChanged(pSource: Array<unknown>, pEventArgs: NotifyCollectionChangedEventArgs): void;
    refreshBindingData(): void;
    implementsInterface(pInterfaceName: string): boolean;
    getCollection(): this;
    writeJson(): string | null;
    static findIndexByPrimaryKey(pTable: BravoDataTable, pCollection: Array<Record<string, unknown>>, pItem: Record<string, unknown> | null, primaryKey?: Array<BravoDataColumn>): number;
    private static _getKey;
}

declare class BravoDataTableCollection extends ObservableArray<BravoDataTable> implements IBravoDataTableCollection {
    private _dataSet;
    constructor(pDataSet: IBravoDataSet);
    add(pTable?: string | BravoDataTable): BravoDataTable;
    contains(pTableName: string): boolean;
    get(pTableName: string): BravoDataTable | undefined;
}

declare const RowIndexProp = "_______idxr";
declare class BravoDataRow implements IBravoDataRow {
    #private;
    readonly item: Record<string, unknown>;
    static isRowIndexProp(pzKey: string): boolean;
    constructor(pTable: BravoDataTable, pItem?: Record<string, unknown>);
    private readonly _columns;
    get rowState(): DataRowStateEnum;
    set rowState(pState: DataRowStateEnum);
    get hasErrors(): boolean;
    get table(): BravoDataTable;
    get currentItems(): Array<unknown>;
    set currentItems(pValue: Array<unknown>);
    get originalItems(): Array<unknown>;
    set originalItems(pValue: Array<unknown>);
    get defaultItems(): unknown[] | undefined;
    private _rowError?;
    get rowError(): string | undefined;
    set rowError(pValue: string | undefined);
    endEdit(pColumn?: string): void;
    commitRow(pColumn?: string): void;
    getParentRow(pRelation: IBravoDataRelation, pVersion?: DataRowVersionEnum): BravoDataRow | undefined;
    getChildRowsByRelationName(pRelationName: string, pVersion?: DataRowVersionEnum): BravoDataRow[] | undefined;
    getChildRows(pRelation: BravoDataRelation, pVersion?: DataRowVersionEnum): BravoDataRow[];
    getValue<T = unknown>(pKey: string | IBravoDataColumn | number, pVersion?: DataRowVersionEnum, pbConvert?: boolean): T;
    isNull(pColumn: string | BravoDataColumn, pVersion?: DataRowVersionEnum): boolean;
    delete(): void;
    rejectChanges(): void;
    setAdded(): void;
    setModified(): void;
    setValue(pKey: string | number | IBravoDataColumn, pValue: unknown): void;
    hasVersion(pVersion: DataRowVersionEnum): boolean;
    setColumnError(pColumnIndex: number, pzError: string | null): void;
    setColumnError(pColumnName: string, pzError: string | null): void;
    setColumnError(pColumn: BravoDataColumn, pzError: string | null): void;
    getColumnError(pColumnIndex: number): string;
    getColumnError(pColumnName: string): string;
    getColumnError(pColumn: BravoDataColumn): string;
    clearErrors(): void;
    getColumnsInError(): BravoDataColumn[] | undefined;
    acceptChanges(): void;
    implementsInterface(pInterfaceName: string): boolean;
}

declare class BravoDataRowCollection extends ObservableArray<BravoDataRow> implements IBravoDataRowCollection {
    #private;
    constructor(pTable: IBravoDataTable);
    get count(): number;
    add(pRow?: BravoDataRow): void;
    push(...pRows: BravoDataRow[]): number;
    static getRow(pItem: Record<string, unknown>, pRowCollection: BravoDataRowCollection): BravoDataRow | undefined;
}

declare class BravoForeignKeyConstraint extends BravoConstraint implements IBravoForeignKeyConstraint {
    #private;
    get childKey(): BravoDataKey;
    get columns(): IBravoDataColumn[];
    get table(): _bravo_infra_core_data.IBravoDataTable;
    get childColumnsName(): string[];
    get parentKey(): BravoDataKey;
    get relatedColumns(): IBravoDataColumn[];
    get relatedTable(): _bravo_infra_core_data.IBravoDataTable;
    get updateRule(): RuleEnum;
    set updateRule(pVal: RuleEnum);
    get deleteRule(): RuleEnum;
    set deleteRule(pVal: RuleEnum);
    constructor(pName: string, pParentColumns: IBravoDataColumn[], pChildColumns: IBravoDataColumn[]);
    create(pName: string, parentColumns: IBravoDataColumn[], pChildColumns: IBravoDataColumn[]): void;
    cascadeUpdate(pRow: BravoDataRow, pCol?: string, pValue?: unknown): void;
    checkConstraint(pRow: IBravoDataRow, pAction: NotifyCollectionChangedActionEnum): boolean;
    dispose(): void;
}

declare class BravoDataParameter {
    private _implicitDbType;
    private _getDbType;
    private _explicitDbType;
    get dbType(): DbTypeEnum;
    set dbType(pVal: DbTypeEnum);
    private _direction;
    get direction(): ParameterDirectionEnum;
    set direction(pVal: ParameterDirectionEnum);
    isNullable: boolean;
    size: number;
    sourceColumn: string;
    private _sourceVersion;
    get sourceVersion(): DataRowVersionEnum;
    set sourceVersion(pVal: DataRowVersionEnum);
    parameterName: string;
    value: unknown;
    scale: unknown;
    precision: unknown;
}
declare class BravoParameterCollection extends Array<BravoDataParameter> {
    get(pzParameterName: string): BravoDataParameter | undefined;
}

declare class BravoDataCommand {
    commandTimeout: number;
    commandType: CommandTypeEnum;
    updatedRowSource: UpdateRowSourceEnum;
    commandText: string;
    parameters: BravoParameterCollection;
    transactionLevel: IsolationLevelEnum;
    connection: unknown;
    constructor();
    clone(): BravoDataCommand;
    implementsInterface(pInterfaceName: string): boolean;
}

declare class BravoDataParameterUtil {
    static convertParameterName(pzName: string): string;
    static extractParameterName(pzParameterName: string): string;
}

declare class BravoDataSet implements IBravoDataSet {
    #private;
    get isInitialized(): boolean;
    get caseSensitive(): boolean;
    set caseSensitive(pValue: boolean);
    get expressionEvaluator(): IBravoExpressionBase | undefined;
    prefix?: string;
    get tables(): BravoDataTableCollection;
    get hasErrors(): boolean;
    private _extendedProperties?;
    get extendedProperties(): Map<string, unknown>;
    private _relationCollection;
    get relations(): BravoDataRelationCollection;
    get name(): string | undefined;
    set name(pVal: string | undefined);
    get enforceConstraints(): boolean;
    set enforceConstraints(pVal: boolean);
    get ignoreDefaultValue(): boolean;
    set ignoreDefaultValue(pVal: boolean);
    constructor({ pName, pExpressionEvaluator }?: {
        pName?: string;
        pExpressionEvaluator?: IBravoExpressionBase;
    });
    beginUpdate(): void;
    endUpdate(): void;
    beginInit(): void;
    clone(): BravoDataSet;
    copy(): BravoDataSet;
    merge(pData: BravoDataSet | BravoDataTable, pPreserveChanges?: boolean, pMissingSchemaAction?: MissingSchemaActionEnum, pSetDefaultValue?: boolean): void;
    mergeRows(pRows: Array<BravoDataRow>, pPreserveChanges?: boolean, pMissingSchemaAction?: MissingSchemaActionEnum): void;
    clear(): void;
    dispose(): void;
    endInit(): void;
    writeJson(pbFormat?: boolean, pbReturnBuffer?: boolean): string | Uint8Array<ArrayBufferLike> | null;
    acceptChanges(): void;
    hasChanges(pRowState?: DataRowStateEnum): boolean;
    writeXml(pMode?: XmlWriteModeEnum): void;
    readXml(pzContent: string, mode?: XmlReadModeEnum): void;
    implementsInterface(pInterfaceName: string): boolean;
}

declare class BravoDataView extends BravoCollectionView implements IBravoBindingList, ITryCastPattern {
    private static _filterWithRelation;
    private readonly _listChanged$;
    get listChanged$(): rxjs.Observable<BravoListChangedEventArgs>;
    onListChanged(pEventArgs: BravoListChangedEventArgs): void;
    getCollection(): IBravoCollectionView;
    getRows(): BravoDataRow[] | undefined;
    private _table?;
    get table(): BravoDataTable | undefined;
    private _expressionEvaluator?;
    private get expressionEvaluator();
    private _rowFilter;
    get rowFilter(): string;
    set rowFilter(pVal: string);
    get currentEditItem(): BrSafeAny;
    set currentEditItem(pVal: BrSafeAny);
    get sort(): string;
    set sort(pVal: string);
    constructor(pSourceCollection?: unknown, pOptions?: unknown);
    private _handleTableRefreshViewRelation;
    commitNew(): void;
    moveCurrentToPosition(pIndex: number): boolean;
    _sameValue(pVal1: unknown, pVal2: unknown, pLevel?: number): boolean;
    _extend(pDest: Record<string, unknown>, pSource: Record<string, unknown>, pLevel?: number): Record<string, unknown>;
    newItemCreator: () => Record<string, unknown>;
    remove(pItem: Record<string, unknown>): void;
    _createGroups(pItems: Array<unknown>): BravoCollectionViewGroup[] | null;
    private getGroup;
    _compareItems(): (a: any, b: any) => number;
    private _sortCmp;
    _performFilter(pItems: unknown[]): any[];
    private _filterRelation;
    onCurrentChanged(pEventArgs?: BravoEventArgs): void;
    onCollectionChanged(pEventArgs: BrSafeAny): void;
    addNew(): any;
    private _rowFilterFn;
    dispose(): void;
    implementsInterface(pInterfaceName: string): boolean;
}

declare class BravoDataRowView {
    readonly row?: BravoDataRow;
    private readonly _dataSource;
    constructor(pSource?: unknown, pRow?: BravoDataRow);
    get dataView(): BravoDataView | null;
    setValue(pKey: string, pValue: unknown): void;
    endEdit(): void;
}

declare const BravoDataInterfaceNamingConstants: {
    IDataTable: string;
    IDataSet: string;
    IDataRow: string;
    IDataRowView: string;
    IDataColumn: string;
    IDataRelation: string;
    IDataView: string;
    IDataCommand: string;
    IUniqueConstraint: string;
    IForeignKeyConstraint: string;
    IBindingList: string;
    IBravoCollectionView: string;
    IBravoEditableCollectionView: string;
};

declare const BravoDataConstants: {
    DEFAULT_UPDATECOMMANDTIMEOUT: number;
    DEFAULT_SELECTCOMMANDTIMEOUT: number;
};

declare class BravoDataConvertUtil {
    static getType(pValue: unknown): TypeCodeEnum;
    static isDateValid(pValue: string, pFormat?: string): false | Date;
    static isNumericType(pType: TypeCodeEnum): pType is TypeCodeEnum.SByte | TypeCodeEnum.Byte | TypeCodeEnum.Int16 | TypeCodeEnum.UInt16 | TypeCodeEnum.Int32 | TypeCodeEnum.UInt32 | TypeCodeEnum.Int64 | TypeCodeEnum.UInt64 | TypeCodeEnum.Single | TypeCodeEnum.Double | TypeCodeEnum.Decimal;
    static isNumericValue(pValue: unknown, pOutArgs: {
        num: number;
    }): boolean;
    static convertValue<T>(pValue: unknown, pType: TypeCodeEnum, pCulture?: string): T;
    static compareValue(pVal1: unknown, pVal2: unknown, pType: TypeCodeEnum, pbIgnoreCaseString?: boolean): boolean;
    static isDateTimeValue(pValue: unknown, pOutArgs: {
        datetime: Date | null;
    }, pCulture?: string): boolean;
    static convertTypeCodeFromString(pzTypeCode: string): TypeCodeEnum;
    static convertDbTypeToType(pDbType: DbTypeEnum): TypeCodeEnum.Object | TypeCodeEnum.Boolean | TypeCodeEnum.SByte | TypeCodeEnum.Byte | TypeCodeEnum.Int16 | TypeCodeEnum.UInt16 | TypeCodeEnum.Int32 | TypeCodeEnum.UInt32 | TypeCodeEnum.Int64 | TypeCodeEnum.UInt64 | TypeCodeEnum.Single | TypeCodeEnum.Double | TypeCodeEnum.Decimal | TypeCodeEnum.DateTime | TypeCodeEnum.String | TypeCodeEnum.ByteArray;
}

declare class BravoFormatterUtil {
    static format(pValue: BrSafeAny, pFormat: string, pLocaleKey?: BrSafeAny, pCultureKey?: BravoCultureType): any;
}

declare const SortPattern: RegExp;
declare function getKeyValues(pKey: IBravoDataKey, pVal: IBravoDataRow | Record<string, unknown>, pVersion?: DataRowVersionEnum): any[];
declare function arraysIdentical(pArray1: unknown[], pArray2: unknown[]): boolean;
declare function buildSortString(pData: BravoCollectionView): string;
declare function buildSort(pCollection: BravoCollectionView, pSort: string): boolean | undefined;
declare function sortBy(pItemName: string, pValue1: IBravoDataRow | Record<string, unknown>, pValue2: IBravoDataRow | Record<string, unknown>, pReverse?: boolean): number;
declare function toDataRelationName(pzName: string): string;
declare function getType(pValue: unknown): TypeCodeEnum;
declare function convertTypeToDbType(pType: TypeCodeEnum): DbTypeEnum;
declare function setCurrentEditItem(pCollection: BrSafeAny, pDataRow: IBravoDataRow, pValueItem: Record<string, unknown>, pzKey?: string, pForceUpdate?: boolean): void;

export { BravoCollectionView, BravoCollectionViewGroup, BravoConstraint, BravoConstraintCollection, BravoDataColumn, BravoDataColumnChangeEventArgs, BravoDataColumnCollection, BravoDataCommand, BravoDataConstants, BravoDataConvertUtil, BravoDataInterfaceNamingConstants, BravoDataParameter, BravoDataParameterUtil, BravoDataRelation, BravoDataRelationCollection, BravoDataRow, BravoDataRowChangeEventArgs, BravoDataRowCollection, BravoDataRowView, BravoDataSet, BravoDataSetRelationCollection, BravoDataTable, BravoDataTableCollection, BravoDataTableRelationCollection, BravoDataView, BravoForeignKeyConstraint, BravoFormatterUtil, BravoParameterCollection, BravoPropertyGroupDescription, BravoSortDescription, BravoUniqueConstraint, BravoXmlStringTypeEnum, CommandTypeEnum, DataRowActionEnum, DataRowStateEnum, DataRowVersionEnum, DataViewRowStateEnum, DbTypeEnum, IsolationLevelEnum, MissingSchemaActionEnum, ParameterDirectionEnum, RowIndexProp, RuleEnum, SerializeOptionEnum, SortPattern, TypeCodeEnum, UpdateRowSourceEnum, XmlReadModeEnum, XmlWriteModeEnum, arraysIdentical, buildSort, buildSortString, convertTypeToDbType, getKeyValues, getType, setCurrentEditItem, sortBy, toDataRelationName };
export type { IBravoBindingList, IBravoCollectionView, IBravoConstraint, IBravoDataColumn, IBravoDataColumnCollection, IBravoDataKey, IBravoDataRelation, IBravoDataRow, IBravoDataRowCollection, IBravoDataSet, IBravoDataTable, IBravoDataTableCollection, IBravoEditableCollectionView, IBravoForeignKeyConstraint, IBravoUniqueConstraint };
