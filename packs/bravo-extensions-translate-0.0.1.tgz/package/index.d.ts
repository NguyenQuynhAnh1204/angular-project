import { HttpClient } from '@angular/common/http';
import { Observable, Subscription } from 'rxjs';
import * as i0 from '@angular/core';
import { InjectionToken, AfterViewChecked, OnDestroy, ElementRef, ChangeDetectorRef, PipeTransform, Provider, EnvironmentProviders, ModuleWithProviders } from '@angular/core';

declare function _<T extends string | string[]>(key: T): T;

interface MissingTranslationHandlerParams {
    /**
     * the key that's missing in translation files
     */
    key: string;
    /**
     * an instance of the service that was unable to translate the key.
     */
    translateService: TranslateService;
    /**
     * interpolation params that were passed along for translating the given key.
     */
    interpolateParams?: object;
}
declare abstract class MissingTranslationHandler {
    /**
     * A function that handles missing translations.
     *
     * @param params context for resolving a missing translation
     * @returns a value or an observable
     *
     * If it returns a value, then this value is used.
     * If it returns an observable, the value returned by this observable will be used (except if the method was "instant").
     * If it returns undefined, the key will be used as a value
     */
    abstract handle(params: MissingTranslationHandlerParams): Translation | Observable<Translation>;
}
/**
 * This handler is just a placeholder that does nothing, in case you don't need a missing translation handler at all
 */
declare class FakeMissingTranslationHandler implements MissingTranslationHandler {
    handle(params: MissingTranslationHandlerParams): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<FakeMissingTranslationHandler, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FakeMissingTranslationHandler>;
}

type InterpolateFunction = (params?: InterpolationParameters) => string;
declare abstract class TranslateParser {
    /**
     * Interpolates a string to replace parameters
     * "This is a {{ key }}" ==> "This is a value", with params = { key: "value" }
     * @param expr
     * @param params
     */
    abstract interpolate(expr: InterpolateFunction | string, params?: InterpolationParameters): string | undefined;
}
declare class TranslateDefaultParser extends TranslateParser {
    templateMatcher: RegExp;
    interpolate(expr: InterpolateFunction | string, params?: InterpolationParameters): string | undefined;
    protected interpolateFunction(fn: InterpolateFunction, params?: InterpolationParameters): string;
    protected interpolateString(expr: string, params?: InterpolationParameters): string;
    /**
     * Returns the replacement for an interpolation parameter
     * @params:
     */
    protected getInterpolationReplacement(params: InterpolationParameters, key: string): string | undefined;
    /**
     * Converts a value into a useful string representation.
     * @param value The value to format.
     * @returns A string representation of the value.
     */
    protected formatValue(value: any): string | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<TranslateDefaultParser, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TranslateDefaultParser>;
}

declare abstract class TranslateCompiler {
    abstract compile(value: string, lang: string): InterpolatableTranslation;
    abstract compileTranslations(translations: Translation, lang: string): InterpolatableTranslationObject;
}
/**
 * This compiler is just a placeholder that does nothing, in case you don't need a compiler at all
 */
declare class TranslateFakeCompiler extends TranslateCompiler {
    compile(value: string, lang: string): string | InterpolateFunction;
    compileTranslations(translations: InterpolatableTranslationObject, lang: string): InterpolatableTranslationObject;
    static ɵfac: i0.ɵɵFactoryDeclaration<TranslateFakeCompiler, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TranslateFakeCompiler>;
}

type DeepReadonly<T> = {
    readonly [K in keyof T]: T[K] extends object ? DeepReadonly<T[K]> : T[K];
};
declare class TranslateStore {
    private _onTranslationChange;
    private _onLangChange;
    private _onDefaultLangChange;
    private _defaultLang;
    private _currentLang;
    private _translations;
    private _languages;
    getTranslations(pLanguage: Language): DeepReadonly<InterpolatableTranslationObject>;
    setTranslations(pLanguage: Language, pTranslations: InterpolatableTranslationObject, pExtend: boolean): void;
    getLanguages(): readonly Language[];
    getCurrentLanguage(): Language;
    getDefaultLanguage(): Language;
    /**
     * Changes the default lang
     */
    setDefaultLang(pLang: string, pIsEmitChange?: boolean): void;
    setCurrentLang(pLang: string, pIsEmitChange?: boolean): void;
    /**
     * An Observable to listen to translation change events
     * onTranslationChange.subscribe((params: TranslationChangeEvent) => {
     *     // do something
     * });
     */
    get onTranslationChange(): Observable<TranslationChangeEvent>;
    /**
     * An Observable to listen to lang change events
     * onLangChange.subscribe((params: LangChangeEvent) => {
     *     // do something
     * });
     */
    get onLangChange(): Observable<LangChangeEvent>;
    /**
     * An Observable to listen to default lang change events
     * onDefaultLangChange.subscribe((params: DefaultLangChangeEvent) => {
     *     // do something
     * });
     */
    get onDefaultLangChange(): Observable<DefaultLangChangeEvent>;
    addLanguages(pLanguages: Language[]): void;
    hasTranslationFor(pLang: string): boolean;
    deleteTranslations(pLang: string): void;
    getTranslation(pKey: string, pIsUseDefaultLang: boolean): InterpolatableTranslation;
    protected _getValue(pLanguage: Language, pKey: string): InterpolatableTranslation;
    formatEngin: Function;
    translateServiceChildren: TranslateService[];
    getChildrenNotLoadLang(pLang: string): TranslateService[];
    translateServiceRoot: TranslateService;
}

declare const ISOLATE_TRANSLATE_SERVICE: InjectionToken<string>;
declare const USE_DEFAULT_LANG: InjectionToken<string>;
declare const DEFAULT_LANGUAGE: InjectionToken<string>;
declare const USE_EXTEND: InjectionToken<string>;
type InterpolationParameters = Record<string, any>;
type Translation = string | Translation[] | TranslationObject | any;
interface TranslationObject {
    [key: string]: Translation;
}
type InterpolatableTranslation = string | InterpolatableTranslation[] | InterpolateFunction | InterpolatableTranslationObject | any;
interface InterpolatableTranslationObject {
    [key: string]: InterpolatableTranslation;
}
type Language = string;
interface TranslationChangeEvent {
    translations: InterpolatableTranslationObject;
    lang: string;
}
interface LangChangeEvent {
    lang: string;
    translations: InterpolatableTranslationObject;
}
interface DefaultLangChangeEvent {
    lang: string;
    translations: InterpolatableTranslationObject;
}
declare class TranslateService {
    #private;
    store: TranslateStore;
    currentLoader: TranslateLoader;
    compiler: TranslateCompiler;
    parser: TranslateParser;
    missingTranslationHandler: MissingTranslationHandler;
    private useDefaultLang;
    private extend;
    private _loadingTranslations;
    private _pending;
    private _translationRequests;
    private _lastUseLanguage;
    readonly isRoot: string;
    readonly formatEngine: Function | null;
    private _isLoadedLangCache;
    get isLoadedLangCache(): Map<string, boolean>;
    /**
     * An Observable to listen to translation change events
     * onTranslationChange.subscribe((params: TranslationChangeEvent) => {
     *     // do something
     * });
     */
    get onTranslationChange(): Observable<TranslationChangeEvent>;
    /**
     * An Observable to listen to lang change events
     * onLangChange.subscribe((params: LangChangeEvent) => {
     *     // do something
     * });
     */
    get onLangChange(): Observable<LangChangeEvent>;
    /**
     * An Observable to listen to default lang change events
     * onDefaultLangChange.subscribe((params: DefaultLangChangeEvent) => {
     *     // do something
     * });
     */
    get onDefaultLangChange(): Observable<DefaultLangChangeEvent>;
    /**
     * The default lang to fallback when translations are missing on the current lang
     */
    get defaultLang(): Language;
    /**
     * The lang currently used
     */
    get currentLang(): Language;
    /**
     * an array of langs
     */
    get langs(): readonly Language[];
    /**
     *
     * @param store an instance of the store (that is supposed to be unique)
     * @param currentLoader An instance of the loader currently used
     * @param compiler An instance of the compiler currently used
     * @param parser An instance of the parser currently used
     * @param missingTranslationHandler A handler for missing translations.
     * @param useDefaultLang whether we should use default language translation when current language translation is missing.
     * @param isolate whether this service should use the store or not
     * @param extend To make a child module extend (and use) translations from parent modules.
     * @param defaultLanguage Set the default language using configuration
     */
    constructor(store: TranslateStore, currentLoader: TranslateLoader, compiler: TranslateCompiler, parser: TranslateParser, missingTranslationHandler: MissingTranslationHandler, useDefaultLang: boolean | undefined, isolate: boolean | undefined, extend: boolean | undefined, defaultLanguage: string);
    /**
     * Sets the default language to use as a fallback
     */
    setDefaultLang(pLang: string): Observable<InterpolatableTranslationObject>;
    /**
     * Gets the default language used
     */
    getDefaultLang(): string;
    /**
     * Changes the lang currently used
     * modified by binhnv
     */
    use(pLang: string): Observable<InterpolatableTranslationObject>;
    private loadAndCompileTranslations;
    /**
     * Manually sets an object of translations for a given language
     * after passing it through the compiler
     */
    setTranslation(lang: Language, translations: InterpolatableTranslationObject, shouldMerge?: boolean): void;
    getLangs(): readonly Language[];
    /**
     * Add available languages
     */
    addLangs(languages: Language[]): void;
    private getParsedResultForKey;
    private getTextToInterpolate;
    private runInterpolation;
    private runInterpolationOnArray;
    private runInterpolationOnDict;
    /**
     * Returns the parsed result of the translations
     */
    getParsedResult(key: string | string[], interpolateParams?: InterpolationParameters): Translation | TranslationObject | Observable<Translation | TranslationObject>;
    private getParsedResultForArray;
    /**
     * Gets the translated value of a key (or an array of keys)
     * @returns the translated key, or an object of translated keys
     */
    get(key: string | string[], interpolateParams?: InterpolationParameters): Observable<Translation | TranslationObject>;
    /**
     * Returns a stream of translated values of a key (or an array of keys) which updates
     * whenever the translation changes.
     * @returns A stream of the translated key, or an object of translated keys
     */
    getStreamOnTranslationChange(key: string | string[], interpolateParams?: InterpolationParameters): Observable<Translation | TranslationObject>;
    /**
     * Returns a stream of translated values of a key (or an array of keys) which updates
     * whenever the language changes.
     * @returns A stream of the translated key, or an object of translated keys
     */
    stream(key: string | string[], interpolateParams?: InterpolationParameters): Observable<Translation | TranslationObject>;
    /**
     * Returns a translation instantly from the internal state of loaded translation.
     * All rules regarding the current language, the preferred language of even fallback languages
     * will be used except any promise handling.
     */
    instant(key: string | string[], interpolateParams?: InterpolationParameters): Translation | TranslationObject;
    /**
     * Sets the translated value of a key, after compiling it
     */
    set(key: string, translation: Translation, lang?: Language): void;
    /**
     * Allows to reload the lang file from the file
     */
    reloadLang(lang: string): Observable<InterpolatableTranslationObject>;
    /**
     * Deletes inner translation
     */
    resetLang(lang: string): void;
    /**
     * Returns the language code name from the browser, e.g. "de"
     */
    getBrowserLang(): string | undefined;
    /**
     * Returns the culture language code name from the browser, e.g. "de-DE"
     */
    getBrowserCultureLang(): string | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<TranslateService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TranslateService>;
}

declare abstract class TranslateLoader {
    abstract getTranslation(lang: string): Observable<TranslationObject>;
}
/**
 * This loader is just a placeholder that does nothing, in case you don't need a loader at all
 */
declare class TranslateFakeLoader extends TranslateLoader {
    getTranslation(lang: string): Observable<TranslationObject>;
    static ɵfac: i0.ɵɵFactoryDeclaration<TranslateFakeLoader, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TranslateFakeLoader>;
}

declare class TranslateHttpLoader implements TranslateLoader {
    private http;
    prefix: string;
    suffix: string;
    constructor(http: HttpClient, prefix?: string, suffix?: string);
    /**
     * Gets the translations from the server
     */
    getTranslation(lang: string): Observable<TranslationObject>;
    static ɵfac: i0.ɵɵFactoryDeclaration<TranslateHttpLoader, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TranslateHttpLoader>;
}

interface TranslationResource {
    prefix: string;
    suffix?: string;
    optional?: boolean;
}
declare class MultiTranslateHttpLoader implements TranslateLoader {
    private _handler;
    private _resourcesPrefix;
    constructor(_handler: HttpClient, _resourcesPrefix: (string | TranslationResource)[]);
    getTranslation(lang: string): Observable<any>;
}

interface ExtendedNode extends Text {
    originalContent: string;
    currentValue: Translation;
    lookupKey: string;
    lastKey: string | null;
    data: string;
}
declare class TranslateDirective implements AfterViewChecked, OnDestroy {
    private translateService;
    private element;
    private _ref;
    key: string;
    lastParams?: InterpolationParameters;
    currentParams?: InterpolationParameters;
    onLangChangeSub: Subscription;
    onDefaultLangChangeSub: Subscription;
    onTranslationChangeSub: Subscription;
    set translate(key: string);
    set translateParams(params: InterpolationParameters);
    constructor(translateService: TranslateService, element: ElementRef, _ref: ChangeDetectorRef);
    ngAfterViewChecked(): void;
    checkNodes(forceUpdate?: boolean, translations?: InterpolatableTranslation): void;
    updateValue(key: string, node: ExtendedNode, translations?: InterpolatableTranslation): void;
    getContent(node: ExtendedNode): string;
    setContent(node: ExtendedNode, content: string): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TranslateDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TranslateDirective, "[brTranslate]", never, { "translate": { "alias": "translate"; "required": false; }; "translateParams": { "alias": "translateParams"; "required": false; }; }, {}, never, never, true, never>;
}

declare class TranslatePipe implements PipeTransform, OnDestroy {
    private translate;
    private _ref;
    value: Translation;
    lastKey: string | null;
    lastParams: InterpolationParameters[];
    onTranslationChange: Subscription | undefined;
    onLangChange: Subscription | undefined;
    onDefaultLangChange: Subscription | undefined;
    constructor(translate: TranslateService, _ref: ChangeDetectorRef);
    updateValue(key: string, interpolateParams?: object, translations?: InterpolatableTranslationObject): void;
    transform(query: string, ...args: any[]): any;
    /**
     * Clean any existing subscription to change events
     */
    private _dispose;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TranslatePipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<TranslatePipe, "brTranslate", true>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TranslatePipe>;
}

interface TranslateModuleConfig {
    loader?: Provider;
    compiler?: Provider;
    parser?: Provider;
    missingTranslationHandler?: Provider;
    isolate?: boolean;
    extend?: boolean;
    useDefaultLang?: boolean;
    defaultLanguage?: string;
    formatEngine?: Function;
}
declare const provideTranslateService: (config?: TranslateModuleConfig) => EnvironmentProviders;
declare const provideTranslateServiceChild: (config?: TranslateModuleConfig) => EnvironmentProviders;
declare class TranslateModule {
    /**
     * Use this method in your root module to provide the TranslateService
     */
    static forRoot(config?: TranslateModuleConfig): ModuleWithProviders<TranslateModule>;
    /**
     * Use this method in your other (non-root) modules to import the directive/pipe
     */
    static forChild(config?: TranslateModuleConfig): ModuleWithProviders<TranslateModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<TranslateModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TranslateModule, never, [typeof TranslatePipe, typeof TranslateDirective], [typeof TranslatePipe, typeof TranslateDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TranslateModule>;
}

/**
 * Determines if two objects or two values are equivalent.
 *
 * Two objects or values are considered equivalent if at least one of the following is true:
 *
 * * Both objects or values pass `===` comparison.
 * * Both objects or values are of the same type and all of their properties are equal by
 *   comparing them with `equals`.
 *
 * @param pO1 Object or value to compare.
 * @param pO2 Object or value to compare.
 * @returns true if arguments are equal.
 */
declare function equals(pO1: any, pO2: any): boolean;
declare function isDefinedAndNotNull(pValue: any): boolean;
declare function isDict(pValue: any): boolean;
declare function isObject(pValue: any): boolean;
declare function isArray(pValue: any): boolean;
declare function isString(pValue: any): boolean;
declare function isFunction(pValue: any): boolean;
declare function cloneDeep<T>(pObj: Readonly<T>): T;
declare function mergeDeep(pTarget: Readonly<any>, pSource: any): any;
/**
 * Retrieves a value from a nested object using a dot-separated key path.
 *
 * Example usage:
 * ```ts
 * getValue({ key1: { keyA: 'valueI' }}, 'key1.keyA'); // returns 'valueI'
 * ```
 *
 * @param pTarget The source object from which to retrieve the value.
 * @param pKey Dot-separated key path specifying the value to retrieve.
 * @returns The value at the specified key path, or `undefined` if not found.
 */
declare function getValue(pTarget: any, pKey: string): any;
/**
 * Sets a value on object using a dot separated key.
 * This function modifies the object in place
 * parser.setValue({a:{b:{c: "test"}}}, 'a.b.c', "test2") ==> {a:{b:{c: "test2"}}}
 * @param pTarget an object
 * @param pKey E.g. "a.b.c"
 * @param pValue to set
 * @deprecated use insertValue() instead
 */
declare function setValue(pTarget: any, pKey: string, pValue: any): void;
/**
 * Sets a value on object using a dot separated key.
 * Returns a clone of the object without modifying it
 * parser.setValue({a:{b:{c: "test"}}}, 'a.b.c', "test2") ==> {a:{b:{c: "test2"}}}
 * @param pTarget an object
 * @param pKey E.g. "a.b.c"
 * @param pValue to set
 */
declare function insertValue(pTarget: Readonly<any>, pKey: string, pValue: any): any;
declare const spreadKeyAndArgs: (pVal: string) => {
    key: string;
    arrArgs: unknown[];
};

export { DEFAULT_LANGUAGE, FakeMissingTranslationHandler, ISOLATE_TRANSLATE_SERVICE, MissingTranslationHandler, MultiTranslateHttpLoader, TranslateCompiler, TranslateDefaultParser, TranslateDirective, TranslateFakeCompiler, TranslateFakeLoader, TranslateHttpLoader, TranslateLoader, TranslateModule, TranslateParser, TranslatePipe, TranslateService, TranslateStore, USE_DEFAULT_LANG, USE_EXTEND, _, cloneDeep, equals, getValue, insertValue, isArray, isDefinedAndNotNull, isDict, isFunction, isObject, isString, mergeDeep, provideTranslateService, provideTranslateServiceChild, setValue, spreadKeyAndArgs };
export type { DefaultLangChangeEvent, InterpolatableTranslation, InterpolatableTranslationObject, InterpolateFunction, InterpolationParameters, LangChangeEvent, Language, MissingTranslationHandlerParams, TranslateModuleConfig, Translation, TranslationChangeEvent, TranslationObject, TranslationResource };
